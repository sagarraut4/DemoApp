# LZ.Common

Repository for hosting the Common library targeting .NET

## Overview

This repository has 4 NuGets

1. **LZ.Common.Standard**
   Contains common code to be used in shared libraries in a .net project.

   - Includes `ApiClient` which should be for all HTTP based communication in LZ Ecosystem.
   - `OAuthServiceClient` - Generates the Auth0 based Token
   - `ThreadSafeApiClient` - A more secure and reliable Http Client supports better resource management. This needs additional changes in appsettings.
   - Distributed Caching provider `ICacheProvider`
   - Custom exceptions like `ApiException`
   - Helper classes for password hashing
   - JsonService a custom wrapper for Serialize/Deserialize json capabilities.

   This project should strictly contain items that can be used in various layers in the LZ api project structure. Avoid adding Mvc dependencies here.

2. **LZ.Common.Core**
   Contains base classes, helpers and extension methods for a web api Project.

   - Includes `BaseController`, attributes and filters
   - Extension methods for to setup Api Projects which includes `ControllerExtensions`, `MvcExtensions`, `SwaggerExtensions`
   - Resource based authorization classes

   This project should contain items that are specific to the Service project which includes items required to configure the Service Project.

3. **LZ.Common.Serilog**
   Contains Serilog logging implementation which creates logs based on rolling file.

4. **LZ.Common.Persistence.Mongo**
   Contains code for interacting with MongoDb, hosts configuration, generic repository and db context for interacting with MongoDb.

# Publishing NuGet

The versioning for these NuGets for .net core 3.1 will start from 3.1.0

The versioning for these NuGets for .net core 6 will start from 6.0.0

## Steps to publish

1. Change version in all csproj file to appropriate values. It is recommended to have all the csproj in this repository to have same version.

2. Create a release branch based on the version

3. Once branch is published, it should trigger the jenkins job at [lz.common-multibranch](https://cjm.legalzoom.com/job/lz.common-multibranch/)

4. After build completes, new versions for the NuGet packages should be available in LZ artifactory.

5. Please merge the release branch after NuGet is published and merge it to develop branch.

Nuget with 3.1.x represents .net core 3.1 based nuget package

Nuget with 6.0.x represents .net 6 based nuget package

## Support for older version

Whenever the framework is upgraded for example, from net core 3.1 to net 6, we need to create a support branch for the last version.
This support branch contains the latest code for that version. Going forward, if any changes are to be done, those should be merged in support branch
The support branches to be name like `support/net3.1.x`.

If these changes needs to be for the net6 branch, they should be separately added to develop branch.

PLEASE NOTE - develop branch would contain the latest framework code. Be careful to not mix both frameworks.
