﻿using FluentAssertions;
using LZ.Common.Standard.Helpers;
using Xunit;

namespace Test.LZ.Common.Helpers
{
    public class PersonNameTests
    {
        public PersonNameTests()
        {

        }

        [Theory]
        [InlineData("Louis Anthony Middleton II", "Louis", "Anthony", "Middleton", "II")]
        [InlineData("louis anthony middleton SR.", "Louis", "Anthony", "Middleton", "SR.")]
        [InlineData("McGregor anthony ston middleton II", "McGregor", "Anthony Ston", "Middleton", "II")]
        [InlineData("McGregor MiddleSton II", "McGregor", "", "MiddleSton", "II")]
        public void Verify_PersonName(string name, string firstName, string middleName, string lastName, string suffix)
        {
            PersonName personName = PersonName.ParseName(name);

            personName.Should().NotBeNull();
            personName.FullName.Should().Be(name);
            personName.FirstName.Should().Be(firstName);
            personName.MiddleName.Should().Be(middleName);
            personName.LastName.Should().Be(lastName);
            personName.Suffix.Should().Be(suffix);
        }

        [Fact]
        public void verify_emptyName()
        {
            PersonName personName = PersonName.ParseName(null);
            personName.FirstName.Should().BeNullOrEmpty();
            personName.FullName.Should().BeNullOrEmpty();
            personName.LastName.Should().BeNullOrEmpty();
            personName.MiddleName.Should().BeNullOrEmpty();
            personName.Suffix.Should().BeNullOrEmpty();
        }
    }
}
