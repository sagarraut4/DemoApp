﻿using FluentAssertions;
using LZ.Common.Core.Infrastructure;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Xunit;

namespace Test.LZ.Common.AuthorizationTests
{
    public class JwtAuthorizationMiddlewareTests
    {
        private const string CUSTOMER_ID = "x-lz-customerId";
        private const string AUTHORIZATION = "Authorization";
        private const string SESSION_ID = "x-lz-sessionid";
        private const string DEFAULT_ROLE_CLAIM = "user";
        private const string CC_USER_ROLE_CLAIM = "cc_user";
        private const string LOGGEDINUSER_ROLE_CLAIM = "loggedInUser";
        private const string ATTORNEY_ROLE_CLAIM = "attorney";
        private const string FIRM_ADMIN_ROLE_CLAIM = "firm_admin";
        private const string AUTHENTICATED_USER_TYPE = "AuthenticatedUser";
        private const string JWT_BEARER_USER_TYPE = "JwtBearerToken";
        private const string AUTHORIZE_FLAG = "x-lz-authorize";
        private const string APIKEY = "x-lz-api-key";

        protected static IConfigurationRoot _configuration;

        public JwtAuthorizationMiddlewareTests()
        {
            string basePath = AppContext.BaseDirectory;
            _configuration = GetIConfigurationRoot(basePath);
        }

        public static IConfigurationRoot GetIConfigurationRoot(string outputPath)
        {
            return new ConfigurationBuilder()
                .SetBasePath(outputPath)
                .AddJsonFile("appsettings.json", optional: true)
                .Build();
        }

        [Fact]
        public async Task ShouldNotAddCustomerIdClaimsWhenNoTokenPresent()
        {
            // Arrange
            HttpContext defaultContext = new DefaultHttpContext()
            {
                User = null
            };

            RequestDelegate next = (HttpContext context) => Task.CompletedTask;
            var authMiddleware = new JwtAuthorizationMiddleware(next, _configuration);

            // Act
            await authMiddleware.Invoke(defaultContext).ConfigureAwait(false);

            // Assert
            defaultContext.User.Identity.Should().NotBeNull();
            defaultContext.User.Claims.Count().Should().Be(1);
            var claims = defaultContext.User.Claims.ToList();
            claims.Where(c => c.Type == ClaimTypes.NameIdentifier).FirstOrDefault().Should().BeNull();
            claims.Where(c => c.Type == ClaimsIdentity.DefaultRoleClaimType).FirstOrDefault().Should().BeNull();
        }

        [Fact]
        public async Task ShouldPopulateClaimsWhenOAuthAndSessionIdPresent()
        {
            // Arrange
            string customerId = "13490958";
            HttpContext defaultContext = new DefaultHttpContext()
            {
                User = null
            };
            defaultContext.Request.Headers[AUTHORIZATION] = "Bearer fvqz5jG7yneCRCCd8yONADRpCYeb";
            defaultContext.Request.Headers[CUSTOMER_ID] = customerId;
            defaultContext.Request.Headers[SESSION_ID] = "m1N7ClDDdxgH08XPOUUIYA=="; //encrypted timestring for cust id - 13490958

            RequestDelegate next = (HttpContext context) => Task.CompletedTask;
            var authMiddleware = new JwtAuthorizationMiddleware(next, _configuration);

            // Act
            await authMiddleware.Invoke(defaultContext).ConfigureAwait(false);

            // Assert
            defaultContext.User.Identity.Should().NotBeNull();
            defaultContext.User.Claims.Should().NotBeNull();
            defaultContext.User.Identity.AuthenticationType.Should().Be(AUTHENTICATED_USER_TYPE);
            var claims = defaultContext.User.Claims.ToList();
            claims.Where(c => c.Type == ClaimTypes.NameIdentifier).FirstOrDefault().Value.Should().Be(customerId);
            claims.Where(c => c.Type == ClaimsIdentity.DefaultRoleClaimType).FirstOrDefault().Value.Should().Be(DEFAULT_ROLE_CLAIM);
        }

        [Fact]
        public async Task ShouldPopulateClaimsForOAuthToken()
        {
            // Arrange
            string customerId = "13490958";
            HttpContext defaultContext = new DefaultHttpContext()
            {
                User = null
            };
            defaultContext.Request.Headers[AUTHORIZATION] = "Bearer fvqz5jG7yneCRCCd8yONADRpCYeb";
            defaultContext.Request.Headers[CUSTOMER_ID] = customerId;

            RequestDelegate next = (HttpContext context) => Task.CompletedTask;
            var authMiddleware = new JwtAuthorizationMiddleware(next, _configuration);

            // Act
            await authMiddleware.Invoke(defaultContext).ConfigureAwait(false);

            // Assert
            defaultContext.User.Identity.Should().NotBeNull();
            defaultContext.User.Claims.Should().NotBeNull();
            defaultContext.User.Identity.AuthenticationType.Should().Be(AUTHENTICATED_USER_TYPE);
            var claims = defaultContext.User.Claims.ToList();
            claims.Where(c => c.Type == ClaimTypes.NameIdentifier).FirstOrDefault().Value.Should().Be(customerId);
            claims.Where(c => c.Type == ClaimsIdentity.DefaultRoleClaimType).FirstOrDefault().Value.Should().Be(DEFAULT_ROLE_CLAIM);
        }

        [Theory]
        [InlineData("true")]
        [InlineData(null)]
        [InlineData("")]
        public async Task ShouldPopulateAuthorizeClaimAsTrueForOAuthToken(string authorizeHeader)
        {
            // Arrange
            HttpContext defaultContext = new DefaultHttpContext()
            {
                User = null
            };
            defaultContext.Request.Headers[AUTHORIZATION] = "Bearer fvqz5jG7yneCRCCd8yONADRpCYeb";
            defaultContext.Request.Headers[AUTHORIZE_FLAG] = authorizeHeader;

            RequestDelegate next = (HttpContext context) => Task.CompletedTask;
            var authMiddleware = new JwtAuthorizationMiddleware(next, _configuration);

            // Act
            await authMiddleware.Invoke(defaultContext).ConfigureAwait(false);

            // Assert
            defaultContext.User.Identity.Should().NotBeNull();
            defaultContext.User.Claims.Should().NotBeNull();
            defaultContext.User.Identity.AuthenticationType.Should().Be(AUTHENTICATED_USER_TYPE);
            var claims = defaultContext.User.Claims.ToList();
            claims.Where(c => c.Type == ClaimTypes.AuthorizationDecision).FirstOrDefault().Value.Should().Be(bool.TrueString);
            claims.Where(c => c.Type == ClaimsIdentity.DefaultRoleClaimType).FirstOrDefault().Should().BeNull();
        }

        [Fact]
        public async Task ShouldPopulateCCUserClaimForOAuthTokenUserWithAuthorizeFalse()
        {
            // Arrange
            HttpContext defaultContext = new DefaultHttpContext()
            {
                User = null
            };
            defaultContext.Request.Headers[AUTHORIZATION] = "Bearer fvqz5jG7yneCRCCd8yONADRpCYeb";
            defaultContext.Request.Headers[AUTHORIZE_FLAG] = "false";

            RequestDelegate next = (HttpContext context) => Task.CompletedTask;
            var authMiddleware = new JwtAuthorizationMiddleware(next, _configuration);

            // Act
            await authMiddleware.Invoke(defaultContext).ConfigureAwait(false);

            // Assert
            defaultContext.User.Identity.Should().NotBeNull();
            defaultContext.User.Claims.Should().NotBeNull();
            defaultContext.User.Identity.AuthenticationType.Should().Be(AUTHENTICATED_USER_TYPE);
            var claims = defaultContext.User.Claims.ToList();
            claims.Exists(c => c.Type == ClaimTypes.AuthorizationDecision && c.Value == bool.FalseString).Should().BeTrue();
            claims.Where(c => c.Type == ClaimsIdentity.DefaultRoleClaimType).FirstOrDefault().Value.Should().Be(CC_USER_ROLE_CLAIM);
        }

        [Fact]
        public async Task ShouldPopulateClaimsWhenJWTCustomerIdAndSessionIdPresent()
        {
            // Arrange
            string customerId = "13490958";
            var contextUser = new ClaimsPrincipal(new ClaimsIdentity(new Claim[]
            {
                new Claim(_configuration["Jwt:CustomerIdClaimType"], customerId),
                new Claim(_configuration["Jwt:RoleClaimType"], FIRM_ADMIN_ROLE_CLAIM),
                new Claim(_configuration["Jwt:RoleClaimType"], ATTORNEY_ROLE_CLAIM)
            }));
            HttpContext defaultContext = new DefaultHttpContext()
            {
                User = contextUser
            };
            defaultContext.Request.Headers[AUTHORIZATION] = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ik5UWkJNRVZHUVVVNE9UYzBOREl3TjBaR1JrSTNRVVU1TkRZd016WXpNVVEwTTBaR01qbENRdyJ9.eyJodHRwczovL3d3dy5sZWdhbHpvb20uY29tL3JvbGVzIjpbImF0dG9ybmV5IiwiZmlybV9hZG1pbiJdLCJodHRwczovL3d3dy5sZWdhbHpvb20uY29tL2FwaWtleSI6Ijl6TkdOVEhITHluOWk1QWNhOENpeVRwS0U2c0lWRVo2IiwiaHR0cHM6Ly93d3cubGVnYWx6b29tLmNvbS91c2VyTmFtZSI6Im5laWx3c2llZ2VsQGdtYWlsLmNvbS5kZXYiLCJodHRwczovL3d3dy5sZWdhbHpvb20uY29tL2ludGVybmFsX2lkIjoiOTU5NDI0NDItYjc3OC00YmIwLWI2NzgtMTBlMjc1NzhiNzY0IiwiaHR0cHM6Ly93d3cubGVnYWx6b29tLmNvbS9ncm91cHMiOlsiY2Q0NjEzMDItMWQ0Ny00YjMzLThlMmEtOWRmNTExMGJmZjJmIl0sImlzcyI6Imh0dHBzOi8vZGV2LWxlZ2Fsem9vbS5hdXRoMC5jb20vIiwic3ViIjoiYXV0aDB8NWRiYzczNmRiNDMwZjIwZTI1Zjc4YTgxIiwiYXVkIjpbInVybjphcGlnZWU6dGFyZ2V0OmFwaSIsImh0dHBzOi8vZGV2LWxlZ2Fsem9vbS5hdXRoMC5jb20vdXNlcmluZm8iXSwiaWF0IjoxNTk4NDMzODcyLCJleHAiOjE1OTg0Mzc0NzIsImF6cCI6IlI5dGNUc2k2QUVRdXQxNXJjUERKNEp6aUtJU2Q2UEFDIiwic2NvcGUiOiJvcGVuaWQgcHJvZmlsZSBlbWFpbCBvZmZsaW5lX2FjY2VzcyJ9.oBzU2c9ycaxFDZjZNsNnIlzQYw94L2vWFRjMfoB2PfX0xv2QPIxDgbSBnA9X-7IAQwvg4GJpjeFOTTCKpRTivBSCJnmU50WiEffeCIs557tQ3tsZjxTlYGbzA8qHRaPfhO3vnw590hk5mnE84dJXOobk2vsH0uQUWvywaJV37_0fYXfy7EUeWiOrjPgs4AYp6iGZSjAAMxr-0oKVj3DL-x1pT8KTPHyexuATliA4S9dKdvikr5WeW2QuZPdVRIoDCJSh-UGGGw5j6cQPUtNEDEhltwUD2O-O8JCA_oFStNYdFyIXIcEfO_eR2q2k5zzr1VWQdHywjI9cbDM_gA0w2Q";
            defaultContext.Request.Headers[CUSTOMER_ID] = customerId;
            defaultContext.Request.Headers[SESSION_ID] = "m1N7ClDDdxgH08XPOUUIYA=="; //encrypted timestring for cust id - 13490958

            RequestDelegate next = (HttpContext context) => Task.CompletedTask;
            var authMiddleware = new JwtAuthorizationMiddleware(next, _configuration);

            // Act
            await authMiddleware.Invoke(defaultContext).ConfigureAwait(false);

            // Assert
            defaultContext.User.Identity.Should().NotBeNull();
            defaultContext.User.Claims.Should().NotBeNull();
            defaultContext.User.Identity.AuthenticationType.Should().Be(JWT_BEARER_USER_TYPE);
            var claims = defaultContext.User.Claims.ToList();
            claims.Where(c => c.Type == ClaimTypes.NameIdentifier).FirstOrDefault().Value.Should().Be(customerId);
            claims.Exists(c => c.Type == _configuration["Jwt:RoleClaimType"] && c.Value == DEFAULT_ROLE_CLAIM).Should().BeTrue();
            claims.Exists(c => c.Type == _configuration["Jwt:RoleClaimType"] && c.Value == LOGGEDINUSER_ROLE_CLAIM).Should().BeTrue();
            claims.Exists(c => c.Type == _configuration["Jwt:RoleClaimType"] && c.Value == FIRM_ADMIN_ROLE_CLAIM).Should().BeTrue();
            claims.Exists(c => c.Type == _configuration["Jwt:RoleClaimType"] && c.Value == ATTORNEY_ROLE_CLAIM).Should().BeTrue();
        }

        [Fact]
        public async Task ShouldPopulateClaimsForJwtCustomerRole()
        {
            // Arrange
            string customerId = "13490958";
            var contextUser = new ClaimsPrincipal(new ClaimsIdentity(new Claim[]
            {
                new Claim(_configuration["Jwt:CustomerIdClaimType"], customerId)
            }));
            HttpContext defaultContext = new DefaultHttpContext()
            {
                User = contextUser
            };
            defaultContext.Request.Headers[AUTHORIZATION] = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ik5UWkJNRVZHUVVVNE9UYzBOREl3TjBaR1JrSTNRVVU1TkRZd016WXpNVVEwTTBaR01qbENRdyJ9.eyJodHRwczovL3d3dy5sZWdhbHpvb20uY29tL3JvbGVzIjpbImF0dG9ybmV5IiwiZmlybV9hZG1pbiJdLCJodHRwczovL3d3dy5sZWdhbHpvb20uY29tL2FwaWtleSI6Ijl6TkdOVEhITHluOWk1QWNhOENpeVRwS0U2c0lWRVo2IiwiaHR0cHM6Ly93d3cubGVnYWx6b29tLmNvbS91c2VyTmFtZSI6Im5laWx3c2llZ2VsQGdtYWlsLmNvbS5kZXYiLCJodHRwczovL3d3dy5sZWdhbHpvb20uY29tL2ludGVybmFsX2lkIjoiOTU5NDI0NDItYjc3OC00YmIwLWI2NzgtMTBlMjc1NzhiNzY0IiwiaHR0cHM6Ly93d3cubGVnYWx6b29tLmNvbS9ncm91cHMiOlsiY2Q0NjEzMDItMWQ0Ny00YjMzLThlMmEtOWRmNTExMGJmZjJmIl0sImlzcyI6Imh0dHBzOi8vZGV2LWxlZ2Fsem9vbS5hdXRoMC5jb20vIiwic3ViIjoiYXV0aDB8NWRiYzczNmRiNDMwZjIwZTI1Zjc4YTgxIiwiYXVkIjpbInVybjphcGlnZWU6dGFyZ2V0OmFwaSIsImh0dHBzOi8vZGV2LWxlZ2Fsem9vbS5hdXRoMC5jb20vdXNlcmluZm8iXSwiaWF0IjoxNTk4NDMzODcyLCJleHAiOjE1OTg0Mzc0NzIsImF6cCI6IlI5dGNUc2k2QUVRdXQxNXJjUERKNEp6aUtJU2Q2UEFDIiwic2NvcGUiOiJvcGVuaWQgcHJvZmlsZSBlbWFpbCBvZmZsaW5lX2FjY2VzcyJ9.oBzU2c9ycaxFDZjZNsNnIlzQYw94L2vWFRjMfoB2PfX0xv2QPIxDgbSBnA9X-7IAQwvg4GJpjeFOTTCKpRTivBSCJnmU50WiEffeCIs557tQ3tsZjxTlYGbzA8qHRaPfhO3vnw590hk5mnE84dJXOobk2vsH0uQUWvywaJV37_0fYXfy7EUeWiOrjPgs4AYp6iGZSjAAMxr-0oKVj3DL-x1pT8KTPHyexuATliA4S9dKdvikr5WeW2QuZPdVRIoDCJSh-UGGGw5j6cQPUtNEDEhltwUD2O-O8JCA_oFStNYdFyIXIcEfO_eR2q2k5zzr1VWQdHywjI9cbDM_gA0w2Q";

            RequestDelegate next = (HttpContext context) => Task.CompletedTask;
            var authMiddleware = new JwtAuthorizationMiddleware(next, _configuration);

            // Act
            await authMiddleware.Invoke(defaultContext).ConfigureAwait(false);

            // Assert
            defaultContext.User.Identity.Should().NotBeNull();
            defaultContext.User.Claims.Should().NotBeNull();
            defaultContext.User.Identity.AuthenticationType.Should().Be(JWT_BEARER_USER_TYPE);
            var claims = defaultContext.User.Claims.ToList();
            claims.Exists(c => c.Type == ClaimTypes.NameIdentifier && c.Value == customerId).Should().BeTrue();
            claims.Exists(c => c.Type == _configuration["Jwt:RoleClaimType"] && c.Value == DEFAULT_ROLE_CLAIM).Should().BeTrue();
            claims.Exists(c => c.Type == _configuration["Jwt:RoleClaimType"] && c.Value == LOGGEDINUSER_ROLE_CLAIM).Should().BeTrue();
        }

        [Fact]
        public async Task ShouldPopulateCCUserRoleForJwtBasedUserWithAuthorizeFalse()
        {
            // Arrange
            var contextUser = new ClaimsPrincipal(new ClaimsIdentity());
            HttpContext defaultContext = new DefaultHttpContext()
            {
                User = contextUser
            };
            defaultContext.Request.Headers[AUTHORIZATION] = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ik5UWkJNRVZHUVVVNE9UYzBOREl3TjBaR1JrSTNRVVU1TkRZd016WXpNVVEwTTBaR01qbENRdyJ9.eyJodHRwczovL3d3dy5sZWdhbHpvb20uY29tL3JvbGVzIjpbImF0dG9ybmV5IiwiZmlybV9hZG1pbiJdLCJodHRwczovL3d3dy5sZWdhbHpvb20uY29tL2FwaWtleSI6Ijl6TkdOVEhITHluOWk1QWNhOENpeVRwS0U2c0lWRVo2IiwiaHR0cHM6Ly93d3cubGVnYWx6b29tLmNvbS91c2VyTmFtZSI6Im5laWx3c2llZ2VsQGdtYWlsLmNvbS5kZXYiLCJodHRwczovL3d3dy5sZWdhbHpvb20uY29tL2ludGVybmFsX2lkIjoiOTU5NDI0NDItYjc3OC00YmIwLWI2NzgtMTBlMjc1NzhiNzY0IiwiaHR0cHM6Ly93d3cubGVnYWx6b29tLmNvbS9ncm91cHMiOlsiY2Q0NjEzMDItMWQ0Ny00YjMzLThlMmEtOWRmNTExMGJmZjJmIl0sImlzcyI6Imh0dHBzOi8vZGV2LWxlZ2Fsem9vbS5hdXRoMC5jb20vIiwic3ViIjoiYXV0aDB8NWRiYzczNmRiNDMwZjIwZTI1Zjc4YTgxIiwiYXVkIjpbInVybjphcGlnZWU6dGFyZ2V0OmFwaSIsImh0dHBzOi8vZGV2LWxlZ2Fsem9vbS5hdXRoMC5jb20vdXNlcmluZm8iXSwiaWF0IjoxNTk4NDMzODcyLCJleHAiOjE1OTg0Mzc0NzIsImF6cCI6IlI5dGNUc2k2QUVRdXQxNXJjUERKNEp6aUtJU2Q2UEFDIiwic2NvcGUiOiJvcGVuaWQgcHJvZmlsZSBlbWFpbCBvZmZsaW5lX2FjY2VzcyJ9.oBzU2c9ycaxFDZjZNsNnIlzQYw94L2vWFRjMfoB2PfX0xv2QPIxDgbSBnA9X-7IAQwvg4GJpjeFOTTCKpRTivBSCJnmU50WiEffeCIs557tQ3tsZjxTlYGbzA8qHRaPfhO3vnw590hk5mnE84dJXOobk2vsH0uQUWvywaJV37_0fYXfy7EUeWiOrjPgs4AYp6iGZSjAAMxr-0oKVj3DL-x1pT8KTPHyexuATliA4S9dKdvikr5WeW2QuZPdVRIoDCJSh-UGGGw5j6cQPUtNEDEhltwUD2O-O8JCA_oFStNYdFyIXIcEfO_eR2q2k5zzr1VWQdHywjI9cbDM_gA0w2Q";
            defaultContext.Request.Headers[APIKEY] = "xyz";
            defaultContext.Request.Headers[AUTHORIZE_FLAG] = "false";

            RequestDelegate next = (HttpContext context) => Task.CompletedTask;
            var authMiddleware = new JwtAuthorizationMiddleware(next, _configuration);

            // Act
            await authMiddleware.Invoke(defaultContext).ConfigureAwait(false);

            // Assert
            defaultContext.User.Identity.Should().NotBeNull();
            defaultContext.User.Claims.Should().NotBeNull();
            defaultContext.User.Identity.AuthenticationType.Should().Be(JWT_BEARER_USER_TYPE);
            var claims = defaultContext.User.Claims.ToList();
            claims.Exists(c => c.Type == ClaimTypes.AuthorizationDecision && c.Value == bool.FalseString).Should().BeTrue();
            claims.Exists(c => c.Type == _configuration["Jwt:RoleClaimType"] && c.Value == CC_USER_ROLE_CLAIM).Should().BeTrue();
        }

        [Fact]
        public async Task ShouldPopulateClaimsForJwtOtherRoles()
        {
            // Arrange
            var contextUser = new ClaimsPrincipal(new ClaimsIdentity(new Claim[]
            {
                new Claim(_configuration["Jwt:RoleClaimType"], FIRM_ADMIN_ROLE_CLAIM),
                new Claim(_configuration["Jwt:RoleClaimType"], ATTORNEY_ROLE_CLAIM)
            }));
            HttpContext defaultContext = new DefaultHttpContext()
            {
                User = contextUser
            };
            defaultContext.Request.Headers[AUTHORIZATION] = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ik5UWkJNRVZHUVVVNE9UYzBOREl3TjBaR1JrSTNRVVU1TkRZd016WXpNVVEwTTBaR01qbENRdyJ9.eyJodHRwczovL3d3dy5sZWdhbHpvb20uY29tL3JvbGVzIjpbImF0dG9ybmV5IiwiZmlybV9hZG1pbiJdLCJodHRwczovL3d3dy5sZWdhbHpvb20uY29tL2FwaWtleSI6Ijl6TkdOVEhITHluOWk1QWNhOENpeVRwS0U2c0lWRVo2IiwiaHR0cHM6Ly93d3cubGVnYWx6b29tLmNvbS91c2VyTmFtZSI6Im5laWx3c2llZ2VsQGdtYWlsLmNvbS5kZXYiLCJodHRwczovL3d3dy5sZWdhbHpvb20uY29tL2ludGVybmFsX2lkIjoiOTU5NDI0NDItYjc3OC00YmIwLWI2NzgtMTBlMjc1NzhiNzY0IiwiaHR0cHM6Ly93d3cubGVnYWx6b29tLmNvbS9ncm91cHMiOlsiY2Q0NjEzMDItMWQ0Ny00YjMzLThlMmEtOWRmNTExMGJmZjJmIl0sImlzcyI6Imh0dHBzOi8vZGV2LWxlZ2Fsem9vbS5hdXRoMC5jb20vIiwic3ViIjoiYXV0aDB8NWRiYzczNmRiNDMwZjIwZTI1Zjc4YTgxIiwiYXVkIjpbInVybjphcGlnZWU6dGFyZ2V0OmFwaSIsImh0dHBzOi8vZGV2LWxlZ2Fsem9vbS5hdXRoMC5jb20vdXNlcmluZm8iXSwiaWF0IjoxNTk4NDMzODcyLCJleHAiOjE1OTg0Mzc0NzIsImF6cCI6IlI5dGNUc2k2QUVRdXQxNXJjUERKNEp6aUtJU2Q2UEFDIiwic2NvcGUiOiJvcGVuaWQgcHJvZmlsZSBlbWFpbCBvZmZsaW5lX2FjY2VzcyJ9.oBzU2c9ycaxFDZjZNsNnIlzQYw94L2vWFRjMfoB2PfX0xv2QPIxDgbSBnA9X-7IAQwvg4GJpjeFOTTCKpRTivBSCJnmU50WiEffeCIs557tQ3tsZjxTlYGbzA8qHRaPfhO3vnw590hk5mnE84dJXOobk2vsH0uQUWvywaJV37_0fYXfy7EUeWiOrjPgs4AYp6iGZSjAAMxr-0oKVj3DL-x1pT8KTPHyexuATliA4S9dKdvikr5WeW2QuZPdVRIoDCJSh-UGGGw5j6cQPUtNEDEhltwUD2O-O8JCA_oFStNYdFyIXIcEfO_eR2q2k5zzr1VWQdHywjI9cbDM_gA0w2Q";

            RequestDelegate next = (HttpContext context) => Task.CompletedTask;
            var authMiddleware = new JwtAuthorizationMiddleware(next, _configuration);

            // Act
            await authMiddleware.Invoke(defaultContext).ConfigureAwait(false);

            // Assert
            defaultContext.User.Identity.Should().NotBeNull();
            defaultContext.User.Claims.Should().NotBeNull();
            defaultContext.User.Identity.AuthenticationType.Should().Be(JWT_BEARER_USER_TYPE);
            var claims = defaultContext.User.Claims.ToList();
            claims.Exists(c => c.Type == ClaimTypes.NameIdentifier).Should().BeFalse();
            claims.Exists(c => c.Type == _configuration["Jwt:RoleClaimType"] && c.Value == DEFAULT_ROLE_CLAIM).Should().BeFalse();
            claims.Exists(c => c.Type == _configuration["Jwt:RoleClaimType"] && c.Value == LOGGEDINUSER_ROLE_CLAIM).Should().BeFalse();
            claims.Exists(c => c.Type == _configuration["Jwt:RoleClaimType"] && c.Value == FIRM_ADMIN_ROLE_CLAIM).Should().BeTrue();
            claims.Exists(c => c.Type == _configuration["Jwt:RoleClaimType"] && c.Value == ATTORNEY_ROLE_CLAIM).Should().BeTrue();
        }

        [Fact]
        public async Task ShouldPopulateClaimsWhenApiKeyAndAuthorizeIsFalse()
        {
            // Arrange
            HttpContext defaultContext = new DefaultHttpContext()
            {
                User = null
            };
            defaultContext.Request.Headers[APIKEY] = "xyz";
            defaultContext.Request.Headers[AUTHORIZE_FLAG] = "false";

            RequestDelegate next = (HttpContext context) => Task.CompletedTask;
            var authMiddleware = new JwtAuthorizationMiddleware(next, _configuration);

            // Act
            await authMiddleware.Invoke(defaultContext).ConfigureAwait(false);

            // Assert
            defaultContext.User.Identity.Should().NotBeNull();
            var claims = defaultContext.User.Claims.ToList();
            claims.Count.Should().BeGreaterThan(0);
            defaultContext.User.Identity.AuthenticationType.Should().Be(AUTHENTICATED_USER_TYPE);
            claims.Exists(c => c.Type == ClaimTypes.AuthorizationDecision && c.Value == bool.FalseString)
                .Should().BeTrue();
            claims.Exists(c => c.Type == ClaimsIdentity.DefaultRoleClaimType && c.Value == CC_USER_ROLE_CLAIM)
                .Should().BeTrue();
        }

        [Theory]
        [InlineData("true")]
        [InlineData(null)]
        [InlineData("")]
        public async Task ShouldPopulateAuthorizeClaimAsTrueForJwtToken(string authorizeHeader)
        {
            // Arrange
            HttpContext defaultContext = new DefaultHttpContext()
            {
                User = null
            };
            defaultContext.Request.Headers[APIKEY] = "xyz";
            defaultContext.Request.Headers[AUTHORIZE_FLAG] = authorizeHeader;

            RequestDelegate next = (HttpContext context) => Task.CompletedTask;
            var authMiddleware = new JwtAuthorizationMiddleware(next, _configuration);

            // Act
            await authMiddleware.Invoke(defaultContext).ConfigureAwait(false);

            // Assert
            defaultContext.User.Identity.Should().NotBeNull();
            var claims = defaultContext.User.Claims.ToList();
            claims.Count.Should().BeGreaterThan(0);
            defaultContext.User.Identity.AuthenticationType.Should().Be(AUTHENTICATED_USER_TYPE);
            claims.Exists(c => c.Type == ClaimTypes.AuthorizationDecision && c.Value == bool.TrueString)
                .Should().BeTrue();
        }

        [Fact]
        public async Task ShouldRemoveExistingNameIdentifierClaimForJwtUser()
        {
            // Arrange
            string customerId = "13490958";
            var contextUser = new ClaimsPrincipal(new ClaimsIdentity(new Claim[]
            {
                new Claim(ClaimTypes.NameIdentifier, $"auth0|{customerId}"),
                new Claim(_configuration["Jwt:CustomerIdClaimType"], customerId)
            }));
            HttpContext defaultContext = new DefaultHttpContext()
            {
                User = contextUser
            };
            defaultContext.Request.Headers[AUTHORIZATION] = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ik5UWkJNRVZHUVVVNE9UYzBOREl3TjBaR1JrSTNRVVU1TkRZd016WXpNVVEwTTBaR01qbENRdyJ9.eyJodHRwczovL3d3dy5sZWdhbHpvb20uY29tL2N1c3RvbWVySWQiOjEzNDkwOTU4LCJodHRwczovL3d3dy5sZWdhbHpvb20uY29tL3VzZXJOYW1lIjoicnVwYWxpXzI1b2N0XzFAbHouY29tIiwiaHR0cHM6Ly93d3cubGVnYWx6b29tLmNvbS9hcGlrZXkiOiJ3bnFXV1dneVhxbHc4Q243V2E4NnJTTHBsOWNWY09keiIsImlzcyI6Imh0dHBzOi8vZGV2LWxlZ2Fsem9vbS5hdXRoMC5jb20vIiwic3ViIjoiYXV0aDB8MTM0OTA5NTgiLCJhdWQiOlsidXJuOmFwaWdlZTp0YXJnZXQ6YXBpIiwiaHR0cHM6Ly9kZXYtbGVnYWx6b29tLmF1dGgwLmNvbS91c2VyaW5mbyJdLCJpYXQiOjE2MDE5MDIyOTEsImV4cCI6MTYwMTkwNTg5MSwiYXpwIjoieHdkVEFaMXBvaGwxU0VKQ2MySXd6ZUJPa1didG9SSmEiLCJzY29wZSI6Im9wZW5pZCBwcm9maWxlIGVtYWlsIGFkZHJlc3MgcGhvbmUgb2ZmbGluZV9hY2Nlc3MiLCJndHkiOiJwYXNzd29yZCJ9.skmbAQo-5qOiSjjbpyUHGr8G0xa8ctaq6glllIgCCo6sdhMp2v--xxH5zDqb6zjaTXNjpVuLGh7te4xAW1I90WgJNsRnWLoaeIHkQVW9b8INtn0g8YJ1nMb_2-QjqTmc9x8vXc4TQG_1JQIzwdQ-m1g0H_N-9vcceszVQe8LDaGWIayydQFun6WZsCmdtfxJDYzeCdHHD-Alax4C5ngpRcBSyjFMa6PDYLTA9LtZCRSM12YpqNgqDDVy4VH4nNJc7HqycVoLiRX8WywBzLV-SZigNf1ZoUxRyALD77GvqUrhyjVYGv2eNayvbwaHWBblg-9m_XS2LK6i6s8I-UMaJA";

            RequestDelegate next = (HttpContext context) => Task.CompletedTask;
            var authMiddleware = new JwtAuthorizationMiddleware(next, _configuration);

            // Act
            await authMiddleware.Invoke(defaultContext).ConfigureAwait(false);

            // Assert
            defaultContext.User.Identity.Should().NotBeNull();
            defaultContext.User.Claims.Should().NotBeNull();
            defaultContext.User.Identity.AuthenticationType.Should().Be(JWT_BEARER_USER_TYPE);
            var claims = defaultContext.User.Claims.ToList();
            claims.Exists(c => c.Type == _configuration["Jwt:RoleClaimType"] && c.Value == DEFAULT_ROLE_CLAIM).Should().BeTrue();
            claims.Exists(c => c.Type == _configuration["Jwt:RoleClaimType"] && c.Value == LOGGEDINUSER_ROLE_CLAIM).Should().BeTrue();
            claims.Exists(c => c.Type == ClaimTypes.NameIdentifier && c.Value == customerId).Should().BeTrue();
        }
    }
}
