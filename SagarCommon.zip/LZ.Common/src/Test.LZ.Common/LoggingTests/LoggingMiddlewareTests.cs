using System;
using System.Threading.Tasks;
using FluentAssertions;
using LZ.Common.Core.Infrastructure;
using LZ.Common.Logging;
using LZ.Common.Logging.Serilog;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Xunit;

namespace Test.LZ.Common.LoggingTests
{
    public class LoggingMiddlewareTests
    {
        private static readonly IConfigurationRoot _configuration = new ConfigurationBuilder()
            .SetBasePath(AppContext.BaseDirectory)
            .AddJsonFile("appsettings.json", optional: true)
            .Build();

        private static readonly ILoggingService _loggingService = new SerilogLoggingService(_configuration);

        [Fact]
        public async Task ShouldAddContextIdAndCorrelationId()
        {
            // Arrange
            HttpContext defaultContext = new DefaultHttpContext();
            Task Next(HttpContext context) => Task.CompletedTask;
            var loggingMiddleware = new LoggingMiddleware(Next);

            // Act
            await loggingMiddleware.Invoke(defaultContext, _loggingService).ConfigureAwait(false);

            // Assert
            defaultContext.Response.StatusCode.Should().Be(200);
            defaultContext.Request.Headers["x-lz-contextId"].ToString().Should().NotBeEmpty();
            defaultContext.Request.Headers["x-lz-correlationId"].ToString().Should().NotBeEmpty();
        }
    }
}
