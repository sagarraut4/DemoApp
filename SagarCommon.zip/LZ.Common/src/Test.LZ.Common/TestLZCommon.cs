using LZ.Common.Core.Infrastructure;
using Xunit;

namespace Test.LZ.Common
{
    public class TestLZCommon
    {
        [Fact]
        public void TestRequestTracker()
        {
            RequestTracker req = new RequestTracker();
            Assert.NotNull(req.MachineName);
            Assert.True(req.MachineName.Length <= 4);
        }
    }
}