﻿using FluentAssertions;
using LZ.Common.Standard;
using LZ.Common.Standard.Json;
using Microsoft.AspNetCore.Http;
using NSubstitute;
using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Xunit;

namespace Test.LZ.Common.ApiClients
{
    /// <summary>
    ///
    /// </summary>
    public class ThreadSafeApiClientTests
    {
        private const string _url = "http://test.com";

        public ThreadSafeApiClientTests()
        {
        }

        [Fact]
        public async Task GetReturnsCorrectCodes()
        {
            //Arrange
            TestJson testJson = new TestJson { Test1 = "test1", Test2 = 123456789 };
            var values = Enum.GetValues(typeof(HttpStatusCode));
            foreach (HttpStatusCode code in values)
            {
                var accessor = Substitute.For<IHttpContextAccessor>();
                var messageHandler = new MockHttpMessageHandler(JsonService.SerializeObject(testJson), code);
                var httpClient = new HttpClient(messageHandler)
                {
                    BaseAddress = new Uri(_url)
                };

                var threadSafeApiClient = new ThreadSafeApiClient(httpClient, accessor, _url, string.Empty);

                //Act
                if((int)code >= 300 || (int)code < 200)
                {
                    var result = await Assert.ThrowsAsync<ApiException>(() => threadSafeApiClient.GetJsonAsync<TestJson>(string.Empty, null, null, null)).ConfigureAwait(false);

                    //Assert
                    result.Should().NotBeNull("Must contain a result");
                    result.Should().BeOfType<ApiException>();
                    result.StatusCode.Should().Be(code);
                }
                else
                {
                    var result = await threadSafeApiClient.GetJsonAsync<TestJson>(string.Empty, null, null, null).ConfigureAwait(false);

                    //Assert
                    result.Should().NotBeNull("Must contain a result");
                    result.Test1.Should().Be(testJson.Test1);
                    result.Test2.Should().Be(testJson.Test2);

                }
                
            }
        }

        [Fact]
        public async Task PutReturnsCorrectCodes()
        {
            //Arrange
            TestJson testJson = new TestJson { Test1 = "test1", Test2 = 123456789 };
            var values = Enum.GetValues(typeof(HttpStatusCode));
            foreach (HttpStatusCode code in values)
            {
                var accessor = Substitute.For<IHttpContextAccessor>();
                var messageHandler = new MockHttpMessageHandler(JsonService.SerializeObject(testJson), code);
                var httpClient = new HttpClient(messageHandler)
                {
                    BaseAddress = new Uri(_url)
                };

                var threadSafeApiClient = new ThreadSafeApiClient(httpClient, accessor, _url, string.Empty);

                //Act
                if ((int)code >= 300 || (int)code < 200)
                {
                    var result = await Assert.ThrowsAsync<ApiException>(() => threadSafeApiClient.PutJsonAsync<TestJson, string>(string.Empty, null, null, null)).ConfigureAwait(false);

                    //Assert
                    result.Should().NotBeNull("Must contain a result");
                    result.Should().BeOfType<ApiException>();
                    result.StatusCode.Should().Be(code);
                }
                else
                {
                    var result = await threadSafeApiClient.PutJsonAsync<TestJson, string>(string.Empty, null, null, null).ConfigureAwait(false);

                    //Assert
                    result.Should().NotBeNull("Must contain a result");
                    result.Test1.Should().Be(testJson.Test1);
                    result.Test2.Should().Be(testJson.Test2);

                }

            }
        }

        [Fact]
        public async Task PostReturnsCorrectCodes()
        {
            //Arrange
            TestJson testJson = new TestJson { Test1 = "test1", Test2 = 123456789 };
            var values = Enum.GetValues(typeof(HttpStatusCode));
            foreach (HttpStatusCode code in values)
            {
                var accessor = Substitute.For<IHttpContextAccessor>();
                var messageHandler = new MockHttpMessageHandler(JsonService.SerializeObject(testJson), code);
                var httpClient = new HttpClient(messageHandler)
                {
                    BaseAddress = new Uri(_url)
                };

                var threadSafeApiClient = new ThreadSafeApiClient(httpClient, accessor, _url, string.Empty);

                //Act
                if ((int)code >= 300 || (int)code < 200)
                {
                    var result = await Assert.ThrowsAsync<ApiException>(() => threadSafeApiClient.PostJsonAsync<TestJson, string>(string.Empty, null, null, null)).ConfigureAwait(false);

                    //Assert
                    result.Should().NotBeNull("Must contain a result");
                    result.Should().BeOfType<ApiException>();
                    result.StatusCode.Should().Be(code);
                }
                else
                {
                    var result = await threadSafeApiClient.PostJsonAsync<TestJson, string>(string.Empty, null, null, null).ConfigureAwait(false);

                    //Assert
                    result.Should().NotBeNull("Must contain a result");
                    result.Test1.Should().Be(testJson.Test1);
                    result.Test2.Should().Be(testJson.Test2);

                }

            }
        }
    }

    class TestJson
    {
        public string Test1 { get; set; }
        public int Test2 { get; set; }
    }
}