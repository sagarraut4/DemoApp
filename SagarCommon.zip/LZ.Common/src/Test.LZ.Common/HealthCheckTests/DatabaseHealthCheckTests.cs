﻿using FluentAssertions;
using LZ.Common.Logging.Serilog;
using LZ.Common.Core.Infrastructure;
using LZ.Common.Standard.Json;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using Xunit;
using LZ.Common.Logging;

namespace Test.LZ.Common.HealthCheckTests
{
    public class DatabaseHealthCheckTests
    {
        protected static ILoggingService _loggingService;
        protected static IConfigurationRoot _configuration;

        public DatabaseHealthCheckTests()
        {
            InitAsIntegrationTest();
        }

        private void InitAsIntegrationTest()
        {
            string basePath = AppContext.BaseDirectory;
            _configuration = GetIConfigurationRoot(basePath);
            _loggingService = new SerilogLoggingService(_configuration);

        }

        public static IConfigurationRoot GetIConfigurationRoot(string outputPath)
        {
            return new ConfigurationBuilder()
                .SetBasePath(outputPath)
                .AddJsonFile("appsettings.json", optional: true)
                .Build();
        }

        [Fact]
        public async System.Threading.Tasks.Task ShouldReturnSuccessHealthFromConfiguration()
        {
            // Arrange
            var handler = new DbHealthHandler(_configuration, _loggingService);

            // Act
            DbHealth result = await handler.CheckDbHealth().ConfigureAwait(false);

            var stream = JsonService.SerializeObject(result);

            // Assert
            DbHealthStatusEnum status = (DbHealthStatusEnum)Enum.Parse(typeof(DbHealthStatusEnum), result.overallDatabaseStatus);

            status.Should().Be(DbHealthStatusEnum.DbHealthSuccess);
            result.Should().NotBeNull();
            result.DatabaseConnections.Count.Should().Be(3);
            result.DatabaseConnections[0].connectionStatus.Should().Be(DbHealthStatusEnum.OpenConnectionSuccess.ToString());
            result.DatabaseConnections[1].connectionStatus.Should().Be(DbHealthStatusEnum.OpenConnectionSuccess.ToString());
            result.DatabaseConnections[2].connectionStatus.Should().Be(DbHealthStatusEnum.OpenConnectionSuccess.ToString());
        }


        [Fact]
        public async System.Threading.Tasks.Task ShouldReturnSuccessFromOptions_SingleSQL_DB()
        {
            // Arrange
            var handler = new DbHealthHandler(_configuration, _loggingService);
            var databaseList = new List<DbHealthCheckOption>()
            {
                new DbHealthCheckOption()
                {
                    Commands = null,
                    Conn = "Server=d-ladyday-xxx-001.legalzoom.com;Database=LZData;Trusted_Connection=False;User ID=LZWebUser; Password=c@l14n1a; MultipleActiveResultSets=true;",
                    Type = DatabaseType.SQL
                }
            };

            // Act
            DbHealth result = await handler.CheckDbHealth(databaseList).ConfigureAwait(false);

            // Assert
            DbHealthStatusEnum status = (DbHealthStatusEnum)Enum.Parse(typeof(DbHealthStatusEnum), result.overallDatabaseStatus);

            status.Should().Be(DbHealthStatusEnum.DbHealthSuccess);
            result.Should().NotBeNull();
            result.DatabaseConnections.Count.Should().Be(1);
            result.DatabaseConnections[0].connectionStatus.Should().Be(DbHealthStatusEnum.OpenConnectionSuccess.ToString());
        }

        [Fact]
        public async System.Threading.Tasks.Task ShouldReturnSuccessFromOptions_SingleSQL_Type_Not_Specified()
        {
            // Arrange
            var handler = new DbHealthHandler(_configuration, _loggingService);
            var databaseList = new List<DbHealthCheckOption>()
            {
                new DbHealthCheckOption()
                {
                    Commands = null,
                    Conn = "Server=d-ladyday-xxx-001.legalzoom.com;Database=LZData;Trusted_Connection=False;User ID=LZWebUser; Password=c@l14n1a; MultipleActiveResultSets=true;",
                }
            };

            // Act
            DbHealth result = await handler.CheckDbHealth(databaseList).ConfigureAwait(false);

            // Assert
            DbHealthStatusEnum status = (DbHealthStatusEnum)Enum.Parse(typeof(DbHealthStatusEnum), result.overallDatabaseStatus);

            status.Should().Be(DbHealthStatusEnum.DbHealthSuccess);
            result.Should().NotBeNull();
            result.DatabaseConnections.Count.Should().Be(1);
            result.DatabaseConnections[0].connectionStatus.Should().Be(DbHealthStatusEnum.OpenConnectionSuccess.ToString());
        }

        [Fact]
        public async System.Threading.Tasks.Task ShouldReturnSuccessFromOptions_SingleMongo_DB()
        {
            // Arrange
            // "mongodb://advisorDomainUser:Leqa!Zoom101@laimgodb004q.legalzoom.com:27017,laimgodb005q.legalzoom.com:27017,adrmgodb006q.legalzoom.com:27017/advisorDB?replicaSet=rsqa1&w=majority",
            // advisorDomainUser:Lega!Zoom101@laimgodb002d:27017/advisorDB
            var handler = new DbHealthHandler(_configuration, _loggingService);
            var databaseList = new List<DbHealthCheckOption>()
            {
                new DbHealthCheckOption()
                {
                    Commands = null,
                    Conn = "mongodb://advisorDomainUser:Lega!Zoom101@laimgodb002d:27017/advisorDB",
                    Type = DatabaseType.Mongo,
                    Name = "advisorDB"
                }
            };

            // Act
            DbHealth result = await handler.CheckDbHealth(databaseList).ConfigureAwait(false);

            // Assert
            DbHealthStatusEnum status = (DbHealthStatusEnum)Enum.Parse(typeof(DbHealthStatusEnum), result.overallDatabaseStatus);

            status.Should().Be(DbHealthStatusEnum.DbHealthSuccess);
            result.Should().NotBeNull();
            result.DatabaseConnections.Count.Should().Be(1);
            result.DatabaseConnections[0].connectionStatus.Should().Be(DbHealthStatusEnum.OpenConnectionSuccess.ToString());
        }

        [Fact]
        public async System.Threading.Tasks.Task ShouldFailFromOptions_SingleMongo_Invalid_Connection()
        {
            // Arrange
            var handler = new DbHealthHandler(_configuration, _loggingService);
            var databaseList = new List<DbHealthCheckOption>()
            {
                new DbHealthCheckOption()
                {
                    Commands = null,
                    Conn = "mongodb://advisorDomainUser:Lega!Zoom101@laimgodb002d:27017/advisor",
                    Type = DatabaseType.Mongo,
                    Name = "advisorDB"
                }
            };

            // Act
            DbHealth result = await handler.CheckDbHealth(databaseList).ConfigureAwait(false);

            // Assert
            DbHealthStatusEnum status = (DbHealthStatusEnum)Enum.Parse(typeof(DbHealthStatusEnum), result.overallDatabaseStatus);

            status.Should().Be(DbHealthStatusEnum.DbHealthFailure);
            result.Should().NotBeNull();
            result.DatabaseConnections.Count.Should().Be(1);
            result.DatabaseConnections[0].connectionStatus.Should().Be(DbHealthStatusEnum.OpenConnectionFailure.ToString());
        }

        [Fact]
        public async System.Threading.Tasks.Task ShouldReturnSuccessFromOptions_MultipleDB()
        {
            // Arrange
            var handler = new DbHealthHandler(_configuration, _loggingService);
            var databaseList = new List<DbHealthCheckOption>()
            {
                new DbHealthCheckOption()
                {
                    Commands = null,
                    Conn = "Server=d-ladyday-xxx-001.legalzoom.com;Database=LZData;Trusted_Connection=False;User ID=LZWebUser; Password=c@l14n1a; MultipleActiveResultSets=true;",
                    Type = DatabaseType.SQL,
                    Name = "LZData"
                },
                new DbHealthCheckOption()
                {
                    Commands = null,
                    Conn = "mongodb://advisorDomainUser:Lega!Zoom101@laimgodb002d:27017/advisorDB",
                    Type = DatabaseType.Mongo,
                    Name = "advisorDB"
                }
            };

            // Act
            DbHealth result = await handler.CheckDbHealth(databaseList).ConfigureAwait(false);

            // Assert
            DbHealthStatusEnum status = (DbHealthStatusEnum)Enum.Parse(typeof(DbHealthStatusEnum), result.overallDatabaseStatus);

            status.Should().Be(DbHealthStatusEnum.DbHealthSuccess);
            result.Should().NotBeNull();
            result.DatabaseConnections.Count.Should().Be(3);
            result.DatabaseConnections[0].connectionStatus.Should().Be(DbHealthStatusEnum.OpenConnectionSuccess.ToString());
            result.DatabaseConnections[1].connectionStatus.Should().Be(DbHealthStatusEnum.OpenConnectionSuccess.ToString());
            result.DatabaseConnections[2].connectionStatus.Should().Be(DbHealthStatusEnum.OpenConnectionSuccess.ToString());
        }

        [Fact(Skip = "Postgres databases are in AWS and cannot be reached directly, need to use a local database for test.")]
        public async System.Threading.Tasks.Task ShouldReturnSuccessFromOptions_SinglePostgres_DB()
        {
            // Arrange
            var handler = new DbHealthHandler(_configuration, _loggingService);
            var databaseList = new List<DbHealthCheckOption>()
            {
                new DbHealthCheckOption()
                {
                    Commands = null,
                    Conn = "Host=localhost;Database=postgres;Username=postgres;Password=postgres",
                    Type = DatabaseType.Postgres
                }
            };

            // Act
            var result = await handler.CheckDbHealth(databaseList).ConfigureAwait(false);

            // Assert
            var status = Enum.Parse<DbHealthStatusEnum>(result.overallDatabaseStatus);

            status.Should().Be(DbHealthStatusEnum.DbHealthSuccess);
            result.Should().NotBeNull();
            result.DatabaseConnections.Count.Should().Be(1);
            result.DatabaseConnections[0].connectionStatus.Should().Be(DbHealthStatusEnum.OpenConnectionSuccess.ToString());
        }

        [Fact]
        public async System.Threading.Tasks.Task ShouldFailFromOptions_SinglePostgres_Invalid_Connection()
        {
            // Arrange
            var handler = new DbHealthHandler(_configuration, _loggingService);
            var databaseList = new List<DbHealthCheckOption>()
            {
                new DbHealthCheckOption()
                {
                    Commands = null,
                    Conn = "Host=invalid;Database=invalid;Username=invalid;Password=invalid",
                    Type = DatabaseType.Postgres
                }
            };

            // Act
            var result = await handler.CheckDbHealth(databaseList).ConfigureAwait(false);

            // Assert
            var status = Enum.Parse<DbHealthStatusEnum>(result.overallDatabaseStatus);

            status.Should().Be(DbHealthStatusEnum.DbHealthFailure);
            result.Should().NotBeNull();
            result.DatabaseConnections.Count.Should().Be(1);
            result.DatabaseConnections[0].connectionStatus.Should().Be(DbHealthStatusEnum.OpenConnectionFailure.ToString());
        }

        [Fact]
        public async System.Threading.Tasks.Task ShouldNotFailWhenDatabaseListIsEmpty()
        {
            // Arrange
            var handler = new DbHealthHandler(_configuration, _loggingService);
            var databaseList = new List<DbHealthCheckOption>();

            // Act
            var result = await handler.CheckDbHealth(databaseList).ConfigureAwait(false);

            // Assert
            var status = Enum.Parse<DbHealthStatusEnum>(result.overallDatabaseStatus);

            status.Should().Be(DbHealthStatusEnum.None);
            result.Should().NotBeNull();
            result.DatabaseConnections.Count.Should().Be(0);
        }
    }
}
