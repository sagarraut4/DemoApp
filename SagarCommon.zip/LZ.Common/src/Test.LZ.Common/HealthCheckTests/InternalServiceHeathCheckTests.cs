﻿using FluentAssertions;
using LZ.Common.Core.Infrastructure;
using LZ.Common.Logging;
using LZ.Common.Standard;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using Xunit;

namespace Test.LZ.Common
{
    /// <summary>
    ///
    /// </summary>
    public class InternalServiceHeathCheckTests
    {
        private const string orderServiceapiName = "OrderService";

        public InternalServiceHeathCheckTests()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddHttpClient();

            httpClientFactory = serviceCollection.BuildServiceProvider().GetService<IHttpClientFactory>();
        }

        private IHttpClientFactory httpClientFactory { get; }

        private string AppConfigPath(string apiName) => Path.Combine(Directory.GetCurrentDirectory(), $"appsettings.{apiName}.json");

        private IConfigurationRoot GetConfiguration(string apiName)
        {
            var builder = new ConfigurationBuilder()
                        .SetBasePath(Directory.GetCurrentDirectory())
                        .AddJsonFile($"appsettings.{apiName}.json", true, true);
            return builder.Build();
        }

        [Theory]
        [InlineData("api-order-service", "OrderService", 9)]
        public async Task InternalServiceHealthCheckSuccess(string apiSolutionName, string apiName, int numberOfInternalServices)
        {
            await GetJsonString(apiSolutionName, apiName).ConfigureAwait(false);
            var configuration = GetConfiguration(apiName);
            var logger = NSubstitute.Substitute.For<ILoggingService>();
            var apiClient = NSubstitute.Substitute.For<IApiClient>();
            var handler = new InternalServiceHealthHandler(configuration, logger, apiClient);
            var response = await handler.CheckInternalServiceHealth().ConfigureAwait(false);

            response.Should().NotBeNull();
            response.Services.Count.Should().Be(numberOfInternalServices);

            foreach (var service in response.Services)
            {
                service.ServiceStatus.Should().NotBeNull();
                service.ServiceStatus[0].ErrorMessage.Should().BeNullOrEmpty();
            }
        }

        [Theory]
        [InlineData("https://apidev-internal.legalzoom.com:8443/v1/customers/{0}/contacts/?type={1}", "https://apidev-internal.legalzoom.com:8443/v1/customers")]
        [InlineData("https://apidev-internal.legalzoom.com:8443/V2/customers/{0}/contacts/?type={1}", "https://apidev-internal.legalzoom.com:8443/v2/customers")]
        [InlineData("https://apidev-internal.legalzoom.com:8443/v3/customers/{0}/contacts/?type={1}", "https://apidev-internal.legalzoom.com:8443/v3/customers")]
        [InlineData("https://apidev-internal.legalzoom.com:8443/V4/customers/{0}/contacts/?type={1}", "https://apidev-internal.legalzoom.com:8443/v4/customers")]
        [InlineData("https://apidev-internal.legalzoom.com:8443/v10/customers/{0}/contacts/?type={1}", "https://apidev-internal.legalzoom.com:8443/v10/customers")]
        [InlineData("https://apidev-internal.legalzoom.com:8443/V100/customers/{0}/contacts/?type={1}", "https://apidev-internal.legalzoom.com:8443/v100/customers")]
        [InlineData("https://api.legalzoom.com:8443/V100/customers/{0}/contacts/?type={1}", "https://api.legalzoom.com:8443/v100/customers")]
        [InlineData("https://apiqa.legalzoom.com:8444/V100/customers/{0}/contacts/?type={1}", "https://apiqa.legalzoom.com:8444/v100/customers")]
        [InlineData("https://apidev-internal.legalzoom.com:8443/v1/core/processing-orders/processing-orders-queue/", "https://apidev-internal.legalzoom.com:8443/v1/core/processing-orders")]
        public void CanGetBaseUrlFromEndpointUrl(string url, string expected)
        {
            var configuration = GetConfiguration(orderServiceapiName);
            var logger = NSubstitute.Substitute.For<ILoggingService>();
            var apiClient = NSubstitute.Substitute.For<IApiClient>();
            var handler = new InternalServiceHealthHandler(configuration, logger, apiClient);
            var baseUrl = handler.GetBaseUrl(url);
            baseUrl.Should().Be(expected);
        }

        private async Task GetJsonString(string apiSolutionName, string apiName)
        {
            var appSettingPath = AppConfigPath(apiName);
            if (!File.Exists(appSettingPath))
            {
                var path = $"https://github.legalzoom.com/engineering/{apiSolutionName}/develop/src/{apiName}/appsettings.json";
                var uri = new Uri(path);
                var api = new ApiClient(null, null, httpClientFactory, null, null, null);
                var response = await api.GetJsonAsync<object>(uri, 30).ConfigureAwait(false);

                File.WriteAllText(appSettingPath, response.ToString());
            }
        }
    }
}
