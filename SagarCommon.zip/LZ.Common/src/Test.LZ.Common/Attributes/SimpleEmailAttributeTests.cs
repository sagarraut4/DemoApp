﻿using LZ.Common.Standard.Attributes;
using System.ComponentModel.DataAnnotations;
using Xunit;

namespace Test.LZ.Common.Attributes
{
    [Trait("Unit Tests", "AttributesTest")]
    public class SimpleEmailAttributeTests
    {
        private readonly SimpleEmailAttribute _simpleEmailAttribute;
        public SimpleEmailAttributeTests()
        {
            _simpleEmailAttribute = new SimpleEmailAttribute();
        }

        [Theory]
        [InlineData("someemail@emailprovider.com")]
        [InlineData("some-1email@email.com")]
        [InlineData("some-1-email@email-provider.com")]
        [InlineData("some-1-email@email-provider.org")]
        [InlineData("some-1-email@email-12.lz")]
        [InlineData("some-1123@email-provider.lz")]
        public void SimpleEmailValid(string fieldName)
        {
            //Arrange
            var validationContext = new ValidationContext(fieldName);

            //Act & Assert
            _simpleEmailAttribute.Validate(fieldName, validationContext);
        }

        [Theory]
        [InlineData("someemail@legalzoom.com@")]
        public void SimpleEmailInValid(string fieldName)
        {
            //Arrange
            var validationContext = new ValidationContext(fieldName);

            //Act & Assert
            Assert.Throws<ValidationException>(() => _simpleEmailAttribute.Validate(fieldName, validationContext));
        }
    }
}
