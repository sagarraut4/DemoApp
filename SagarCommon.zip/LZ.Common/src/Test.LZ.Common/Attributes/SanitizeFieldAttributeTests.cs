﻿using LZ.Common.Standard.Attributes;
using System.ComponentModel.DataAnnotations;
using Xunit;

namespace Test.LZ.Common.Attributes
{
    [Trait("Unit Tests", "AttributesTest")]
    public class SanitizeFieldAttributeTests
    {
        private readonly SanitizeFieldAttribute _contactFieldAttribute;
        public SanitizeFieldAttributeTests()
        {
            _contactFieldAttribute = new SanitizeFieldAttribute();
        }

        [Theory]
        [InlineData("valid name")]
        [InlineData("valid name #")]
        [InlineData("12345654?")]
        public void ContactFieldValid(string fieldName)
        {
            //Arrange
            var validationContext = new ValidationContext(fieldName);

            //Act & Assert
            _contactFieldAttribute.Validate(fieldName, validationContext);
        }

        [Theory]
        [InlineData("1321<2331")]
        [InlineData("invalid<name")]
        [InlineData("invalid>name")]
        [InlineData("<invalidname>")]
        [InlineData(">invalidname<")]
        [InlineData("<invalidname")]
        [InlineData("invalidname>")]
        [InlineData("invalidname><")]
        [InlineData("invalidname<>")]
        [InlineData("<>invalidname")]
        public void ContactFieldInValid(string fieldName)
        {
            //Arrange
            var validationContext = new ValidationContext(fieldName);

            //Act & Assert
            Assert.Throws<ValidationException>(() => _contactFieldAttribute.Validate(fieldName, validationContext));
        }
    }
}
