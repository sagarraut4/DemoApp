﻿using LZ.Common.Logging;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;

namespace LZ.Common.Standard.Caching
{
    public class CacheProvider : ICacheProvider
    {
        private readonly IConfiguration _configuration;
        private readonly IDistributedCache _cache;
        private readonly ILogger _logger;

        private const int SLIDING_EXPIRATION_DEFAULT = 60; // default to 1 hour if not configured
        private const int ABSOLUTE_EXPIRATION_DEFAULT = 320; // default to 4 hour if not configured

        public CacheProvider(IConfiguration configuration,
                            IDistributedCache cache,
                            ILoggingService loggingService)
        {
            _logger = loggingService?.GetLogger<CacheProvider>(nameof(CacheProvider));
            _configuration = configuration;
            _cache = cache;
        }

        public async Task<T> GetData<T>(string path, string identifier, Func<Task<T>> GetFromDatabase) where T : class
        {
            var key = $"{_configuration[$"{path}:Key"]}_{identifier}";

            int slidingExpirationInMinutes = SLIDING_EXPIRATION_DEFAULT;
            int absoluteExpirationInMinutes = ABSOLUTE_EXPIRATION_DEFAULT;
            
            int.TryParse(_configuration[$"{path}:SlidingExpiration"], out slidingExpirationInMinutes);
            int.TryParse(_configuration[$"{path}:AbsoluteExpiration"], out absoluteExpirationInMinutes);

            _logger.LogInformation($"Trying to fetch {key} from cache");

            var cacheObj = await _cache.GetObjectAsync<T>(key).ConfigureAwait(false);

            if (cacheObj == null)
            {
                if (GetFromDatabase != null)
                {
                    _logger.LogInformation($"Making call to db as key {key} was not found in cache");
                    cacheObj = await GetFromDatabase().ConfigureAwait(false);

                    if (cacheObj != null)
                    {
                        _logger.LogInformation($"Set result in cache for key {key}");
                        await _cache.SetObjectAsync(cacheObj, key, slidingExpirationInMinutes, absoluteExpirationInMinutes).ConfigureAwait(false);
                        return cacheObj;
                    }
                }
            }

            return cacheObj;
        }

        public async Task ClearCache()
        {
            await _cache.RemoveAllAsync().ConfigureAwait(false);
        }
    }
}
