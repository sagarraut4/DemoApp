﻿using System;
using System.Threading.Tasks;

namespace LZ.Common.Standard.Caching
{
    public interface ICacheProvider
    {
        Task<T> GetData<T>(string path, string identifier, Func<Task<T>> GetFromDatabse) where T : class;

        Task ClearCache();
    }
}