﻿using Microsoft.Extensions.Caching.Distributed;
using System;
using System.Collections.Concurrent;
using System.Threading.Tasks;

namespace LZ.Common.Standard.Caching
{
    public static class DistributedCacheExtensions
    {
        private static readonly ConcurrentDictionary<string, string> CachedKeysDictionary = new ConcurrentDictionary<string, string>();

        public static async Task SetObjectAsync(this IDistributedCache cache, object obj, string cacheKey, int slidingExpirationInMinutes, int absoluteExpirationInMinutes)
        {
            var cacheOptions = new DistributedCacheEntryOptions
            {
                SlidingExpiration = TimeSpan.FromMinutes(slidingExpirationInMinutes),
                AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(absoluteExpirationInMinutes)
            };

            await cache.SetObjectAsync(obj, cacheKey, cacheOptions).ConfigureAwait(false);
        }

        public static async Task SetObjectAsync(this IDistributedCache cache, object obj, string cacheKey, DistributedCacheEntryOptions cacheOptions)
        {
            if (cache == null)
            {
                throw new ArgumentNullException(nameof(cache));
            }

            byte[] arr = DistributedCacheSerializer.SerializeUsingJson(obj);
            await cache.SetAsync(cacheKey, arr, cacheOptions).ConfigureAwait(false);

            //add keys to ConcurrentDictionary to maintain a list
            AddKeysToCacheAsync(cacheKey);
        }

        public static async Task<T> GetObjectAsync<T>(this IDistributedCache cache, string cacheKey)
            where T : class
        {
            if (cache == null)
            {
                throw new ArgumentNullException(nameof(cache));
            }

            var byteArray = await cache.GetAsync(cacheKey).ConfigureAwait(false);

            if (byteArray != null)
            {
                return await DistributedCacheSerializer.DeserializeUsingJson<T>(byteArray).ConfigureAwait(false);
            }
            return null;
        }

        private static void AddKeysToCacheAsync(string keyToCache)
        {
            CachedKeysDictionary.TryAdd(keyToCache, keyToCache);
        }

        public static async Task RemoveAllAsync(this IDistributedCache cache)
        {
            if (cache == null)
            {
                throw new ArgumentNullException(nameof(cache));
            }

            bool removed;
            foreach (var keyValuePair in CachedKeysDictionary)
            {
                removed = CachedKeysDictionary.TryRemove(keyValuePair.Key, out _);
                if (removed)
                {
                    await cache.RemoveAsync(keyValuePair.Key).ConfigureAwait(false);
                }
            }
        }
    }
}