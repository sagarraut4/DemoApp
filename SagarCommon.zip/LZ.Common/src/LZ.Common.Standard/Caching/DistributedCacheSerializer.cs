﻿using LZ.Common.Standard.Json;
using System.Text;
using System.Threading.Tasks;

namespace LZ.Common.Standard.Caching
{
    public static class DistributedCacheSerializer
    {
        public static byte[] SerializeUsingJson(object obj)
        {
            if (obj == null)
            {
                return null;
            }
            string json = JsonService.SerializeObject(obj);

            return Encoding.UTF8.GetBytes(json);
        }

        public static async Task<T> DeserializeUsingJson<T>(byte[] byteArray) where T : class
        {
            if (byteArray == null)
            {
                return null;
            }

            string json = Encoding.UTF8.GetString(byteArray);

            return await Task.Factory.StartNew(() => JsonService.DeserializeObject<T>(json)).ConfigureAwait(false);
        }
    }
}