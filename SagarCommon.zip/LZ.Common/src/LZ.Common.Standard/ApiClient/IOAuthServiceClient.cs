using System.Threading.Tasks;

namespace LZ.Common.Standard
{
    public interface IOAuthServiceClient
    {
        Task<string> GetAccessToken();
    }
}