﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LZ.Common.Standard
{
    public class ApiClientOptions
    {
        public bool UseTokenForAuth { get; set; } = false;
    }

    public interface IApiClient
    {
        void SetHeaders(Dictionary<string, string> headers);

        TResponse Put<TResponse, TRequest>(Uri uri, TRequest data, int? timeOut);

        Task<TResponse> PutAsync<TResponse, TRequest>(Uri uri, TRequest data, int? timeOut);

        Task<TResponse> PutJsonAsync<TResponse, TRequest>(Uri uri, TRequest data, int? timeOut);

        Task<TResponse> PutAsync<TResponse>(Uri uri, int? timeOut);

        Task<TResponse> PutJsonAsync<TResponse>(Uri uri, int? timeOut);

        TResponse Get<TResponse>(Uri uri, int? timeOut);

        Task<TResponse> GetAsync<TResponse>(Uri uri, int? timeOut);

        Task<TResponse> GetJsonAsync<TResponse>(Uri uri, int? timeOut);

        Task<TResponse> DeleteAsync<TResponse>(Uri uri, int? timeOut);

        Task<TResponse> DeleteJsonAsync<TResponse>(Uri uri, int? timeOut);

        TResponse Post<TResponse, TRequest>(Uri uri, TRequest data, int? timeOut);

        Task<TResponse> PostAsync<TResponse, TRequest>(Uri uri, TRequest data, int? timeOut);

        Task<TResponse> PostJsonAsync<TResponse, TRequest>(Uri uri, TRequest data, int? timeOut);

        Task<TResponse> PatchAsync<TResponse, TRequest>(Uri uri, TRequest data, int? timeOut);

        Task<TResponse> PatchJsonAsync<TResponse, TRequest>(Uri uri, TRequest data, int? timeOut);
    }
}