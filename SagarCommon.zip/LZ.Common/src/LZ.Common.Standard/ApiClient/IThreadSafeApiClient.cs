using System.Collections.Generic;
using System.Threading.Tasks;

namespace LZ.Common.Standard
{
    public interface IThreadSafeApiClient
    {



        Task<TResponse> PutJsonAsync<TResponse, TRequest>(string path, TRequest data, Dictionary<string, string> headers, int? timeOut);
        Task<TResponse> PutJsonAsync<TResponse, TRequest>(string path, string query, TRequest data, Dictionary<string, string> headers, int? timeOut);

        Task<TResponse> GetJsonAsync<TResponse>(string path, string query, Dictionary<string, string> headers, int? timeOut);
        
        Task<TResponse> DeleteJsonAsync<TResponse>(string path, Dictionary<string, string> headers, int? timeOut);
        
        Task<TResponse> PostJsonAsync<TResponse, TRequest>(string path, TRequest data, Dictionary<string, string> headers, int? timeOut);
        Task<TResponse> PostJsonAsync<TResponse, TRequest>(string path, string query, TRequest data, Dictionary<string, string> headers, int? timeOut);

    }
}