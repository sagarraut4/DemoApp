﻿using LZ.Common.Logging;
using LZ.Common.Standard.Json;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace LZ.Common.Standard
{
    public class ApiClient : IApiClient
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger _logger;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IOAuthServiceClient _oAuthServiceClient;
        private readonly HttpContext _context;

        private readonly ConcurrentDictionary<string, string> _headers;
        private readonly bool _useTokenForAuth;

        private const string ApiUrl = "Api_Url";
        private const string MediaType = "application/json";

        public ApiClient(IConfiguration configuration,
            ILoggingService loggingService,
            IHttpClientFactory httpClientFactory,
            IHttpContextAccessor httpContextAccessor,
            IOAuthServiceClient oAuthServiceClient = null,
            IOptions<ApiClientOptions> options = null)
        {
            _logger = loggingService?.GetLogger<ApiClient>(nameof(ApiClient));

            _configuration = configuration;
            _httpClientFactory = httpClientFactory;
            _context = httpContextAccessor?.HttpContext;
            _oAuthServiceClient = oAuthServiceClient;

            _headers = new ConcurrentDictionary<string, string>(StringComparer.InvariantCultureIgnoreCase);

            _useTokenForAuth = options?.Value?.UseTokenForAuth ?? false;
        }

        public void SetHeaders(Dictionary<string, string> headers)
        {
            if (headers?.Count > 0)
            {
                foreach (KeyValuePair<string, string> header in headers)
                {
                    _headers.AddOrUpdate(header.Key, header.Value, (k, v) => header.Value);
                }
            }
        }

        public TResponse Put<TResponse, TRequest>(Uri uri, TRequest data, int? timeOut)
        {
            try
            {
                return PutJsonAsync<TResponse, TRequest>(uri, data, timeOut).Result;
            }
            catch (AggregateException aggEx)
            {
                throw aggEx.InnerException;
            }
        }

        public async Task<TResponse> PutAsync<TResponse, TRequest>(Uri uri, TRequest data, int? timeOut)
        {
            return await PutJsonAsync<TResponse, TRequest>(uri, data, timeOut).ConfigureAwait(false);
        }

        public async Task<TResponse> PutJsonAsync<TResponse, TRequest>(Uri uri, TRequest data, int? timeOut)
        {
            var dict = new Dictionary<string, object> { { ApiUrl, uri.AbsoluteUri } };
            var stopwatch = new Stopwatch();
            bool isException = false;
            TResponse responseData = default(TResponse);
            try
            {
                stopwatch.Start();
                StringContent content = null;
                if (data != null)
                {
                    content = new StringContent(JsonService.SerializeObject(data), Encoding.UTF8, MediaType);
                }
                var httpClient = await GetHttpClient(timeOut).ConfigureAwait(false);

                var response = await httpClient.PutAsync(uri, content).ConfigureAwait(false);
                await EnsureSuccessStatusCode(response).ConfigureAwait(false);
                responseData = JsonService.DeserializeObject<TResponse>(await response.Content.ReadAsStringAsync().ConfigureAwait(false));
            }
            catch (Exception)
            {
                isException = true;
                throw;
            }
            finally
            {
                LogMetrics(dict, stopwatch.ElapsedMilliseconds, isException);
                stopwatch.Stop();
            }
            return responseData;
        }

        public async Task<TResponse> PutAsync<TResponse>(Uri uri, int? timeOut)
        {
            return await PutJsonAsync<TResponse>(uri, timeOut).ConfigureAwait(false);
        }

        public async Task<TResponse> PutJsonAsync<TResponse>(Uri uri, int? timeOut)
        {
            var dict = new Dictionary<string, object> { { ApiUrl, uri.AbsoluteUri } };
            var stopwatch = new Stopwatch();
            bool isException = false;
            TResponse responseData = default(TResponse);
            try
            {
                stopwatch.Start();
                var httpClient = await GetHttpClient(timeOut).ConfigureAwait(false);

                var response = await httpClient.PutAsync(uri, null).ConfigureAwait(false);
                await EnsureSuccessStatusCode(response).ConfigureAwait(false);
                responseData = JsonService.DeserializeObject<TResponse>(await response.Content.ReadAsStringAsync().ConfigureAwait(false));
            }
            catch (Exception)
            {
                isException = true;
                throw;
            }
            finally
            {
                LogMetrics(dict, stopwatch.ElapsedMilliseconds, isException);
                stopwatch.Stop();
            }
            return responseData;
        }

        public TResponse Get<TResponse>(Uri uri, int? timeOut)
        {
            try
            {
                return GetJsonAsync<TResponse>(uri, timeOut).Result;
            }
            catch (AggregateException aggEx)
            {
                throw aggEx.InnerException;
            }
        }

        public async Task<TResponse> GetAsync<TResponse>(Uri uri, int? timeOut)
        {
            return await GetJsonAsync<TResponse>(uri, timeOut).ConfigureAwait(false);
        }

        public async Task<TResponse> GetJsonAsync<TResponse>(Uri uri, int? timeOut)
        {
            var dict = new Dictionary<string, object> { { ApiUrl, uri.AbsoluteUri } };
            var stopwatch = new Stopwatch();
            bool isException = false;
            TResponse responseData = default(TResponse);
            try
            {
                var httpClient = await GetHttpClient(timeOut).ConfigureAwait(false);

                stopwatch.Start();

                var response = await httpClient.GetAsync(uri).ConfigureAwait(false);
                await EnsureSuccessStatusCode(response).ConfigureAwait(false);
                responseData = JsonService.DeserializeObject<TResponse>(await response.Content.ReadAsStringAsync().ConfigureAwait(false));
            }
            catch (Exception)
            {
                isException = true;
                throw;
            }
            finally
            {
                LogMetrics(dict, stopwatch.ElapsedMilliseconds, isException);
                stopwatch.Stop();
            }
            return responseData;
        }

        public async Task<TResponse> DeleteAsync<TResponse>(Uri uri, int? timeOut)
        {
            return await DeleteJsonAsync<TResponse>(uri, timeOut).ConfigureAwait(false);
        }

        public async Task<TResponse> DeleteJsonAsync<TResponse>(Uri uri, int? timeOut)
        {
            var dict = new Dictionary<string, object> { { ApiUrl, uri.AbsoluteUri } };
            var stopwatch = new Stopwatch();
            bool isException = false;
            TResponse responseData = default(TResponse);
            try
            {
                var httpClient = await GetHttpClient(timeOut).ConfigureAwait(false);
                stopwatch.Start();

                var response = await httpClient.DeleteAsync(uri).ConfigureAwait(false);
                await EnsureSuccessStatusCode(response).ConfigureAwait(false);
                responseData = JsonService.DeserializeObject<TResponse>(await response.Content.ReadAsStringAsync().ConfigureAwait(false));
            }
            catch (Exception)
            {
                isException = true;
                throw;
            }
            finally
            {
                LogMetrics(dict, stopwatch.ElapsedMilliseconds, isException);
                stopwatch.Stop();
            }
            return responseData;
        }

        public TResponse Post<TResponse, TRequest>(Uri uri, TRequest data, int? timeOut)
        {
            try
            {
                return PostJsonAsync<TResponse, TRequest>(uri, data, timeOut).Result;
            }
            catch (AggregateException aggEx)
            {
                throw aggEx.InnerException;
            }
        }

        public async Task<TResponse> PostAsync<TResponse, TRequest>(Uri uri, TRequest data, int? timeOut)
        {
            return await PostJsonAsync<TResponse, TRequest>(uri, data, timeOut).ConfigureAwait(false);
        }

        public async Task<TResponse> PostJsonAsync<TResponse, TRequest>(Uri uri, TRequest data, int? timeOut)
        {
            var dict = new Dictionary<string, object> { { ApiUrl, uri.AbsoluteUri } };
            var content = new StringContent(JsonService.SerializeObject(data), Encoding.UTF8, MediaType);

            var stopwatch = new Stopwatch();
            bool isException = false;
            TResponse responseData = default(TResponse);
            try
            {
                stopwatch.Start();

                var httpClient = await GetHttpClient(timeOut).ConfigureAwait(false);

                var response = await httpClient.PostAsync(uri, content).ConfigureAwait(false);
                await EnsureSuccessStatusCode(response).ConfigureAwait(false);
                responseData = JsonService.DeserializeObject<TResponse>(await response.Content.ReadAsStringAsync().ConfigureAwait(false));
            }
            catch (Exception)
            {
                isException = true;
                throw;
            }
            finally
            {
                LogMetrics(dict, stopwatch.ElapsedMilliseconds, isException);
                stopwatch.Stop();
            }
            return responseData;
        }

        public async Task<TResponse> PatchAsync<TResponse, TRequest>(Uri uri, TRequest data, int? timeOut)
        {
            return await PatchJsonAsync<TResponse, TRequest>(uri, data, timeOut).ConfigureAwait(false);
        }

        public async Task<TResponse> PatchJsonAsync<TResponse, TRequest>(Uri uri, TRequest data, int? timeOut)
        {
            var dict = new Dictionary<string, object> { { ApiUrl, uri.AbsoluteUri } };
            var stopwatch = new Stopwatch();
            bool isException = false;
            TResponse responseData = default(TResponse);
            try
            {
                stopwatch.Start();
                StringContent content = null;
                if (data != null)
                {
                    content = new StringContent(JsonService.SerializeObject(data), Encoding.UTF8, MediaType);
                }

                var httpClient = await GetHttpClient(timeOut).ConfigureAwait(false);

                var response = await httpClient.PatchAsync(uri, content).ConfigureAwait(false);
                await EnsureSuccessStatusCode(response).ConfigureAwait(false);
                responseData = JsonService.DeserializeObject<TResponse>(await response.Content.ReadAsStringAsync().ConfigureAwait(false));
            }
            catch (Exception)
            {
                isException = true;
                throw;
            }
            finally
            {
                LogMetrics(dict, stopwatch.ElapsedMilliseconds, isException);
                stopwatch.Stop();
            }
            return responseData;
        }

        private void SetHeadersFromContext()
        {
            if (_context != null)
            {
                foreach (var header in _context.Request.Headers)
                {
                    if (header.Key.StartsWith("x-", StringComparison.CurrentCultureIgnoreCase))
                    {
                        _headers.GetOrAdd(header.Key, header.Value);
                    }
                }
            }
        }

        private HttpClient SetHttpClientHeaders(HttpClient client)
        {
            SetHeadersFromContext();
            if (_headers.Count > 0)
            {
                foreach (var header in _headers)
                {
                    client.DefaultRequestHeaders.Add(header.Key, header.Value);
                }
            }
            return client;
        }

        private async Task<HttpClient> GetHttpClient(int? timeOut)
        {
            HttpClient httpClient = _httpClientFactory.CreateClient(nameof(ApiClient));
            httpClient = SetHttpClientHeaders(httpClient);
            if (timeOut.HasValue)
            {
                httpClient.Timeout = new TimeSpan(0, 0, 0, timeOut.Value);
            }
            if (_useTokenForAuth)
            {
                var accessToken = await _oAuthServiceClient.GetAccessToken().ConfigureAwait(false);

                httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {accessToken}");
            }
            return httpClient;
        }

        private void LogMetrics(Dictionary<string, object> dict, long elapsedMilliseconds, bool isException)
        {
            dict.Add("Duration", elapsedMilliseconds);

            _logger?.LogInformation("{@Metrics}", dict);
        }

        protected virtual async Task EnsureSuccessStatusCode(HttpResponseMessage response)
        {
            if (response?.IsSuccessStatusCode ?? false)
            {
                return;
            }

            var content = await response.Content.ReadAsStringAsync().ConfigureAwait(false);

            if (response.Content != null)
                response.Content.Dispose();

            throw new ApiException(response.StatusCode, $"An Api exception has occurred - HttpStatusCode= {(int)response.StatusCode} - {content}");
        }
    }
}
