using LZ.Common.Standard.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace LZ.Common.Standard
{
    public class ThreadSafeApiClient : IThreadSafeApiClient
    {
        private readonly HttpClient _httpClient;
        private readonly string _hostname;
        private readonly int _port;
        private readonly string _protocol;
        private readonly string _apiKey;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private const string MediaType = "application/json";
        private const string ApiKeyHeader = "X-LZ-Api-Key";
        public ThreadSafeApiClient(HttpClient httpClient, IHttpContextAccessor httpContextAccessor, string hostname, string apiKey)
        {
            Uri uri = new Uri(hostname);
            _httpClient = httpClient;
            _hostname = uri.Host;
            _port = uri.Port;
            _protocol = uri.Scheme;
            _httpContextAccessor = httpContextAccessor;
            _apiKey = apiKey;
        }

        private void SetHeadersFromContext(HttpHeaders httpHeaders)
        {
            var context = _httpContextAccessor.HttpContext;
            if (context != null)
            {
                foreach (var header in context.Request.Headers)
                {
                    if (header.Key.StartsWith("x-", StringComparison.CurrentCultureIgnoreCase) && !header.Key.StartsWith(ApiKeyHeader, StringComparison.CurrentCultureIgnoreCase))
                    {
                        httpHeaders.Add(header.Key, header.Value.ToArray());
                    }
                }
            }
        }

        public async Task<TResponse> PutJsonAsync<TResponse, TRequest>(string path, TRequest data, Dictionary<string, string> headers, int? timeOut)
        {
            return await PutJsonAsync<TResponse, TRequest>(path, null, data, headers, timeOut).ConfigureAwait(false);
        }

        public async Task<TResponse> PutJsonAsync<TResponse, TRequest>(string path, string query, TRequest data, Dictionary<string, string> headers, int? timeOut)
        {
            headers ??= new Dictionary<string, string>();
            StringContent content = null;
            UriBuilder uriBuilder = new UriBuilder
            {
                Host = _hostname,
                Path = path,
                Query = query,
                Scheme = _protocol,
                Port = _port
            };
            if (data != null)
            {
                content = new StringContent(JsonService.SerializeObject(data), Encoding.UTF8, MediaType);
                SetHeadersFromContext(content.Headers);
                foreach (KeyValuePair<string, string> header in headers)
                {
                    content.Headers.Add(header.Key, header.Value);
                }
                content.Headers.ContentType = MediaTypeHeaderValue.Parse(MediaType);
                content.Headers.Add(ApiKeyHeader, _apiKey);
            }

            using (content)
            {
                var response = await _httpClient.PutAsync(uriBuilder.Uri, content).ConfigureAwait(false);
                await EnsureSuccessStatusCode(response).ConfigureAwait(false);
                TResponse responseData = JsonService.DeserializeObject<TResponse>(await response.Content.ReadAsStringAsync().ConfigureAwait(false));
                return responseData;
            }
        }

        public async Task<TResponse> GetJsonAsync<TResponse>(string path, string query, Dictionary<string, string> headers, int? timeOut)
        {
            headers ??= new Dictionary<string, string>();
            TResponse responseData = default;
            UriBuilder uriBuilder = new UriBuilder
            {
                Host = _hostname,
                Path = path,
                Query = query,
                Scheme = _protocol,
                Port = _port
            };
            using (HttpRequestMessage httpRequestMessage = new HttpRequestMessage()
            {
                RequestUri = uriBuilder.Uri,
                Method = HttpMethod.Get
            })
            {
                SetHeadersFromContext(httpRequestMessage.Headers);
                foreach (KeyValuePair<string, string> header in headers)
                {
                    httpRequestMessage.Headers.Add(header.Key, header.Value);
                }
                httpRequestMessage.Headers.Add(ApiKeyHeader, _apiKey);
                var response = await _httpClient.SendAsync(httpRequestMessage).ConfigureAwait(false);
                await EnsureSuccessStatusCode(response).ConfigureAwait(false);
                responseData = JsonService.DeserializeObject<TResponse>(await response.Content.ReadAsStringAsync().ConfigureAwait(false));
            }
            return responseData;
        }

        public async Task<TResponse> DeleteJsonAsync<TResponse>(string path, Dictionary<string, string> headers, int? timeOut)
        {
            headers ??= new Dictionary<string, string>();
            TResponse responseData = default;
            UriBuilder uriBuilder = new UriBuilder
            {
                Host = _hostname,
                Path = path,
                Scheme = _protocol,
                Port = _port
            };
            using (HttpRequestMessage httpRequestMessage = new HttpRequestMessage()
            {
                RequestUri = uriBuilder.Uri,
                Method = HttpMethod.Delete
            })
            {
                SetHeadersFromContext(httpRequestMessage.Headers);
                foreach (KeyValuePair<string, string> header in headers)
                {
                    httpRequestMessage.Headers.Add(header.Key, header.Value);
                }
                httpRequestMessage.Headers.Add(ApiKeyHeader, _apiKey);
                var response = await _httpClient.SendAsync(httpRequestMessage).ConfigureAwait(false);
                await EnsureSuccessStatusCode(response).ConfigureAwait(false);
                responseData = JsonService.DeserializeObject<TResponse>(await response.Content.ReadAsStringAsync().ConfigureAwait(false));
            }
            return responseData;
        }

        public async Task<TResponse> PostJsonAsync<TResponse, TRequest>(string path, TRequest data, Dictionary<string, string> headers, int? timeOut)
        {
            return await PostJsonAsync<TResponse, TRequest>(path, null, data, headers, timeOut).ConfigureAwait(false);
        }

        public async Task<TResponse> PostJsonAsync<TResponse, TRequest>(string path, string query, TRequest data, Dictionary<string, string> headers, int? timeOut)
        {
            headers ??= new Dictionary<string, string>();
            TResponse responseData;
            var content = new StringContent(JsonService.SerializeObject(data), Encoding.UTF8, MediaType);
            UriBuilder uriBuilder = new UriBuilder
            {
                Host = _hostname,
                Path = path,
                Query = query,
                Scheme = _protocol,
                Port = _port
            };
            
            using (content)
            {
                SetHeadersFromContext(content.Headers);
                foreach (KeyValuePair<string, string> header in headers)
                {
                    content.Headers.Add(header.Key, header.Value);
                }
                content.Headers.Add(ApiKeyHeader, _apiKey);
                content.Headers.ContentType = MediaTypeHeaderValue.Parse(MediaType);
                var response = await _httpClient.PostAsync(uriBuilder.Uri, content).ConfigureAwait(false);
                await EnsureSuccessStatusCode(response).ConfigureAwait(false);
                responseData = JsonService.DeserializeObject<TResponse>(await response.Content.ReadAsStringAsync().ConfigureAwait(false));
            }
            return responseData;
        }

        protected virtual async Task EnsureSuccessStatusCode(HttpResponseMessage response)
        {
            if (response == null)
            {
                throw new ArgumentNullException(nameof(response));
            }

            if (response.IsSuccessStatusCode)
            {
                return;
            }

            var content = await response.Content.ReadAsStringAsync().ConfigureAwait(false);

            if (response.Content != null)
                response.Content.Dispose();

            throw new ApiException(response.StatusCode, $"An Api exception has occurred - HttpStatusCode= {(int)response.StatusCode} - {content}");
        }
    }
}
