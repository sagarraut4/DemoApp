﻿using Microsoft.Extensions.Configuration;
using System.Collections.Generic;

namespace LZ.Common.Standard
{
    public class ServiceClientBase
    {
        protected IConfiguration Configuration { get; }
        protected IApiClient ApiClient { get; }
        protected IOAuthServiceClient OAuthServiceClient { get; }
        protected int TimeOut { get; set; }

        public ServiceClientBase(IConfiguration configuration, IApiClient apiClient, IOAuthServiceClient oAuthServiceClient = null)
        {
            Configuration = configuration;
            OAuthServiceClient = oAuthServiceClient;

            ApiClient = apiClient;

            TimeOut = 30;
        }

        public void AddAPIKey(string key)
        {
            Dictionary<string, string> apiKeyDictionary = new Dictionary<string, string>();

            string apiKey = Configuration[key];

            if (!string.IsNullOrEmpty(apiKey))
            {
                apiKeyDictionary.Add("X-LZ-Api-Key", apiKey);
            }

            ApiClient.SetHeaders(apiKeyDictionary);
        }
    }
}
