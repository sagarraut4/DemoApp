﻿using Microsoft.Extensions.Configuration;
using System;
using System.Net.Http;

namespace LZ.Common.Standard
{
    public class ThreadSafeServiceClientBase
    {
        protected IConfiguration Configuration { get; }
        protected IThreadSafeApiClient ApiClient { get; set; }
        protected IHttpClientFactory HttpClientFactory { get; }
        protected int TimeOut { get; set; }

        public ThreadSafeServiceClientBase(IConfiguration configuration, IHttpClientFactory httpClientFactory)
        {
            Configuration = configuration;
            HttpClientFactory = httpClientFactory;
            TimeOut = 30;
        }

        protected HttpClient GetHttpClient(int? timeOut)
        {
            HttpClient _httpClient = HttpClientFactory.CreateClient(nameof(IThreadSafeApiClient));

            if (timeOut.HasValue)
            {
                _httpClient.Timeout = new TimeSpan(0, 0, 0, timeOut.Value);
            }
            return _httpClient;
        }
    }
}
