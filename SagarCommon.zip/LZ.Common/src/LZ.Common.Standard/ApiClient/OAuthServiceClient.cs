﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Net.Http;
using System.Threading.Tasks;
using LZ.Common.Logging;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace LZ.Common.Standard
{
    public class OAuthServiceClient : IOAuthServiceClient, IDisposable
    {
        private readonly ILogger _logger;
        private readonly IConfiguration _configuration;
        private readonly IHttpClientFactory _httpClientFactory;
        private int _timeOut;
        private bool disposedValue;
        private readonly IMemoryCache _memoryCache;

        public OAuthServiceClient(IConfiguration configuration, ILoggingService loggingService, IHttpClientFactory httpClientFactory)
        {
            if (configuration is null)
            {
                throw new ArgumentNullException(nameof(configuration));
            }
            _configuration = configuration;
            _logger = loggingService?.GetLogger<OAuthServiceClient>(nameof(OAuthServiceClient));

            if (httpClientFactory is null)
            {
                throw new ArgumentNullException(nameof(httpClientFactory));
            }
            _httpClientFactory = httpClientFactory;

            _memoryCache = new MemoryCache(new MemoryCacheOptions());
        }

        public async Task<string> GetAccessToken()
        {
            try
            {
                var token = _memoryCache.Get<string>("token");
                if (!string.IsNullOrEmpty(token))
                {
                    return token;
                }

                var url = _configuration["ServiceClients:OAuthService:API:GetToken:Url"];
                var dict = new Dictionary<string, object> { { "Api_Url", url } };
                _logger?.LogInformation("{@Metrics}", dict);

                var clientId = _configuration["ServiceClients:OAuthService:ClientId"];
                var clientSecret = _configuration["ServiceClients:OAuthService:ClientSecret"];
                var grantType = string.IsNullOrEmpty(_configuration["ServiceClients:OAuthService:GrantType"])
                                                     ? "client_credentials"
                                                     : _configuration["ServiceClients:OAuthService:GrantType"];
                var expirationTime = _configuration["ServiceClients:OAuthService:ExpirationTime"];
                var audience = _configuration["ServiceClients:OAuthService:Audience"];
                _ = int.TryParse(_configuration["ServiceClients:OAuthService:ConnectionTimeout"], out _timeOut);
                _timeOut = _timeOut > 0 ? _timeOut : 30; //default timeout to 30 seconds if value not specified

                using (var httpClient = _httpClientFactory.CreateClient(nameof(OAuthServiceClient)))
                {
                    httpClient.Timeout = TimeSpan.FromSeconds(_timeOut);

                    FormUrlEncodedContent encodedPayload = GetRequestPayload(clientId, clientSecret, grantType, expirationTime, audience);

                    using (var response = await httpClient.PostAsync(new Uri(url), encodedPayload).ConfigureAwait(false))
                    {
                        await EnsureSuccessStatusCode(response).ConfigureAwait(false);

                        var responseContent = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                        var tokenResponse = JsonConvert.DeserializeObject<OAuthTokenResponse>(responseContent);

                        if (!string.IsNullOrEmpty(tokenResponse.AccessToken))
                        {
                            SetValueInCache(tokenResponse.ExpiresIn, "token", tokenResponse.AccessToken);
                        }
                        else
                        {
                            var message = "Failed to obtain auth0 token";
                            _logger?.LogCritical(message);
                            throw new Exception(message);
                        }

                        return tokenResponse.AccessToken ?? string.Empty;
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        private static FormUrlEncodedContent GetRequestPayload(string clientId, string clientSecret, string grantType, string expirationTime, string audience)
        {
            var payload = new List<KeyValuePair<string, string>>()
            {
                new KeyValuePair<string, string>("grant_type", grantType),
                new KeyValuePair<string, string>("client_id", clientId),
                new KeyValuePair<string, string>("client_secret", clientSecret),
                new KeyValuePair<string, string>("expires_in", $"{Math.Round(Convert.ToDouble(expirationTime, CultureInfo.CurrentCulture))}"),
                new KeyValuePair<string, string>("audience", audience)
            };

            return new FormUrlEncodedContent(payload);
        }

        private void SetValueInCache<T>(string expirationTime, string key, T value)
        {
            _ = int.TryParse(expirationTime, out var expiresIn);

            _memoryCache.Set(key, value, new MemoryCacheEntryOptions
            {
                AbsoluteExpiration = DateTime.Now + TimeSpan.FromSeconds(expiresIn - 300),
                SlidingExpiration = TimeSpan.FromMinutes(10)
            });
        }

        private async Task EnsureSuccessStatusCode(HttpResponseMessage response)
        {
            if (response?.IsSuccessStatusCode ?? false)
            {
                return;
            }

            _logger?.LogError("Error occurred while executing the request");

            var content = await response.Content.ReadAsStringAsync().ConfigureAwait(false);

            if (response.Content != null)
                response.Content.Dispose();

            throw new ApiException(response.StatusCode, $"An Api exception has occurred - HttpStatusCode= {(int)response.StatusCode} - {content}");
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    _memoryCache.Dispose();
                }

                // TODO: free unmanaged resources (unmanaged objects) and override finalizer
                // TODO: set large fields to null
                disposedValue = true;
            }
        }

        // // TODO: override finalizer only if 'Dispose(bool disposing)' has code to free unmanaged resources
        // ~OAuthServiceClient()
        // {
        //     // Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
        //     Dispose(disposing: false);
        // }

        public void Dispose()
        {
            // Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }
    }
}
