﻿using System.ComponentModel.DataAnnotations;

namespace LZ.Common.Standard.Attributes
{
    public class AmountAttribute : RegularExpressionAttribute
    {
        public AmountAttribute() : base(@"^\d+(.\d{1,2})?$")
        {

        }
    }
}
