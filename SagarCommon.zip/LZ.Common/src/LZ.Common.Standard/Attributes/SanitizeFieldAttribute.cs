﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace LZ.Common.Standard.Attributes
{
    public sealed class SanitizeFieldAttribute : ValidationAttribute
    {
        private const string UnacceptableCharacters = "<>";

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (validationContext is null)
            {
                throw new ArgumentNullException(nameof(validationContext));
            }

            if (value != null)
            {
                if (Regex.Matches(((string)value), $"[{UnacceptableCharacters}]").Count > 0)
                {
                    var member = new List<string>
                    {
                        validationContext.MemberName
                    };
                    return new ValidationResult($"Field contains one or more of the following unacceptable characters '{UnacceptableCharacters}'", member);
                }
            }

            return ValidationResult.Success;
        }
    }
}