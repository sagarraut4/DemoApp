﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace LZ.Common.Standard.Attributes
{
    public class AllowedEnumsAttribute : ValidationAttribute
    {
        public object[] AllowedEnums { get; set; }

        public Type EnumType { get; set; }

        public AllowedEnumsAttribute() : base()
        {
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (AllowedEnums.Contains(value))
            {
                return ValidationResult.Success;
            }

            var member = new List<string>();
            member.Add(validationContext.MemberName);
            return new ValidationResult(ErrorMessage, member);
        }
    }
}