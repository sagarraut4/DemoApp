﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace LZ.Common.Standard.Attributes
{
    public sealed class SimpleEmailAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (validationContext is null)
            {
                throw new ArgumentNullException(nameof(validationContext));
            }

            if (value != null)
            {
                string valueAsString = value as string;

                if (string.IsNullOrEmpty(valueAsString))
                {
                    return ValidationResult.Success;
                }

                int atCount = 0;

                foreach (char c in valueAsString)
                {
                    if (c == '@')
                    {
                        atCount++;
                    }
                }

                var valid = (valueAsString != null
                                && atCount == 1
                                && valueAsString[0] != '@'
                                && valueAsString[valueAsString.Length - 1] != '@');

                if (!valid)
                {
                    var member = new List<string>
                    {
                        validationContext.MemberName
                    };

                    return new ValidationResult("Field is not a valid email address", member);
                }
            }

            return ValidationResult.Success;
        }
    }
}