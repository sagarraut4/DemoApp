﻿using LZ.Common.Standard.Logging;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace LZ.Common.Standard.Extensions
{
    public static class DbContextExtensions
    {
        public static void LogSqlStats(this DbContext context, IConfiguration configuration)
        {
            var serviceProvider = context.GetInfrastructure();
            var loggerFactory = serviceProvider.GetService<ILoggerFactory>();
            if (loggerFactory != null)
            {
                loggerFactory.AddProvider(new DbLoggerProvider(configuration));
            }
        }
    }
}