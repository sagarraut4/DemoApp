﻿using Microsoft.EntityFrameworkCore.SqlServer.Storage.Internal;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Linq;

namespace LZ.Common.Standard.Logging
{
    public class DbLoggerProvider : ILoggerProvider
    {
        private IConfiguration _configuration;

        private const string CommandNamespace = "Microsoft.EntityFrameworkCore.Database.Command";

        public DbLoggerProvider(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        private static readonly string[] _whitelist =
        {
            typeof(RelationalCommandBuilderFactory).FullName,
            typeof(SqlServerConnection).FullName,
            CommandNamespace
        };

        public ILogger CreateLogger(string name)
        {
            if (_whitelist.Contains(name))
            {
                return new DbLogger(_configuration);
            }

            return NullLogger.Instance;
        }

        public void Dispose()
        {
        }
    }
}