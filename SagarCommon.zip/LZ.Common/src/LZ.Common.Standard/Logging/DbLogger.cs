﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.IO;

namespace LZ.Common.Standard.Logging
{
    public class DbLogger : ILogger
    {
        private IConfiguration _configuration;
        private static readonly object _fileLockObject = new object();

        public DbLogger(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        //        public void Log(LogLevel logLevel, int eventId, object state, Exception exception, Func<object, Exception, string> formatter)
        public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
        {
            if (IsEnabled(logLevel))
            {
                var message = $"{Environment.NewLine}{DateTime.Now}{Environment.NewLine}{formatter(state, exception)}";
                string fileName = string.Format("{0}_{1}.txt", _configuration["EntityFramework:Logging:pathFormat"], DateTime.Now.ToString("yyyymmdd"));

                try
                {
                    lock (_fileLockObject)
                    {
                        File.AppendAllText(fileName, message);
                    }
                }
                catch (Exception)
                {
                }
            }
        }

        public bool IsEnabled(LogLevel logLevel)
        {
            bool isEnabled = false;
            bool res = bool.TryParse(_configuration["EntityFramework:Logging:logQueryEnabled"], out isEnabled);

            return res ? isEnabled : false;
        }

        public IDisposable BeginScope<TState>(TState state)
        {
            return null;
        }
    }
}