﻿using System.Net;

namespace LZ.Common.Standard.Exceptions
{
    public interface IHaveExceptionMessage
    {
        string Code { get; }
        string DisplayMessage { get; }
        HttpStatusCode StatusCode { get; set; }
    }
}