﻿using System;
using System.Net;

namespace LZ.Common.Standard.Exceptions
{
    public class CustomException : Exception, IHaveExceptionMessage
    {
        public string Code { get; protected set; }
        public string DisplayMessage { get; set; }
        public HttpStatusCode StatusCode { get; set; }
    }
}