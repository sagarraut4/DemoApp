﻿using LZ.Common.Standard.Exceptions;
using System;
using System.Net;

namespace LZ.Common.Standard
{
    public class ApiException : Exception, IHaveExceptionMessage
    {
        public string DisplayMessage { get; }
        public HttpStatusCode StatusCode { get; set; }
        public string Code { get; }

        public ApiException(HttpStatusCode statusCode, string message, Exception innerException)
            : base(message, innerException)
        {
            StatusCode = statusCode;
        }

        public ApiException(HttpStatusCode statusCode, string message)
            : base(message)
        {
            StatusCode = statusCode;
        }
    }
}