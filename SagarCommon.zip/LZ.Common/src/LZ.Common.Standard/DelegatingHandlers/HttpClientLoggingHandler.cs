﻿using LZ.Common.Logging;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace LZ.Common.Standard.DelegatingHandlers
{
    public class HttpClientLoggingHandler: DelegatingHandler
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ILogger _logger;

        private const string ApiUrl = "Api_Url";
        private const string HttpMethodMetric = "HttpMethod";
        private const string Metrics = "{@Metrics}";


        public HttpClientLoggingHandler(IHttpContextAccessor httpContextAccessor, ILoggingService loggingService)
        {
            _httpContextAccessor = httpContextAccessor;
            _logger = loggingService?.GetLogger<HttpClientLoggingHandler>(nameof(HttpClientLoggingHandler));
        }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            HttpResponseMessage httpResponseMessage;
            var dict = new Dictionary<string, object> {
                    { ApiUrl, request?.RequestUri },
                    { HttpMethodMetric, request?.Method.Method }
                };

            var stopwatch = new Stopwatch();
            bool isException = false;
            try
            {
                stopwatch.Start();
                httpResponseMessage = await base.SendAsync(request, cancellationToken).ConfigureAwait(false);
            }
            catch (Exception)
            {
                isException = true;
                throw;
            }
            finally
            {
                LogMetrics(dict, stopwatch.ElapsedMilliseconds, isException);
                stopwatch.Stop();
            }

            return httpResponseMessage;
        }

        private void LogMetrics(Dictionary<string, object> dict, long elapsedMiliseconds, bool isException)
        {
            dict.Add("Duration", elapsedMiliseconds);
            dict.Add("IsException", isException);

            _logger?.LogInformation(Metrics, dict);
        }
    }
}
