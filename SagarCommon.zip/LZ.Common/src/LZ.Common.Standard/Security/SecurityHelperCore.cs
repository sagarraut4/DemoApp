﻿using LZ.Common.Logging;
using Microsoft.Extensions.Logging;
using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace LZ.Common.Standard.Security
{
    public class SecurityHelperCore
    {
        protected ILogger _logger { get; set; }

        public SecurityHelperCore(ILoggingService loggingService)
        {
            _logger = loggingService.GetLogger<SecurityHelperCore>(nameof(SecurityHelperCore));
        }

        private const string INIT_VECTOR = "@1B2c3D4e5F6g7H8";

        public enum HashingAlgorithm
        {
            SHA1 = 1,
            SHA256 = 3,
            SHA512 = 4
        }

        /// <summary>
        ///     1. Convert the string to byte[]
        ///     2. Convert the salt string to byte[]
        ///     3. Create a new byte[] with the plaintext byte[] + salt value byte[]
        ///     4. Identify the Hashing algorithm to be used. Throw error if the hashing algorithm requested is not implemented.
        ///     5. Compute hash
        ///     6. Return string
        /// </summary>
        /// <param name="plainText">Plain text string to be hashed</param>
        /// <param name="salt">Salt value to be appended to the plain text</param>
        /// <param name="hashAlgorithm">LZSecure.HashingAlgorithm enum</param>
        /// <returns>Hashed String</returns>
        public static string HashString(string plainText, string salt, HashingAlgorithm hashAlgorithm)
        {
            // Convert plain text into a byte array.
            byte[] saltBytes = Encoding.UTF8.GetBytes(salt);
            byte[] plainTextBytes = Encoding.UTF8.GetBytes(plainText);

            // Allocate array, which will hold plain text and salt.
            byte[] plainTextWithSaltBytes =
                new byte[plainTextBytes.Length + saltBytes.Length];

            // Copy plain text bytes into resulting array.
            for (int i = 0; i < plainTextBytes.Length; i++)
            {
                plainTextWithSaltBytes[i] = plainTextBytes[i];
            }

            // Append salt bytes to the resulting array.
            for (int i = 0; i < saltBytes.Length; i++)
            {
                plainTextWithSaltBytes[plainTextBytes.Length + i] = saltBytes[i];
            }

            HashAlgorithm hash = null;

            // Make sure hashing algorithm name is specified.
            if (hashAlgorithm == HashingAlgorithm.SHA1)
            {
                hash = SHA1.Create();
            }
            else if (hashAlgorithm == HashingAlgorithm.SHA256)
            {
                hash = SHA256.Create();
            }
            else if (hashAlgorithm == HashingAlgorithm.SHA512)
            {
                hash = SHA512.Create();
            }
            else
            {
                throw new ArgumentException("Default Hash Algorithm does not match the hash algorithms implemented. Please define the hash algorithm explicitly");
            }

            // Compute hash value of our plain text with appended salt.
            byte[] hashBytes = hash.ComputeHash(plainTextWithSaltBytes);

            // Convert result into a base64-encoded string.
            string hashValue = Convert.ToBase64String(hashBytes);

            // Return the result.
            return hashValue;
        }

        /// <summary>
        ///     1. Convert the hashed value into byte array
        ///     2. Identify the Hashing algorithm to be used. Throw error if the hashing algorithm requested is not implemented.
        ///     3. Get the hash string for the plain text to be compared.
        ///     4. Compare the hash values and return result.
        /// </summary>
        /// <param name="plainText">Plain text string to be compared with hashed value</param>
        /// <param name="saltValue">Salt value to be used for comparing plain text</param>
        /// <param name="hashAlgorithm">LZSecure.HashingAlgorithm enum</param>
        /// <param name="hashValue">Hashed String</param>
        /// <returns>
        ///     true = Hash matches,
        ///     false = Hash matching fails
        /// </returns>
        public static bool VerifyHash(string plainText, string saltValue,
            HashingAlgorithm hashAlgorithm,
            string hashValue)
        {
            // Convert base64-encoded hash value into a byte array.
            byte[] hashWithSaltBytes = Convert.FromBase64String(hashValue);

            int hashSizeInBits, hashSizeInBytes;
            hashSizeInBits = 0;

            // Make sure that hashing algorithm name is specified.
            if (hashAlgorithm == HashingAlgorithm.SHA1)
            {
                hashSizeInBits = 160;
            }
            else if (hashAlgorithm == HashingAlgorithm.SHA256)
            {
                hashSizeInBits = 256;
            }
            else if (hashAlgorithm == HashingAlgorithm.SHA512)
            {
                hashSizeInBits = 512;
            }
            else
            {
                throw new ArgumentException("Default Hash Algorithm does not match the hash algorithms implemented. Please define the hash algorithm explicitly");
            }

            // Convert size of hash from bits to bytes.
            hashSizeInBytes = hashSizeInBits / 8;

            // Make sure that the specified hash value is long enough.
            if (hashWithSaltBytes.Length < hashSizeInBytes)
            {
                return false;
            }

            // Compute a new hash string.
            string expectedHashString =
                HashString(plainText, saltValue, hashAlgorithm);

            // If the computed hash matches the specified hash,
            // the plain text value must be correct.
            return hashValue == expectedHashString;
        }

        /// <summary>
        ///     Encrypts specified plaintext using Rijndael symmetric key algorithm
        ///     and returns a base64-encoded result.
        /// </summary>
        /// <param name="plainText">
        ///     Plaintext value to be encrypted.
        /// </param>
        /// <param name="passPhrase">
        ///     Passphrase from which a pseudo-random password will be derived. The
        ///     derived password will be used to generate the encryption key.
        ///     Passphrase can be any string. In this example we assume that this
        ///     passphrase is an ASCII string.
        /// </param>
        /// <param name="saltValue">
        ///     Salt value used along with passphrase to generate password. Salt can
        ///     be any string. In this example we assume that salt is an ASCII string.
        /// </param>
        /// <param name="hashAlgorithm">
        ///     Hash algorithm used to generate password. Allowed values are: "MD5" and
        ///     "SHA1". SHA1 hashes are a bit slower, but more secure than MD5 hashes.
        /// </param>
        /// <param name="passwordIterations">
        ///     Number of iterations used to generate password. One or two iterations
        ///     should be enough.
        /// </param>
        /// <param name="initVector">
        ///     Initialization vector (or IV). This value is required to encrypt the
        ///     first block of plaintext data. For RijndaelManaged class IV must be
        ///     exactly 16 ASCII characters long.
        /// </param>
        /// <param name="keySize">
        ///     Size of encryption key in bits. Allowed values are: 128, 192, and 256.
        ///     Longer keys are more secure than shorter keys.
        /// </param>
        /// <returns>
        ///     Encrypted value formatted as a base64-encoded string.
        /// </returns>
        public static string Encrypt(string plainText,
            string passPhrase,
            string saltValue,
            HashingAlgorithm hashAlgorithm = HashingAlgorithm.SHA1,
            int passwordIterations = 2,
            string initVector = INIT_VECTOR,
            int keySize = 256)
        {
            // Convert strings into byte arrays.
            // Let us assume that strings only contain ASCII codes.
            // If strings include Unicode characters, use Unicode, UTF7, or UTF8
            // encoding.
            byte[] initVectorBytes = Encoding.ASCII.GetBytes(initVector);
            byte[] saltValueBytes = Encoding.ASCII.GetBytes(saltValue);

            // Convert our plaintext into a byte array.
            // Let us assume that plaintext contains UTF8-encoded characters.
            byte[] plainTextBytes = Encoding.UTF8.GetBytes(plainText);

            // First, we must create a password, from which the key will be derived.
            // This password will be generated from the specified passphrase and
            // salt value. The password will be created using the specified hash
            // algorithm. Password creation can be done in several iterations.
            Rfc2898DeriveBytes password = new Rfc2898DeriveBytes(
                passPhrase,
                saltValueBytes,
                //hashAlgorithm.ToString(),
                passwordIterations);

            // derive a 256-bit subkey (use HMACSHA1 with 10,000 iterations)
            //string hashed = Convert.ToBase64String(KeyDerivation.Pbkdf2(
            //    password: passPhrase,
            //    salt: saltValueBytes,
            //    prf: KeyDerivationPrf.HMACSHA1,
            //    iterationCount: passwordIterations,
            //    numBytesRequested: keySize / 8));

            // Use the password to generate pseudo-random bytes for the encryption
            // key. Specify the size of the key in bytes (instead of bits).
            byte[] keyBytes = password.GetBytes(keySize / 8);

            byte[] cipherTextBytes = null;

            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = keyBytes;
                aesAlg.IV = initVectorBytes;
                aesAlg.Mode = CipherMode.CBC;

                // Create a decrytor to perform the stream transform.
                ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);

                // Create the streams used for encryption.
                using (MemoryStream memoryStream = new MemoryStream())
                {
                    using (CryptoStream cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write))
                    {
                        // Start encrypting.
                        cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);

                        // Finish encrypting.
                        cryptoStream.FlushFinalBlock();

                        // Convert our encrypted data from a memory stream into a byte array.
                        cipherTextBytes = memoryStream.ToArray();
                    }
                }
            }

            // Create uninitialized Rijndael encryption object.
            //RijndaelManaged symmetricKey = new RijndaelManaged();

            // Generate encryptor from the existing key bytes and initialization
            // vector. Key size will be defined based on the number of the key
            // bytes.
            //ICryptoTransform encryptor = symmetricKey.CreateEncryptor(
            //                                                 keyBytes,
            //                                                 initVectorBytes);

            //// Define memory stream which will be used to hold encrypted data.
            //byte[] cipherTextBytes = null;

            //// Define cryptographic stream (always use Write mode for encryption).
            //using (MemoryStream memoryStream = new MemoryStream())
            //{
            //    using (CryptoStream cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write))
            //    {
            //        // Start encrypting.
            //        cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);

            //        // Finish encrypting.
            //        cryptoStream.FlushFinalBlock();

            //        // Convert our encrypted data from a memory stream into a byte array.
            //        cipherTextBytes = memoryStream.ToArray();
            //    }
            //}

            // Convert encrypted data into a base64-encoded string.
            string cipherText = Convert.ToBase64String(cipherTextBytes);

            // Return encrypted string.
            return cipherText;
        }

        public static string EncryptWithRijndael(string plainText,
                                            string passPhrase,
                                            string saltValue,
                                            HashingAlgorithm hashAlgorithm = HashingAlgorithm.SHA1,
                                            int passwordIterations = 2,
                                            string initVector = INIT_VECTOR,
                                            int keySize = 256)
        {
            // Convert strings into byte arrays.
            // Let us assume that strings only contain ASCII codes.
            // If strings include Unicode characters, use Unicode, UTF7, or UTF8
            // encoding.
            byte[] initVectorBytes = Encoding.ASCII.GetBytes(initVector);
            byte[] saltValueBytes = Encoding.ASCII.GetBytes(saltValue);

            // Convert our plaintext into a byte array.
            // Let us assume that plaintext contains UTF8-encoded characters.
            byte[] plainTextBytes = Encoding.UTF8.GetBytes(plainText);

            PasswordDeriveBytes password = new PasswordDeriveBytes(
                                                passPhrase,
                                                saltValueBytes,
                                                hashAlgorithm.ToString(),
                                                passwordIterations);

            // Use the password to generate pseudo-random bytes for the encryption
            // key. Specify the size of the key in bytes (instead of bits).
            byte[] keyBytes = password.GetBytes(keySize / 8);

            byte[] cipherTextBytes = null;

            using (var rijAlg = new RijndaelManaged())
            {
                rijAlg.Key = keyBytes;
                rijAlg.IV = initVectorBytes;
                rijAlg.Mode = CipherMode.CBC;

                // Create a decrytor to perform the stream transform.
                ICryptoTransform encryptor = rijAlg.CreateEncryptor(rijAlg.Key, rijAlg.IV);

                // Create the streams used for encryption.
                using (MemoryStream memoryStream = new MemoryStream())
                {
                    using (CryptoStream cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write))
                    {
                        // Start encrypting.
                        cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);

                        // Finish encrypting.
                        cryptoStream.FlushFinalBlock();

                        // Convert our encrypted data from a memory stream into a byte array.
                        cipherTextBytes = memoryStream.ToArray();
                    }
                }
            }

            // Convert encrypted data into a base64-encoded string.
            string cipherText = Convert.ToBase64String(cipherTextBytes);

            // Return encrypted string.
            return cipherText;
        }

        /// <summary>
        ///     Decrypts specified ciphertext using Rijndael symmetric key algorithm.
        /// </summary>
        /// <param name="cipherText">
        ///     Base64-formatted ciphertext value.
        /// </param>
        /// <param name="passPhrase">
        ///     Passphrase from which a pseudo-random password will be derived. The
        ///     derived password will be used to generate the encryption key.
        ///     Passphrase can be any string. In this example we assume that this
        ///     passphrase is an ASCII string.
        /// </param>
        /// <param name="saltValue">
        ///     Salt value used along with passphrase to generate password. Salt can
        ///     be any string. In this example we assume that salt is an ASCII string.
        /// </param>
        /// <param name="hashAlgorithm">
        ///     Hash algorithm used to generate password. Allowed values are: "MD5" and
        ///     "SHA1". SHA1 hashes are a bit slower, but more secure than MD5 hashes.
        /// </param>
        /// <param name="passwordIterations">
        ///     Number of iterations used to generate password. One or two iterations
        ///     should be enough.
        /// </param>
        /// <param name="initVector">
        ///     Initialization vector (or IV). This value is required to encrypt the
        ///     first block of plaintext data. For RijndaelManaged class IV must be
        ///     exactly 16 ASCII characters long.
        /// </param>
        /// <param name="keySize">
        ///     Size of encryption key in bits. Allowed values are: 128, 192, and 256.
        ///     Longer keys are more secure than shorter keys.
        /// </param>
        /// <returns>
        ///     Decrypted string value.
        /// </returns>
        /// <remarks>
        ///     Most of the logic in this function is similar to the Encrypt
        ///     logic. In order for decryption to work, all parameters of this function
        ///     - except cipherText value - must match the corresponding parameters of
        ///     the Encrypt function which was called to generate the
        ///     ciphertext.
        /// </remarks>
        public static string Decrypt(string cipherText,
                                            string passPhrase,
                                            string saltValue,
                                            HashingAlgorithm hashAlgorithm = HashingAlgorithm.SHA1,
                                            int passwordIterations = 2,
                                            string initVector = INIT_VECTOR,
                                            int keySize = 256)
        {
            bool method1Result = true;
            string decryptedString = string.Empty;

            try
            {
                decryptedString = DecryptMethod1(cipherText, passPhrase, saltValue, hashAlgorithm, passwordIterations, initVector, keySize);
            }
            catch (Exception)
            {
                method1Result = false;
            }
            if (method1Result == false)
            {
                decryptedString = DecryptMethod2(cipherText, passPhrase, saltValue, hashAlgorithm, passwordIterations, initVector, keySize);
            }
            return decryptedString;
        }

        private static string DecryptMethod1(string cipherText,
                                        string passPhrase,
                                        string saltValue,
                                        HashingAlgorithm hashAlgorithm = HashingAlgorithm.SHA1,
                                        int passwordIterations = 2,
                                        string initVector = INIT_VECTOR,
                                        int keySize = 256)
        {
            // Convert strings defining encryption key characteristics into byte
            // arrays. Let us assume that strings only contain ASCII codes.
            // If strings include Unicode characters, use Unicode, UTF7, or UTF8
            // encoding.
            byte[] initVectorBytes = Encoding.ASCII.GetBytes(initVector);
            byte[] saltValueBytes = Encoding.ASCII.GetBytes(saltValue);

            // Convert our ciphertext into a byte array.
            byte[] cipherTextBytes = Convert.FromBase64String(cipherText);
            string plainText = string.Empty;

            // First, we must create a password, from which the key will be
            // derived. This password will be generated from the specified
            // passphrase and salt value. The password will be created using
            // the specified hash algorithm. Password creation can be done in
            // several iterations.
            PasswordDeriveBytes password = new PasswordDeriveBytes(
                                                            passPhrase,
                                                            saltValueBytes,
                                                            hashAlgorithm.ToString(),
                                                            passwordIterations);

            // Use the password to generate pseudo-random bytes for the encryption
            // key. Specify the size of the key in bytes (instead of bits).
            byte[] keyBytes = password.GetBytes(keySize / 8);

            using (var rijAlg = new RijndaelManaged())
            {
                rijAlg.Key = keyBytes;
                rijAlg.IV = initVectorBytes;
                rijAlg.Mode = CipherMode.CBC;

                // Create a decrytor to perform the stream transform.
                ICryptoTransform decryptor = rijAlg.CreateDecryptor(rijAlg.Key, rijAlg.IV);

                // Create the streams used for encryption.
                using (MemoryStream memoryStream = new MemoryStream(cipherTextBytes))
                {
                    using (CryptoStream cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader srDecrypt = new StreamReader(cryptoStream))
                        {
                            // Read the decrypted bytes from the decrypting stream
                            // and place them in a string.
                            plainText = srDecrypt.ReadToEnd();
                        }
                    }
                }
            }
            // Return decrypted string.
            return plainText;
        }

        private static string DecryptMethod2(string cipherText,
                                string passPhrase,
                                string saltValue,
                                HashingAlgorithm hashAlgorithm = HashingAlgorithm.SHA1,
                                int passwordIterations = 2,
                                string initVector = INIT_VECTOR,
                                int keySize = 256)
        {
            // Convert strings defining encryption key characteristics into byte
            // arrays. Let us assume that strings only contain ASCII codes.
            // If strings include Unicode characters, use Unicode, UTF7, or UTF8
            // encoding.
            byte[] initVectorBytes = Encoding.ASCII.GetBytes(initVector);
            byte[] saltValueBytes = Encoding.ASCII.GetBytes(saltValue);

            // Convert our ciphertext into a byte array.
            byte[] cipherTextBytes = Convert.FromBase64String(cipherText);
            string plainText = string.Empty;

            // First, we must create a password, from which the key will be
            // derived. This password will be generated from the specified
            // passphrase and salt value. The password will be created using
            // the specified hash algorithm. Password creation can be done in
            // several iterations.
            Rfc2898DeriveBytes password = new Rfc2898DeriveBytes(
                                                                passPhrase,
                                                                saltValueBytes,
                                                                //hashAlgorithm.ToString(),
                                                                passwordIterations);

            // Use the password to generate pseudo-random bytes for the encryption
            // key. Specify the size of the key in bytes (instead of bits).
            byte[] keyBytes = password.GetBytes(keySize / 8);

            using (var rijAlg = new RijndaelManaged())
            {
                rijAlg.Key = keyBytes;
                rijAlg.IV = initVectorBytes;
                rijAlg.Mode = CipherMode.CBC;

                // Create a decrytor to perform the stream transform.
                ICryptoTransform decryptor = rijAlg.CreateDecryptor(rijAlg.Key, rijAlg.IV);

                // Create the streams used for encryption.
                using (MemoryStream memoryStream = new MemoryStream(cipherTextBytes))
                {
                    using (CryptoStream cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader srDecrypt = new StreamReader(cryptoStream))
                        {
                            // Read the decrypted bytes from the decrypting stream
                            // and place them in a string.
                            plainText = srDecrypt.ReadToEnd();
                        }
                    }
                }
            }
            // Return decrypted string.
            return plainText;
        }
    }
}
