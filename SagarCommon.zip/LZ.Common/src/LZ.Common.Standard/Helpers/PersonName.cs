﻿using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace LZ.Common.Standard.Helpers
{
    public class PersonName
    {
        public string FullName { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string Suffix { get; set; }

        public static readonly PersonName Empty = new PersonName
        {
            FirstName = string.Empty,
            FullName = string.Empty,
            LastName = string.Empty,
            MiddleName = string.Empty,
            Suffix = string.Empty
        };

        public static PersonName ParseName(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                return PersonName.Empty;
            }

            var namesList = name?.Trim().Split(' ').ToList();
            var suffixList = new List<string> { "JR.", "SR.", "II", "III", "IV", "V" };

            var firstName = string.Empty;
            var lastName = string.Empty;
            var middleName = string.Empty;
            var suffix = string.Empty;

            if (namesList.Count > 0)
            {
                // Identify suffix and pop from list
                if (suffixList.Contains(namesList.Last().ToUpper(CultureInfo.CurrentCulture)))
                {
                    suffix = namesList.Last();
                    namesList.RemoveAt(namesList.Count - 1);
                }

                // shift firstName
                if (namesList.Count > 0)
                {
                    firstName = CapitalizeName(namesList.First());
                    namesList.RemoveAt(0);
                }
                // pop last name
                if (namesList.Count > 0)
                {
                    lastName = CapitalizeName(namesList.Last());
                    namesList.RemoveAt(namesList.Count - 1);
                }

                // capitalize middle name(s) and compline
                for (var j = 0; j < namesList.Count; j++)
                {
                    namesList[j] = CapitalizeName(namesList[j]);
                }
                middleName = string.Join(" ", namesList);
            }
            else
            {
                firstName = name;
            }

            return new PersonName
            {
                FullName = name,
                FirstName = firstName,
                MiddleName = middleName,
                LastName = lastName,
                Suffix = suffix
            };
        }

        public bool IsEmpty()
        {
            //atleast FirstName should be present, other properties can be null 
            return string.IsNullOrWhiteSpace(FirstName) && string.IsNullOrWhiteSpace(FullName);
        }

        private static string CapitalizeName(string name)
        {
            var capitalizedName = string.Empty;
            if (name?.Length == 1)
            {
                capitalizedName = CultureInfo.CurrentCulture.TextInfo.ToUpper(name);
            }
            else if (name.Length > 1)
            {
                capitalizedName = $"{CultureInfo.CurrentCulture.TextInfo.ToUpper(name[0])}{name[1..]}";
            }
            return capitalizedName;
        }
    }
}
