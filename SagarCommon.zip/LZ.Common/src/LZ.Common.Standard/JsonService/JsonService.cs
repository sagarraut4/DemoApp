﻿using Newtonsoft.Json;

namespace LZ.Common.Standard.Json
{
    public sealed class JsonService
    {
        public static T DeserializeObject<T>(string value)
        {
            return JsonConvert.DeserializeObject<T>(value);
        }

        public static object DeserializeObject(string value)
        {
            return JsonConvert.DeserializeObject(value);
        }

        public static string SerializeObject(object value, Formatting formatting = Formatting.None)
        {
            return JsonConvert.SerializeObject(value, formatting);
        }

        public static string SerializeObject<T>(T value, Formatting formatting = Formatting.None)
        {
            return JsonConvert.SerializeObject(value, Formatting.Indented);
        }
    }
}