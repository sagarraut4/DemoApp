﻿using MongoDbGenericRepository.Attributes;
using System;

namespace LZ.Common.CustomAttributes
{
    [AttributeUsage(AttributeTargets.Class)]
    public class CollectionAttribute : CollectionNameAttribute
    {
        public CollectionAttribute(string collectionName) : base(collectionName) { }
    }
}
