﻿using MongoDbGenericRepository;

namespace LZ.Common.Persistence.Mongo.Repository
{
    public interface IMongoRepositoryBase : IBaseMongoRepository
    {
    }
}