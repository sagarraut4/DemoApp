﻿using LZ.Common.Persistence.Mongo.Configuration;
using Microsoft.Extensions.Options;
using MongoDbGenericRepository;

namespace LZ.Common.Persistence.Mongo.Repository
{
    public abstract class MongoRepositoryBase : BaseMongoRepository, IMongoRepositoryBase
    {
        public MongoRepositoryBase(
                                    IOptions<MongoDbSettings> settings
                                ) : base(settings.Value.ConnectionString, settings.Value.Database)
        {
        }
    }
}