﻿using LZ.Common.Persistence.Mongo.Configuration;
using Microsoft.Extensions.Options;
using MongoDB.Driver;

namespace LZ.Common.Persistence.Mongo
{
    public abstract class MongoDbContext
    {
        protected readonly IMongoDatabase _database = null;

        public MongoDbContext(IOptions<MongoDbSettings> settings)
        {
            var client = new MongoClient(settings.Value.ConnectionString);
            if (client != null)
                _database = client.GetDatabase(settings.Value.Database);
        }
    }
}