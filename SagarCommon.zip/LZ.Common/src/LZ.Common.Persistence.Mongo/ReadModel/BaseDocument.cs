﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDbGenericRepository.Models;
using System;

namespace LZ.Common.Persistence.Mongo
{
    public class BaseDocument<TKey> : IDocument<TKey>
        where TKey : IEquatable<TKey>
    {
        /// <summary>
        /// The Id of the document
        /// </summary>
        [BsonId]
        public TKey Id { get; set; }

        /// <summary>
        /// The version of the schema of the document
        /// </summary>
        public int Version { get; set; }

        [BsonDateTimeOptions]
        public DateTime DateCreated { get; set; }

        [BsonDateTimeOptions]
        public DateTime DateUpdated { get; set; }
    }
}