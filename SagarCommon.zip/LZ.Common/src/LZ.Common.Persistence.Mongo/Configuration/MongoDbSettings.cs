﻿namespace LZ.Common.Persistence.Mongo.Configuration
{
    public class MongoDbSettings
    {
        public string ConnectionString { get; set; }
        public string Database { get; set; }
    }
}