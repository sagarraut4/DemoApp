﻿using System;

namespace LZ.Common.Core.Extensions
{
    public static class StringExtensions
    {
        /// <summary>
        /// Checks if current string matches with valueToCompare
        /// </summary>
        /// <param name="value">current string</param>
        /// <param name="valueToCompare">value to compare with</param>
        /// <param name="comparisonOptions">comparison options</param>
        /// <returns></returns>
        public static bool Is(this string value, string valueToCompare, StringComparison comparisonOptions = StringComparison.OrdinalIgnoreCase)
        {
            return string.Compare(value, valueToCompare, comparisonOptions) == 0;
        }
    }
}
