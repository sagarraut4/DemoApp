﻿using LZ.Common.Core.Infrastructure;
using Microsoft.AspNetCore.Builder;

namespace LZ.Common.Core.Extensions
{
    public static class HealthCheckExtensions
    {
        /// <summary>
        /// Registers the <see cref="HealthChecksMiddleware"/>
        /// </summary>
        /// <param name="builder"></param>
        public static IApplicationBuilder UseHealthCheck(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<HealthChecksMiddleware>();
        }
    }
}