﻿using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System.Collections.Generic;
using LZ.Common.Core.Infrastructure;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Versioning;
using Microsoft.AspNetCore.Mvc;
using LZ.Common.Standard.DelegatingHandlers;

namespace LZ.Common.Core.Extensions
{
    public static class MvcCoreExtensions
    {
        /// <summary>
        /// This method adds the Mvc Core to the request pipeline along with NewtonSoftJson
        /// This method
        ///     1. Adds MvcCore()
        ///     2. Adds Api Explorer
        ///     3. Adds the default NewtonSoft with below SerializerSettings
        ///         i. CamelCasePropertyNamesContractResolver
        ///         ii. Sets DateFormatHandling - IsoDateFormat
        ///         iii. Sets DateTimeZoneHandling - Utc
        ///         iv. Adds converters specified in <paramref name="jsonConverters"/>
        /// </summary>
        /// <param name="services"></param>
        /// <param name="controllerAssemblyName"></param>
        /// <param name="jsonConverters"></param>
        public static void AddMvcCoreWithNewtonsoftJson(this IServiceCollection services, List<JsonConverter> jsonConverters = null)
        {
            services.AddMvcCore()
                        .AddApiExplorer()
                        .AddNewtonsoftJson(options =>
                        {
                            options.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
                            options.SerializerSettings.DateFormatHandling = DateFormatHandling.IsoDateFormat;
                            options.SerializerSettings.DateTimeZoneHandling = DateTimeZoneHandling.Utc;
                            if (jsonConverters != null && jsonConverters.Count > 0)
                            {
                                options.SerializerSettings.Converters = jsonConverters;
                            }
                        });
        }

        /// <summary>
        /// This method adds the Mvc to the request pipeline
        /// This method registeres
        ///     1. Controllers
        ///     2. Adds ApiClient
        ///     3. Disables Auto Model State validations
        ///     4. Adds EntityFrameworkSql
        ///     5. Adds AppInsights
        ///     6. Addes <see cref="RequestTracker">Request Tracker</see>
        ///     7. Registeres HttpContextAccessor
        /// </summary>
        /// <param name="services"></param>
        /// <param name="controllersAssemblyName"></param>
        public static IServiceCollection AddCustomMvc(this IServiceCollection services)
        {
            services.AddApiClient();

            services.AddControllers();

            return services.AddVersionedApiExplorer(options =>
            {
                options.GroupNameFormat = "'v'VVV";
                options.SubstituteApiVersionInUrl = true;
            })
            .AddApiVersioning(o =>
            {
                o.ApiVersionReader = new HeaderApiVersionReader("x-lz-api-version");
                o.DefaultApiVersion = new ApiVersion(1, 0);
                o.ReportApiVersions = true;
                o.AssumeDefaultVersionWhenUnspecified = true;
            })
            .DisableAutoModelStateValidation()
            .AddEntityFrameworkSqlServer()
            .AddSingleton<RequestTracker>()// Add Monitoring
            .AddSingleton<IHttpContextAccessor, HttpContextAccessor>()
            .AddTransient<HttpClientLoggingHandler>()
            .AddScoped<IDbHealthHandler, DbHealthHandler>()
            .AddScoped<IInternalServiceHealthHandler, InternalServiceHealthHandler>()
            .AddScoped<IExternalServiceHealthHandler, ExternalServiceHealthHandler>();
        }
    }
}

