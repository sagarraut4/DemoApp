﻿using LZ.Common.Core.Infrastructure;
using Microsoft.AspNetCore.Builder;

namespace LZ.Common.Core.Extensions
{
    public static class LoggingExtensions
    {
        /// <summary>
        /// Uses simple authorization <see cref="LoggingMiddleware"/>
        /// </summary>
        /// <param name="builder"></param>
        public static IApplicationBuilder UseLogging(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<LoggingMiddleware>();
        }
    }
}