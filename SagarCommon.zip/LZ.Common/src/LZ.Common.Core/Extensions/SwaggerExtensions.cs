﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi.Models;
using System;
using System.Linq;

namespace LZ.Common.Core.Extensions
{
    public static class SwaggerExtensions
    {
        /// <summary>
        /// Adds the swagger support to the Api
        /// </summary>
        /// <param name="services"></param>
        /// <param name="xmlCommentsFilePath">xml comments file path</param>
        /// <param name="openApiInfo">information about the Api</param>
        public static IServiceCollection AddSwagger(this IServiceCollection services, string xmlCommentsFilePath, Action<OpenApiInfo> openApiInfo)
        {
            var info = new OpenApiInfo();
            openApiInfo?.Invoke(info);

            return services.AddSwagger(xmlCommentsFilePath, info);
        }

        /// <summary>
        /// Adds the swagger support to the Api
        /// </summary>
        /// <param name="services"></param>
        /// <param name="xmlCommentsFilePath">xml comments file path</param>
        /// <param name="openApiInfo">information about the Api</param>
        public static IServiceCollection AddSwagger(this IServiceCollection services, string xmlCommentsFilePath, OpenApiInfo openApiInfo)
        {
            // Initializes Swagger for the Documentation
            return services.AddSwaggerGen(options =>
            {
                options.ResolveConflictingActions(apiDescriptions => apiDescriptions.First());

                // resolve the IApiVersionDescriptionProvider service
                // note: that we have to build a temporary service provider here because one has not been created yet
                var provider = services.BuildServiceProvider().GetRequiredService<IApiVersionDescriptionProvider>();

                // add a swagger document for each discovered API version
                // note: you might choose to skip or document deprecated API versions differently
                foreach (var description in provider.ApiVersionDescriptions)
                {
                    openApiInfo.Title += $" {description.ApiVersion}";
                    openApiInfo.Version = description.ApiVersion.ToString();
                    if (description.IsDeprecated)
                    {
                        openApiInfo.Description += " This API version has been deprecated.";
                    }

                    options.SwaggerDoc(description.GroupName, openApiInfo);
                }

                // add a custom operation filter which sets default values
                options.OperationFilter<SwaggerDefaultValues>();
                options.IncludeXmlComments(xmlCommentsFilePath, includeControllerXmlComments: true);

                options.EnableAnnotations();
            })
            .AddSwaggerGenNewtonsoftSupport();
        }

        public static IApplicationBuilder UseSwagger(this IApplicationBuilder app, IApiVersionDescriptionProvider provider)
        {
            // Add the Swagger UI
            //Changing swagger endpoint for Confluence Documentation backwards compatibility

            return app.UseSwagger()
                      .UseSwaggerUI(options =>
                        {
                            // build a swagger endpoint for each discovered API version
                            foreach (var description in provider.ApiVersionDescriptions)
                            {
                                options.SwaggerEndpoint($"/swagger/{description.GroupName}/swagger.json", description.GroupName.ToUpperInvariant());
                                options.RoutePrefix = "swagger/ui";
                            }
                        });
        }
    }
}
