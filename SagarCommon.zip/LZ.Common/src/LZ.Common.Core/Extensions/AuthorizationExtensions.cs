﻿using LZ.Common.Core.Infrastructure;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using Microsoft.IdentityModel.Tokens;

namespace LZ.Common.Core.Extensions
{
    public static class AuthorizationExtensions
    {
        /// <summary>
        /// Uses x-lz-authorize header based authorization <see cref="AuthFlagAuthorizationMiddleware"/>
        /// </summary>
        /// <param name="builder"></param>
        public static IApplicationBuilder UseAuthFlagAuthorization(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<AuthFlagAuthorizationMiddleware>();
        }

        /// <summary>
        /// Uses Jwt authorization <see cref="JwtAuthorizationMiddleware"/>
        /// </summary>
        /// <param name="builder"></param>
        public static IApplicationBuilder UseJwtAuthorization(this IApplicationBuilder builder, IConfiguration configuration)
        {
            return builder.UseMiddleware<JwtAuthorizationMiddleware>(configuration);
        }

        /// <summary>
        /// adds the JWT configuration 
        /// </summary>
        /// <param name="services"></param>
        /// <param name="configuration"></param>
        public static void AddJwtAuthorization(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddJwtAuthorization(configuration, options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            });
        }

        /// <summary>
        /// adds the JWT configuration 
        /// </summary>
        /// <param name="services"></param>
        /// <param name="configuration"></param>
        public static void AddJwtAuthorization(this IServiceCollection services, IConfiguration configuration, Action<AuthenticationOptions> authOptions)
        {
            services.AddAuthentication(authOptions)
                    .AddJwtBearer(options =>
                    {
                        options.Authority = $"https://{configuration["Jwt:Domain"]}/";
                        options.Audience = configuration["Jwt:Audience"];
                        List<String> legacyIssuers = new List<String> //This should be removed after all services are switched in production to the new issuer.
                        {
                            configuration["Jwt:Issuer"]
                        };

                        List<String> newIssuers = configuration.GetSection("Jwt:Issuers").Get<List<String>>();
                        
                        options.TokenValidationParameters = new TokenValidationParameters()
                        {
                            ValidateIssuer = true,
                            ValidIssuers = newIssuers ?? legacyIssuers
                        };
                    });
        }
    }
}