﻿using LZ.Common.Standard;
using LZ.Common.Standard.DelegatingHandlers;
using Microsoft.Extensions.DependencyInjection;

namespace LZ.Common.Core.Extensions
{
    public static class ApiClientExtensions
    {
        public static void AddApiClient(this IServiceCollection services)
        {
            services.AddHttpClient<IApiClient, ApiClient>();
            services.AddHttpClient<IThreadSafeApiClient>()
                .AddHttpMessageHandler<HttpClientLoggingHandler>();
        }
    }
}