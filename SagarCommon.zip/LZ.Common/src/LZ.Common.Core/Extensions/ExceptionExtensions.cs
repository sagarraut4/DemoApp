﻿using Microsoft.AspNetCore.Builder;

namespace LZ.Common.Core.Extensions
{
    public static class ExceptionExtensions
    {
        /// <summary>
        /// Registers the <see cref="ExceptionHandlingMiddleware"/>
        /// </summary>
        /// <param name="builder"></param>
        /// <returns></returns>
        public static IApplicationBuilder UseExceptionHandling(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<ExceptionHandlingMiddleware>();
        }
    }
}