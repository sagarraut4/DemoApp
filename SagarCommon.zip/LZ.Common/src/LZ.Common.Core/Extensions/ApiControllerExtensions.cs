﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;

namespace LZ.Common.Core.Extensions
{
    public static class ApiControllerExtensions
    {
        public static IServiceCollection DisableAutoModelStateValidation(this IServiceCollection services)
        {
            return services.Configure<ApiBehaviorOptions>(options =>
            {
                options.SuppressModelStateInvalidFilter = true;
            });
        }

        /// <summary>
        /// Use this method only when we have Controllers decorated with [ApiController] attribute
        /// </summary>
        /// <param name="services"></param>
        public static IServiceCollection EnableAutoModelStateValidation(this IServiceCollection services)
        {
            return services.Configure<ApiBehaviorOptions>(options =>
            {
                options.SuppressModelStateInvalidFilter = false;
            });
        }
    }
}