﻿using LZ.Common.Core.Error;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using System.ComponentModel.DataAnnotations;
using System.Reflection;

namespace LZ.Common.Core.Controllers.Filters
{
    /// <summary>
    /// ValidateModelStateAttribute
    /// </summary>
    public class ValidateModelStateAttribute : ActionFilterAttribute
    {
        /// <summary>
        /// OnActionExecuting
        /// </summary>
        /// <param name="context"></param>
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            var descriptor = context.ActionDescriptor as ControllerActionDescriptor;

            if (descriptor != null)
            {
                var parameters = descriptor.MethodInfo.GetParameters();

                foreach (var parameter in parameters)
                {
                    if (context.ActionArguments.ContainsKey(parameter.Name))
                    {
                        var argument = context.ActionArguments[parameter.Name];

                        EvaluateValidationAttributes(parameter, argument, context.ModelState);
                    }
                }
            }
            if (!context.ModelState.IsValid)
            {
                var errorProvidor = new ApiErrorProvider();

                context.Result = new BadRequestObjectResult(errorProvidor.GetErrorResponse(context.ModelState));
            }
            base.OnActionExecuting(context);
        }

        private void EvaluateValidationAttributes(ParameterInfo parameter, object argument, ModelStateDictionary modelState)
        {
            var customAttributes = CustomAttributeExtensions.GetCustomAttributes<ValidationAttribute>(parameter);
            foreach (var attribute in customAttributes)
            {
                var isValid = attribute.IsValid(argument);
                if (!isValid)
                {
                    modelState.AddModelError(parameter.Name, attribute.FormatErrorMessage(parameter.Name));
                }
            }
        }
    }
}