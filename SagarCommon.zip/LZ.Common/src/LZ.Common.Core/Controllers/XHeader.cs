﻿namespace LZ.Common.Core.Controllers
{
    public sealed class XHeader
    {
        public string ContextId { get; set; }
        public string CustomerId { get; set; }
        public string SessionId { get; set; }
        public string Route { get; set; }
        public string OrderId { get; set; }
    }
}