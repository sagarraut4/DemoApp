﻿using LZ.Common.Core.Error;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Primitives;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;

namespace LZ.Common.Core.Controllers
{
    public abstract class BaseController : Controller
    {
        private const string SESSION_ID = "X-LZ-SessionId";
        private const string CUSTOMER_ID = "X-LZ-CustomerId";
        private const string ORDER_ID = "X-LZ-OrderId";
        private const string CONTEXT_ID = "X-LZ-ContextId";

        protected ApiErrorProvider ApiErrorProvider { get; private set; }
        protected ILogger _logger { get; set; }
        private XHeader _xHeaders;
        private readonly IConfiguration Configuration;

        public BaseController(IConfiguration configuration)
        {
            Configuration = configuration;
            ApiErrorProvider = new ApiErrorProvider(configuration);
        }

        public BaseController()
        {
            ApiErrorProvider = new ApiErrorProvider();
        }

        protected XHeader XHeaders
        {
            get
            {
                if (_xHeaders == null)
                {
                    _xHeaders = new XHeader
                    {
                        ContextId = HeaderValue(CONTEXT_ID),
                        CustomerId = HeaderValue(CUSTOMER_ID),
                        SessionId = HeaderValue(SESSION_ID),
                        OrderId = HeaderValue(ORDER_ID)
                    };
                }
                return _xHeaders;
            }
        }

        [NonAction]
        protected string HeaderValue(string key)
        {
            StringValues result;
            if (!Request.Headers.TryGetValue(key, out result))
            {
                return null;
            }
            return result.FirstOrDefault();
        }

        public IEnumerable<string> Roles
        {
            get => User.Claims
                         .Where(x => x.Type == Configuration["Jwt:RoleClaimType"])
                         .Select(x => x.Value);
        }

        /// <summary>
        /// 
        /// </summary>
        public IEnumerable<string> Groups
        {
            get =>
                  User.Claims
                  .Where(c => c.Type == Configuration["Jwt:GroupClaimType"])
                  .Select(c => c.Value);
        }

        public string UserName { get => User.Identity.Name; }

        [NonAction]
        /// <summary>
        ///     401
        /// </summary>
        /// <returns></returns>
        protected IActionResult UnauthorizedAccessResponse()
        {
            var code = "Service.NotAuthorized";
            HttpContext.Response.StatusCode = (int)HttpStatusCode.Unauthorized;

            return ErrorResponse(code, string.Empty);
        }

        [NonAction]
        /// <summary>
        ///     401 Response with custom messages
        /// </summary>
        /// <returns></returns>
        protected IActionResult UnauthorizedAccessResponse(ErrorServiceResponse errorResponse)
        {
            HttpContext.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
            return new ObjectResult(errorResponse);
        }

        [NonAction]
        /// <summary>
        ///     404
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        protected IActionResult ObjectNotFoundResponse(Type type)
        {
            var code = "NotFound";
            var message = string.Format("Object Not Found: '{0}'.", type != null ? type.Name : "[null]");
            HttpContext.Response.StatusCode = (int)HttpStatusCode.NotFound;

            return ErrorResponse(code, message);
        }

        [NonAction]
        /// <summary>
        ///     400
        /// </summary>
        /// <returns></returns>
        protected IActionResult MissingParameterResponse(string paramName)
        {
            var code = "BadRequest.MissingParameter";
            var message = string.Format("Missing Parameter: '{0}'.", paramName ?? "[null]");
            HttpContext.Response.StatusCode = (int)HttpStatusCode.BadRequest;

            return ErrorResponse(code, message);
        }

        [NonAction]
        /// <summary>
        ///     400
        /// </summary>
        /// <param name="paramName"></param>
        /// <returns></returns>
        protected IActionResult InvalidParameterResponse(string paramName)
        {
            var code = "BadRequest.InvalidParameter";
            var message = string.Format("Invalid Parameter: '{0}'.", paramName ?? "[null]");
            HttpContext.Response.StatusCode = (int)HttpStatusCode.BadRequest;

            return ErrorResponse(code, message);
        }

        [NonAction]
        protected IActionResult NoContentResponse()
        {
            return new NoContentResult();
        }

        [NonAction]
        protected IActionResult InternalServerResponse()
        {
            var code = HttpStatusCode.InternalServerError.ToString();
            HttpContext.Response.StatusCode = (int)HttpStatusCode.InternalServerError;

            return ErrorResponse(code, string.Empty);
        }

        [NonAction]
        public IActionResult CreateErrorResponse(HttpStatusCode httpStatusCode, string apiErrorCodes, Exception exception = null)
        {
            HttpContext.Response.StatusCode = (int)httpStatusCode;

            return new ObjectResult(new ErrorResponse(apiErrorCodes, "", null, exception));
        }

        //public IActionResult CreateResponse(HttpStatusCode httpStatusCode)
        //{
        //    return new HttpStatusCodeResult((int)httpStatusCode);
        //}

        [NonAction]
        public IActionResult CreateResponse(HttpStatusCode httpStatusCode, object response)
        {
            HttpContext.Response.StatusCode = (int)httpStatusCode;
            return new ObjectResult(response);
        }

        /// <summary>
        /// Bad Request Response with error code as 400
        /// </summary>
        /// <returns></returns>
        [NonAction]
        protected IActionResult BadRequestResponse() => new BadRequestObjectResult(ModelState);

        private IActionResult ErrorResponse(string code, string message) => new ObjectResult(ApiErrorProvider.GetErrorResponse(code, message));
    }
}