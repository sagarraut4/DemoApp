﻿using LZ.Common.Core.Error;
using LZ.Common.Logging;
using LZ.Common.Standard.Exceptions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Net;
using System.Threading.Tasks;

namespace LZ.Common.Core.Exceptions
{
    public class HandleExceptionAttribute : ExceptionFilterAttribute
    {
        private readonly ILogger _logger;

        private readonly ApiErrorProvider _apiErrorProvider;

        public HandleExceptionAttribute(ILoggingService loggingService, IConfiguration configuration)
        {
            _logger = loggingService.GetLogger<HandleExceptionAttribute>(nameof(HandleExceptionAttribute));

            _apiErrorProvider = new ApiErrorProvider(configuration);
        }

        public override void OnException(ExceptionContext context)
        {
            HandleException(context);
        }

        public override Task OnExceptionAsync(ExceptionContext context)
        {
            return HandleException(context);
        }

        private Task HandleException(ExceptionContext context)
        {
            var errorResponse = new ErrorServiceResponse();

            var statusCode = context.Exception is IHaveExceptionMessage ? (context.Exception as IHaveExceptionMessage).StatusCode : HttpStatusCode.InternalServerError;

            if (context.Exception is IHaveExceptionMessage)
            {
                _logger.LogError("Failed to process request. Error:{error}", context.Exception);

                errorResponse = _apiErrorProvider.GetErrorResponse((context.Exception as IHaveExceptionMessage).DisplayMessage);
            }
            else
            {
                _logger.LogCritical("Failed to process request. Error:{error}", context.Exception);

                errorResponse = _apiErrorProvider.GetErrorResponse("internal_Server_error");
            }

            context.ExceptionHandled = true;

            var response = context.HttpContext.Response;
            response.StatusCode = (int)statusCode;
            response.ContentType = "application/json";

            return response.WriteAsync(errorResponse.ToString());
        }
    }
}
