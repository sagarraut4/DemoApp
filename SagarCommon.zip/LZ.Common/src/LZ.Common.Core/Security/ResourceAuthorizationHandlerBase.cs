﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace LZ.Common.Core.Security
{

    /// <summary>
    /// 
    /// </summary>
    /// <typeparam name="TRequirement"></typeparam>
    /// <typeparam name="TResource"></typeparam>
    /// <typeparam name="TOwner"></typeparam>
    public abstract class ResourceAuthorizationHandlerBase<TRequirement, TResource, TOwner> : AuthorizationHandler<TRequirement, TResource>,
        IResourceAuthorizationServiceBase<TResource, TOwner>
        where TRequirement : IAuthorizationRequirement
        where TResource : class
        where TOwner : class
    {
        /// <summary>
        /// 
        /// </summary>
        protected readonly IConfiguration Configuration;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="configuration"></param>
        public ResourceAuthorizationHandlerBase(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        /// <summary>
        /// 
        /// </summary>
        public AuthorizationHandlerContext Context { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public abstract List<IAuthorizationRequirement> Allowed { get; }
        /// <summary>
        /// 
        /// </summary>
        public abstract TOwner Owner { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="resource"></param>
        /// <returns></returns>
        public abstract Task<TOwner> GetResourceOwner(TResource resource);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="requiredOwner"></param>
        /// <returns></returns>
        public abstract bool ValidateResourceOwner(TOwner requiredOwner);

        /// <summary>
        /// 
        /// </summary>
        public IEnumerable<string> Groups
        {
            get =>
                  Context?.User.Claims
                  .Where(c => c.Type == Configuration["Jwt:GroupClaimType"])
                  .Select(c => c.Value);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="roleName"></param>
        /// <returns></returns>
        public bool? IsInRole(string roleName)
        {
            var roleClaimTypes = new string[] { ClaimsIdentity.DefaultRoleClaimType, Configuration["Jwt:RoleClaimType"] };
            return Context?.User.Claims.FirstOrDefault(c => roleClaimTypes.Contains(c.Type) && c.Value == roleName) != null;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        /// <param name="requirement"></param>
        /// <param name="resource"></param>
        /// <returns></returns>
        protected override async Task HandleRequirementAsync(AuthorizationHandlerContext context,
                                                                TRequirement requirement,
                                                                TResource resource)
        {
            if (Allowed.Contains(requirement))
            {
                Context = context;
                bool authorize = true;

                // first check if authorization is required
                if (context.User.HasClaim(c => c.Type == ClaimTypes.AuthorizationDecision))
                {
                    var auth = context.User.FindFirst(c => c.Type == ClaimTypes.AuthorizationDecision).Value;
                    bool res = bool.TryParse(auth, out authorize);
                }
                if (authorize == false)
                {
                    // If authorization is not required - it automatically succeeds
                    context.Succeed(requirement);
                }
                else if (context.User.HasClaim(c => c.Type == ClaimTypes.NameIdentifier))
                {
                    var userId = context.User.FindFirst(c => c.Type == ClaimTypes.NameIdentifier).Value as TOwner;

                    Owner = await GetResourceOwner(resource).ConfigureAwait(false);

                    if (ValidateResourceOwner(userId))
                    {
                        context.Succeed(requirement);
                    }
                }
            }
        }
    }

}
