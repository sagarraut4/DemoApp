﻿using System.Threading.Tasks;

namespace LZ.Common.Core.Security
{
    public interface IResourceAuthorizationService<TResource, TOwner>
        where TResource : class
        where TOwner : class
    {
        TOwner Owner { get; set; }

        Task<TOwner> GetResource(TResource resource);

        bool ValidateResourceOwner(TOwner requiredOwner);
    }
}