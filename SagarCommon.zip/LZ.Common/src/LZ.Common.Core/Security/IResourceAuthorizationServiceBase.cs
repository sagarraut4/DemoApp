﻿using System.Threading.Tasks;

namespace LZ.Common.Core.Security
{
    /// <summary>
    /// 
    /// </summary>
    /// <typeparam name="TResource"></typeparam>
    /// <typeparam name="TOwner"></typeparam>
    public interface IResourceAuthorizationServiceBase<TResource, TOwner>
        where TResource : class
        where TOwner : class
    {
        /// <summary>
        /// 
        /// </summary>
        TOwner Owner { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="resource"></param>
        /// <returns></returns>
        Task<TOwner> GetResourceOwner(TResource resource);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="requiredOwner"></param>
        /// <returns></returns>
        bool ValidateResourceOwner(TOwner requiredOwner);
    }
}
