﻿using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using System.Threading.Tasks;

namespace LZ.Common.Core.Security
{
    public abstract class ResourceAuthorizationHandler<TRequirement, TResource, TOwner> : AuthorizationHandler<TRequirement, TResource>,
        IResourceAuthorizationService<TResource, TOwner>
        where TRequirement : IAuthorizationRequirement
        where TResource : class
        where TOwner : class
    {
        public abstract TOwner Owner { get; set; }

        public abstract Task<TOwner> GetResource(TResource resource);

        public abstract bool ValidateResourceOwner(TOwner requiredOwner);

        protected override async Task HandleRequirementAsync(AuthorizationHandlerContext context,
            TRequirement requirement,
            TResource resource)
        {
            bool authorize = true;

            // first check if authorization is required
            if (context.User.HasClaim(c => c.Type == ClaimTypes.AuthorizationDecision))
            {
                var auth = context.User.FindFirst(c => c.Type == ClaimTypes.AuthorizationDecision).Value;
                bool res = bool.TryParse(auth, out authorize);
            }
            if (authorize == false)
            {
                // If authorization is not required - it automatically succeeds
                context.Succeed(requirement);
            }
            else if (context.User.HasClaim(c => c.Type == ClaimTypes.NameIdentifier))
            {
                var userId = context.User.FindFirst(c => c.Type == ClaimTypes.NameIdentifier).Value as TOwner;

                await GetResource(resource).ConfigureAwait(false);

                if (ValidateResourceOwner(userId))
                {
                    context.Succeed(requirement);
                }
            }
        }
    }
}