﻿namespace LZ.Common.Core.Infrastructure
{
    public class ExternalServiceUrlResult
    {
        public string Url { get; set; }
        public string ServiceStatus { get; set; }
        public string ErrorMessage { get; set; }
    }
}