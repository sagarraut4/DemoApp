﻿using System.Collections.Generic;

namespace LZ.Common.Core.Infrastructure
{
    public class ExternalServiceHealthCheckOption
    {
        public string Name { get; set; }
        public bool Custom { get; set; }
        public List<BaseUrlOption> baseUrls { get; set; }
    }
}