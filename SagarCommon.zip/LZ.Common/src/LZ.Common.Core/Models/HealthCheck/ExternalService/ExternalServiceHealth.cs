﻿using System.Collections.Generic;

namespace LZ.Common.Core.Infrastructure
{
    public class ExternalServiceHealth
    {
        public string Status { get; set; }
        public List<ExternalServiceHealthCheckResult> Services { get; set; }
    }
}