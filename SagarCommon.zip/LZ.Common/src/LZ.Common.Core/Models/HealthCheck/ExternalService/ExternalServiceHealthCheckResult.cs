﻿using System.Collections.Generic;

namespace LZ.Common.Core.Infrastructure
{
    public class ExternalServiceHealthCheckResult
    {
        public string Name { get; set; }
        public List<ExternalServiceUrlResult> EndPoints { get; set; }
    }
}