﻿namespace LZ.Common.Core.Infrastructure
{
    public enum ExternalServiceHealthStatusEnum
    {
        None = 0,
        ExternalServiceHealthSuccess = 1,
        ExternalServiceHealthFailure = 2
    }
}