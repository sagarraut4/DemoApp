﻿namespace LZ.Common.Core.Infrastructure
{
    public class HealthCheckOption
    {
        public string Route { get; set; }
        public HealthCheckTypeEnum HealthCheckType { get; set; }
    }
}