﻿namespace LZ.Common.Core.Infrastructure
{
    public enum HealthCheckTypeEnum
    {
        None = 0,
        DatabaseCheck = 1,
        UptimeCheck = 2,
        InternalServiceCheck = 3,
        ThirdPartyServiceCheck = 4
    }
}