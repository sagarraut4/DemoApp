﻿using System.Collections.Generic;

namespace LZ.Common.Core.Infrastructure
{
    public class InternalServiceHealthCheckResult
    {
        public string Name { get; set; }
        public List<InternalServiceUrlResult> ServiceStatus { get; set; }
    }
}