﻿namespace LZ.Common.Core.Infrastructure
{
    public class InternalServiceUrlResult
    {
        public string Url { get; set; }
        public string ErrorMessage { get; set; }
        public ServiceUptimeResponse ServiceUptime { get; set; }
    }
}