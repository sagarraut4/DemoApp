﻿using System.Collections.Generic;

namespace LZ.Common.Core.Infrastructure
{
    public class BaseUrlOption
    {
        public string url { get; set; }
        public List<HeaderOption> headers { get; set; }
    }
}