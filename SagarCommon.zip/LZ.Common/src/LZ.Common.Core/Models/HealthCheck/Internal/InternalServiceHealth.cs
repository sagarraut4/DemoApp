﻿using System.Collections.Generic;

namespace LZ.Common.Core.Infrastructure
{
    public class InternalServiceHealth
    {
        public string Status { get; set; }
        public List<InternalServiceHealthCheckResult> Services { get; set; }
    }
}