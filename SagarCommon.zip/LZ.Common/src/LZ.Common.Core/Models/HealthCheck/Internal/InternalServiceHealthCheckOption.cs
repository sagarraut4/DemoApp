﻿using System.Collections.Generic;

namespace LZ.Common.Core.Infrastructure
{
    public class InternalServiceHealthCheckOption
    {
        public string Name { get; set; }
        public List<BaseUrlOption> baseUrls { get; set; }
    }
}