﻿namespace LZ.Common.Core.Infrastructure
{
    public enum InternalServiceHealthStatusEnum
    {
        None = 0,
        InternalServiceHealthSuccess = 1,
        InternalServiceHealthFailure = 2
    }
}