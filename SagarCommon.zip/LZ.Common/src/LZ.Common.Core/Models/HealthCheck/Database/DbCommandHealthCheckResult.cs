﻿namespace LZ.Common.Core.Infrastructure
{
    public class DbCommandHealthCheckResult
    {
        public string command { get; set; }
        public string errorMessage { get; set; }
        public string commandStatus { get; set; }
        public long durationMiliseconds { get; set; }
    }
}