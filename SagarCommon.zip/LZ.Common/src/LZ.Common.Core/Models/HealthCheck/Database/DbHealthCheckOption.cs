﻿using System.Collections.Generic;

namespace LZ.Common.Core.Infrastructure
{
    public class DbHealthCheckOption
    {
        public string Name { get; set; }
        public string Conn { get; set; }
        public DatabaseType Type { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public List<DbCommandHealthCheckOption> Commands { get; set; }
    }
}