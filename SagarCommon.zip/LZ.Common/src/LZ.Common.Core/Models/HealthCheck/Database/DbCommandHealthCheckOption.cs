﻿namespace LZ.Common.Core.Infrastructure
{
    public class DbCommandHealthCheckOption
    {
        public string Name { get; set; }
        public string Command { get; set; }
    }
}