﻿using System.Collections.Generic;

namespace LZ.Common.Core.Infrastructure
{
    public class DbHealth
    {
        public string overallDatabaseStatus { get; set; }
        public List<DbHealthCheckResult> DatabaseConnections { get; set; }
    }
}