﻿namespace LZ.Common.Core.Infrastructure
{
    public enum DbHealthStatusEnum
    {
        None = 0,
        OpenConnectionSuccess = 1,
        OpenConnectionFailure = 2,
        CommandSuccess = 3,
        CommandFailure = 4,
        DbHealthSuccess = 5,
        DbHealthFailure = 6
    }
}