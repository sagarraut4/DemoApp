﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System.Collections.Generic;

namespace LZ.Common.Core.Infrastructure
{
    public class DbHealthCheckResult
    {
        public string connectionString { get; set; }
        public string errorMessage { get; set; }
        public string connectionStatus { get; set; }
        public List<DbCommandHealthCheckResult> commands { get; set; }
        public string databaseStatus { get; set; }
        [JsonConverter(typeof(StringEnumConverter))]
        public DatabaseType databaseType { get; set; }
    }
}