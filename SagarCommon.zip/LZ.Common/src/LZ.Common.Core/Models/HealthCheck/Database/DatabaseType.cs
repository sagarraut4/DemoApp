﻿namespace LZ.Common.Core.Infrastructure
{
    public enum DatabaseType
    {
        SQL,
        Mongo,
        Postgres
    }
}