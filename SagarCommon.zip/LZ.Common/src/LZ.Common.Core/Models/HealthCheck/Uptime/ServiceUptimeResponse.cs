﻿using System.Collections.Generic;

namespace LZ.Common.Core.Infrastructure
{
    public class ServiceUptimeResponse
    {
        public string uptime { get; set; }
        public int requestCount { get; set; }
        public Dictionary<string, int> responseCodes { get; set; }
    }
}