using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;

namespace LZ.Common.Core.ResponseConverters
{
    /// <summary>
    /// Convert decimal value to have 2 digit precision
    /// </summary>
    public sealed class DecimalFormatConverter : JsonConverter
    {
        public override bool CanConvert(Type objectType)
        {
            return objectType == typeof(decimal) || Nullable.GetUnderlyingType(objectType) == typeof(decimal);
        }

        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            decimal? d = default(decimal?);
            if (value != null)
            {
                d = value as decimal?;
                if (d.HasValue) // If value was a decimal?, then this is possible
                {
                    d = decimal.Round(d.Value, 2); // The ToDouble-conversion removes all unnessecary precision
                }
            }
            JToken.FromObject(d).WriteTo(writer);
        }

        public override bool CanRead
        {
            get { return false; }
        }

        public override object ReadJson(JsonReader reader, Type objectType,
                                     object existingValue, JsonSerializer serializer)
        {
            throw new NotImplementedException();
        }
    }
}