﻿using LZ.Common.Logging;
using LZ.Common.Standard;
using LZ.Common.Standard.Json;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace LZ.Common.Core.Infrastructure
{
    public class HealthChecksMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly IConfiguration _configuration;
        private readonly ILoggingService _logingService;
        private readonly RequestTracker _tracker;
        private readonly ICustomHealthCheckHandler _customHandler;
        private readonly IApiClient _apiClient;
        private readonly IDbHealthHandler _dbHealthHandler;
        private readonly IInternalServiceHealthHandler _internalServiceHealthHandler;
        private readonly IExternalServiceHealthHandler _externalServiceHealthHandler;

        private HealthCheckOption[] routes =
        {
            new HealthCheckOption {Route = "/uptime", HealthCheckType = HealthCheckTypeEnum.UptimeCheck},
            new HealthCheckOption {Route = "/database", HealthCheckType = HealthCheckTypeEnum.DatabaseCheck},
            new HealthCheckOption {Route = "/internal-services", HealthCheckType = HealthCheckTypeEnum.InternalServiceCheck},
            new HealthCheckOption {Route = "/external-services", HealthCheckType = HealthCheckTypeEnum.ThirdPartyServiceCheck}
        };

        public HealthChecksMiddleware(RequestDelegate next, IConfiguration configuration, ILoggingService logingService,
            RequestTracker tracker, IApiClient apiClient, IDbHealthHandler dbHealthHandler, IInternalServiceHealthHandler internalServiceHealthHandler,
            IExternalServiceHealthHandler externalServiceHealthHandler, ICustomHealthCheckHandler customHandler = null)
        {
            _next = next;
            _configuration = configuration;
            _logingService = logingService;
            _tracker = tracker;
            _customHandler = customHandler;
            _apiClient = apiClient;
            _dbHealthHandler = dbHealthHandler;
            _internalServiceHealthHandler = internalServiceHealthHandler;
            _externalServiceHealthHandler = externalServiceHealthHandler;
        }

        public async Task Invoke(HttpContext context)
        {
            HealthCheckTypeEnum handlerType = HealthCheckTypeEnum.None;

            if (context.Request.Path.HasValue)
            {
                if ((handlerType = IsHealthcheckRoute(context.Request.Path.Value)) != HealthCheckTypeEnum.None)
                {
                    switch (handlerType)
                    {
                        case HealthCheckTypeEnum.DatabaseCheck:
                            await CheckDatabaseHealth(context).ConfigureAwait(false);
                            return;

                        case HealthCheckTypeEnum.InternalServiceCheck:
                            await CheckInternalServicesHealth(context).ConfigureAwait(false);
                            return;

                        case HealthCheckTypeEnum.ThirdPartyServiceCheck:
                            await CheckExternalServicesHealth(context).ConfigureAwait(false);
                            return;

                        case HealthCheckTypeEnum.UptimeCheck:
                            await CheckServiceStatus(context).ConfigureAwait(false);
                            return;

                        default:
                            break;
                    }
                }
                else
                {
                    _tracker?.IncrementRequestCount();
                }
            }
            await _next(context).ConfigureAwait(false);

            _tracker?.AddOrUpdateResponseCodes(context.Response.StatusCode.ToString());
        }

        private async Task CheckServiceStatus(HttpContext context)
        {
            context.Response.StatusCode = (int)HttpStatusCode.OK;
            context.Response.ContentType = "application/json";

            await context.Response.WriteAsync(JsonService.SerializeObject(_tracker)).ConfigureAwait(false);
        }

        private async Task CheckInternalServicesHealth(HttpContext context)
        {
            InternalServiceHealth response = await _internalServiceHealthHandler.CheckInternalServiceHealth().ConfigureAwait(false);

            InternalServiceHealthStatusEnum status = (InternalServiceHealthStatusEnum)Enum.Parse(typeof(InternalServiceHealthStatusEnum), response.Status);

            context.Response.StatusCode = status == InternalServiceHealthStatusEnum.InternalServiceHealthFailure ? (int)HttpStatusCode.InternalServerError : (int)HttpStatusCode.OK;
            context.Response.ContentType = "application/json";

            await context.Response.WriteAsync(JsonService.SerializeObject(response)).ConfigureAwait(false);
        }

        private async Task CheckExternalServicesHealth(HttpContext context)
        {
            ExternalServiceHealth response = await _externalServiceHealthHandler.CheckExternalServiceHealth().ConfigureAwait(false);

            ExternalServiceHealthStatusEnum status = (ExternalServiceHealthStatusEnum)Enum.Parse(typeof(ExternalServiceHealthStatusEnum), response.Status);

            context.Response.StatusCode = status == ExternalServiceHealthStatusEnum.ExternalServiceHealthFailure ? (int)HttpStatusCode.InternalServerError : (int)HttpStatusCode.OK;
            context.Response.ContentType = "application/json";

            await context.Response.WriteAsync(JsonService.SerializeObject(response)).ConfigureAwait(false);
        }

        private async Task CheckDatabaseHealth(HttpContext context)
        {
            DbHealth result = await _dbHealthHandler.CheckDbHealth().ConfigureAwait(false);
            DbHealthStatusEnum status = (DbHealthStatusEnum)Enum.Parse(typeof(DbHealthStatusEnum), result.overallDatabaseStatus);

            context.Response.StatusCode = status == DbHealthStatusEnum.DbHealthFailure ? (int)HttpStatusCode.InternalServerError : (int)HttpStatusCode.OK;
            context.Response.ContentType = "application/json";

            await context.Response.WriteAsync(JsonService.SerializeObject(result, Formatting.Indented)).ConfigureAwait(false);
        }

        private HealthCheckTypeEnum IsHealthcheckRouteFromConfiguration(string value)
        {
            var list = new List<HealthCheckOption>();
            _configuration.GetSection("HealthcheckHandlers:Routes").Bind(list);

            HealthCheckOption option = list.SingleOrDefault(l => string.Compare(l.Route, value, false) == 0);
            return option == null ? HealthCheckTypeEnum.None : option.HealthCheckType;
        }

        private HealthCheckTypeEnum IsHealthcheckRoute(string value)
        {
            string route = value.Substring(value.LastIndexOf('/'));

            HealthCheckOption option = routes.SingleOrDefault(l => string.Compare(l.Route, route, false) == 0);
            return option == null ? HealthCheckTypeEnum.None : option.HealthCheckType;
        }
    }
}
