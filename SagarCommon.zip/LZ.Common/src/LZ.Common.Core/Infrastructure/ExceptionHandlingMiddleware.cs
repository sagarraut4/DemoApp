﻿using LZ.Common.Core.Error;
using LZ.Common.Logging;
using LZ.Common.Standard.Exceptions;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Net;
using System.Threading.Tasks;

namespace LZ.Common.Core.Extensions
{
    /// <summary>
    /// The Exception handling Middleware is intended to log the unhandled exceptions accross the application.
    /// </summary>
    public class ExceptionHandlingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger _logger;

        private readonly ApiErrorProvider _apiErrorProvider;

        public ExceptionHandlingMiddleware(RequestDelegate next, ILoggingService loggingService, IConfiguration configuration)
        {
            _next = next;
            _logger = loggingService.GetLogger<ExceptionHandlingMiddleware>(nameof(ExceptionHandlingMiddleware));

            _apiErrorProvider = new ApiErrorProvider(configuration);
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                await _next(context).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                if (ex is IHaveExceptionMessage)
                {
                    _logger.LogError("Failed to process request. Error:{error}", ex.Message);
                    await HandleExceptionAsync(context, (ex as IHaveExceptionMessage).StatusCode, _apiErrorProvider.GetErrorResponse((ex as IHaveExceptionMessage).Code, (ex as IHaveExceptionMessage).DisplayMessage)).ConfigureAwait(false);
                }
                else
                {
                    _logger.LogCritical("Failed to process request. Error:{error}", ex);
                    await HandleExceptionAsync(context, HttpStatusCode.InternalServerError, _apiErrorProvider.GetErrorResponse("internal_Server_error")).ConfigureAwait(false);
                }
            }
        }

        private static Task HandleExceptionAsync(HttpContext context, HttpStatusCode statusCode, ErrorServiceResponse errorResponse)
        {
            context.Response.ContentType = "application/json";

            context.Response.StatusCode = (int)statusCode;

            return context.Response.WriteAsync(errorResponse.ToString());
        }
    }
}
