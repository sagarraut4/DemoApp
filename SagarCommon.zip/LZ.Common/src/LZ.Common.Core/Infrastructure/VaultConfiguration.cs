using System;
using System.Collections.Generic;
using System.Globalization;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using VaultSharp;
using VaultSharp.V1.AuthMethods;
using VaultSharp.V1.AuthMethods.AppRole;
using VaultSharp.V1.AuthMethods.Kubernetes;
using VaultSharp.V1.Commons;

namespace LZ.Common.Core.Extensions
{
    public class VaultConfigurationProvider : ConfigurationProvider
    {
        private const String KubernetesJwtLocation = "/var/run/secrets/kubernetes.io/serviceaccount/token";
        private IVaultClient _client;
        public VaultOptions _config;


        public VaultConfigurationProvider(VaultOptions config)
        {
            _config = config;
            AbstractAuthMethodInfo vaultAuthMethodInfo;
            if (System.IO.File.Exists(KubernetesJwtLocation))
            {
                var jwt = System.IO.File.ReadAllText(KubernetesJwtLocation);
                vaultAuthMethodInfo = new KubernetesAuthMethodInfo(config.ClusterName, config.Role, jwt);
            } else if (Environment.GetEnvironmentVariable("VAULT_TOKEN") != null)
            {
                vaultAuthMethodInfo = new AppRoleAuthMethodInfo(config.Role, Environment.GetEnvironmentVariable("VAULT_TOKEN"));
            }
            else
            {
                vaultAuthMethodInfo = null;
            }
            var vaultClientSettings = new VaultClientSettings(
                _config.Address,
                vaultAuthMethodInfo
            );

            _client = new VaultClient(vaultClientSettings);
        }

        public override void Load()
        {
            LoadAsync().Wait();
        }

        private async Task LoadAsync()
        {
            await LoadSecrets();
        }

        private async Task LoadSecrets()
        {

            Secret<SecretData> secrets = await _client.V1.Secrets.KeyValue.V2.ReadSecretAsync(
                _config.SecretPath, null, _config.MountPath);


            SetData(secrets.Data.Data, string.Empty);
        }


        private void SetData<TValue>(IEnumerable<KeyValuePair<string, TValue>> data, string key)
        {
            foreach (var pair in data)
            {
                var nestedKey = string.IsNullOrEmpty(key) ? pair.Key : $"{key}:{pair.Key}";

                var nestedValue = pair.Value;
                switch (nestedValue)
                {
                    case string sValue:
                        this.Set(nestedKey, sValue);
                        break;
                    case int intValue:
                        this.Set(nestedKey, intValue.ToString(CultureInfo.InvariantCulture));
                        break;
                    case long longValue:
                        this.Set(nestedKey, longValue.ToString(CultureInfo.InvariantCulture));
                        break;
                    case bool boolValue:
                        this.Set(nestedKey, boolValue.ToString(CultureInfo.InvariantCulture));
                        break;
                    case JToken token:
                        switch (token.Type)
                        {
                            case JTokenType.Object:
                                this.SetData<JToken>(token.Value<JObject>(), nestedKey);
                                break;
                            case JTokenType.None:
                            case JTokenType.Array:
                                var array = (JArray)token;
                                for (var i = 0; i < array.Count; i++)
                                {
                                    if (array[i].Type == JTokenType.Array)
                                    {
                                        this.SetData<JToken>(array[i].Value<JObject>(), $"{nestedKey}:{i}");
                                    }
                                    else if (array[i].Type == JTokenType.Object)
                                    {
                                        this.SetData<JToken>(array[i].Value<JObject>(), $"{nestedKey}:{i}");
                                    }
                                    else
                                    {
                                        this.Set($"{nestedKey}:{i}", array[i].Value<string>());
                                    }
                                }

                                break;

                            case JTokenType.Property:
                            case JTokenType.Integer:
                            case JTokenType.Float:
                            case JTokenType.Boolean:
                            case JTokenType.Undefined:
                            case JTokenType.Date:
                            case JTokenType.Raw:
                            case JTokenType.Bytes:
                            case JTokenType.Guid:
                            case JTokenType.Uri:
                            case JTokenType.TimeSpan:
                            case JTokenType.String:
                                this.Set(nestedKey, token.Value<string>());
                                break;
                        }

                        break;
                }
            }
        }
    }
    
    

    public class VaultOptions
    {
        public string Address { get; set; }
        public string Role { get; set; }
        public string MountPath { get; set; }

        public string SecretPath { get; set; }

        public string ClusterName { get; set; }
    }

    public class VaultConfigurationSource : IConfigurationSource
    {
        private VaultOptions _config;

        public VaultConfigurationSource(Action<VaultOptions> config)
        {
            _config = new VaultOptions();
            config.Invoke(_config);
        }

        public IConfigurationProvider Build(IConfigurationBuilder builder)
        {
            return new VaultConfigurationProvider(_config);
        }
    }
}
