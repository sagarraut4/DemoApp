﻿using LZ.Common.Logging;
using LZ.Common.Standard;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace LZ.Common.Core.Infrastructure
{
    public interface IInternalServiceHealthHandler
    {
        Task<InternalServiceHealth> CheckInternalServiceHealth();
    }

    public class InternalServiceHealthHandler : IInternalServiceHealthHandler
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger _logger;
        private readonly IApiClient _apiClient;
        private const string VersionRegEx = @"\/v[0-9]*\/";
        private const string UrlPattern = "\"https:\\\\{baseutl}\v{versionNumber}\\{serviveName}\\{routeUrl}\"";

        public InternalServiceHealthHandler(IConfiguration configuration, ILoggingService loggingService, IApiClient apiClient)
        {
            _configuration = configuration;
            _logger = loggingService?.GetLogger<InternalServiceHealthHandler>(nameof(InternalServiceHealthHandler));
            _apiClient = apiClient;
        }

        public async Task<InternalServiceHealth> CheckInternalServiceHealth()
        {
            var internalServiceHealth = new InternalServiceHealth { Status = InternalServiceHealthStatusEnum.InternalServiceHealthSuccess.ToString() };
            var services = new List<InternalServiceHealthCheckResult>();
            try
            {
                var serviceList = GetInternalServiceList(_configuration);

                foreach (var service in serviceList)
                {
                    var serviceUrls = new List<InternalServiceUrlResult>();
                    var serviceHealth = new InternalServiceHealthCheckResult { Name = service.Name };
                    foreach (var url in service.baseUrls)
                    {
                        var serviceUrlHealth = new InternalServiceUrlResult { Url = url.url };
                        Dictionary<string, string> headers = null;
                        if (url.headers != null)
                        {
                            headers = new Dictionary<string, string>();
                            foreach (var header in url.headers)
                            {
                                headers.Add(header.name, header.value);
                            }
                        }

                        try
                        {
                            string uptimeUrl = url.url + "/uptime";
                            _apiClient.SetHeaders(headers);
                            serviceUrlHealth.ServiceUptime = await _apiClient.GetAsync<ServiceUptimeResponse>(new Uri(uptimeUrl), null).ConfigureAwait(false);
                        }
                        catch (Exception e)
                        {
                            serviceUrlHealth.ErrorMessage = e.Message;
                            internalServiceHealth.Status = InternalServiceHealthStatusEnum.InternalServiceHealthFailure.ToString();
                            _logger?.LogError(e, e.Message);
                        }
                        serviceUrls.Add(serviceUrlHealth);
                    }
                    serviceHealth.ServiceStatus = serviceUrls;
                    services.Add(serviceHealth);
                }
                internalServiceHealth.Services = services;
            }
            catch
            {
                internalServiceHealth.Status = InternalServiceHealthStatusEnum.InternalServiceHealthFailure.ToString();
            }

            return internalServiceHealth;
        }

        private List<InternalServiceHealthCheckOption> GetInternalServiceList(IConfiguration configuration)
        {
            var serviceList = new List<InternalServiceHealthCheckOption>();
            var serviceClientConfigs = configuration.GetSection(InfrastructureKeys.ServiceClients);

            if (serviceClientConfigs != null)
            {
                var allServices = serviceClientConfigs.GetChildren();

                try
                {
                    foreach (var service in allServices)
                    {
                        var isSkipped = service.GetValue<bool>(InfrastructureKeys.SkipMonitoring);
                        if (isSkipped)
                        {
                            continue;
                        }

                        var serviceName = service.Key;
                        var apikey = service.GetValue<string>(InfrastructureKeys.MonitoringApiKey);
                        var apiHostname = service.GetValue<string>(InfrastructureKeys.Hostname);
                        var monitoringBasePath = service.GetValue<string>(InfrastructureKeys.MonitoringBasePath);
                        string monitoringBaseUrl = null;

                        //if Hostname and MonitoringPath exist then use them
                        if (!string.IsNullOrEmpty(apiHostname) && !string.IsNullOrEmpty(monitoringBasePath))
                        {
                            if (Uri.TryCreate(new Uri(apiHostname), monitoringBasePath, out Uri monitoringUri))
                            {
                                monitoringBaseUrl = monitoringUri.AbsoluteUri;
                            }
                            else
                            {
                                _logger?.LogError("Could not create monitoring Uri from {0} and {1}", apiHostname, monitoringBasePath);
                            }
                        }
                        //if no Hostname/MonitoringBasePath for service, then parse from one of the endpoint Urls
                        else
                        {
                            var api = service.GetSection(InfrastructureKeys.Api);
                            if (api != null)
                            {
                                var allEndPoints = api.GetChildren()
                                    .ToList() ?? null;

                                if (allEndPoints != null && allEndPoints.Any())
                                {
                                    var url = allEndPoints[0].GetValue<string>(InfrastructureKeys.Url);

                                    try
                                    {
                                        monitoringBaseUrl = GetBaseUrl(url);
                                    }
                                    catch (Exception ex)
                                    {
                                        _logger?.LogError(0, ex, ex.Message);
                                    }
                                }
                            }
                        }

                        if (!string.IsNullOrEmpty(monitoringBaseUrl))
                        {
                            serviceList.Add(new InternalServiceHealthCheckOption
                            {
                                Name = serviceName,
                                baseUrls = new List<BaseUrlOption>
                                        {
                                            new BaseUrlOption
                                            {
                                                headers = new List<HeaderOption>
                                                {
                                                    new HeaderOption
                                                    {
                                                         name =  InfrastructureKeys.LzApiKeyHeader,
                                                         value = apikey
                                                    }
                                                },
                                                url  = monitoringBaseUrl
                                            }
                                        }
                            });
                        }
                    }
                }
                catch (Exception ex)
                {
                    _logger?.LogError(0, ex, ex.Message);
                }
            }

            return serviceList;
        }

        /// <summary>
        /// Get the base url from  the given url.
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public string GetBaseUrl(string url)
        {
            var basePath = string.Empty;
            if (url == string.Empty)
                return basePath;

            url = url.ToLower();

            var versionExpression = new Regex(VersionRegEx);
            var versionMatch = versionExpression.Match(url);

            if (!versionMatch.Success)
            {
                _logger.LogWarning("Route url does not matches the pattern: {{UrlPattern}}. Requested Url: {{url}} ", UrlPattern, url);
                return basePath;
            }

            var splitter = versionMatch.Value;

            var versionUrl = versionExpression.Split(url);
            if (versionUrl?.Length == 2)
            {
                var routes = versionUrl[1].Split(new string[] { @"/" }, StringSplitOptions.RemoveEmptyEntries);

                if (routes?.Length > 0)
                {
                    if (string.Equals(routes[0], "core"))
                    {
                        if (routes.Length < 2)
                        {
                            throw new Exception(@"Incorrect route {url}");
                        }

                        basePath = versionUrl[0] + splitter + routes[0] + @"/" + routes[1];

                        return basePath;
                    }

                    basePath = versionUrl[0] + splitter + routes[0];

                    return basePath;
                }
            }

            throw new Exception($"Failed to predict the base path for {url}");
        }
    }
}
