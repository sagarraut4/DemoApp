﻿using LZ.Common.Logging;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using MongoDB.Driver;
using MongoDB.Driver.Core.Clusters;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Npgsql;

namespace LZ.Common.Core.Infrastructure
{
    public interface IDbHealthHandler
    {
        Task<DbHealth> CheckDbHealth();
    }
    public class DbHealthHandler : IDbHealthHandler
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger _logger;
        public DbHealthHandler(IConfiguration configuration, ILoggingService loggingService)
        {
            _configuration = configuration;
            _logger = loggingService?.GetLogger<DbHealthHandler>(nameof(DbHealthHandler));
        }

        public async Task<DbHealth> CheckDbHealth(List<DbHealthCheckOption> databaseList)
        {
            var dbHealth = new DbHealth()
            {
                overallDatabaseStatus = DbHealthStatusEnum.None.ToString()
            };
            var dbCheckResults = new List<DbHealthCheckResult>();

            if (databaseList != null)
            {
                try
                {
                    foreach (var database in databaseList)
                    {
                        DbHealthCheckResult result = null;
                        switch (database.Type)
                        {
                            case DatabaseType.SQL:
                                result = await ValidateSQLConnection(database).ConfigureAwait(false);
                                break;
                            case DatabaseType.Mongo:
                                result = await ValidateMongoConnection(database).ConfigureAwait(false);
                                break;
                            case DatabaseType.Postgres:
                                result = ValidatePostgresConnection(database);
                                break;
                            default:
                                result = new DbHealthCheckResult
                                {
                                    connectionString = database.Name,
                                    connectionStatus = DbHealthStatusEnum.OpenConnectionFailure.ToString()
                                };
                                break;
                        }
                        if (result != null)
                        {
                            dbCheckResults.Add(result);
                        }
                    }
                }
                catch
                {
                    // this is catastrophic failure not related to DB health - just return empty HealthCheck collection
                    dbCheckResults.Clear();
                }
                finally
                {
                    if (dbCheckResults.Any())
                    {
                        dbHealth.overallDatabaseStatus =
                            dbCheckResults.Any(r => r.databaseStatus == DbHealthStatusEnum.DbHealthFailure.ToString())
                                ? DbHealthStatusEnum.DbHealthFailure.ToString()
                                : DbHealthStatusEnum.DbHealthSuccess.ToString();
                    }
                    dbHealth.DatabaseConnections = dbCheckResults;
                }
            }
            return dbHealth;
        }

        public async Task<DbHealth> CheckDbHealth()
        {
            List<DbHealthCheckOption> databaseList = null;
            DbHealth dbHealth = null;

            try
            {
                databaseList = new List<DbHealthCheckOption>();
                _configuration?.GetSection("HealthcheckHandlers:DatabaseCheck:Databases").Bind(databaseList);

                _logger?.LogDebug("Database HealthCheck: Obtained {count} connections to validate", databaseList.Count());

                foreach (var database in databaseList)
                {
                    string connectionString = _configuration[database.Conn];
                    database.Conn = connectionString;
                    database.UserName = string.IsNullOrWhiteSpace(database.UserName) == false ?
                        _configuration[database.UserName] : string.Empty;
                    database.Password = string.IsNullOrWhiteSpace(database.Password) == false ?
                        _configuration[database.Password] : string.Empty;
                }

                dbHealth = await CheckDbHealth(databaseList).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                _logger?.LogError(ex, "Database HealthCheck: Failed to read database options");
            }
            finally
            {
                if (dbHealth == null)
                {
                    dbHealth = new DbHealth()
                    {
                        overallDatabaseStatus = DbHealthStatusEnum.DbHealthFailure.ToString()
                    };
                }
            }
            return dbHealth;
        }

        private static async Task<DbHealthCheckResult> ValidateMongoConnection(DbHealthCheckOption database)
        {
            var result = new DbHealthCheckResult
            {
                // obfuscate connection string
                connectionString = database.Type.ToString(),
                connectionStatus = DbHealthStatusEnum.OpenConnectionFailure.ToString(),
                databaseStatus = DbHealthStatusEnum.DbHealthFailure.ToString(),
                databaseType = database.Type
            };
            MongoClient client = null;
            IMongoDatabase db = null;

            try
            {
                client = new MongoClient(database.Conn);

                if (client != null)
                {
                    var dbNames = await client.ListDatabaseNames().ToListAsync();

                    ClusterState state = client.Cluster.Description.State;
                    result.connectionStatus = state == ClusterState.Connected ?
                        DbHealthStatusEnum.OpenConnectionSuccess.ToString() :
                        DbHealthStatusEnum.OpenConnectionFailure.ToString();

                    if (result.connectionStatus == DbHealthStatusEnum.OpenConnectionSuccess.ToString())
                    {
                        db = client.GetDatabase(database.Name);

                        if (db == null)
                        {
                            result.errorMessage = "Failed to obtain database object";
                        }
                        else
                        {
                            var collectionNames = db.ListCollectionNames().ToList();

                            if (collectionNames != null && collectionNames.Any())
                            {
                                result.databaseStatus = DbHealthStatusEnum.DbHealthSuccess.ToString();
                            }
                            else
                            {
                                result.errorMessage = "Failed to obtain database object";
                            }
                        }
                    }
                    else
                    {
                        result.errorMessage = "Failed to establish connection";
                    }
                }
            }
            catch (Exception e)
            {
                result.errorMessage = e.Message;
            }
            finally
            {
                if (client == null)
                {
                    result.errorMessage = "Failed to establish connection";
                }
                else if (db == null && string.IsNullOrWhiteSpace(result.errorMessage))
                {
                    result.errorMessage = "Failed to obtain database object";
                }
            }

            return result;
        }

        private static string SanitizeMongoConnectionString(string connectionString)
        {
            string newConnectionString = string.Empty;
            if (string.IsNullOrWhiteSpace(connectionString) == false)
            {
                try
                {
                    var ss = connectionString.Substring(0, connectionString.IndexOf("@"));
                    int firstIndex = ss.LastIndexOf(":");
                    newConnectionString = connectionString.Replace(ss.Substring(firstIndex + 1, ss.Length - firstIndex - 1), "xxxxxxxx");
                }
                catch (Exception)
                {
                    // malformed connection string
                    newConnectionString = string.Empty;
                }
            }
            return newConnectionString;
        }

        private static string SanitizeSQLConnectionString(string connectionString)
        {
            string newConnectionString = string.Empty;
            const string passwordKey = "password";

            if (string.IsNullOrWhiteSpace(connectionString) == false)
            {
                try
                {
                    var ss = connectionString.Substring(connectionString.IndexOf(passwordKey, StringComparison.OrdinalIgnoreCase) + passwordKey.Length);
                    int firstIndex = ss.IndexOf("=") + 1;
                    int pswLength = ss.IndexOf(";") - firstIndex;
                    newConnectionString = connectionString.Replace(ss.Substring(firstIndex, pswLength), "xxxxxxxx");
                }
                catch (Exception)
                {
                    // Password keyword is not in the connection string - return original
                    newConnectionString = connectionString;
                }
            }
            return newConnectionString;
        }

        private async Task<DbHealthCheckResult> ValidateSQLConnection(DbHealthCheckOption database)
        {
            var result = new DbHealthCheckResult
            {
                // obfuscate connection string
                connectionString = database.Type.ToString(),
                connectionStatus = DbHealthStatusEnum.OpenConnectionFailure.ToString(),
                databaseStatus = DbHealthStatusEnum.DbHealthFailure.ToString(),
                databaseType = database.Type
            };

            if (string.IsNullOrWhiteSpace(database.Conn) == false)
            {
                using (SqlConnection connection = new SqlConnection(database.Conn))
                {
                    try
                    {
                        await connection.OpenAsync().ConfigureAwait(false);

                        if (connection.State == ConnectionState.Open)
                        {
                            result.connectionStatus = DbHealthStatusEnum.OpenConnectionSuccess.ToString();
                            result.databaseStatus = DbHealthStatusEnum.DbHealthSuccess.ToString();

                            result = await CheckSQLDatabaseCommandHealth(database, result, connection).ConfigureAwait(false);
                        }
                        else
                        {
                            result.errorMessage = connection.State.ToString();
                            result.connectionStatus = DbHealthStatusEnum.OpenConnectionFailure.ToString();
                        }
                    }
                    catch (SqlException e)
                    {
                        result.errorMessage = e.Message;
                        result.connectionStatus = DbHealthStatusEnum.OpenConnectionFailure.ToString();
                    }
                    finally
                    {
                        if (connection.State != ConnectionState.Closed)
                        {
                            connection.Close();
                        }
                        connection.Dispose();
                    }
                }
            }
            return result;
        }

        private static async Task<DbHealthCheckResult> CheckSQLDatabaseCommandHealth(DbHealthCheckOption database, DbHealthCheckResult result, SqlConnection connection)
        {
            if (database.Commands != null && database.Commands.Count > 0)
            {
                result.commands = new List<DbCommandHealthCheckResult>();

                foreach (var command in database.Commands)
                {
                    var commandResult = new DbCommandHealthCheckResult
                    {
                        command = command.Name
                    };
                    var stopwatch = new Stopwatch();

                    using (SqlCommand sqlCommand = new SqlCommand())
                    {
                        sqlCommand.Connection = connection;
                        sqlCommand.CommandType = CommandType.Text;
                        sqlCommand.CommandText = command.Command;

                        try
                        {
                            stopwatch.Start();
                            var result1 = await sqlCommand.ExecuteScalarAsync().ConfigureAwait(false);
                            if (result1 == null)
                            {
                                result.databaseStatus = DbHealthStatusEnum.DbHealthFailure.ToString();
                                commandResult.commandStatus = DbHealthStatusEnum.CommandFailure.ToString();
                            }
                            else
                            {
                                commandResult.commandStatus = DbHealthStatusEnum.CommandSuccess.ToString();
                            }
                        }
                        catch (Exception e)
                        {
                            result.databaseStatus = DbHealthStatusEnum.DbHealthFailure.ToString();
                            commandResult.errorMessage = e.Message;
                            commandResult.commandStatus = DbHealthStatusEnum.CommandFailure.ToString();
                        }
                        finally
                        {
                            commandResult.durationMiliseconds = stopwatch.ElapsedMilliseconds;
                            stopwatch.Stop();

                            result.commands.Add(commandResult);
                        }
                        sqlCommand.Dispose();
                    }
                }
            }
            return result;
        }

        private DbHealthCheckResult ValidatePostgresConnection(DbHealthCheckOption database)
        {
            string errorMessage;

            try
            {
                using var connection = new NpgsqlConnection(database.Conn);
                connection.Open();
                if (connection.State == ConnectionState.Open)
                {
                    return new DbHealthCheckResult
                    {
                        connectionStatus = DbHealthStatusEnum.OpenConnectionSuccess.ToString(),
                        databaseStatus = DbHealthStatusEnum.DbHealthSuccess.ToString(),
                        databaseType = database.Type,
                    };
                }
                errorMessage = connection.State.ToString();
            }
            catch (Exception e)
            {
                errorMessage = e.Message;
            }

            return new DbHealthCheckResult
            {
                connectionStatus = DbHealthStatusEnum.OpenConnectionFailure.ToString(),
                databaseStatus = DbHealthStatusEnum.DbHealthFailure.ToString(),
                databaseType = database.Type,
                errorMessage = errorMessage
            };
        }
    }
}
