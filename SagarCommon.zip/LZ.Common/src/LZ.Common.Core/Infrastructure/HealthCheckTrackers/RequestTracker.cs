﻿using Newtonsoft.Json;
using System;
using System.Collections.Concurrent;
using System.Reflection;

namespace LZ.Common.Core.Infrastructure
{
    public class RequestTracker
    {
        private static object _lock = new object();
        private string _runtimeVersion;
        private string _machineName;

        [JsonProperty(PropertyName = "runtimeVersion")]
        public string AssemblyInfo
        {
            get
            {
                if (_runtimeVersion == null)
                {
                    _runtimeVersion = Assembly
                        .GetEntryAssembly()
                        .GetCustomAttribute<AssemblyInformationalVersionAttribute>()
                        .InformationalVersion;
                }

                return _runtimeVersion;
            }
        }

        [JsonProperty(PropertyName = "machineName")]
        public string MachineName
        {
            get
            {
                if (_machineName == null)
                {
                    if (Environment.MachineName != null)
                    {
                        _machineName = Environment.MachineName.Length > 3 ? Environment.MachineName.Substring(Environment.MachineName.Length - 4, 4) : Environment.MachineName;
                    }
                    else
                    {
                        _machineName = "";
                    }
                }

                return _machineName;
            }
        }

        private DateTime ServiceStarted { get; }

        [JsonProperty(PropertyName = "uptime")]
        public string ServiceUptimeInSeconds
        {
            get
            {
                TimeSpan ts = TimeSpan.FromSeconds((DateTime.Now - ServiceStarted).TotalSeconds);

                return string.Format("{0:0} days, {1:0} hours, {2:0} minutes, {3:0} seconds, {4:0} milliseconds", ts.Days, ts.Hours, ts.Minutes, ts.Seconds, ts.Milliseconds);
            }
        }

        [JsonProperty(PropertyName = "requestCount")]
        public int RequestCount { get; private set; }

        private ConcurrentDictionary<string, int> _returnCodes;

        [JsonProperty(PropertyName = "responseCodes")]
        public ConcurrentDictionary<string, int> ReturnCodes
        {
            get { return _returnCodes; }
        }

        public RequestTracker()
        {
            ServiceStarted = DateTime.Now;
            _returnCodes = new ConcurrentDictionary<string, int>();
        }

        public void IncrementRequestCount()
        {
            lock (_lock)
            {
                RequestCount++;
            }
        }

        public void AddOrUpdateResponseCodes(string key)
        {
            _ = _returnCodes.AddOrUpdate(key, 1, (existingKey, oldValue) =>
            {
                return oldValue + 1;
            });
        }
    }
}