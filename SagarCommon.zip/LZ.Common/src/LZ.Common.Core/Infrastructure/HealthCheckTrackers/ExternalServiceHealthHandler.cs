﻿using LZ.Common.Logging;
using LZ.Common.Standard;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LZ.Common.Core.Infrastructure
{
    public interface IExternalServiceHealthHandler
    {
        Task<ExternalServiceHealth> CheckExternalServiceHealth();
    }

    public class ExternalServiceHealthHandler : IExternalServiceHealthHandler
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger _logger;
        private readonly IApiClient _apiClient;
        private readonly ICustomHealthCheckHandler _customHandler;
        public ExternalServiceHealthHandler(IConfiguration configuration, ILoggingService loggingService, IApiClient apiClient, ICustomHealthCheckHandler customHandler = null)
        {
            _configuration = configuration;
            _logger = loggingService?.GetLogger<ExternalServiceHealthHandler>(nameof(ExternalServiceHealthHandler));
            _apiClient = apiClient;
            _customHandler = customHandler;
        }

        public async Task<ExternalServiceHealth> CheckExternalServiceHealth()
        {
            var externalServiceHealth = new ExternalServiceHealth { Status = ExternalServiceHealthStatusEnum.ExternalServiceHealthSuccess.ToString() };
            var services = new List<ExternalServiceHealthCheckResult>();

            try
            {
                var serviceList = new List<ExternalServiceHealthCheckOption>();
                _configuration.GetSection("HealthcheckHandlers:ExternalServiceCheck:Services").Bind(serviceList);

                foreach (var service in serviceList)
                {
                    var serviceUrls = new List<ExternalServiceUrlResult>();
                    var serviceHealth = new ExternalServiceHealthCheckResult { Name = service.Name };
                    if (service.Custom)
                    {
                        serviceUrls = _customHandler?.CheckServiceHealth(service);
                        if (serviceUrls != null)
                        {
                            foreach (var endpoint in serviceUrls)
                            {
                                ExternalServiceHealthStatusEnum status = (ExternalServiceHealthStatusEnum)Enum.Parse(typeof(ExternalServiceHealthStatusEnum), endpoint.ServiceStatus);
                                if (status == ExternalServiceHealthStatusEnum.ExternalServiceHealthFailure)
                                {
                                    externalServiceHealth.Status = ExternalServiceHealthStatusEnum.ExternalServiceHealthFailure.ToString();
                                    break;
                                }
                            }
                        }
                    }
                    else
                    {
                        foreach (var url in service.baseUrls)
                        {
                            var serviceUrlHealth = new ExternalServiceUrlResult { Url = url.url };
                            Dictionary<string, string> headers = null;
                            if (url.headers != null)
                            {
                                headers = new Dictionary<string, string>();
                                foreach (var header in url.headers)
                                {
                                    headers.Add(header.name, header.value);
                                }
                            }

                            try
                            {
                                var response = await _apiClient.GetAsync<dynamic>(new Uri(url.url), null).ConfigureAwait(false);
                                serviceUrlHealth.ServiceStatus = ExternalServiceHealthStatusEnum.ExternalServiceHealthSuccess.ToString();
                            }
                            catch (Exception e)
                            {
                                serviceUrlHealth.ServiceStatus = ExternalServiceHealthStatusEnum.ExternalServiceHealthFailure.ToString();
                                serviceUrlHealth.ErrorMessage = e.Message;
                                externalServiceHealth.Status = ExternalServiceHealthStatusEnum.ExternalServiceHealthFailure.ToString();
                            }
                            serviceUrls.Add(serviceUrlHealth);
                        }
                    }
                    serviceHealth.EndPoints = serviceUrls;
                    services.Add(serviceHealth);
                }
                externalServiceHealth.Services = services;
            }
            catch
            {
                externalServiceHealth.Status = ExternalServiceHealthStatusEnum.ExternalServiceHealthFailure.ToString();
            }

            return externalServiceHealth;
        }

        private List<ExternalServiceUrlResult> CustomThirdPartyHandler(IConfiguration configuration)
        {
            return new List<ExternalServiceUrlResult>();
        }
    }
}
