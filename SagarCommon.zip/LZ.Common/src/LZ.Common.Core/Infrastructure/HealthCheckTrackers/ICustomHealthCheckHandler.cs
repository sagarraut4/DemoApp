﻿using System.Collections.Generic;

namespace LZ.Common.Core.Infrastructure
{
    public interface ICustomHealthCheckHandler
    {
        List<ExternalServiceUrlResult> CheckServiceHealth(ExternalServiceHealthCheckOption service);
    }
}