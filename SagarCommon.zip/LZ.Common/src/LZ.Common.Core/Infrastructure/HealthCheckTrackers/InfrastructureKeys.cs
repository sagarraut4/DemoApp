﻿namespace LZ.Common.Core.Infrastructure
{
    public static class InfrastructureKeys
    {
        public const string ServiceClients = "ServiceClients";
        public const string SkipMonitoring = "SkipMonitoring";
        public const string MonitoringApiKey = "MonitoringApiKey";
        public const string MonitoringBasePath = "MonitoringBasePath";
        public const string Hostname = "Hostname";
        public const string Url = "Url";
        public const string Api = "Api";    
        public const string LzApiKeyHeader = "X-LZ-Api-Key";
    }
}