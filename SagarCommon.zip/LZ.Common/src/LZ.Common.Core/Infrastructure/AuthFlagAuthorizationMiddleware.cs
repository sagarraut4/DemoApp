﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Primitives;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;

namespace LZ.Common.Core.Infrastructure
{
    public class AuthFlagAuthorizationMiddleware
    {
        private const string CUSTOMER_ID = "x-lz-customerId";
        private const string AUTHORIZE_FLAG = "x-lz-authorize";

        private readonly RequestDelegate _next;

        public AuthFlagAuthorizationMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            const string Issuer = "https://legalzoom.com";
            StringValues headerEntry;
            StringValues customerId;
            StringValues authorize = bool.TrueString;

            bool res = context.Request.Headers.TryGetValue(AUTHORIZE_FLAG, out headerEntry);
            if (res)
            {
                authorize = headerEntry;
            }
            List<Claim> claims = new List<Claim>();

            claims.Add(new Claim(ClaimTypes.AuthorizationDecision, authorize, ClaimValueTypes.String, Issuer));

            res = context.Request.Headers.TryGetValue(CUSTOMER_ID, out customerId);
            if (res)
            {
                claims.Add(new Claim(ClaimTypes.NameIdentifier, customerId, ClaimValueTypes.String, Issuer));
            }
            var userIdentity = new ClaimsIdentity("AuthenticatedUser");
            userIdentity.AddClaims(claims);
            var userPrincipal = new ClaimsPrincipal(userIdentity);
            context.User = userPrincipal;

            await _next(context).ConfigureAwait(false);
        }
    }
}