﻿using LZ.Common.Logging;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Primitives;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;

namespace LZ.Common.Core.Infrastructure
{
    public class LoggingMiddleware
    {
        private const string SESSION_ID = "x-lz-sessionId";
        private const string CUSTOMER_ID = "x-lz-customerId";
        private const string CONTEXT_ID = "x-lz-contextId";
        private const string CORRELATION_ID = "x-lz-correlationId";
        private const string ROUTE = "route";
        private const string APPLICATION_ID = "x-lz-applicationId";
        private const string FORWARDED_FOR = "x-forwarded-for";

        private readonly RequestDelegate next;

        public LoggingMiddleware(RequestDelegate next)
        {
            this.next = next;
        }

        public async Task Invoke(HttpContext context, ILoggingService loggingService)
        {
            var stopwatch = new Stopwatch();

            try
            {
                ConcurrentDictionary<string, object> dict = new ConcurrentDictionary<string, object>();
                StringValues sessionId;
                StringValues contextId;
                StringValues customerId;
                StringValues applicationId;

                bool res = context.Request.Headers.TryGetValue(SESSION_ID, out sessionId);
                if (!res)
                {
                    //context.Request.Headers[SESSION_ID] = new string[] { sessionId };
                }
                res = context.Request.Headers.TryGetValue(CUSTOMER_ID, out customerId);
                res = context.Request.Headers.TryGetValue(CONTEXT_ID, out contextId);

                if (!res)
                {
                    // If context id is not found in the header, create new one and add it to request headers
                    contextId = Guid.NewGuid().ToString().Replace("-", "");
                    context.Request.Headers.Add(CONTEXT_ID, contextId);
                }
                else if (string.IsNullOrWhiteSpace(contextId))
                {
                    // context id is found but it consists of white spaces
                    // remove it first
                    context.Request.Headers.Remove(CONTEXT_ID);
                    // and generate new guid
                    contextId = Guid.NewGuid().ToString().Replace("-", "");
                    context.Request.Headers.Add(CONTEXT_ID, contextId);
                }
                // test for correlation id
                res = context.Request.Headers.TryGetValue(CORRELATION_ID, out StringValues correlationId);
                if (!res)
                {
                    // correlation id not found
                    // use context id to populate correlation id header
                    correlationId = contextId;
                    context.Request.Headers.Add(CORRELATION_ID, correlationId);
                }
                else if (string.IsNullOrWhiteSpace(correlationId))
                {
                    // correlation id is found but it consists of white spaces
                    // remove it first
                    context.Request.Headers.Remove(CORRELATION_ID);
                    // and add generated guid
                    correlationId = contextId;
                    context.Request.Headers.Add(CORRELATION_ID, correlationId);
                }
                if (!string.IsNullOrEmpty(contextId))
                {
                    dict.TryAdd(CONTEXT_ID, contextId);
                }
                if (!string.IsNullOrEmpty(correlationId))
                {
                    dict.TryAdd(CORRELATION_ID, correlationId);
                }
                if (!string.IsNullOrEmpty(sessionId))
                {
                    dict.TryAdd(SESSION_ID, sessionId);
                }
                if (!string.IsNullOrEmpty(customerId))
                {
                    dict.TryAdd(CUSTOMER_ID, customerId);
                }
                if (context.Request.Path.HasValue)
                {
                    dict.TryAdd(ROUTE, context.Request.Path.Value);
                }

                if (!context.Request.Headers.TryGetValue(APPLICATION_ID, out applicationId))
                {
                    applicationId = "UnknownApplication";
                }

                if (!string.IsNullOrEmpty(applicationId))
                {
                    dict.TryAdd(APPLICATION_ID, applicationId);
                }

                if (!context.Request.Headers.TryGetValue(FORWARDED_FOR, out StringValues forwardedFor))
                {
                    forwardedFor = "Not Availble";
                }

                if (context.Request.Path.Value != "/uptime" )
                {
                    using (loggingService.ConfigureLogging(dict))
                    {
                        stopwatch.Start();

                        var logger = loggingService.GetLogger<LoggingMiddleware>(nameof(LoggingMiddleware));

                        using (logger.BeginScope(new Dictionary<string, object> { ["ForwardedFor"] = forwardedFor }))
                        {
                            logger.LogInformation("Started processing Http request to URL: {url}", context.Request.Path.Value);
                        };

                        await next(context).ConfigureAwait(false);

                        stopwatch.Stop();

                        logger.LogInformation("Finished processing Http request to URL: {URL}. HttpMethod: {HttpMethod}. StatusCode: {StatusCode}. Duration: {RequestDuration}",
                            context.Request.Path.Value, context.Request.Method, context.Response?.StatusCode, stopwatch.ElapsedMilliseconds);
                    }
                }
            }
            catch (Exception e)
            {
                var logger = loggingService.GetLogger<LoggingMiddleware>(nameof(LoggingMiddleware));
                logger.LogCritical("Failed to process request. Error:{error}", e.Message);
                throw;
            }
        }
    }
}
