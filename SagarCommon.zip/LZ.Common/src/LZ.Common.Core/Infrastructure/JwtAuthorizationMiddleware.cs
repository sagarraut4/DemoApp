﻿using LZ.Common.Core.Extensions;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Primitives;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace LZ.Common.Core.Infrastructure
{
    /// <summary>
    /// 
    /// </summary>
    public class JwtAuthorizationMiddleware
    {
        private const string CUSTOMER_ID = "x-lz-customerId";
        private const string AUTHORIZE_HEADER = "x-lz-authorize";
        private const string AUTHORIZATION = "Authorization";
        private const string BEARER_KEY = "Bearer ";
        private const string USER_ROLE = "user";
        private const string CCUSER_ROLE = "cc_user";
        private const string DEFAULT_ISSUER = "https://legalzoom.com";

        private readonly RequestDelegate _next;
        /// <summary>
        /// 
        /// </summary>
        protected readonly IConfiguration _configuration;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="next"></param>
        /// <param name="configuration"></param>
        public JwtAuthorizationMiddleware(RequestDelegate next, IConfiguration configuration)
        {
            _next = next;
            _configuration = configuration;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task Invoke(HttpContext context)
        {
            context.Request.Headers.TryGetValue(AUTHORIZE_HEADER, out StringValues authorize);
            bool overrideAuthorization = authorize.FirstOrDefault().Is(bool.FalseString);

            if (HasJwtToken(context))
            {
                context.User = await EnrichUser(context.User, (!overrideAuthorization).ToString());
            }
            else
            {
                context.User = await CreateUser(context, (!overrideAuthorization).ToString());
            }
            await _next(context).ConfigureAwait(false);
        }

        /// <summary>
        /// Return default LZ Identity. JWT token was not passed
        /// </summary>
        /// <param name="context"></param>
        /// <param name="authorize"></param>
        /// <returns></returns>
        private async Task<ClaimsPrincipal> CreateUser(HttpContext context, string authorize)
        {
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.AuthorizationDecision, authorize, ClaimValueTypes.String, DEFAULT_ISSUER)
            };

            if (authorize.Is(bool.FalseString))
            {
                claims.Add(new Claim(ClaimsIdentity.DefaultRoleClaimType, CCUSER_ROLE, ClaimValueTypes.String, DEFAULT_ISSUER));
            }

            if (context.Request.Headers.TryGetValue(CUSTOMER_ID, out StringValues customerId))
            {
                claims.Add(new Claim(ClaimTypes.NameIdentifier, customerId, ClaimValueTypes.String, DEFAULT_ISSUER));
                claims.Add(new Claim(ClaimsIdentity.DefaultRoleClaimType, USER_ROLE, ClaimValueTypes.String, DEFAULT_ISSUER));
            }
            return await Task.FromResult(new ClaimsPrincipal(new ClaimsIdentity(claims, "AuthenticatedUser"))).ConfigureAwait(false);
        }

        /// <summary>
        /// Returns enriched identity when JWT has been passed
        /// </summary>
        /// <param name="user"></param>
        /// <param name="authorize"></param>
        /// <returns></returns>
        private async Task<ClaimsPrincipal> EnrichUser(ClaimsPrincipal user, string authorize)
        {
            string Issuer = user.HasClaim(c => c.Type == "iss") ? user.FindFirst(c => c.Type == "iss").Value : DEFAULT_ISSUER;
            var enrichedIdentity = (ClaimsIdentity)user.Identity;

            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.AuthorizationDecision, authorize, ClaimValueTypes.String, Issuer)
            };

            // this is the case when JWT token is not passed
            // if Authorization is not required, we assume the call is made from internal system and we assign a role of "internal_user"
            if (authorize.Is(bool.FalseString) && user.Claims.Count() == 0)
            {
                claims.Add(new Claim(_configuration["Jwt:RoleClaimType"], CCUSER_ROLE, ClaimValueTypes.String, Issuer));
            }
            // If Authorization required, add NameIdentifier claim with internal_id value
            if (authorize.Is(bool.TrueString) && user.HasClaim(c => c.Type == _configuration["Jwt:InternalIdClaimType"]))
            {
                claims.Add(new Claim(ClaimTypes.UserData,
                                        user.FindFirst(c => c.Type == _configuration["Jwt:InternalIdClaimType"]).Value,
                                        ClaimValueTypes.String,
                                        Issuer));
            }
            // Authorization is required and Jwt:CustomerIdClaimType is defined - this "customer" use case.
            // Add CustomerID to UserData claim type and "user" role to Role Claim Type.
            if (authorize.Is(bool.TrueString) && user.HasClaim(c => c.Type == _configuration["Jwt:CustomerIdClaimType"]))
            {
                Claim nameIdentifierClaim = enrichedIdentity.Claims.SingleOrDefault(c => c.Type == ClaimTypes.NameIdentifier);
                if (nameIdentifierClaim != null)
                {
                    enrichedIdentity.RemoveClaim(nameIdentifierClaim); //removing existing name identifier since it has auth0| prefix
                }
                claims.Add(new Claim(ClaimTypes.NameIdentifier,
                                        user.FindFirst(c => c.Type == _configuration["Jwt:CustomerIdClaimType"]).Value,
                                        ClaimValueTypes.String,
                                        Issuer));
                claims.Add(new Claim(_configuration["Jwt:RoleClaimType"], USER_ROLE, ClaimValueTypes.String, Issuer));
                claims.Add(new Claim(_configuration["Jwt:RoleClaimType"], "loggedInUser", ClaimValueTypes.String, Issuer));
            }
            return await Task.FromResult(new ClaimsPrincipal(new ClaimsIdentity(enrichedIdentity,
                                                                                claims,
                                                                                "JwtBearerToken",
                                                                                _configuration["Jwt:NameClaimType"],
                                                                                _configuration["Jwt:RoleClaimType"]))).ConfigureAwait(false);
        }

        /// <summary>
        /// Checks if request has jwt token
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        private bool HasJwtToken(HttpContext context)
        {
            var jwtHandler = new JwtSecurityTokenHandler();
            string authHeader = context.Request.Headers[AUTHORIZATION];
            authHeader = authHeader?.Replace(BEARER_KEY, string.Empty);
            return jwtHandler.CanReadToken(authHeader);
        }
    }

}
