﻿using LZ.Common.Standard.Json;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace LZ.Common.Core.Error
{
    /// <summary>
    /// </summary>
    [JsonObject(MemberSerialization.OptIn)]
    public class ErrorServiceResponse
    {
        [JsonProperty(PropertyName = "errors")]
        public List<ErrorResponse> Errors { get; set; }

        public override string ToString() => JsonService.SerializeObject(this);
    }
}