﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Serilog;
using Serilog.Context;
using Serilog.Core;
using Serilog.Core.Enrichers;
using Serilog.Enrichers;
using Serilog.Events;
using Serilog.Formatting.Json;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ILogger = Microsoft.Extensions.Logging.ILogger;

namespace LZ.Common.Logging.Serilog
{
    public class SerilogLoggingService : ILoggingService
    {
        private readonly IConfiguration _configuration;
        private readonly IConfigurationSection _loggingConfigSection;
        
        private ILoggerFactory _loggerFactory;
        private readonly ILogger _logger;

        public SerilogLoggingService(IConfiguration configuration)
        {
            _configuration = configuration;

            _loggingConfigSection = _configuration.GetSection("serilog");

            CreateLoggerConfiguration();

            _logger = GetLogger<SerilogLoggingService>(_configuration["ServiceSetting:ServiceName"]);

            _logger.LogInformation("Logging path '{Path}, Log Level '{LogLevel}'",
                _loggingConfigSection["pathFormat"],
                _loggingConfigSection["MinimumLevel"]);
        }

        private void CreateLoggerConfiguration(IDictionary<string, object> contextProperties = null)
        {
            long? fileSizeLimitBytes = null;
            int? retainedFileCountLimit = null;

            // If "fileSizeLimitBytes" element not found - keep fileSizeLimitBytes = null,
            // This implies default that is 1Gb size
            if (long.TryParse(_loggingConfigSection["fileSizeLimitBytes"], out long limit))
            {
                fileSizeLimitBytes = limit;
            }

            // If "retainedFileCountLimit" element not found - keep retainedFileCountLimit = null,
            // This implies default that is 31 files
            if (int.TryParse(_loggingConfigSection["retainedFileCountLimit"], out int countLimit))
            {
                retainedFileCountLimit = countLimit;
            }

            LoggerConfiguration config = new LoggerConfiguration()
                .ReadFrom.Configuration(_configuration)
                .Enrich.WithMachineName()
                .Enrich.WithProperty("ApplicationName", _configuration["ServiceSetting:ServiceName"])
                .Enrich.WithEnvironmentUserName()
                .Enrich.WithProcessId()
                .Enrich.WithProperty("SourceContext", "")
                .Enrich.With(new ThreadIdEnricher(), new MachineNameEnricher())
                // this ensures that calls to LogContext.PushProperty will cause the logger to be enriched
                .Enrich.FromLogContext();

            if (!string.IsNullOrEmpty(Environment.GetEnvironmentVariable("KUBERNETES_SERVICE_HOST")))
            {
                config.WriteTo.Console(new JsonFormatter(renderMessage: true), (LogEventLevel)Enum.Parse(typeof(LogEventLevel), _loggingConfigSection["MinimumLevel"]));
            }
            else
            {
                config.WriteTo.File(
                        formatter: new JsonFormatter(renderMessage: true),
                        path: _loggingConfigSection["pathFormat"],
                        restrictedToMinimumLevel: (LogEventLevel)Enum.Parse(typeof(LogEventLevel), _loggingConfigSection["MinimumLevel"]),
                        fileSizeLimitBytes: fileSizeLimitBytes,
                        retainedFileCountLimit: retainedFileCountLimit);
            }

            // If "logConsoleEnabled" element is not found - dont log to console
            if (bool.TryParse(_loggingConfigSection["logConsoleEnabled"], out bool consoleOutputEnabled) == false)
            {
                consoleOutputEnabled = false;
            }

            if (consoleOutputEnabled)
            {
                config.WriteTo.Console(LogEventLevel.Debug);
            }

            Log.Logger = config.CreateLogger();

            _loggerFactory = new LoggerFactory()
                                .AddSerilog();
        }

        public void Shutdown()
        {

        }

        public ILogger GetLogger<TSource>(string sourceContext, IDictionary<string, object> contextProperties = null)
        {
            if (contextProperties != null)
            {
                foreach (KeyValuePair<string, object> prop in contextProperties)
                {
                    Log.Logger = Log.Logger.ForContext(prop.Key, prop.Value);
                }
            }

            return _loggerFactory?.CreateLogger<TSource>();
        }

        public Task ConfigureLoggingAsync(ConcurrentDictionary<string, object> dict)
        {
            if (dict != null)
            {
                foreach (KeyValuePair<string, object> pair in dict)
                {
                    LogContext.PushProperty(pair.Key, pair.Value);
                }
                return Task.FromResult(0);
            }

            throw new Exception();
        }

        public IDisposable ConfigureLogging(ConcurrentDictionary<string, object> dict)
        {
            if (dict != null)
            {
                var properties = dict.ToList()
                    .Select(kv => (ILogEventEnricher)new PropertyEnricher(kv.Key, kv.Value))
                    .ToArray();

                return LogContext.Push(properties);
            }
            throw new Exception();
        }
    }
}
