﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LZ.Common.Logging
{
    // This project can output the Class library as a NuGet Package.
    // To enable this option, right-click on the project and select the Properties menu item. In the Build tab select "Produce outputs on build".
    public interface ILoggingService
    {
        ILogger GetLogger<TSource>(string sourceContext, IDictionary<string, object> contextProperties = null);

        Task ConfigureLoggingAsync(ConcurrentDictionary<string, object> dict);

        IDisposable ConfigureLogging(ConcurrentDictionary<string, object> dict);

        void Shutdown();
    }
}
