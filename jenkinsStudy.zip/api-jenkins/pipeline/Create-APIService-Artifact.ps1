param(
    [Parameter(Mandatory = $True)][string]$Source,
    [Parameter(Mandatory = $True)][string]$Destination
)
$ErrorActionPreference = "Stop"

Write-Host "Preparing to create API service artifact"
# Create new directory for artifacts to go into
New-Item artifact -type directory -Force

Write-Host "Compressing build output to '$Destination' from '$Source'"
Compress-Archive -Path $Source -DestinationPath $Destination -Force
