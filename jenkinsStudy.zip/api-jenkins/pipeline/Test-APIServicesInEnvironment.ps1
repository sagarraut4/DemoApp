param(
	[Parameter(Mandatory=$True)][string]$Port,
	[ValidateSet("predev","dev","qa","stg","prod")]
	[Parameter(Mandatory=$True)][string]$Environment
)
$ErrorActionPreference = "Stop"

# Get list of servers that we just deployed to
Write-Host ("Getting list of servers that are targeted for deployment for given environment")
$targetServersJson = Get-Content -Raw -Path (join-path -Path $Pwd.Path -ChildPath "\build\targetServers\TargetServers.${Environment}.json")
$allServers = ConvertFrom-Json $targetServersJson

$atLeastOneRequestFailed = $false
Write-Host "Requesting application uptime"
foreach($server in $allServers)
{
	try {
		Write-Host ("Attempting to make uptime GET request to Server : {0} , Port : {1}" -f ${server}, ${Port})
		Invoke-RestMethod -Uri http://${server}:${Port}/uptime
	}
	catch {
		# Swallow to allow other services to be checked as well in the pool
		$_
		$atLeastOneRequestFailed = $true
	}
}

if($atLeastOneRequestFailed)
{
	throw 'One or more requests to backend servers failed'
}