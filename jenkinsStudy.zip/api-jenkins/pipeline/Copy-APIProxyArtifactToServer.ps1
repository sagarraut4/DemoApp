$ErrorActionPreference = "Stop"

$proxyBuildArchivePath = ".\artifact\${env:API_PROXY_ARTIFACT_NAME}.zip"

# Allow all branch builds to go here, so we can filder using dropdown for deploy
$environmentDir = (${env:API_SERVICE_ENV} + "/" + ${env:API_SERVICE_NAME})
# The target destinations, controlled by environment variable per Felix request
$proxyArchiveBaseDir = (join-path ${env:API_PROXY_ARCHIVE_BASE_DIR} $environmentDir)

# Create target dir if it does not exist
if (!(Test-Path -path $proxyArchiveBaseDir)) {
    Write-Host ("{0} directory does not exist for api proxy. Creating new folder for archive" -f $proxyArchiveBaseDir)
    New-Item $proxyArchiveBaseDir -Type Directory -Verbose
}

Write-Host ("Copying archive of proxy. proxyBuildArchivePath : {0} , proxyArchiveBaseDir : {1} " -f $proxyBuildArchivePath, $proxyArchiveBaseDir)
Copy-Item $proxyBuildArchivePath $proxyArchiveBaseDir -Force -Verbose
Write-Host "Copy proxy complete"

