param(
	[Parameter(Mandatory=$True)][string]$Port,
	[Parameter(Mandatory=$True)][string]$ServiceHostName,
	[Parameter(Mandatory=$True)][string]$ServiceName,
	[ValidateSet("predev","dev","qa")]
	[Parameter(Mandatory=$True)][string]$Environment
)
$ErrorActionPreference = "Stop"

# Load module that was pulled from api-jenkins
$modulePath = (join-path -path $Pwd.Path -ChildPath "\build\modules\PSAPIServices")
Write-Host ("Importing module from modulePath : {0}"  -f $modulePath)
Import-Module $modulePath -Force -Verbose

# Get single application server to deploy artifact to as is
$targetServersJson = Get-Content -Raw -Path (Join-Path -Path $Pwd.Path -ChildPath "\build\targetServers\TargetServers.${Environment}.json")
$targetServersConverted = ConvertFrom-Json $targetServersJson

write-output "targetServersConverted: $targetServersConverted"

# Set directory we plan on deploying to on application servers
# Consider changing if we fix 1-to-1 environment to server problem
$servicesDirectory = ("D:\Services2\" + $Environment + "\")
Write-Host "Using servicesDirectory : $servicesDirectory"

if($targetServersConverted.Count -gt 1)
{
	throw 'Only 1 server is allowed for non stg/prod deployments'
}

# Credential is set differently for each environment. Therefore, expect env var values to be different per environment
$backendServerPass = ConvertTo-SecureString $ENV:APP_SERVER_CRED_PSW -AsPlainText -Force
$backendServerCredential = New-Object System.Management.Automation.PSCredential ($ENV:APP_SERVER_CRED_USR, $backendServerPass) -Verbose

Write-Host ("Deploying to application server {0}" -f $targetServersConverted[0])
try 
{
	Stop-APIService -ServiceHostName $ServiceHostName -ComputerName  $targetServersConverted[0].ToString() -Environment $Environment -Credential $backendServerCredential
}
catch 
{
	# Swallow exception since we cannot guarantee that the service will be running at the time of deploy
	Write-Host "Error occured trying to stop the service"
	echo $_.Exception|format-list -force
}

$artifactLocation = ".\artifact\${env:API_SERVICE_NAME}.zip"
Publish-APIService -ServiceName $ServiceName -ComputerName  $targetServersConverted[0].ToString() -ServicesDirectory $servicesDirectory -ArtifactLocation $artifactLocation -Credential $backendServerCredential
Start-APIService -ServiceName $ServiceName -ServiceHostName $ServiceHostName -Port $Port -ComputerName $targetServersConverted[0].ToString() -ServicesDirectory $servicesDirectory -Environment $Environment -Credential $backendServerCredential

if (($ServiceName -eq "StorageService") -Or ($ServiceName -ne "DocumentDeliveryService") -Or ($ServiceName -ne "DocumentGenerationUtilityService")){
    Write-Host "Going to mount volumes for API $ServiceName"
    Mount-Volumes -ServiceName $ServiceName  -ComputerName $targetServersConverted[0].ToString() -Environment $Environment -un $ENV:APP_SERVER_CRED_USR -pw $ENV:APP_SERVER_CRED_PSW
}

$server = $targetServersConverted[0].ToString()

write-output "server: $server"
write-output "port: $Port"

$sleep=5
write-output "Sleeping for $sleep seconds"
sleep -s $sleep

Invoke-RestMethod -Uri http://${server}:${Port}/uptime
