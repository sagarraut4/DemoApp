param(
    [string]$ServiceName = $env:API_SERVICE_NAME,
    [ValidateSet("predev","dev","qa","stg","prod")]
    [string]$Environment = $env:API_SERVICE_ENV
)
$ErrorActionPreference = "Stop"

Write-Host "Preparing to zip api service using env variables"
# Create new directory for artifacts to go into
New-Item artifact -type directory -Force
$buildOutputPath = ".\bin\${Environment}" + "\" + "${ServiceName}"
$buildArchivePath = ".\artifact\${Environment}" + "\" + "${ServiceName}.zip"

$requiredFolder = ".\artifact\${Environment}"
# Create folder if it doesnt exist
if (!(Test-Path -path $requiredFolder)) {
    Write-Host ("Folder doesnt exist. Creating necessary folder {0} " -f $requiredFolder)
    mkdir $requiredFolder -Force
}

Write-Host "Compressing build output to : $buildArchivePath from : $buildOutputPath"
Compress-Archive -Path $buildOutputPath -DestinationPath $buildArchivePath -Force