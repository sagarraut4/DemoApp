param(
    [string]$ServiceName = $env:API_SERVICE_NAME,
    [ValidateSet("predev","dev","qa","stg","prod")]
    [string]$Environment = $env:API_SERVICE_ENV,
    [string]$ArchiveBaseDir = $env:API_SERVICE_ARCHIVE_BASE_DIR
)
$ErrorActionPreference = "Stop"

$apiBuildArchivePath = ".\artifact\${Environment}\${ServiceName}.zip"

# All branch build artifacts to go here
$environmentDir = (${Environment} + "/" + ${ServiceName})

# The target destinations, controlled by environment variable per request
$apiArchiveBaseDir = (join-path ${ArchiveBaseDir} $environmentDir)

# Create target dir if it does not exist
if (!(Test-Path -path $apiArchiveBaseDir)) {
    Write-Host ("{0} directory does not exist for api. Creating new folder for archive" -f $apiArchiveBaseDir)
    New-Item $apiArchiveBaseDir -Type Directory -Verbose
}

Write-Host ("Copying archive of api service. apiBuildArchivePath : {0} , apiArchiveBaseDir : {1} " -f $apiBuildArchivePath, $apiArchiveBaseDir)
Copy-Item $apiBuildArchivePath $apiArchiveBaseDir -Force -Verbose
Write-Host "Copy api complete"

