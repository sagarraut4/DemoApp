param(
	[Parameter(Mandatory=$True)][string]$ServiceName,
	[ValidateSet("stg","prod")]
	[Parameter(Mandatory=$True)][string]$Environment
)
$ErrorActionPreference = "Stop"
# expand archive, copy appsettings file into that folder, and compress it for deployment
$unzipLocation = (join-path $pwd "bin")
$artifactLocation = join-path (join-path $pwd "artifact") "${Environment}\${ServiceName}.zip"
Write-Host ("Unzipping artifact : {0} to destination : {1}" -f $artifactLocation, $unzipLocation)
Expand-Archive $artifactLocation -DestinationPath $unzipLocation -Force

$directoryOfApiConfigs = ".\ReleaseManagement\configs\apis"
$directoryWithAppSettingsFiles = (join-path $directoryOfApiConfigs $ServiceName)
$unzippedApplicationDirectory = (join-path $unzipLocation "${Environment}\${ServiceName}")
$secureFilePath = "$directoryWithAppSettingsFiles\appsettings.$Environment.json"
if (!(Test-Path -path $secureFilePath)) {
    Write-Host ("The app settings file {0} does not exist" -f $secureFilePath)
    throw ("The app settings file {0} does not exist" -f $secureFilePath)
}
Write-Host ("Copying secure file {0} to {1}" -f $secureFilePath, $unzippedApplicationDirectory )
Copy-Item $secureFilePath $unzippedApplicationDirectory -Force

$newZipWithConfigDirectory = (Join-Path $pwd "artifact")
$newArtifactPath = (Join-Path $newZipWithConfigDirectory "${Environment}\${ServiceName}.zip")
if (!(Test-Path -path $newZipWithConfigDirectory)) {
    New-Item $newZipWithConfigDirectory -Type Directory -Verbose
}
Compress-Archive $unzippedApplicationDirectory -DestinationPath $newArtifactPath -Force
