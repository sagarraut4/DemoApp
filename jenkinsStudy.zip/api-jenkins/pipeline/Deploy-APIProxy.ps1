param(
    [ValidateSet("predev","dev","qa","stg","prod")]
    [Parameter(Mandatory=$True)][string]
    $Env
)
$ErrorActionPreference = "Stop"

# Load module that was pulled from api-jenkins
$modulePath = join-path -path (Split-Path -Path $Pwd.Path -Parent) -ChildPath "\build\modules\PSApigeeEdgeInternal"
Write-Host ("Importing module from modulePath : {0}"  -f $modulePath)
Import-Module $modulePath -Force

# Convert json to module state. Settings in this JSON allow for different values per environment to be used
$deploySettingsJson = Get-Content -Raw -Path .\deploySettings.$Env.json
$deploySettings = ConvertFrom-Json $deploySettingsJson

# Depends on environment variables
# TODO Consider username password authentication to edge
Set-EdgeConnection -MgmtUri $deploySettings.mgmtUrl -OAuthToken $ENV:APIGEE_EDGE_TOKEN -OAuthUrl $deploySettings.oauthUrl

$existingTargetServer = (Get-TargetServer -Name $deploySettings.targetServer.name -Env $Env)
if(!$existingTargetServer)
{
    Write-Host "Creating new target server"
    Create-TargetServer -Env $Env -TargetServer $deploySettings.targetServer
}
else
{
    Write-Host "Updating existing target server"
    Update-TargetServer -Env $Env -TargetServer $deploySettings.targetServer
}

# Zip folder, upload to apigee, then with response.revision, deploy that version with some delay. Assumed APIProxy already exists, otherwise it will create new proxy and Deploy-EdgeApi will fail
# TODO Consider using existing archived zip instead of zipping folder again which has already been done in another stage of pipeline
Write-Host ("Importing proxy revision in current directory to Apigee Adge. Name : {0}" -f $deploySettings.apiProxyName)
[string]$newRevision =(Import-EdgeApi -Name $deploySettings.apiProxyName -Source ./ -Verbose).revision
Write-Host ("Deploying new version of apigee api proxy. Name : {0} , Env : {1} , Org : {2} , Revision : {3}" -f $deploySettings.apiProxyName, $Env, $deploySettings.org, $newRevision) 
(Deploy-EdgeApi -Name $deploySettings.apiProxyName -Env $Env -Org $deploySettings.org -Revision $newRevision -Verbose).environment