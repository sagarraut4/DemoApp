$ErrorActionPreference = "Stop"

Write-Host "Preparing to zip api proxy"
# Create new directory for artifacts to go into
New-Item artifact -type directory -Force
$buildOutputPath = ".\apigee"
Write-Host ("env:API_PROXY_ARTIFACT_NAME : {0}" -f $env:API_PROXY_ARTIFACT_NAME)
$buildArchivePath = ".\artifact\${env:API_PROXY_ARTIFACT_NAME}.zip"
Write-Host "Compressing build output to : $buildArchivePath"
Compress-Archive -Path $buildOutputPath -DestinationPath $buildArchivePath -Force