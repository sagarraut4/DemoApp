param(
    [Parameter(Mandatory = $True)][string]$ServiceName,
    [Parameter(Mandatory = $True)][string]$Port,
    [ValidateSet("predev", "dev", "qa")]
    [Parameter(Mandatory = $True)][string]$Environment,
    [string]$ArtifactLocation = ".\artifact\${Environment}\${ServiceName}.zip"
)
$ErrorActionPreference = "Stop"

# Load module that was pulled from api-jenkins
$modulePath = (join-path -path $Pwd.Path -ChildPath "\build\modules\PSAPIServices")
Write-Host ("Importing module from modulePath : {0}" -f $modulePath)
Import-Module $modulePath -Force -Verbose

# Get single application server to deploy artifact to as is
$targetServersJson = Get-Content -Raw -Path (Join-Path -Path $Pwd.Path -ChildPath "\build\targetServers\TargetServers.${Environment}.json")
$targetServersConverted = ConvertFrom-Json $targetServersJson

# Set directory we plan on deploying to on application servers
# Consider changing if we fix 1-to-1 environment to server problem
$servicesDirectory = ("D:\wwwroot\services\" + $Environment + "\")
Write-Host "Using servicesDirectory : $servicesDirectory"

if ($targetServersConverted.Count -gt 1) {
    throw 'Only 1 server is allowed for non stg/prod deployments'
}

# Credential is set differently for each environment. Therefore, expect env var values to be different per environment
$backendServerPass = ConvertTo-SecureString $ENV:APP_SERVER_CRED_PSW -AsPlainText -Force
$backendServerCredential = New-Object System.Management.Automation.PSCredential ($ENV:APP_SERVER_CRED_USR, $backendServerPass) -Verbose

Write-Host ("Deploying to application server {0}" -f $targetServersConverted[0])
try {
    Stop-APIService -ServiceHostName $ServiceName -ComputerName  $targetServersConverted[0].ToString() -Environment $Environment  -Credential $backendServerCredential
}
catch {
    Write-Host "Exception occured during attempt to terminate legacy process using kestrel without IIS"
    echo $_.Exception|format-list -force				
}

try {
    # Ensure app pool and website exist in IIS for the given service
    Create-WebsiteIfDoesntExist -ServiceName $ServiceName -Port $Port -ServicesDirectory $servicesDirectory -ComputerName $targetServersConverted[0].ToString() -Environment $Environment -Credential $backendServerCredential  

    # Stop app pool for the given service
    Stop-APIServiceIIS -ServiceName $ServiceName -ComputerName $targetServersConverted[0].ToString() -Environment $Environment -Credential $backendServerCredential
    
}
catch {
    # Swallow exception since we cannot guarantee that the service will be running at the time of deploy
    Write-Host "Error occured trying to stop the service in IIS"
    echo $_.Exception|format-list -force
}

Publish-APIService -ServiceName $ServiceName -ComputerName  $targetServersConverted[0].ToString() -ServicesDirectory $servicesDirectory -ArtifactLocation $ArtifactLocation -Credential $backendServerCredential
Start-APIServiceIIS -ServiceName $ServiceName -ComputerName $targetServersConverted[0].ToString() -Environment $Environment -Credential $backendServerCredential

$server = $targetServersConverted[0].ToString()

write-output "server: $server"
write-output "port: $Port"

$sleep=5
write-output "Sleeping for $sleep seconds"
sleep -s $sleep

Invoke-RestMethod -Uri http://${server}:${Port}/uptime
