param(
	[Parameter(Mandatory=$True)][string]$Port,
	[Parameter(Mandatory=$True)][string]$ServiceHostName,
	[Parameter(Mandatory=$True)][string]$ServiceName,
	[ValidateSet("stg","prod")]
	[Parameter(Mandatory=$True)][string]$Environment,
	[string]$ArtifactName = $env:API_ARTIFACT_NAME,
	[switch]$InteractWithLoadBalancer = $false
)
$ErrorActionPreference = "Stop"

# Load module that was pulled from api-jenkins
$modulePath = (join-path -path $Pwd.Path -ChildPath "\build\modules\PSAPIServices")
Write-Host ("Importing module from modulePath : {0}"  -f $modulePath)
Import-Module $modulePath -Force -Verbose

$modulePath = (join-path $Pwd "\build\modules\Posh-SSH")
Write-Host ("Importing module from modulePath : {0}"  -f $modulePath)
Import-Module $modulePath -Force -Verbose

# Used exclusively for 50% deploy strategy
function Split-Array 
{
  param($inArray,[int]$parts,[int]$size)  
  if ($parts) {
    $PartSize = [Math]::Ceiling($inArray.count / $parts)
  } 
  if ($size) {
    $PartSize = $size
    $parts = [Math]::Ceiling($inArray.count / $size)
  }

  $outArray = New-Object 'System.Collections.Generic.List[psobject]'

  for ($i=1; $i -le $parts; $i++) {
    $start = (($i-1)*$PartSize)
    $end = (($i)*$PartSize) - 1
    if ($end -ge $inArray.count) {$end = $inArray.count -1}
	$outArray.Add(@($inArray[$start..$end]))
  }
  return ,$outArray
}

Write-Host ("Preparing to set credentials used for backend")
# Requires credentails in ENV variables
$backendServerPass = ConvertTo-SecureString $ENV:APP_SERVER_CRED_PSW -AsPlainText -Force
$backendServerCredential = New-Object System.Management.Automation.PSCredential ($ENV:APP_SERVER_CRED_USR, $backendServerPass)

Write-Host ("Preparing to set credentials used for LB")
# Requires credentails in ENV variables
$loadBalancerPass = ConvertTo-SecureString $ENV:LOAD_BALANCER_CRED_PSW -AsPlainText -Force
$loadBalancerCredential = New-Object System.Management.Automation.PSCredential ($ENV:LOAD_BALANCER_CRED_USR, $loadBalancerPass)

# TODO Test credentials before we complete unit of work
# TODO Validate all pool members are able to be disabled/enabled BEFORE executing script to ensure no members are disabled under exception cases

# Get list of servers to target for deployment
Write-Host ("Getting list of servers to target for deployment")
$targetServersJson = Get-Content -Raw -Path (join-path -Path $Pwd.Path -ChildPath "\build\targetServers\TargetServers.${Environment}.json")
$allServers = ConvertFrom-Json $targetServersJson

# Split into subsets so that we can deploy subset-at-a-time instead of service-at-a-time
$numberOfSubsetsToCreate = 2
Write-Host ("Splitting server collection into subsets")
$serverSubsets = Split-Array -inArray $allServers -parts $numberOfSubsetsToCreate

# Set directory we plan on deploying application on application servers
# TODO consider changing if we fix 1-to-1 environment to server problem, which will eliminate need for this convention
$servicesDirectory = ("D:\Services2\" + $Environment + "\")
Write-Host ("Using servicesDirectory : {0}" -f $servicesDirectory)

$atLeastOneDeployFailed = $false
$numberOfApplicationsDeployed = 0

# LB for stg and prod
$loadBalancerServer = "lz-lax-internal"

# Convention used at f5 LB is to name pools BAPI-<EnvironmentName> where EnvironmentName is capitalized
$uppercaseEnv = $Environment.ToUpper()
$poolName = "BAPI-$uppercaseEnv"
$artifactLocation = ".\artifact\${ArtifactName}.zip"
Write-Host "Displaying application version BEFORE deployment"
foreach($server in $allServers)
{	
	try {
		Invoke-RestMethod -Uri http://${server}:${Port}/uptime
	}
	catch {
		# Swallow for services that are not up
		Write-Host ("error when attempting to make uptime GET request to Server : {0} , Port : {1}" -f ${server}, ${Port})
	}
}

for ($i = 0; $i -lt $serverSubsets.Count; $i++) 
{
	Write-Host ("NumberOfServersInSubset : {0}" -f $serverSubsets[$i].Count)
	Write-Host ("Deploying subset index : {0}" -f $i)

	if($InteractWithLoadBalancer)
	{
		# Disable subset from LB
		foreach($node in $serverSubsets[$i])
		{
			Write-Host ("Disabling node {0} in pool {1}" -f $node , $poolName)
			Disable-LTMPoolMember -Node $node -LoadBalancerServer $loadBalancerServer -Pool $poolName -Credential $loadBalancerCredential -Verbose
		}
	}

	for ($j = 0; $j -lt $serverSubsets[$i].Count; $j++)
	{
		Write-Host ("Deploying to application server {0}" -f $serverSubsets[$i][$j])
		try 
		{
			# swallow exception since there is no guarantee the service will be running on application server at time of deploy
			try 
			{
				Stop-APIService -ServiceHostName $ServiceHostName -ComputerName  $serverSubsets[$i][$j] -Environment $Environment  -Credential $backendServerCredential
			}
			catch 
			{				
			}
			Publish-APIService -ServiceName $ServiceName -ComputerName  $serverSubsets[$i][$j] -ServicesDirectory $servicesDirectory -ArtifactLocation $artifactLocation -Credential $backendServerCredential
			Start-APIService -ServiceName $ServiceName -ServiceHostName $ServiceHostName -Port $Port -ComputerName $serverSubsets[$i][$j] -ServicesDirectory $servicesDirectory -Environment $Environment -Credential $backendServerCredential
			
			$numberOfApplicationsDeployed++
		}
		catch 
		{
			# Swallow exception to avoid a situation where a deploy attempt an application server results in all remaining deployments to fail
			echo $_.Exception|format-list -force
			$atLeastOneDeployFailed = $true
		}
		Start-Sleep 2
	}
	if($InteractWithLoadBalancer)
	{
		# Enable subset of nodes in pool
		foreach($node in $serverSubsets[$i])
		{
			Write-Host ("Enabling node {0} in pool {1}" -f $node , $poolName)
			Enable-LTMPoolMember -Node $node -LoadBalancerServer $loadBalancerServer -Pool $poolName -Credential $loadBalancerCredential -Verbose
		}
	}

	Write-Host "Completed iteration"
	Write-Host ""
}
Write-Host "End of iterations"

# Since we swallowed the exception
if($atLeastOneDeployFailed)
{
	throw 'One or more Publish packages failed to be re-deployed to the target server'
}

"numberOfApplicationsDeployed: " + $numberOfApplicationsDeployed
if($numberOfApplicationsDeployed -eq 0)
{
	throw 'No applications were deployed, please ensure you have specified 1 or more target servers in TargetServers.json file'
}

Write-Host "Displaying application version AFTER deployment"
foreach($server in $allServers)
{
	try {
		Write-Host ("Attempting to make uptime GET request to Server : {0} , Port : {1}" -f ${server}, ${Port})
		Invoke-RestMethod -Uri http://${server}:${Port}/uptime
	}
	catch {
		# Swallow to allow other services to be checked as well in the pool
		$_
	}

}
