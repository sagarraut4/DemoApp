# api-jenkins

## SYNOPSIS
The centralized location to host shared pipeline scripts, shared modules, and shared libraries.


## ORGANIZATION
[Modules](modules/) directory contains powershell modules that are imported on demand for jenkins pipelines, but can be imported and cmdlets executed locally as well.

[Pipeline](pipeline/) directory contains high-level coordination scripts that interact with one or more modules to complete a unit-of-work.

[TargetServers](targetServers/) directory contains a centralized location for pipeline jobs to map environments to a set of application servers.

[Vars](vars/) directory contains shared library code that can be used for any new multibranch pipeline.
