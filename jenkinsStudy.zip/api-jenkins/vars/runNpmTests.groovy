#!/usr/bin/env groovy

/**
 * A generic pipeline function for running unit tests for JavaScript projects 
 */

def call(Map map = [:]) {
    testProjectDirectory = map.testProjectDirectory ?: env.TEST_PROJECT_DIRECTORY
    testCommand = map.testCommand ?: 'npm run test:coverage'
    colors = colorCodes()

    statusMessage(status: "Preparing Unit Tests", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}TEST_PROJECT_DIRECTORY:${colors.none} ${testProjectDirectory}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }

    statusMessage(status: "Starting Unit Tests", level: "info")
    try {
        dir(testProjectDirectory) {
            sh "${testCommand}"
        } 
    } catch(e) {
        ansiColor('xterm') {
            error("${colors.red}Unit tests failed:${colors.none} ${colors.bold}${e}${colors.none}")
        }
        return
    }
}
