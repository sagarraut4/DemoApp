#!/usr/bin/env groovy
/* groovylint-disable LineLength, NoDef, VariableTypeRequired */
import groovy.json.JsonSlurper

/**
 * A generic pipeline function for to set up AWS Profile before deployment
 */

def call(Map map = [:]) {
    awsProfile = map.awsProfile ?: env.AWS_PROFILE
    awsRegion = map.awsRegion ?: env.AWS_REGION
    awsS3Bucket = map.awsS3Bucket ?: env.AWS_S3_BUCKET
    awsCfStack = map.awsCfStack ?: env.AWS_CF_STACK
    awsCfParams = map.awsCfParams ?: env.AWS_CF_PARAMS
    awsCfSubstitutions = map.awsCfSubstitutions ?: env.AWS_CF_SUBS
    awsIamRoleSnsDeliveryStatus = map.awsIamRoleSnsDeliveryStatus ?: env.AWS_IAM_ROLE_SNS_DELIVERY_STATUS
    awsCfChildStacks = map.awsCfChildStacks ?: env.AWS_CF_CHILD_STACKS

    colors = colorCodes()

    statusMessage(status: 'Setting up AWS Keys', level: 'info')

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
            ${colors.magenta}AWS_PROFILE:${colors.none} ${awsProfile}
            ${colors.magenta}AWS_REGION:${colors.none} ${awsRegion}
            ${colors.magenta}AWS_S3_BUCKET:${colors.none} ${awsS3Bucket}
            ${colors.magenta}AWS_CF_STACK:${colors.none} ${awsCfStack}
            ${colors.magenta}AWS_CF_PARAMS:${colors.none} ${awsCfParams}
            ${colors.magenta}AWS_CF_SUBSTITUTIONS:${colors.none} ${awsCfSubstitutions}
            ${colors.magenta}AWS_CF_CHILD_STACKS:${colors.none} ${awsCfChildStacks}
            ${colors.magenta}AWS_IAM_ROLE_SNS_DELIVERY_STATUS:${colors.none} ${awsIamRoleSnsDeliveryStatus}
            ${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
            """
    }

    try {
        deployCommand = "pwsh -file .//deploy//deploy.ps1 -region ${awsRegion} -profile ${awsProfile} -bucket ${awsS3Bucket} -stack ${awsCfStack} -templateParameters \"${awsCfParams}\" "

        if (awsIamRoleSnsDeliveryStatus != '') {
            deployCommand = "${deployCommand} -snsDeliveryStatusRoleArn ${awsIamRoleSnsDeliveryStatus} "
        }

        if ("${awsCfSubstitutions}" && "${awsCfSubstitutions}" != 'null') {
            deployCommand = "${deployCommand} -templateSubstitutions \"${awsCfSubstitutions}\" "
        }
        else {
            deployCommand = "${deployCommand} "
        }

        if ("${awsCfChildStacks}" && "${awsCfChildStacks}" != 'null') {
            deployCommand = "${deployCommand} -childStacks \"${awsCfChildStacks}\" "
        }
        else {
            deployCommand = "${deployCommand} "
        }

        deployCommand = "${deployCommand} -Verbose"

        echo '''
            Invoking deploy.ps1 file for deployment
        '''
        def exitStatus = sh(script: "${deployCommand}", returnStatus: true)

        // def exitCode = sh(script: 'pwsh $LASTEXITCODE', returnStatus: true, returnStdout: true)

        // echo "exitCode ${exitCode.trim()}"

        echo "exitStatus ${exitStatus}"

        if (exitStatus != 0) {
            ansiColor('xterm') {
                error("${colors.red}Error occured while deploying:${colors.none}")
            }
            return
        }
    } catch (e) {
        ansiColor('xterm') {
            error("${colors.red}Unable to restore packages:${colors.none} ${colors.bold}${e}${colors.none}")
        }
        return
    }
}
