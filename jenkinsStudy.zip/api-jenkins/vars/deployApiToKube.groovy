#!/usr/bin/env groovy

/**
 * A generic pipeline function for executing the angular deploy job in Rundeck
 */

def call(Map map = [:]) {
    // optional
    environment = map.environment ?: env.ENVIRONMENT
    deploymentRepo = map.deploymentRepo
    image = map.image
    extension = "zip"
    deployFilesOnly = 'true'
    colors = colorCodes()
    commit = env.GIT_COMMIT
    try {
        assert environment != null
    } catch (e) {
        error("One or more required parameters were null: ${e}")
    }

    statusMessage(status: "Deploying", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}TARGET_ENVIRONMENT:${colors.none} ${environment}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }

    if(environment != "prod") {
        withCredentials([
                usernamePassword(
                    credentialsId: '685757ba-4b94-45ec-a37a-4f48b340ef83',
                    passwordVariable: 'PASSWORD',
                    usernameVariable: 'USER'
                )
            ]) {
            git url: "https://${USER}:${PASSWORD}@github.legalzoom.com/${deploymentRepo}"
            container('kustomize') {
                sh """
                cd envs/${environment} && kustomize edit set image ${image}=${image}:${commit}
                """
            }
            gitCredentialsUrl = "https://${USER}:${PASSWORD}@github.legalzoom.com/${deploymentRepo}"
            sh """
                git config --global user.email "dl-devops@legalzoom.com"
                git config --global user.name "Jenkins Pipeline"
                git add envs
                if [ -z \$(git status --porcelain) ];
                then
                    echo "No change to commit"
                else
                    git commit -m "Update ${environment} container to version ${commit}"
                    git push ${gitCredentialsUrl}
                fi
            """
        }
        echo "Deployment Complete"
    }
}
