#!/usr/bin/env groovy

/**
 * Send notifications based on build status string
 */
def call(Map map = [:]) {
    buildStatus = map.buildStatus
    slackChannel = map.slackChannel ?: env.SLACK_CHANNEL
    slackToken = map.slackToken ?: env.SLACK_TOKEN
    subject = "${buildStatus}: ${env.JOB_NAME} [BUILD #${env.BUILD_NUMBER}] [GIT COMMIT: ${env.GIT_COMMIT}]"
	summary = "${subject} (${env.BUILD_URL})"
	colors = colorCodes()

	if (buildStatus == 'STARTED') {
		colorCode = '#FFFF00' // Yellow
	} else if (buildStatus == 'SUCCESS') {
		colorCode = '#00FF00' // Green
	} else {
		colorCode = '#FF0000' // Red
	}

    statusMessage(status: "Sending Slack Message", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}SLACK_CHANNEL:${colors.none} ${slackChannel}
${colors.magenta}BUILD_STATUS:${colors.none} ${buildStatus}
${colors.magenta}SUBJECT:${colors.none} ${subject}
${colors.magenta}COLOR_CODE:${colors.none} ${colorCode}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }

	slackSend(
        channel: slackChannel,
        color: colorCode,
        message: summary,
        teamDomain: "legalzoom",
        token: slackToken
    )
}
