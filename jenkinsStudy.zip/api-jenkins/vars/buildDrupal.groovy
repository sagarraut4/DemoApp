#!/usr/bin/env groovy

/**
 * A generic pipeline function for building Drupal
 */

def call(Map map = [:]) {
    gulpTasks = map.gulpTasks
    targetEnvironment = map.targetEnvironment ?: env.TARGET_DRUPAL_ENVIRONMENT
    sourceDirectory = map.sourceDirectory ?: env.SOURCE_DIRECTORY
    productName = map.productName ?: env.PRODUCT_NAME
    colors = colorCodes()

    // ============================================= [ param assertions ] ==============================================

    try {
        assert gulpTasks != null
        assert targetEnvironment != null
        assert sourceDirectory != null
    } catch(NullPointerException e) {
        ansiColor('xterm') {
            error("${colors.red}One or more required parameters were null:${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }

    // =============================================== [ log headers ] =================================================

    statusMessage(status: "Building ${productName}", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}SOURCE_DIRECTORY:${colors.none} ${sourceDirectory}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }

    // ================================================ [ update npm ] =================================================

    ansiColor('xterm') {
        echo "${colors.bold}(Step 1 of 2) Updating 'npm'${colors.none}"
    }
    try {
        dir(sourceDirectory) {
            sh("npm update")
        }
    } catch(e) {
        ansiColor('xterm') {
            error("${colors.red}An exception occurred while trying to update 'npm':" +
                    "${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }

    // =============================================== [ run gulp tasks ] ==============================================

    ansiColor('xterm') {
        echo "${colors.bold}(Step 2 of 2) Running Gulp Tasks${colors.none}"
    }
    try {
        dir(sourceDirectory) {
            gulpTasks.each { task ->
                sh("gulp ${task}")
            }
        }
    } catch(e) {
        ansiColor('xterm') {
            error("${colors.red}An exception occurred while trying to run a gulp task:" +
                    "${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }

}
