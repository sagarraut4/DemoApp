#!/usr/bin/env groovy

/**
 * A generic pipeline for automated testing
 */

def call(body) {
    // evaluate the body block, and collect configuration into the object
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    appName = config.appName ?: env.APP_NAME
    alias = config.alias ?: env.TEST_AUTOMATION_ALIAS
    testEnvironment = (config.testEnvironment ?: env.TEST_ENVIRONMENT).toLowerCase()
    testType = config.testType ?: env.TEST_TYPE
    testTarget = env.TEST_VIP ?: env.TEST_ENVIRONMENT
    currentBuild.displayName = "#${BUILD_NUMBER}" + " - " + "${testTarget}".toUpperCase()
    colors = colorCodes()
	mailRecipients = config.mailRecipients ?: "DL-TestAutomation-All@legalzoom.com,dl-devops@legalzoom.com"

    try {
        assert appName != null
        assert alias != null
        assert testEnvironment != null
        assert testType != null
        assert testTarget != null
    } catch(NullPointerException e) {
        error("One or more required parameters were missing: ${e}")
    }

    testAutomationArtifact = config.testAutomationArtifact ?: "test-automation-${testType}-${testEnvironment}-snapshot.zip"
    uncompressedArtifactDestinationPath = config.uncompressedArtifactDestinationPath ?: ".\\automatedTests"
    htmlReportFile = config.htmlReportFile ?: "${testEnvironment}".toUpperCase() + ".html"
    htmlReportFiles = config.htmlReportFiles ?: "DEV.html|QA.html|STG.html|Prod.html"
    htmlReportName = config.htmlReportName ?: "Latest Test Results"
    outputFile = config.outputFile ?: "${testEnvironment}_test_output.xml"
    failureNewThreshold = config.failureNewThreshold ?: ''
    failureThreshold = config.failureThreshold ?: ''
    unstableNewThreshold = config.unstableNewThreshold ?: '0'
    unstableThreshold = config.unstableThreshold ?: '0'
    promoteApiIfTestsPass = "${env.PROMOTE_API_IF_TESTS_PASS}" ?: "no"

    if (testType == "api") {
        nodeLabel = config.nodeLabel ?: "ta"
    } else {
        if (testEnvironment == "qa") {
            nodeLabel = "ta-qa-win"
        } else if (testEnvironment == "prod") {
            nodeLabel = "ta"
        } else {
            error("invalid testEnvironment: currently only 'qa' and 'prod' are eligible test environments")
        }
    }

    pipeline {
        options{
            buildDiscarder(logRotator(numToKeepStr: '30'))
            disableConcurrentBuilds()
            timeout(time: 150, unit: 'MINUTES')
            timestamps()
        }

        environment {
            // mandatory
            APP_NAME = "${appName}"
            TEST_AUTOMATION_ALIAS = "${alias}"
            TEST_AUTOMATION_ARTIFACT = "${testAutomationArtifact}"
            TEST_ENVIRONMENT = "${testEnvironment}".toLowerCase()
            TEST_TARGET = "${testTarget}".toLowerCase()
            TEST_TYPE = "${testType}"
            UNCOMPRESSED_ARTIFACT_DESTINATION_PATH = "${uncompressedArtifactDestinationPath}"
            HTML_REPORT_NAME = "${htmlReportName}"
            HTML_REPORT_FILE = "${htmlReportFile}"
            OUTPUT_FILE = "${outputFile}"
            UNSTABLE_NEW_THRESHOLD = "${unstableNewThreshold}"
            UNSTABLE_THRESHOLD = "${unstableThreshold}"
            FAILURE_NEW_THRESHOLD = "${failureNewThreshold}"
            FAILURE_THRESHOLD = "${failureThreshold}"
            SLACK_CHANNELS= "${env.SLACK_CHANNELS}"
            NODE_LABEL = "${nodeLabel}"
            // constant
            SLACK_TOKEN = credentials('slack-token')
	    BUILD_USER_ID=setBuildUser()
        }

        agent {
            node {
                label "${nodeLabel}"
                customWorkspace "D:\\Jenkins\\8e52cda1\\workspace\\${JOB_NAME}\\"
            }
        }

        stages {
            stage('Prepare') {
                steps {
                    statusMessage(status: "Preparing Workspace For Test Automation", level: "info")
                    ansiColor('xterm') {
                        echo "${colors.bold}(Step 1 of 4) Deleting Previous Tests${colors.none}"
                    }
                    powershell("""
                        if (Test-Path "${env.TEST_AUTOMATION_ARTIFACT}") {
                            Remove-Item -Path "${env.TEST_AUTOMATION_ARTIFACT}" -Recurse -Force
                        }
                        if (Test-Path "${env.UNCOMPRESSED_ARTIFACT_DESTINATION_PATH}") {
                            Remove-Item -Path "${env.UNCOMPRESSED_ARTIFACT_DESTINATION_PATH}" -Recurse -Force
                        }
                    """)

                    ansiColor('xterm') {
                        echo "${colors.bold}(Step 2 of 4) Downloading Artifact: ${env.TEST_AUTOMATION_ARTIFACT}${colors.none}"
                    }
                    downloadArtifact(
                        sourceRepo: "TestAutomation",
                        sourceArtifact: "${env.TEST_AUTOMATION_ARTIFACT}",
                        targetPath: ".\\"
                    )

                    ansiColor('xterm') {
                        echo "${colors.bold}(Step 3 of 4) Uncompressing Artifact: ${env.TEST_AUTOMATION_ARTIFACT}${colors.none}"
                    }
                    powershell("""
                        Expand-Archive "${env.TEST_AUTOMATION_ARTIFACT}" -DestinationPath "${env.UNCOMPRESSED_ARTIFACT_DESTINATION_PATH}" -Force
                    """)

                    ansiColor('xterm') {
                        echo "${colors.bold}(Step 4 of 4) Creating HTML Report Directory${colors.none}"
                    }
                    script{
                        env.HTML_REPORT_DIRECTORY = "D:\\Jenkins\\8e52cda1\\testAutomationReports\\${JOB_NAME}"
                        powershell("mkdir ${env.HTML_REPORT_DIRECTORY} -Force")
                    }
                }
            }

            stage("Run Test Automation") {
                steps {
                    script {
                        if (testType == "api") {
                            runApiTests(testEnvironment: "${env.TEST_ENVIRONMENT}")
                            if (promoteApiIfTestsPass == "yes") {
                                /**
                                 * Was pulling my hair out trying to figure out why Jenkins was refusing to trigger Rundeck
                                 * jobs in post{ always{} } when builds were unsuccessful, but just couldn't figure it out.
                                 * So instead we'll invoke promoteAPI(). It will trigger a rundeck job waits until
                                 * this test automation run completes before slacking test results and promoting, if
                                 * eligible.
                                 */
                                promoteAPI(
                                    serviceName: env.APP_NAME,
                                    artifactName: getArtifactInEnvironment(serviceName: env.APP_NAME, environment: env.TEST_ENVIRONMENT),
                                    currentEnvironment: env.TEST_ENVIRONMENT,
                                    targetEnvironment: getUpperEnvironment(environment: env.TEST_ENVIRONMENT),
                                    slackChannel: env.SLACK_CHANNELS,
                                    waitUntilBuildIsComplete: "yes",
                                )
                            } else {
                                recordTestResults(
                                    appName: env.APP_NAME,
                                    environment: env.TEST_ENVIRONMENT,
                                    testType: env.TEST_TYPE,
                                    artifactName: getArtifactInEnvironment(serviceName: env.APP_NAME, environment: env.TEST_ENVIRONMENT),
                                    slackChannel: env.SLACK_CHANNELS,
                                    waitUntilBuildIsComplete: "yes",
                                )
                            }
                        } else {
                            runWebTests(
                                    category: "${env.TEST_AUTOMATION_ALIAS}",
                                    testEnvironment: "${env.TEST_ENVIRONMENT}",
                                    testTarget: "${env.TEST_TARGET}",
                                )                            
                            recordTestResults(
                                appName: env.APP_NAME,
                                environment: env.TEST_ENVIRONMENT,
                                testType: env.TEST_TYPE,
                                artifactName: getArtifactInEnvironment(serviceName: env.APP_NAME, environment: env.TEST_ENVIRONMENT),
                                slackChannel: env.SLACK_CHANNELS,
                                waitUntilBuildIsComplete: "yes",
                            )
                        }
                    }
                }
            }
        }

        post {
            always {
                statusMessage(status: "Publishing Test Reports", level: "info")
                script {
                    reportFiles = powershell(
                        returnStdout: true,
                        script: """(Get-ChildItem '${env.HTML_REPORT_DIRECTORY}' | where {\$_ -match '${htmlReportFiles}'}) -join ',' """
                    )
                }

                publishHTML (
                    target: [
                        allowMissing: false,
                        alwaysLinkToLastBuild: true,
                        keepAll: true,
                        reportDir: "${env.HTML_REPORT_DIRECTORY}",
                        reportFiles: "${reportFiles}",
                        reportName: "${env.HTML_REPORT_NAME}"
                    ]
                )

                script {
                    dir("${env.HTML_REPORT_DIRECTORY}"){
                        try{
                            timeout(time: 5, unit: 'MINUTES') {
                                if (testType == "api") {
                                    publishXunitReport(
                                        unstableNewThreshold: "${env.UNSTABLE_NEW_THRESHOLD}",
                                        unstableThreshold: "${env.UNSTABLE_THRESHOLD}",
                                        outputFile: "${env.OUTPUT_FILE}"
                                    )
                                } else {
                                    nunit(testResultsPattern: "${env.OUTPUT_FILE}")
                                }
                            }
                        } catch(e) {
                            timeout(time: 5, unit: 'MINUTES') {
                                if (testType == "api") {
                                    publishXunitReport(
                                        unstableNewThreshold: "${env.UNSTABLE_NEW_THRESHOLD}",
                                        unstableThreshold: "${env.UNSTABLE_THRESHOLD}",
                                        outputFile: "${env.OUTPUT_FILE}"
                                    )
                                } else {
                                    nunit(testResultsPattern: "${env.OUTPUT_FILE}")
                                }
                            }
                        }
                    }

					def result = currentBuild.result
					def level = "success"
					if (currentBuild.result == 'FAILURE' || currentBuild.result == 'UNSTABLE')
					{
						level ="failure"
					}
						emailext(
								 body: "Build Log: ${env.BUILD_URL}console",
								 recipientProviders: [[$class: 'CulpritsRecipientProvider']],
								 subject: "[JENKINS]: ${env.JOB_NAME} (${env.BUILD_NUMBER}) - ${result}!",
								 to: "${mailRecipients}",
								 replyTo: "${mailRecipients}",
								)
				    
					statusMessage(status: "Test Automation ${result}", level: "${level}")
                }
                statusMessage(status: "Archiving APIResponseData.csv", level: "info")
                archiveArtifacts allowEmptyArchive: true, artifacts: '**/APIResponseData.csv', caseSensitive: false
            }
         }
    }
}

def setBuildUser(){
	def userName
    wrap([$class: 'BuildUser']) { 
        userName="${env.BUILD_USER_ID}"
    }
    return "${userName}"
}

