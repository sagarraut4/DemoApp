#!/usr/bin/env groovy

/**
 * A generic pipeline function for executing the angular deploy job in Rundeck
 */

def call(Map map = [:]) {
    // optional
    project = map.project ?: env.SERVICE_NAME
    artifact = map.artifactName ?: env.ARTIFACT_NAME
    environment = map.environment ?: env.ENVIRONMENT
    extension = "zip"
    deployFilesOnly = 'true'
    colors = colorCodes()

    try {
        assert project != null
        assert artifact != null
        assert environment != null
    } catch (e) {
        error("One or more required parameters were null: ${e}")
    }

    // luigiweb endpoints
    luigiWebBaseUrl = "https://luigiweb.devops.legalzoom.com"
    extensionEndpoint = "${luigiWebBaseUrl}/services/website/${project}/attributes?key=artifactory.ext"
    extension = httpRequest("${extensionEndpoint}").getContent()[1..-3].replace('"','')
    repoEndpoint = "${luigiWebBaseUrl}/services/website/${project}/attributes?key=artifactory.repo"
    repo = httpRequest("${repoEndpoint}").getContent()[1..-3].replace('"','')

    statusMessage(status: "Deploying", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}PROJECT_NAME:${colors.none} ${project}
${colors.magenta}ARTIFACT:${colors.none} ${artifact}
${colors.magenta}TARGET_ENVIRONMENT:${colors.none} ${environment}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }

    slackMessage = "by jenkins <${env.BUILD_URL}|build #${env.BUILD_NUMBER}>"

    runRundeckJob(
        jobId: "b761130a-961e-4e95-a15c-6f1f0396ce68",
        jobOptions: "project=${project}\nartifact=${artifact}\nrepo=${repo}\nenvironment=${environment}\nextension=${extension}\ndeploy_files_only=${deployFilesOnly}"
    )
    echo "Deployment Complete"

}
