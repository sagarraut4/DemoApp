#!/usr/bin/env groovy

/**
 * A generic pipeline function for building and pushing docker
 */

def call(Map map = [:]) {
    // optional
    project = map.project ?: env.SERVICE_NAME
    environment = map.environment ?: null
    org = map.org
    repo = map.repo ?: env.SERVICE_NAME
    imageTag = map.imageTag ?: 'latest'
    colors = colorCodes()
    try {
        assert project != null
        assert org != null
        assert imageTag != null
    } catch (e) {
        error("One or more required parameters were null: ${e}")
    }
    statusMessage(status: "Deploying", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}PROJECT_NAME:${colors.none} ${project}
${colors.magenta}TARGET_ENVIRONMENT:${colors.none} ${environment}
${colors.magenta}ORG:${colors.none} ${org}
${colors.magenta}REPO:${colors.none} ${repo}
${colors.magenta}IMAGE TAG:${colors.none} ${imageTag}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }
    container('docker') {
        dir("empty-dir")
        {
        withCredentials([
                            usernamePassword(
                                credentialsId: 'Artifactory',
                                passwordVariable: 'PASSWORD',
                                usernameVariable: 'USER'
                            )
                        ]) {
            if(environment != null){
                sh """
                docker login artifactory.legalzoom.com -u ${USER} -p ${PASSWORD}
                docker tag artifactory.legalzoom.com/docker/${org}/${repo}/${repo}-${environment}:${imageTag} artifactory.legalzoom.com/docker/${org}/${repo}/${repo}-${environment}:latest
                docker push artifactory.legalzoom.com/docker/${org}/${repo}/${repo}-${environment}:${imageTag}
                docker push artifactory.legalzoom.com/docker/${org}/${repo}/${repo}-${environment}:latest
                """
            }else{
                sh """
                docker login artifactory.legalzoom.com -u ${USER} -p ${PASSWORD}
                docker tag artifactory.legalzoom.com/docker/${org}/${repo}/${repo}:${imageTag} artifactory.legalzoom.com/docker/${org}/${repo}/${repo}:latest
                docker push artifactory.legalzoom.com/docker/${org}/${repo}/${repo}:${imageTag}
                docker push artifactory.legalzoom.com/docker/${org}/${repo}/${repo}:latest
                """
            }
            }
        }
    }
}
