#!/usr/bin/env groovy

/**
 * A generic pipeline function that returns an ansii color code map
 */

def call() {
    return [
        blue: '\033[36m',
        cyan: '\033[96m',
        green: '\033[32m',
        magenta: '\033[35m',
        yellow: '\033[93m',
        red: '\033[91m',
        bold: '\033[1m',
        underline: '\033[4m',
        none: '\033[0m',
    ]
}

