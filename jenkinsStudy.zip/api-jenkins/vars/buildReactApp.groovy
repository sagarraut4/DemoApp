#!/usr/bin/env groovy

/**
 * A generic pipeline function for building react applications
 */

def call(Map map = [:]) {
    def targetEnvironment = map.targetEnvironment
    // optional
    def appName = map.appName ?: env.PRODUCT_NAME
    def href =  map.href ?: env.HREF    
    def gulpTasks = map.gulpTasks ?: null
    def verbosity = map.verbosity ?: "development"
    def sourceDirectory = map.sourceDirectory ?: env.SOURCE_DIRECTORY
    def outputDirectory = map.outputDirectory ?: "${env.WORKSPACE}/artifact"
    def npmRegistryName = map.npmRegistryName ?: env.NPM_REGISTRY_NAME
    def npmRegistryUrl = map.npmRegistryUrl ?: env.NPM_REGISTRY_URL
    def buildWorkspace = map.buildWorkspace ?: "${env.WORKSPACE}/build/${targetEnvironment}"
    def artifactWorkspace = map.artifactWorkspace ?: "${env.WORKSPACE}/artifact/${targetEnvironment}"
    def stashedWorkspace = map.stashedWorkspace ?: env.REACT_BUILD_WORKSPACE
    def appendConfig = map.appendConfig ?: null
    def addHashToFiles = map.addHashToFiles.toBoolean() ?: false
    def useNewCdn = map.useNewCdn ?: "false"
    def colors = colorCodes()
    def addPeerDependencies = map.addPeerDependencies ?: null

    try {
        assert targetEnvironment != null
        assert appName != null
        assert href != null        
        assert sourceDirectory != null
        assert npmRegistryName != null
        assert npmRegistryUrl != null
    } catch(NullPointerException e) {
        error("One or more required parameters were missing: ${e}")
    }

    map.each{println it.key +" "+it.value}


    statusMessage(status: "Building", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}APP_NAME:${colors.none} ${appName}
${colors.magenta}TARGET_BUILD_ENVIRONMENT:${colors.none} ${targetEnvironment}
${colors.magenta}APPEND_CONFIG:${colors.none} ${appendConfig}
${colors.magenta}BUILD_WORKSPACE:${colors.none} ${buildWorkspace}
${colors.magenta}HREF:${colors.none} ${href}
${colors.magenta}VERBOSITY:${colors.none} ${verbosity}
${colors.magenta}OUTPUT_DIRECTORY:${colors.none} ${outputDirectory}
${colors.magenta}NPM_REGISTRY_NAME:${colors.none} ${npmRegistryName}
${colors.magenta}NPM_REGISTRY_URL:${colors.none} ${npmRegistryUrl}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }
    dir(buildWorkspace) {
        unstash stashedWorkspace
        sh "ls -lth"
        ansiColor('xterm') {
            echo "${colors.bold}(Step 1 of 2) Installing Dependencies${colors.none}"
        }
        try {
            sh("npm config set registry ${npmRegistryUrl}")
                dir("${env.SOURCE_DIRECTORY}") {
                    sh("node -v")
                    sh("rm -rf node_modules")
                    sh("cp .env.${targetEnvironment} .env.production")
                    sh("npm install --legacy-peer-deps")
                }
        } catch (e) {
            error("Failed to install dependencies: ${e}")
            return
        }

        ansiColor('xterm') {
            echo "${colors.bold}(Step 2 of 2) Running 'npm run build'${colors.none}"
        }
        try {
            sh("mkdir -p ${outputDirectory}")
        } catch(e) {
            error("Failed to create  ${outputDirectory}: ${e}")
            return
        }

        try {
            dir("${sourceDirectory}") {
                def configurationValue = ""
                if (appendConfig != 'null') {
                    configurationValue = targetEnvironment + appendConfig
                } else {
                    configurationValue = targetEnvironment
                }

                withCredentials([[
                    $class: 'AmazonWebServicesCredentialsBinding',
                    credentialsId: 's3-cdn-access',
                    accessKeyVariable: 'AWS_ACCESS_KEY_ID',
                    secretKeyVariable: 'AWS_SECRET_ACCESS_KEY'
                ]]) {
                    def shellScriptArray = ["npm run build",
                                            "--configuration=${configurationValue}"]
                    def publicUrl = ""

                    if (!addHashToFiles) {
                        shellScriptArray << "--output-hashing=none"
                    }

                    if (addHashToFiles && targetEnvironment != "prod") {
                        if(env.CREATE_AND_UPLOAD_ARTIFACT == "yes" || (env.RUN_CYPRESS_TESTS == "true" && env.TARGET_ENVIRONMENT == "dev" && (env.BRANCH_NAME ==~ /^PR-[0-9]+$/ || env.BRANCH_NAME ==~ /^develop$/)))  {
                            ansiColor('xterm') {
                                publicUrl = "https://preprod.legalzoomcdn.net/${appName}/${targetEnvironment}/${href}/"
                                shellScriptArray << "--deploy-url=https://preprod.legalzoomcdn.net/${appName}/${targetEnvironment}/${href}/"
                                shellScriptArray << "\nrsync -avz ${buildWorkspace}/build/* ${artifactWorkspace}/${href}"
                                shellScriptArray << "\naws s3 sync ${artifactWorkspace}/${href} s3://preprod.legalzoomcdn.net/${appName}/${targetEnvironment}/${href}/"
                            }
                        }
                    } else if (addHashToFiles && targetEnvironment == "prod" && useNewCdn == "true") {
                        ansiColor('xterm') {
                            publicUrl = "https://legalzoomcdn.net/${appName}/${href}/"
                            shellScriptArray << "--deploy-url=https://legalzoomcdn.net/${appName}/${href}/"
                            shellScriptArray << "\nrsync -avz ${buildWorkspace}/build/* ${artifactWorkspace}/${href}"
                            shellScriptArray << "\naws s3 sync ${artifactWorkspace}/${href} s3://legalzoomcdn.net/${appName}/${href}/"
                        }
                    }
                    def shellScript = "PUBLIC_URL=" + publicUrl + " " + shellScriptArray.join(" ")
                    echo "executing shell script: ${shellScript}"
                    sh(shellScript)
                }
            }
        } catch(e) {
            error("Failed to build ${appName}: ${e}")
            return
        }
    }
    echo "Build Complete"
}
