#!/usr/bin/env groovy

/**
 * A generic pipeline function for building angular applications
 */

def call(Map map = [:]) {
    // mandatory
    platforms = map.platforms
    // optional
    appName = map.appName ?: env.PRODUCT_NAME
    environment = map.environment ?: env.ENVIRONMENT
    href = map.href ?: env.HREF
    slackChannel = map.slackChannel ?: env.SLACK_CHANNEL
    sourceDirectory = map.sourceDirectory ?: env.SOURCE_DIRECTORY
    outputDirectory = map.outputDirectory ?: "./artifact"

    try {
        assert map.platforms != null
    } catch(NullPointerException e) {
        error("One or more required parameters were missing: ${e}")
    }

    echo """Build Info:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
APP_NAME = ${appName}
ENVIRONMENT = ${environment}
PLATFORMS = ${platforms}
HREF = ${href}
SLACK_CHANNEL = ${slackChannel}
NODE_LABEL = ${env.NODE_LABEL}
NODE = ${env.NODE_NAME}
"""

    echo "Building"
    try {
        echo "installing dependencies"
        sh("npm-recursive-install")

        echo "running gulp tasks"
        sh("./gulpTasks.sh")

        dir("${sourceDirectory}") {
            platforms.each { platform ->
                echo "building for ${platform}"

                switch(platform) {
                    case "mobile":
                        href = "m-${href}"
                        break;
                    case "mobile-native":
                        href = "mn-${href}"
                        break;
                    case "desktop-glo":
                        href = "${href}-glo"
                        break;
                    case "mobile-glo":
                        href = "m-${href}-glo"
                        break;
                    default:
                        href = "${href}"
                        break;
                }

                ansiColor('xterm') {
                    sh("""
                       ng build ${platform} \
                        --configuration=${environment} \
                        --base-href /${href}/ \
                        --output-path="${outputDirectory}/${href}" \
                        --output-hashing=none
                        """
                    )
                }
            }
        }
    } catch(e) {
        error("Failed to build ${appName}: ${e}")
        return
    }
    echo "Build Complete"
}
