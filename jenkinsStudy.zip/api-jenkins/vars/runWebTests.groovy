#!/usr/bin/env groovy

/**
 * A generic pipeline function for running automated web tests
 */

def call(Map map = [:]) {
    testEnvironment = map.testEnvironment ?: env.TEST_ENVIRONMENT
    outputFile = map.outputFile ?: env.OUTPUT_FILE
    htmlReportDirectory = map.htmlReport ?: env.HTML_REPORT_DIRECTORY
    htmlReport = map.htmlReport ?: env.HTML_REPORT_FILE
    testsBaseDirectory = map.testsBaseDirectory ?: env.UNCOMPRESSED_ARTIFACT_DESTINATION_PATH
    category = map.category ?: env.TEST_AUTOMATION_ALIAS
    numOfWorkers = map.numOfWorkers ?: 10
    testTarget = map.testTarget ?: env.TEST_TARGET
    /*sourceDllConfig = map.sourceDllConfig ?: "${env.WORKSPACE}\\automatedTests\\Config\\Testing.Web.${testTarget}.dll.config"
    targetDllConfig = map.sourceDllConfig ?: "${testsBaseDirectory}\\Testing.Web.dll.config"*/
    colors = colorCodes()

    try {
        assert outputFile != null
        assert htmlReport != null
        assert testsBaseDirectory != null
        assert testEnvironment != null
        assert testTarget != null
    } catch(e) {
        error("One or more required parameters were missing: ${e}")
    }

    statusMessage(status: "Starting Test Automation", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}TEST_TYPE:${colors.none} ${env.TEST_TYPE}
${colors.magenta}TEST_AUTOMATION_ALIAS:${colors.none} ${env.TEST_AUTOMATION_ALIAS}
${colors.magenta}TEST_ENVIRONMENT:${colors.none} ${testEnvironment}
${colors.magenta}TEST_TARGET:${colors.none} ${testTarget}
${colors.magenta}TEST_AUTOMATION_ARTIFACT:${colors.none} ${env.TEST_AUTOMATION_ARTIFACT}
${colors.magenta}TESTS_BASE_DIRECTORY:${colors.none} ${testsBaseDirectory}
${colors.magenta}OUTPUT_FILE:${colors.none} ${outputFile}
${colors.magenta}HTML_REPORT_DIRECTORY:${colors.none} ${htmlReportDirectory}
${colors.magenta}HTML_REPORT_FILE:${colors.none} ${htmlReport}
${colors.magenta}NUM_OF_WORKERS:${colors.none} ${numOfWorkers}
${colors.magenta}UNSTABLE_NEW_THRESHOLD:${colors.none} ${env.UNSTABLE_NEW_THRESHOLD}
${colors.magenta}UNSTABLE_THRESHOLD:${colors.none} ${env.UNSTABLE_THRESHOLD}
${colors.magenta}FAILURE_NEW_THRESHOLD:${colors.none} ${env.FAILURE_NEW_THRESHOLD}
${colors.magenta}FAILURE_THRESHOLD:${colors.none} ${env.FAILURE_THRESHOLD}
${colors.magenta}NODE_LABEL:${colors.none} ${env.NODE_LABEL}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }

    ansiColor('xterm') {
        echo "${colors.bold}(Step 1 of 3) Preparing Testing.Web.dll.config${colors.none}"
    }
    /*
    try {
        powershell("""cat ${sourceDllConfig} | Out-File -Encoding "UTF8" ${targetDllConfig}""")
    } catch(e) {
        error("Exception occurred while preparing ${sourceDllConfig}: ${e}")
    }
    */
    ansiColor('xterm') {
        echo "${colors.bold}(Step 2 of 3) Running ${category} Tests (${testEnvironment})${colors.none}"
    }

    testEnvironmentUpper = testEnvironment.toUpperCase()
    try {
        dir("${testsBaseDirectory}") {
            env.JOB_NAME = "${env.JOB_NAME}_${testEnvironmentUpper}"
            bat("""
                nunit3-console.exe Testing.Web.dll --where "cat == ${category}" --workers=${numOfWorkers} --result=${htmlReportDirectory}\\${outputFile}
                IF %ERRORLEVEL% GTR 0 (
                    EXIT /B 1
                ) ELSE (
                    EXIT /B %ERRORLEVEL%
                )
            """)
            env.JOB_NAME = "${env.JOB_NAME}".replace("_${testEnvironmentUpper}", "")
        }
    } catch(e) {
        env.JOB_NAME = "${env.JOB_NAME}".replace("_${testEnvironmentUpper}", "")
        echo "Exception occurred while executing nunit3-console.exe: ${e}"
    }

    ansiColor('xterm') {
        echo "${colors.bold}(Step 3 of 3) Generating HTML Report${colors.none}"
    }

    try {
        dir("${testsBaseDirectory}") {
            bat("""%userprofile%\\.nuget\\packages\\reportunit\\1.2.3\\lib\\net40\\ReportUnit.exe ${htmlReportDirectory}\\${outputFile} ${htmlReportDirectory}\\${htmlReport}""")
        }
    } catch(e) {
        error("Exception occurred while executing ReportUnit.exe: ${e}")
    }

    ansiColor('xterm') {
        echo "${colors.bold}Test Automation Complete${colors.none}"
    }

}
