#!/usr/bin/env groovy

/**
 * A generic pipeline function for publishing NPM Packages
 */

def call(Map map = [:]) {
    def sourceDirectory = map.sourceDirectory
    def packageName = map.packageName
    def version = map.version
    def tarFile = map.tarFile ?: null
    def tag = map.tag ?: "testing"
    def colors = colorCodes()

    try {
        assert sourceDirectory != null
        assert packageName != null
        assert version != null
    } catch(NullPointerException e) {
        ansiColor('xterm') {
            error("${colors.red}One or more required parameters were null:${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }

    statusMessage(status: "Publishing NPM", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}SOURCE_DIRECTORY:${colors.none} ${sourceDirectory}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }

    try {
        dir(sourceDirectory) {
            sh "npm config set registry https://artifactory.legalzoom.com/artifactory/api/npm/npm/"
            //NEED TO RESOLVE SCRIPT ISSUE IN shReturn - temp comment out to unblock
            // if (tarFile != null) {
            //     shReturn = sh (
            //       script: "npm view @legalzoom/${packageName} versions | grep ${version}",
            //       returnStdout: true
            //       ).trim()
            //     echo "grep returned ${shReturn}"
            //     if (shReturn?.trim()){ //the query found a version matching
            //       echo "running unpublish @legalzoom/${packageName}@${version}"
            //       sh "npm unpublish @legalzoom/${packageName}@${version}"
            //     }
            //
            //     echo "running publish ${tarfile} tag ${tag}"
            //     sh "npm publish ${tarFile} --tag=${tag}"
            // }  else {
            //     echo "running publish tag ${tag}"
            //     sh "npm publish --tag=${tag}"
            // }

            if (tarFile != null) {
                sh "npm publish ${tarFile} --tag=${tag}"
            }  else {
                sh "npm publish --tag=${tag}"
            }
        }
    } catch(e) {
        ansiColor('xterm') {
            error("${colors.red}Failed to publish NPM Package at ${sourceDirectory}:${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }

}
