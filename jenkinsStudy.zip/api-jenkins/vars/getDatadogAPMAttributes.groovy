#!/usr/bin/env groovy

/**
 * A generic pipeline function to fetch Datadog APM Attributes from YAML configs
 */

def call(Map map = [:]) {
    productName = map.productName
    productType = map.productType
    datadogAPMPackageName = "Datadog.Trace.ClrProfiler.Managed"

    if (productType == "api") {
        datadogAPMBaseEndpoint = "https://luigiweb.devops.legalzoom.com/apiservices/${productName}/datadog/apm"
    } else {
        datadogAPMBaseEndpoint = "https://luigiweb.devops.legalzoom.com/staticsite/${productName}/datadog/apm"
    }

    datadogAPMEnabledEndpoint = "${datadogAPMBaseEndpoint}/enabled"
    datadogAPMVersionEndpoint = "${datadogAPMBaseEndpoint}/version"
    colors = colorCodes()

    statusMessage(status: "Getting ${productName}'s Datadog APM Attributes", level: "info")

    ansiColor('xterm') {
        echo "${colors.bold}(Step 1 of 2) Determining if Datadog APM integration is enabled${colors.none}"
    }

    try {
        includeDatadogAPMPackage = readJSON(text: httpRequest("${datadogAPMEnabledEndpoint}").getContent())[0]
    } catch (e) {
        ansiColor('xterm') {
            error("${colors.red}failed to get Datadog APM 'enabled' attribute from ${datadogAPMEnabledEndpoint} :${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }

    ansiColor('xterm') {
        echo "${colors.bold}(Step 2 of 2) Determining version of Datadog APM package to integrate${colors.none}"
    }

    try {
        datadogAPMPackageVersion = readJSON(text: httpRequest("${datadogAPMVersionEndpoint}").getContent())[0]
    } catch (e) {
        ansiColor('xterm') {
            error("${colors.red}failed to get Datadog APM 'version' attribute from ${datadogAPMVersionEndpoint} :${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}INCLUDE_DATADOG_APM_PACKAGE:${colors.none} ${includeDatadogAPMPackage}
${colors.magenta}DATADOG_APM_PACKAGE_NAME:${colors.none} ${datadogAPMPackageName}
${colors.magenta}DATADOG_APM_PACKAGE_VERSION:${colors.none} ${datadogAPMPackageVersion}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }

    return [
        includeDatadogAPMPackage: includeDatadogAPMPackage,
        datadogAPMPackageName: datadogAPMPackageName,
        datadogAPMPackageVersion: datadogAPMPackageVersion,
    ]

}
