#!/usr/bin/env groovy

/**
 * A generic pipeline for versioned gulp applications
 */

def call(body) {
    // evaluate the body block, and collect configuration into the object
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    nodeLabel = config.nodeLabel ?: "frontend-lighthouse"
    sourceDirectory = config.sourceDirectory ?: "./"
    target = config.target
    gulpVars = config.gulpVars ?: null
    gulpTasks = config.gulpTasks ?: null
    destRepo = config.destRepo ?: null
    npmRegistryName = config.npmRegistryName ?: "@legalzoom:registry"
    npmRegistryUrl = config.npmRegistryUrl ?: "https://artifactory.legalzoom.com/artifactory/api/npm/npm/"
    customTargetEnvironment = config.customTargetEnvironment ?: null
    lighthouseBranch = config.lighthouseBranch ?: "develop"
    lighthouseUrls = config.lighthousePageUrls ?: null
    serviceName = config.serviceName ?: null
    buildType = config.buildType ?: "html"
    deploymentRepo = config.deploymentRepo ?: null
    kubeDeploy = config.kubeDeploy ?: "false"
    multipleDeploy = config.multipleDeploy?: "false"
    containerGithubUrl = config.containerGithubUrl ?: null
    ssiPath = config.ssiPath ?: "NONE"
    useNewCdn = config.useNewCdn ?: "false"

    try {
        assert config.appName != null
        assert config.slackChannel != null
        assert gulpVars != null
        assert gulpTasks != null
    } catch(NullPointerException e) {
        error("One or more required parameters were missing: ${e}")
    }

    pipeline {
        agent {
            kubernetes {
              yaml """\
                apiVersion: v1
                kind: Pod
                metadata:
                  labels:
                    some-label: some-label-value
                spec:
                  securityContext:
                    fsGroup: 2000
                  containers:
                  - name: jnlp
                    image: artifactory.legalzoom.com/docker/jenkinsagentsiteextlh:1.8.2
                    imagePullPolicy: Always
                    tty: true
                    resources:
                    requests:
                      cpu: '3'
                      memory: '6Gi'
                    limits:
                      cpu: '3'
                      memory: '6Gi'
                  - name: docker
                    image: artifactory.legalzoom.com/docker-remote/docker:dind
                    securityContext:
                      privileged: true
                  - name: kustomize
                    image: k8s.gcr.io/kustomize/kustomize:v3.8.7
                    tty: true
                    command:
                    - cat
                  nodeSelector:
                    kubernetes.io/os: linux
                    kubernetes.io/arch: amd64
                """.stripIndent()
                workspaceVolume dynamicPVC(accessModes: 'ReadWriteOnce', requestsSize: '30Gi')
            }
        }

        options{
            buildDiscarder(logRotator(numToKeepStr: '30'))
            disableConcurrentBuilds()
            timeout(time: 20, unit: 'MINUTES')
            timestamps()
        }

        environment {
            // mandatory
            PRODUCT_NAME = "${config.appName}"
            PRODUCT_NAME_LOWER = "${config.appName}".toLowerCase()
            COMPONENT_NAME = "${config.appName}"
            TARGET = "${config.target}"
            SOURCE_DIRECTORY = "${sourceDirectory}"
            SLACK_CHANNEL= "${config.slackChannel}"
            NODE_LABEL = "${nodeLabel}"
            // constant
            ANGULAR_BUILD_WORKSPACE = "angularBuildWorkspace"
            SLACK_TOKEN = credentials('slack-token')
            NPM_REGISTRY_NAME = "${npmRegistryName}"
            NPM_REGISTRY_URL = "${npmRegistryUrl}"
            NPM_SOURCE_DIRECTORY = "${npmSourceDirectory}"
            SERVICE_NAME = "${config.serviceName}"
            BUILD_TYPE = "${buildType}"
        }

        stages {

            stage('Prepare') {
                steps {
                    sendSlackMessage(
                        buildStatus: 'STARTED',
                        slackChannel: env.SLACK_CHANNEL,
                        slackToken: env.SLACK_TOKEN
                    )
                    script {
                        def cdStrategy = determineCDStrategy(
                            productName: env.PRODUCT_NAME,
                            productType: "angular",
                            customTargetEnvironment: customTargetEnvironment,
                        )
                        env.SEMANTIC_VERSION = cdStrategy.get(0)
                        env.CREATE_AND_UPLOAD_ARTIFACT = cdStrategy.get(1)
                        env.DEPLOY_ARTIFACT = cdStrategy.get(2)
                        env.ENVIRONMENT = cdStrategy.get(3)
                        env.SEMANTIC_VERSION = env.SEMANTIC_VERSION == null || env.SEMANTIC_VERSION == 'none' ? 'latest' : env.SEMANTIC_VERSION
                        env.BUILD_ENVIRONMENTS = cdStrategy.get(4)
                    }
                }
            }

            stage("Build") {
                steps {
                    stash name: env.ANGULAR_BUILD_WORKSPACE
                    script {
                        //def buildStage = [:]
                        def buildEnvironments = env.BUILD_ENVIRONMENTS.split(",")
                        buildEnvironments.each { buildEnvironment ->
                            //buildStage[buildEnvironment] = {
                            buildStaticHTML (
                                targetEnvironment: buildEnvironment,
                                gulpVars: gulpVars,
                                gulpTasks: gulpTasks,
                                branchVersion: env.SEMANTIC_VERSION,
                                appName: config.appName,
                                useNewCdn: useNewCdn
                            )
                            //}
                        }
                        //parallel buildStage
                    }
                }
            }

            stage("Create Artifact") {
                when { expression { env.CREATE_AND_UPLOAD_ARTIFACT == "yes" || env.ENVIRONMENT == 'dev' } }
                steps {
                    script {
                        def archiveStage = [:]
                        def buildEnvironments = env.BUILD_ENVIRONMENTS.split(",")
                        buildEnvironments.each { buildEnvironment ->
                            archiveStage[buildEnvironment] = {
                                def artifactName = "${env.PRODUCT_NAME_LOWER}-${buildEnvironment}-${env.SEMANTIC_VERSION}.zip"
                                dir ("${env.WORKSPACE}/artifact/${buildEnvironment}"){
                                    sh "ls -lth"
                                    createArtifact(
                                        artifactName: "${artifactName}",
                                        artifactSource: "${env.WORKSPACE}/artifact/${buildEnvironment}"
                                    )
                                }
                            }
                            parallel archiveStage
                        }
                    }
                }
            }

            // stage("Copy To Dest Repo") {
            //     when { expression { destRepo != null } }
            //     steps {
            //         script {
            //             env.ARTIFACT_NAME = "${env.PRODUCT_NAME_LOWER}-${env.ENVIRONMENT}-${env.SEMANTIC_VERSION}.zip"
            //             def hasChanges = moveStaticToDest (
            //                 destDir: "${env.WORKSPACE}/dest",
            //                 sourceDir: "${env.WORKSPACE}/build/${env.ENVIRONMENT}/artifact",
            //                 destRepo: "${destRepo}",
            //                 artifactFile: env.ARTIFACT_NAME,
            //                 artifactFolder: "${env.WORKSPACE}/artifact"
            //             )
            //             env.HAS_CHANGED_PAGES = hasChanges
            //             echo "${env.HAS_CHANGED_PAGES}"
            //         }
            //     }
            // }

            stage("Prepare for lighthouse / nightwatch"){
                when { expression { env.ENVIRONMENT == 'dev' } }
                steps {
                    script {
                        withCredentials([usernamePassword(credentialsId: '685757ba-4b94-45ec-a37a-4f48b340ef83', passwordVariable: 'password', usernameVariable: 'user')]) {
                            sh """
                                git clone https://${user}:${password}@github.legalzoom.com/engineering/site-external-resources-dest.git /legalzoom/website
                                git clone https://${user}:${password}@github.legalzoom.com/engineering/internal-lighthouse-test.git /legalzoom/lighthouse
                                rm -rf /legalzoom/lighthouse/.git/index.lock
                            """
                        }
                    }
                }
            }

/*             stage("Run lighthouse against changed files") {
                when { expression { env.ENVIRONMENT == 'dev' && env.BUILD_TYPE != 'resources' } }
                steps {
                    runLightHouse(
                        artifact: "${env.WORKSPACE}/artifact/${env.ENVIRONMENT}/${env.PRODUCT_NAME_LOWER}-${env.ENVIRONMENT}-${env.SEMANTIC_VERSION}.zip",
                        lighthouseBranchName: lighthouseBranch,
                        pathUrls: lighthouseUrls
                    )
                }
            }

            stage("Run automation tests") {
                when { expression { env.ENVIRONMENT == 'dev' && env.BUILD_TYPE != 'resources' } }
                steps {
                    runNightwatch(
                        configFile: "nightwatch.customDev"
                    )
                    publishHTML (target : [allowMissing: false,
                    alwaysLinkToLastBuild: true,
                    keepAll: true,
                    reportDir: "build/${env.ENVIRONMENT}/e2e_output",
                    reportFiles: 'report.html',
                    reportName: 'Automation Reports'])
                }
            } */

            stage('Upload Artifact') {
                when { expression { env.CREATE_AND_UPLOAD_ARTIFACT == "yes" } }
                steps {
                    script {
                        uploadArtifact(
                            targetRepo: "${env.PRODUCT_NAME}/",
                            sourceArtifact: "${env.WORKSPACE}/artifact/*/*.zip",
                            productName: "${env.PRODUCT_NAME}"
                        )

                        if (kubeDeploy == "true") {
                            def buildEnvironments = env.BUILD_ENVIRONMENTS.split(",")
                            buildEnvironments.each { buildEnvironment -> 
                                def artifactName = "${env.PRODUCT_NAME_LOWER}-${buildEnvironment}-${env.SEMANTIC_VERSION}.zip"
                                buildStaticAssetContainer(environment: buildEnvironment, artifactName: artifactName, project: "${env.SERVICE_NAME}", deploymentRepo: deploymentRepo, ssiPath: ssiPath, containerGithubUrl: containerGithubUrl)
                            }
                        }
                    }
                }
            }

            stage("Push To Dest Repo") {
                when { expression { destRepo != null } }
                steps {
                    pushStatic (
                        destDir: "${env.WORKSPACE}/dest",
                        sourceDir: "${env.WORKSPACE}/artifact/${env.ENVIRONMENT}",
                        destRepo: "${destRepo}"
                    )
                }
            }

            stage('Rundeck: Start Deploy Job'){
                when { expression { env.DEPLOY_ARTIFACT == "yes" } }
                steps {
                    script {
                      def awsDeploy = false
                      def artifactName = "${env.PRODUCT_NAME_LOWER}-${env.ENVIRONMENT}-${env.SEMANTIC_VERSION}.zip"
                      try {
                          websiteAttributeUrl = "https://luigiweb.devops.legalzoom.com/services/website/${env.PRODUCT_NAME}/attributes?key=aws-deploy"
                          awsDeployString = httpRequest("${websiteAttributeUrl}").getContent()
                          awsDeploy = awsDeployString.toBoolean()
                      } catch(e) {
                          ansiColor('xterm') {
                              error("${colors.red}failed to get deployment type from ${websiteAttributeUrl} :${colors.none} ${colors.bold}${e}${colors.none}")
                          }
                      }
                      if (awsDeploy) {
                        deployStaticToAws(environment: "${env.ENVIRONMENT}", artifactName: "${artifactName}", project: "${env.SERVICE_NAME}")
                      } else if (kubeDeploy == "true") {
                          deployStaticToKube(environment: "${env.ENVIRONMENT}", artifactName: artifactName, project: "${env.SERVICE_NAME}", deploymentRepo: deploymentRepo)
                          if (multipleDeploy == "true") {
                              deployStatic(environment: "${env.ENVIRONMENT}", artifactName: artifactName, serviceName: "${env.SERVICE_NAME}")
                          }
                      } else {
                        deployStatic(environment: "${env.ENVIRONMENT}", artifactName: "${artifactName}", serviceName: "${env.SERVICE_NAME}")
                      }
                    }
                }
            }

        }

        post {
            always {
                script {
                    buildStatus = currentBuild.result ?: 'SUCCESSFUL'
                    subject = "${buildStatus}: ${env.JOB_NAME} [BUILD #${env.BUILD_NUMBER}]"
                    summary = "${subject} (${env.BUILD_URL})"
                    sendSlackMessage(
                        buildStatus: buildStatus,
                        slackChannel: env.SLACK_CHANNEL,
                        slackToken: env.SLACK_TOKEN
                    )
                    if (currentBuild.result == 'FAILURE') {
                        emailext(
                            body: summary,
                            recipientProviders: [[$class: 'CulpritsRecipientProvider']],
                            subject: subject
                        )
                        statusMessage(status: "${env.PRODUCT_NAME} CICD Pipeline Failed", level: "failure")
                    } else if (currentBuild.result == 'SUCCESS' || currentBuild.result == null) {
                        statusMessage(status: "${env.PRODUCT_NAME} CICD Pipeline Complete", level: "success")
                    }
                }
            }
        }
    }
}
