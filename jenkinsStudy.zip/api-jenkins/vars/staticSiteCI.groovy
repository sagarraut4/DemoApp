#!/usr/bin/env groovy

/**
 * A generic pipeline for Static Site services
 */


def call(body) {
    // evaluate the body block, and collect configuration into the object
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    try {
        assert config.productName != null
        assert config.version != null
        assert config.buildNodeLabel != null
        assert config.deploymentNodeLabel != null
        assert config.dependencyRepo != null
        assert config.dependencyArtifact != null
        assert config.gulpVars != null
        assert config.gulpScript != null
        assert config.buildDir != null
        assert config.componentName != null
        assert config.environment != null
        assert config.numberBuildsKeep != null
    } catch(NullPointerException e) {
        error("One or more required parameters were missing: ${e}")
    }

    buildNodeLabel = config.buildNodeLabel
    deploymentNodeLabel = config.deploymentNodeLabel
    npmRegistryName = config.npmRegistryName ?: "@legalzoom:registry"
    npmRegistryUrl = config.npmRegistryUrl ?: "https://artifactory.legalzoom.com/artifactory/api/npm/npm/"

    pipeline {

        environment {
            ARTIFACT_NAME = "${config.productName}-${config.version}.zip"
            ENVIRONMENT = "${config.environment}".toLowerCase()
            SERVICE_NAME = "${config.productName}"
            PRODUCT_NAME = "${config.productName}"
            APP_VERSION = "${config.version}"
            DEPENDENCY_REPO = "${config.dependencyRepo}"
            DEPENDENCY_ARTIFACT = "${config.dependencyArtifact}"
            GULP_VARS = "${config.gulpVars}"
            GULP_SCRIPT = "${config.gulpScript}"
            BUILD_DIR = "${config.buildDir}"
            COMPONENT_NAME = "${config.componentName}"
            deployArtifact = "yes"
            NUMBER_BUILDS_KEEP = "${config.numberBuildsKeep}"
            NPM_REGISTRY_NAME = "${npmRegistryName}"
            NPM_REGISTRY_URL = "${npmRegistryUrl}"
        }

        agent {
            label "${buildNodeLabel}"
        }

        options {
            buildDiscarder(logRotator(numToKeepStr: "${env.NUMBER_BUILDS_KEEP}"))
            disableConcurrentBuilds()
            timeout(time: 30, unit: 'MINUTES')
            timestamps()
        }

        stages {
            stage('Test'){
                steps {
                    // This is a place holder for unit tests, or any static code
                    // analysis
                    echo 'Placeholder for tests'
                }
            }

            stage('Build'){
                steps {
                    // Calling simplified  build script, will generate a "*.zip"
                    // file, this artifact will be used in the following stages
                    //adding the groovy function call for staticBuilds
                    //Calling buildStatic function. Part of the Jenkins shared libraries
                    //These are required parameters. See buildStatic.groovy for function definition
                    echo "printing out env variables"
                    sh 'printenv'
                    buildStatic (
                        gulpVars: "${env.GULP_VARS}",
                        gulpScript: "${env.GULP_SCRIPT}",
                        buildNumber: "${env.APP_VERSION}",
                        productName: "${env.SERVICE_NAME}",
                        buildDir: "${env.BUILD_DIR}",
                        artifactFile: "${env.ARTIFACT_NAME}"
                    )

                   // use STASH to name and save an artifact
                   //stash includes: "${env.PRODUCT_NAME}-${env.APP_VERSION}.tar.gz", name: 'static-site-artifact'
                }
            }

            stage('Upload to Artifactory'){
                //when {
                //  expression { return BRANCH_NAME.contains('release') }
                //}
                steps {
                    echo 'Uploading to Artifactory'
                    //unstash 'static-site-artifact'
                    uploadArtifact(
                        buildName: "${env.PRODUCT_NAME}-${env.APP_VERSION}",
                        targetRepo: "${env.PRODUCT_NAME}/${env.ARTIFACT_NAME}",
                        sourceArtifact: "${env.ARTIFACT_NAME}",
                        productName: "${env.PRODUCT_NAME}"
                    )
                }
            }

            stage('Rundeck: Start deploy job'){
                when { expression { deployArtifact == "yes" } }
                steps {
                    def awsDeploy = false
                    try {
                        websiteAttributeUrl = "https://luigiweb.devops.legalzoom.com/services/website/${env.PRODUCT_NAME}/attributes?key=aws-deploy"
                        awsDeployString = httpRequest("${websiteAttributeUrl}").getContent()
                        awsDeploy = awsDeployString.toBoolean()
                    } catch(e) {
                        ansiColor('xterm') {
                            error("${colors.red}failed to get deployment type from ${websiteAttributeUrl} :${colors.none} ${colors.bold}${e}${colors.none}")
                        }
                    }
                    if (awsDeploy) {
                      deployStaticToAws(environment: "${env.TARGET_ENVIRONMENT}", artifactName: artifactName, project: "${env.SERVICE_NAME}")
                    } else {
                      deployStatic(environment: "${env.TARGET_ENVIRONMENT}", artifactName: artifactName, serviceName: "${env.SERVICE_NAME}")
                    }
                }
            }
        }
    }
}
