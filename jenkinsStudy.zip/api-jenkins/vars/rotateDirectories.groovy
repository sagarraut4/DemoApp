#!/usr/bin/env groovy

/**
 * A generic pipeline function for rotating directories in powershell
 * Mimics a blue-green deployment on IIS with the following scheme:
 * Live  -> Blue
 * Green -> Live
 */

def call(Map map = [:]) {
    // mandatory inputs
    livePath = map.livePath
    bluePath = map.bluePath
    greenPath = map.greenPath
   
    try {
        assert livePath != null
        assert bluePath != null
        assert greenPath != null
    } catch(e) {
        error("One or more required parameters were null: ${e}")
    }
  
    echo "Beginning blue green directory rotation"

    try {
        msg = powershell(returnStdout: true, script: """
            # Checking if greenPath is empty
            \$directoryInfo = Get-ChildItem ${greenPath} | Measure-Object
            If (\$directoryInfo.count -eq 0) {
                Write-Output 'Cowardly refusing to deploy empty directory'
                Exit
            }
            # Check if blue path already exists
            If (Test-Path ${bluePath}) {
                Remove-Item -Force -Recurse ${bluePath}
            }
            Rename-Item -Path ${livePath} -NewName ${bluePath}
            Write-Output "Renamed ${livePath} to ${bluePath}"
            Rename-Item -Path  ${greenPath} -NewName ${livePath}
            Write-Output "Renamed ${greenPath} to ${livePath}"
        """)
        println msg 
    } catch(e) {
        error("Failed to rotate directories: ${e}")
        return
    }

    echo "Directory rotation complete"

}
