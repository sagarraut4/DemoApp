#!/usr/bin/env groovy

/**
 * A generic pipeline function for executing the angular deploy job in Rundeck
 */

def call(Map map = [:]) {
    // optional
    image = map.image
    colors = colorCodes()
    commit = map.commit ?: env.GIT_COMMIT
    tag = map.tag ?: env.TAG_NAME
    try { 
        assert tag != null
        assert image != null
        assert commit != null
    } catch (e) {
        error("One or more required parameters were null: ${e}")
    }

    statusMessage(status: "Tagging Image", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}IMAGE:${colors.none} ${image}
${colors.magenta}COMMIT:${colors.none} ${commit}
${colors.magenta}TAG:${colors.none} ${tag}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }
    container('docker') {
        withCredentials([
            usernamePassword(
                credentialsId: 'Artifactory',
                passwordVariable: 'PASSWORD',
                usernameVariable: 'USER'
            )
        ]) {
            sh """
            docker login artifactory.legalzoom.com -u ${USER} -p ${PASSWORD}
            docker pull artifactory.legalzoom.com/docker/engineering/${env.PRODUCT_NAME_LOWER}:${env.GIT_COMMIT}
            docker tag  artifactory.legalzoom.com/docker/engineering/${env.PRODUCT_NAME_LOWER}:${env.GIT_COMMIT} artifactory.legalzoom.com/docker/engineering/${env.PRODUCT_NAME_LOWER}:${tag}
            docker push artifactory.legalzoom.com/docker/engineering/${env.PRODUCT_NAME_LOWER}:${tag}
            """
        }
        echo "Tag Complete"
    }
}
