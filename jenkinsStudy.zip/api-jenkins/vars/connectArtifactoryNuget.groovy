#!/usr/bin/env groovy

/**
 * A generic pipeline function for uploading to Artifactory
 */

def call(Map map = [:]) {
    nugetSource = map.nugetSource
    colors = colorCodes()
    try {
        assert nugetSource != null
    } catch (e) {
        ansiColor('xterm') {
            error("${colors.red}One or more required parameters were null:${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }

    statusMessage(status: 'Connect to Nuget', level: 'info')

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}nugetSource:${colors.none} ${nugetSource}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }

    try {
        script {
            container('dotnet') {
                withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:'Artifactory', usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
                    sh """
                        dotnet nuget sources list
                        dotnet nuget sources Remove -Name Artifactory -Source ${nugetSource}
                        dotnet nuget sources Add -Name Artifactory -Source ${nugetSource} -username ${USERNAME} -password ${PASSWORD}
                        dotnet nuget setapikey ${USERNAME}:${PASSWORD} -Source Artifactory
                    """
                }
            }
        }
    } catch (e) {
        ansiColor('xterm') {
            error("${colors.red}Exception occurred while connecting to ${nugetSource}:${colors.none} " +
                    "${colors.bold}${e}${colors.none}")
        }
        return
    }
}
