#!groovy

/**
 * A generic pipeline for Drupal
 */

def call(body) {
    // evaluate the body block, and collect configuration into the object
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    colors = colorCodes()

    try {
        assert config.appName != null
        assert config.gulpTasks != null
    } catch(NullPointerException e) {
        ansiColor('xterm') {
            error("${colors.red}One or more required parameters were null:${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }

    sourceDirectory = config.sourceDirectory ?: "./Source/releases/20170113104000/themes/legalzoom"
    nodeLabel = config.nodeLabel ?: "drupal"
    jobName = JOB_NAME.replace('/', '_').replace('%2F', '_')

    pipeline {
        options{
            buildDiscarder(logRotator(numToKeepStr: '30'))
            disableConcurrentBuilds()
            timeout(time: 45, unit: 'MINUTES')
            timestamps()
        }

        environment {
            // mandatory
            PRODUCT_NAME = "${config.appName}"
            PRODUCT_NAME_LOWER = "${config.appName}".toLowerCase()
            SOURCE_DIRECTORY = "${sourceDirectory}"
            WORKSPACE_DIR = pwd()
            NODE_LABEL = "${nodeLabel}"
            SLACK_CHANNEL= "${slackChannel}"
            // constant
            SLACK_TOKEN = credentials('slack-token')
        }

        agent {
            node {
                label "${nodeLabel}"
            }
        }

        stages {
            stage('Prepare') {
                steps {
                    script {
                        def cdStrategy = determineCDStrategy(productName: env.PRODUCT_NAME)
                        env.ARTIFACT_VERSION = cdStrategy.get(0)
                        env.CREATE_AND_UPLOAD_ARTIFACT = cdStrategy.get(1)
                        env.DEPLOY_ARTIFACT = cdStrategy.get(2)
                        env.TARGET_DRUPAL_ENVIRONMENT = cdStrategy.get(3)
                        env.ARTIFACT_NAME = "${env.PRODUCT_NAME_LOWER}-${env.ARTIFACT_VERSION}.zip"
                    }
                }
            }

            stage("Build") {
                steps {
                    buildDrupal(
                        productName: env.PRODUCT_NAME,
                        sourceDirectory: env.SOURCE_DIRECTORY,
                        gulpTasks: config.gulpTasks,
                    )
                }
            }

            stage("Archive") {
                when { expression { env.CREATE_AND_UPLOAD_ARTIFACT == "yes" } }
                steps {
                    createArtifact(
                        artifactName: "${env.ARTIFACT_NAME}",
                        artifactSource: "${env.SOURCE_DIRECTORY}"
                    )
                    uploadArtifact(
                        targetRepo: "${env.PRODUCT_NAME}/${env.ARTIFACT_NAME}",
                        sourceArtifact: "${env.SOURCE_DIRECTORY}/${env.ARTIFACT_NAME}",
                        productName: "${env.PRODUCT_NAME}"
                    )
                }
            }

//            stage('Rundeck: Start Deploy Job'){
//                when { expression { env.DEPLOY_ARTIFACT == "yes" } }
//                steps {
//                    script {
//                        deployDrupal(environment: "${env.TARGET_DRUPAL_ENVIRONMENT}")
//                    }
//                }
//            }
        }

        post {
            always {
                script {
                    buildStatus = currentBuild.result ?: 'SUCCESSFUL'
                    subject = "${buildStatus}: ${env.JOB_NAME} [BUILD #${env.BUILD_NUMBER}]"
                    summary = "${subject} (${env.BUILD_URL})"
                    if (currentBuild.result == 'FAILURE') {
                        emailext(
                            body: summary,
                            recipientProviders: [[$class: 'CulpritsRecipientProvider']],
                            subject: subject
                        )

                        statusMessage(status: "${env.PRODUCT_NAME} CICD Pipeline Failed", level: "failure")

                    } else if (currentBuild.result == 'SUCCESS' || currentBuild.result == null) {

                        statusMessage(status: "${env.PRODUCT_NAME} CICD Pipeline Complete", level: "success")

                    }
                }
            }
        }
    }
}
