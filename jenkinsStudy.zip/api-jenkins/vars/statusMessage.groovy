#!/usr/bin/env groovy

/**
 * A generic pipeline function for printing status messages
 */

def call(Map map = [:]) {
    status = map.status
    level = map.level
    colors = colorCodes()

    try {
        assert status != null
        assert level != null
    } catch(NullPointerException e) {
        ansiColor('xterm') {
            error("${colors.red}One or more required parameters were null:${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }

    if (level == "info") {
        ansiColor('xterm') {
            echo "${colors.bold}---------------------------- [STATUS: ${status}] ----------------------------${colors.none}"
        }
    } else if (level == "success") {
        ansiColor('xterm') {
            echo "${colors.bold}---------------------------- [STATUS: ${colors.green}${status}${colors.none}${colors.bold}] ----------------------------${colors.none}"
        }
    } else if (level == "failure") {
        ansiColor('xterm') {
            echo "${colors.bold}---------------------------- [STATUS: ${colors.red}${status}${colors.none}${colors.bold}] ----------------------------${colors.none}"
        }
    } else {
        ansiColor('xterm') {
            error("${colors.red}'${level}' is not a valid level${colors.none}")
        }
    }

}