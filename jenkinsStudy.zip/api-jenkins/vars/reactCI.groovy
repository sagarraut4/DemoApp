#!/usr/bin/env groovy

/**
 * A generic pipeline for react applications
 */

def call(body) {
    // evaluate the body block, and collect configuration into the object
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    nodeLabel = config.nodeLabel ?: "frontend-react"
    sourceDirectory = config.sourceDirectory ?: "./src"
    verbosity = config.verbosity ?: "development"
    gulpTasks = config.gulpTasks ?: null
    destRepo = config.destRepo ?: null
    npmRegistryName = config.npmRegistryName ?: "@legalzoom:registry"
    npmRegistryUrl = config.npmRegistryUrl ?: "https://artifactory.legalzoom.com/artifactory/api/npm/npm/"
    customTargetEnvironment = config.customTargetEnvironment ?: null
    serviceName = config.serviceName ?: null
    appendConfig = config.appendConfig ?: null
    addHashToFiles = config.addHashToFiles?: "false"
    useNewCdn = config.useNewCdn ?: "false"
    kubeDeploy = config.kubeDeploy ?: "false"
    colors = colorCodes()
    skipDeploy = config.skipDeploy ?: null
    addPeerDependencies = config.addPeerDependencies ?: null
    runUnitTests = config.runUnitTests ?: "false"
    runCypressTests = config.runCypressTests ?: "false"
    testCommand = config.testCommand ?: null
    deploymentRepo = config.deploymentRepo ?: null
    cypressTestGroups = config.cypressTestGroups ?: null

    try {
        assert config.appName != null
        assert config.href != null        
        assert config.slackChannel != null
    } catch(NullPointerException e) {
        error("One or more required parameters were missing: ${e}")
    }

    pipeline {
        agent {
            kubernetes {
              yaml """\
                apiVersion: v1
                kind: Pod
                metadata:
                  labels:
                    build-groovy: reactCI
                spec:
                  securityContext:
                    fsGroup: 2000
                  containers:
                  - name: react
                    image: artifactory.legalzoom.com/docker/jenkinsagentangularcentos:latest
                    tty: true
                    command:
                    - cat
                    resources:
                      requests:
                        cpu: '3'
                        memory: '7Gi'
                      limits:
                        cpu: '6'
                        memory: '14Gi'
                  - name: docker
                    image: artifactory.legalzoom.com/docker-remote/docker:dind
                    securityContext:
                      privileged: true
                  - name: kustomize
                    image: k8s.gcr.io/kustomize/kustomize:v3.8.7
                    tty: true
                    command:
                    - cat
                  nodeSelector:
                    kubernetes.io/os: linux
                    kubernetes.io/arch: amd64
                """.stripIndent()
                workspaceVolume dynamicPVC(accessModes: 'ReadWriteOnce', requestsSize: '30Gi')
            }
        }

        environment {
            // mandatory
            PRODUCT_NAME = "${config.appName}"
            PRODUCT_NAME_LOWER = "${config.appName}".toLowerCase()
            COMPONENT_NAME = "${config.appName}"
            HOME = "."
            HREF = "${config.href}"            
            SOURCE_DIRECTORY = "${sourceDirectory}"
            SLACK_CHANNEL= "${config.slackChannel}"
            NODE_LABEL = "${nodeLabel}"
            // constant
            SLACK_TOKEN = credentials('slack-token')
            NPM_REGISTRY_NAME = "${npmRegistryName}"
            NPM_REGISTRY_URL = "${npmRegistryUrl}"
            REACT_BUILD_WORKSPACE = "reactBuildWorkspace"
            SERVICE_NAME = "${config.serviceName}"
            APPEND_CONFIG = "${config.appendConfig}"
            ADD_HASH_TO_FILES = "${config.addHashToFiles}"
            RUN_CYPRESS_TESTS = "${config.runCypressTests}"
        }

        stages {
            stage('Prepare') {

                steps {
                    sendSlackMessage(
                        buildStatus: 'STARTED',
                        slackChannel: env.SLACK_CHANNEL,
                        slackToken: env.SLACK_TOKEN
                    )
                    script {
                        def cdStrategy = determineCDStrategy(
                            productName: env.PRODUCT_NAME,
                            productType: "react",
                            customTargetEnvironment: customTargetEnvironment,
                            skipDeploy: skipDeploy
                        )
                        env.SEMANTIC_VERSION = cdStrategy.get(0)
                        env.CREATE_AND_UPLOAD_ARTIFACT = cdStrategy.get(1)
                        env.DEPLOY_ARTIFACT = cdStrategy.get(2)
                        env.TARGET_ENVIRONMENT = cdStrategy.get(3)
                        env.BUILD_ENVIRONMENTS = cdStrategy.get(4)
                        
                    }
                }
            }

            stage("Build") {
                steps {
                    stash name: env.REACT_BUILD_WORKSPACE
                    script {
                        container('react') {
                            def buildStage = [:]
                            def buildEnvironments = env.BUILD_ENVIRONMENTS.split(",")
                            buildEnvironments.each { buildEnvironment ->
                                buildStage[buildEnvironment] = {
                                    if (buildEnvironment in ["qa", "stg", "prod"]) {
                                        verbosity = "production"
                                    }
                                    buildReactApp(
                                        href: config.href,                                        
                                        targetEnvironment: buildEnvironment,
                                        outputDirectory: "${env.WORKSPACE}/artifact/${buildEnvironment}",
                                        gulpTasks: gulpTasks,
                                        verbosity: verbosity,
                                        appendConfig: "${env.APPEND_CONFIG}",
                                        addHashToFiles: "${env.ADD_HASH_TO_FILES}",
                                        addPeerDependencies: addPeerDependencies,
                                        useNewCdn: useNewCdn
                                    )
                                }
                            }
                            parallel buildStage
                        }
                    }
                }
            }

            stage("Prepare Test Dependencies") {
                when { expression { runUnitTests == "true" || runCypressTests ==  "true"} }
                steps {
                    script {
                        container('react') {
                            sh("mkdir -p ${env.WORKSPACE}/node_modules")
                            // Copy over node_modules from DEV build
                            sh("rsync -avz ${env.WORKSPACE}/build/${env.TARGET_ENVIRONMENT}/node_modules/* ${env.WORKSPACE}/node_modules/ ")
                            sh("rsync -avz ${env.WORKSPACE}/build/${env.TARGET_ENVIRONMENT}/package-lock.json ${env.WORKSPACE} ")
                            sh("npm install --legacy-peer-deps")
                        }
                    }
                }
            }

            stage("Unit tests") {
                when { expression { runUnitTests == "true" } }
                steps {
                    container('react') {
                        dir("${env.SOURCE_DIRECTORY}") {
                            runNpmTests(testProjectDirectory: "./", testCommand: testCommand)
                        }
                    }
                }
            }
             
            stage("Prepare for Cypress") {
                // ONLY run tests for DEV target environments like develop branch and PRs that point to develop
                // develop branch should always be in a working-happy-path state 
                when { expression { env.RUN_CYPRESS_TESTS == "true" && env.TARGET_ENVIRONMENT == "dev" && (env.BRANCH_NAME ==~ /^PR-[0-9]+$/ || env.BRANCH_NAME ==~ /^develop$/)} }
                steps {
                    script {
                        container('docker') {
                            def workspace = "${env.WORKSPACE}"
                            dir("${workspace}") {
                                statusMessage(status: "Starting Cypress Tests", level: "info")
                                sh "docker network create ${config.href}_default"
                                sh """
                                    docker run -p 80:80 -p 443:443 \
                                        --name wwwlocal.legalzoom.com \
                                        --network ${config.href}_default \
                                        --rm \
                                        --detach \
                                        -v ${workspace}/nginx/local-ssl/:/etc/ssl/ \
                                        -v ${workspace}/nginx/nginx.ci.conf/:/etc/nginx/nginx.conf \
                                        -v ${workspace}/artifact/${env.TARGET_ENVIRONMENT}/:/usr/share/nginx/html/ \
                                        artifactory.legalzoom.com/docker-remote/nginx:latest
                                    """  
                            }
                        }
                    }
                }
            }
            stage("Cypress Test") {
                when { expression { env.RUN_CYPRESS_TESTS == "true" && env.TARGET_ENVIRONMENT == "dev" && (env.BRANCH_NAME ==~ /^PR-[0-9]+$/ || env.BRANCH_NAME ==~ /^develop$/)} }
                steps {
                    script {
                        container('docker') {
                            def cypressRunner = [:]
                            def cypressGroups = cypressTestGroups
                            cypressGroups.each { cypressGroup -> 
                                cypressRunner["${cypressGroup}"] = {
                                    def workspace = "${env.WORKSPACE}"
                                    dir("${workspace}") {
                                        sh """
                                            docker run \
                                                --name cypressci-${cypressGroup} \
                                                --network ${config.href}_default \
                                                -v ${workspace}/:/e2e/ \
                                                -w /e2e \
                                                --entrypoint='' \
                                                artifactory.legalzoom.com/docker-remote/cypress/included:8.7.0 /bin/bash \
                                                -c 'cypress run --config-file cypress.ci.json --spec cypress/integration/${cypressGroup}/*.spec.js --headless --browser chrome --'
                                        """
                                    }
                                }
                            }
                            parallel cypressRunner
                        }
                    }
                }
                post {
                    always {
                        dir("${env.WORKSPACE}") {
                            archiveArtifacts allowEmptyArchive: true, artifacts:'cypress/screenshots/**, cypress/videos/**', caseSensitive: false
                        }
                    }
                }                
            }
            stage("Archive") {
                when { expression { env.CREATE_AND_UPLOAD_ARTIFACT == "yes" } }
                steps {
                    script {
                        container('react') {
                            def archiveStage = [:]
                            def buildEnvironments = env.BUILD_ENVIRONMENTS.split(",")
                            sourceArtifact = "${env.WORKSPACE}/artifact/*/*.zip"
                            if (addPeerDependencies == "yes"){
                                sourceArtifact = "${env.WORKSPACE}/build/*/dist/*.tgz"
                            }
                            buildEnvironments.each { buildEnvironment ->
                                archiveStage[buildEnvironment] = {
                                    def artifactName = "${env.PRODUCT_NAME_LOWER}-${buildEnvironment}-${env.SEMANTIC_VERSION}.zip"
                                    def artifactSource = "${env.WORKSPACE}/artifact/${buildEnvironment}"
                                    if (addPeerDependencies == "yes"){
                                        artifactName = "${env.PRODUCT_NAME_LOWER}-${buildEnvironment}-${env.SEMANTIC_VERSION}.tgz"
                                        artifactSource = "${env.WORKSPACE}/build/${buildEnvironment}/dist"
                                    }
                                    dir ("${artifactSource}"){
                                        sh "ls -lth"
                                        createArtifact(
                                            artifactName: "${artifactName}",
                                            artifactSource: "${artifactSource}",
                                            addPeerDependencies: "${addPeerDependencies}"
                                        )
                                    }
                                }
                            }
                            parallel archiveStage
                            uploadArtifact(
                                targetRepo: "${env.PRODUCT_NAME}/",
                                sourceArtifact: "${sourceArtifact}",
                                productName: "${env.PRODUCT_NAME}"
                            )
                        }
                        if (kubeDeploy == "true") {
                            def buildEnvironments = env.BUILD_ENVIRONMENTS.split(",")
                            buildEnvironments.each { buildEnvironment -> 
                                def artifactName = "${env.PRODUCT_NAME_LOWER}-${buildEnvironment}-${env.SEMANTIC_VERSION}.zip"
                                buildStaticAssetContainer(environment: buildEnvironment, artifactName: artifactName, project: "${env.SERVICE_NAME}", deploymentRepo: deploymentRepo)
                            }
                        }
                    }
                }
            }

            stage('Kube: Start Deploy Job'){
                when { expression { env.DEPLOY_ARTIFACT == "yes" } }
                steps {
                    script {
                        if (env.TARGET_ENVIRONMENT == "poc") {
                            artifactName = "${env.PRODUCT_NAME_LOWER}-dev-${env.SEMANTIC_VERSION}.zip"
                        } else {
                            artifactName = "${env.PRODUCT_NAME_LOWER}-${env.TARGET_ENVIRONMENT}-${env.SEMANTIC_VERSION}.zip"
                        }
                        deployStaticToKube(environment: "${env.TARGET_ENVIRONMENT}", artifactName: artifactName, project: "${env.SERVICE_NAME}", deploymentRepo: deploymentRepo)
                    }
                }
            }
        }

        post {
            always {
                script {
                    buildStatus = currentBuild.result ?: 'SUCCESSFUL'
                    subject = "${buildStatus}: ${env.JOB_NAME} [BUILD #${env.BUILD_NUMBER}]"
                    summary = "${subject} (${env.BUILD_URL})"
                    sendSlackMessage(
                        buildStatus: buildStatus,
                        slackChannel: env.SLACK_CHANNEL,
                        slackToken: env.SLACK_TOKEN
                    )
                    if (currentBuild.result == 'FAILURE') {
                        emailext(
                            body: summary,
                            recipientProviders: [[$class: 'CulpritsRecipientProvider']],
                            subject: subject
                        )
                        statusMessage(status: "${env.PRODUCT_NAME} CICD Pipeline Failed", level: "failure")
                    } else if (currentBuild.result == 'SUCCESS' || currentBuild.result == null) {
                        statusMessage(status: "${env.PRODUCT_NAME} CICD Pipeline Complete", level: "success")
                    }
                    junit testResults: '**/target/**/*.xml', allowEmptyResults: true
                }
            }
        }
    }
}
