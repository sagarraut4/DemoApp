#!/usr/bin/env groovy

/**
 * A generic pipeline function to fetch files from github repos
 */

def call(Map map = [:]) {
    org = map.org
    repo = map.repo
    branch = map.branch ?: "master"
    pathToFile = map.pathToFile
    outputFileName = map.outputFileName ?: pathToFile.split('/').last()
    outputFileEncoding = map.outputFileEncoding ?: "UTF-8"
    outputDirectory = map.outputDirectory ?: pwd()
    githubFileEndpoint = "https://luigiweb.devops.legalzoom.com/github/orgs/${org}/repos/${repo}/get/file?path=${pathToFile}&branch=${branch}"
    stripWrappingDoubleQuotes = map.stripWrappingDoubleQuotes ?: "yes"
    printFileContents = map.printFileContents ?: "yes"
    colors = colorCodes()

    try {
        assert org != null
        assert repo != null
        assert pathToFile != null
    } catch(NullPointerException e) {
        error("One or more required parameters were null: ${e}")
    }

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}ORG:${colors.none} ${org}
${colors.magenta}REPO:${colors.none} ${repo}
${colors.magenta}BRANCH:${colors.none} ${branch}
${colors.magenta}PATH_TO_FILE:${colors.none} ${pathToFile}
${colors.magenta}OUTPUT_FILE_NAME:${colors.none} ${outputFileName}
${colors.magenta}OUTPUT_DIRECTORY:${colors.none} ${outputDirectory}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }

    ansiColor('xterm') {
        echo "${colors.bold}Getting '${pathToFile}' From ${org}/${repo}'s '${branch}' Branch${colors.none}"
    }

    try {
        fileContents = httpRequest(authentication: 'Luigiweb Auth', url: "${githubFileEndpoint}").getContent().toString()
        // convert line endings
        if (isUnix()) {
            fileContents = fileContents.replace("\\r\\n", "\n")
        } else {
            fileContents = fileContents.replace("\\n", "\r\n")
        }

        if (stripWrappingDoubleQuotes == "yes") {
            fileContents = fileContents.replaceAll(/^"/, '').replaceAll(/"$/, '').replaceAll(/\\"/, '"')
        }

        if (printFileContents == "yes") {
            echo "${fileContents}"
        }
        // write the string to a file
        dir("${outputDirectory}") {
            writeFile(file: outputFileName, text: fileContents, encoding: outputFileEncoding)
        }
    } catch (e) {
        error(
            "failed to get contents of '${pathToFile}' in ${org}/${repo}'s ${branch} branch from '${githubFileEndpoint}': ${e}"
        )
    }

}
