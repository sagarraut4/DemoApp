#!/usr/bin/env groovy

/**
 * A pipeline function for API configuration management
 * A python3 script is being used; to be run on any agent
 */

def call(param = [:]) {
    api = param.api.trim()
    ref = param.apiRef.trim()
    forceFeatureBranchDeployment = param.forceFeatureBranchDeployment ?: "no"
    datadogAPMIntegration = param.datadogAPMIntegration ?: "no"
    srcFile = param.srcFile ?: "${WORKSPACE}\\src\\${api}\\appsettings.json"
    webConfigOrig = param.webConfigOrig ?: "${WORKSPACE}\\src\\${api}\\web.config"

    try {
        assert api != null
        assert ref != null
    } catch(e) {
        error("One or more required parameters were null: ${e}")
    }

    configValuesFile = "api-config.yaml"
    envs = ["predev", "dev", "qa", "stg", "prod"]
    //used for repo devops/fabfiles
    configMgmtRepoBranch = "master"

    if ( isUnix() ){
        srcFile = srcFile.replace('\\','/')
    }

    script {
        //for web config (should be deprecated soon
        webConfigDestBaseDir = "${WORKSPACE}\\configurationFiles"

        //going to use global var determineCDStrategy to get version (raw)
        if( !(env.BRANCH_NAME) ){
            echo "BRANCH_NAME does nto have a value. Going to set it to the value of ref (\"${ref}\")"
            env.BRANCH_NAME = ref
        }
        cmCdStrategy = determineCDStrategy(productName: api)
        versionRaw = cmCdStrategy.get(0)

        if ( ref == 'develop' ) {
            //commenting due to testing; this is true value cmBranch = 'develop'
            //cmBranch = 'test'
            cmBranch = 'develop'
            echo "For version, going to obtain value from determineCDStrategy"
            version = versionRaw.trim()
        }
        else if (ref ==~ /^release.*/ || ref ==~ /^hotfix.*/) {
            //commenting due to testing; this is true value cmBranch = 'master'
            //cmBranch = 'test'
            cmBranch = 'master'
            echo "For version, going to obtain value from determineCDStrategy"
            version = versionRaw.find("[0-9]+.[0-9]+.[0-9]+").trim()
        }
        else if (ref == 'master') {
            //commenting due to testing; this is true value cmBranch = 'master'
            //cmBranch = 'test'
            cmBranch = 'master'
            try{
                if ( !(isUnix()) ){
                    // bat does not require %(tag) to be single quoted; powershell and sh does requre it
                    version = powershell(returnStdout: true, script: """git tag --sort=-creatordate|select -first 1""").find("[0-9]+.[0-9]+.[0-9]+").trim()
                    //version = powershell(returnStdout: true, script: "echo 'hello'").trim()
                }
                else{
                    version = sh(returnStdout: true, script: """git tag --sort=-creatordate|head -n1""").find("[0-9]+.[0-9]+.[0-9]+").trim()
                }
           }
           catch(e){
               echo "Exception occurred: ${e}. Setting version to null"
               version = ""
           }
        }
        else if (ref ==~ /^v[0-9]+.[0-9]+.[0-9]+.*$/) {
            //commenting due to testing; this is true value cmBranch = 'master'
            //cmBranch = 'test'
            cmBranch = 'master'
            version = ref.find("[0-9]+.[0-9]+.[0-9]+").trim()
        }
        else if (forceFeatureBranchDeployment == "yes") {
            cmBranch = 'develop'
            version = 'feature'
        }
        else {
            cmBranch = 'test'
            version = 'snapshot'
        }
    }

    echo "Values to be used - cmBranch: $cmBranch, version: ${version}"
    echo "Checkout of devops/configurationFiles, ref ${cmBranch} and devops/fabfiles, branch ${configMgmtRepoBranch}"
    checkout changelog: false, poll: false, scm: [$class: 'GitSCM', branches: [[name: "*/${cmBranch}"]], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'WipeWorkspace'],[$class: 'RelativeTargetDirectory', relativeTargetDir: 'configurationFiles']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: '685757ba-4b94-45ec-a37a-4f48b340ef83', url: 'https://github.legalzoom.com/devops/configurationFiles.git']]]

    checkout changelog: false, poll: false, scm: [$class: 'GitSCM', branches: [[name: "*/${configMgmtRepoBranch}"]], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'WipeWorkspace'],[$class: 'RelativeTargetDirectory', relativeTargetDir: 'fabfiles']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: '685757ba-4b94-45ec-a37a-4f48b340ef83', url: 'https://github.legalzoom.com/devops/fabfiles.git']]]

    dir('configurationFiles'){
        withCredentials([usernamePassword(credentialsId: '685757ba-4b94-45ec-a37a-4f48b340ef83', passwordVariable: 'password', usernameVariable: 'user')]) {
            if ( !(isUnix()) ){
                powershell """
                    echo "https://${user}:${password}@github.legalzoom.com" > git-credentials
                    git config user.name "jenkins"
                    git config user.email "jenkins@legalzoom.com"
                    git config credential.helper "store --file .\\git-credentials"
                """
            }
            else{
                sh """
                    echo "https://${user}:${password}@github.legalzoom.com" > git-credentials
                    git config user.name "jenkins"
                    git config user.email "jenkins@legalzoom.com"
                    git config credential.helper "store --file ./git-credentials"
                """
            }
        }
    }

    retry(3){
        if ( !(isUnix()) ){
            bat "git -C configurationFiles checkout -b ${cmBranch}"
        }
        else{
            sh "git -C configurationFiles checkout -b ${cmBranch}"
        }
    }

    echo """
    Values to be used:
    configValuesFile: \"$configValuesFile\"
    srcFile: \"$srcFile\"
    ref: \"$ref\"
    cmBranch: \"$cmBranch\"
    version: \"$version\"
    """

    if(version){
        version = '-'+version
    }
    //prepping version variable
    echo "adding \"${version}\" to the end of versioned appsettings files (\"appsettings.json${version}\")"

    container('python-git') {
        dir('fabfiles/configurationManagement'){
            envs.each { env ->
                destFiles = ["${WORKSPACE}\\configurationFiles\\apis\\${env}\\${api}\\appsettings.${env}.json", "${WORKSPACE}\\configurationFiles\\apis\\${env}\\${api}\\appsettings.${env}.json${version}"]


                destFiles.each { destFile ->
                    echo "Generating file ${destFile}"
                    destFileGit = destFile.find("apis\\\\${env}.*")
                    if ( !(isUnix()) ){
                        bat """
                            python .\\configMgmt.py $configValuesFile $srcFile $destFile $env
                            git -C ${WORKSPACE}\\configurationFiles add $destFileGit
                        """
                    }
                    else{
                        destFile = destFile.replace('\\','/')
                        destFileGit = destFile.find("apis/${env}.*")
                        sh """
                            ./configMgmt.py $configValuesFile $srcFile $destFile $env
                            git -C ${WORKSPACE}/configurationFiles add $destFileGit
                        """
                    }
                }
            }
        }

        if ( !(isUnix()) ){
            echo "Running powershell script for web config files"
            powershell """
                ${webConfigDestBaseDir}\\webConfigChanges.ps1 -api $api -webConfigOrig $webConfigOrig -webConfigDestBaseDir $webConfigDestBaseDir -gitBranchConfig $cmBranch
            """
        }

        /*
        Augment API web.configs for Datadog APM integration
         */
        if ( datadogAPMIntegration == "yes") {
            envs.each { env ->
                dir('fabfiles/deploy') {
                    webConfigDest = "${WORKSPACE}\\configurationFiles\\apis\\${env}\\${api}\\web.config"
                    command = """
                        python -c "from apis import transform_web_config; transform_web_config(api='${api}',environment='${env}',source_path=r'${webConfigDest}',target_path=r'${webConfigDest}')"
                        git -C ${WORKSPACE}/configurationFiles add $webConfigDest
                    """

                    try {
                        echo "Generating file ${webConfigDest}"
                        if (!(isUnix())) {
                            bat "${command}"
                        } else {
                            webConfigDest = webConfigDest.replace('\\', '/')
                            sh "${command}"
                        }
                    } catch (e) {
                        error("failed to transform ${webConfigDest}: ${e}")
                    }

                }
            }
        }

        dir('configurationFiles'){
            withCredentials([usernamePassword(credentialsId: '685757ba-4b94-45ec-a37a-4f48b340ef83', passwordVariable: 'password', usernameVariable: 'user')]) {
                if ( !(isUnix()) ){
                    try{
                        bat """
                            git status
                            git commit -a -m "API ${api} config updates from ref ${ref}"
                        """
                        retry(3){
                            bat"""
                                git pull https://${user}:${password}@github.legalzoom.com/devops/configurationFiles.git $cmBranch
                                git push -u https://${user}:${password}@github.legalzoom.com/devops/configurationFiles.git $cmBranch
                            """
                        }
                    }
                    catch(e){
                        echo "Continuing (there is probably nothing to commit)."
                        echo e.toString()
                    }
                }
                else{
                    try {
                    sh """
                        echo "is unix true"
                        git status
                        git commit -a -m "API ${api} config updates from ${ref}"
                    """
                    retry(3){
                        sh"""
                            git pull origin $cmBranch
                            git push -u origin $cmBranch
                        """
                    }
                    }
                    catch(e) {
                        echo "Continuing (there is probably nothing to commit)."
                        echo e.toString()
                    }
                }
            }
        }
    }
}
