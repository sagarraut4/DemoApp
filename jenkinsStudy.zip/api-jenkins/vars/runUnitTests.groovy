#!/usr/bin/env groovy

/**
 * A generic pipeline function for running unit tests for API services
 */

def call(Map map = [:]) {
    testProjectDirectory = map.testProjectDirectory ?: env.TEST_PROJECT_DIRECTORY
    try {
        codeCoverageReport = map.codeCoverageReport.toBoolean() ?: false
    } catch(e) {
        echo "Error converting codeCoverageReport to Boolean"
        codeCoverageReport = false
    }
    colors = colorCodes()

    statusMessage(status: "Preparing Unit Tests", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}TEST_PROJECT_DIRECTORY:${colors.none} ${testProjectDirectory}
${colors.magenta}CODE_COVERAGE_REPORT:${colors.none} ${codeCoverageReport}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }

    try {
        if(isUnix()) {
            sh "dotnet restore"
        } else {
            bat "dotnet restore"
        }
    } catch(e) {
        ansiColor('xterm') {
            error("${colors.red}Unable to restore packages:${colors.none} ${colors.bold}${e}${colors.none}")
        }
        return
    }

    statusMessage(status: "Starting Unit Tests", level: "info")
    try {
        if (codeCoverageReport == true) {
            echo "Generating Code Coverage Report..."
            dir(testProjectDirectory) {
                if(isUnix()) {
                    sh "dotnet test /p:CollectCoverage=true /p:CoverletOutputFormat=json /p:CoverletOutput='./BuildReports/'"
                } else {
                    bat "dotnet test /p:CollectCoverage=true /p:CoverletOutputFormat=json /p:CoverletOutput='./BuildReports/'"
                }
            }
        } else {
            echo "Skipping Code Coverage Report"
            dir(testProjectDirectory) {
                if(isUnix()) {
                    sh "dotnet test"
                } else {
                    bat "dotnet test"
                }
            }
        }

    } catch(e) {
        ansiColor('xterm') {
            error("${colors.red}Unit tests failed:${colors.none} ${colors.bold}${e}${colors.none}")
        }
        return
    }
}
