#!/usr/bin/env groovy

/**
 * A generic pipeline for NPM Packages
 */

def call(body) {
    // evaluate the body block, and collect configuration into the object
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    colors = colorCodes()

    try {
        assert config.packageName != null
        assert config.slackChannel != null
    } catch(NullPointerException e) {
        ansiColor('xterm') {
            error("${colors.red}One or more required parameters were null:${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }

    nodeLabel = config.nodeLabel ?: "frontend-angular-npm"
    sourceDirectory = config.sourceDirectory ?: "./"
    testProjectDirectory = config.testProjectDirectory ?: "./"
    slackChannel = config.slackChannel
    jobName = JOB_NAME.replace('/', '_').replace('%2F', '_')
    skipUnitTests = config.skipUnitTests ?: "no"

    pipeline {
        options{
            buildDiscarder(logRotator(numToKeepStr: '30'))
            disableConcurrentBuilds()
            timeout(time: 45, unit: 'MINUTES')
            timestamps()
        }

        environment {
            // mandatory
            PRODUCT_NAME = "${config.packageName}"
            PRODUCT_NAME_LOWER = "${config.packageName}".toLowerCase()
            SOURCE_DIRECTORY = "${sourceDirectory}"
            SLACK_CHANNEL= "${slackChannel}"
            NODE_LABEL = "${nodeLabel}"
            TEST_PROJECT_DIRECTORY = "${testProjectDirectory}"
            SKIP_UNIT_TESTS = "${skipUnitTests}" 
            // constant
            SLACK_TOKEN = credentials('slack-token')
        }

        agent {
            node {
                label "${nodeLabel}"
            }
        }

        stages {
            stage('Prepare') {
                steps {
                    sendSlackMessage(
                        buildStatus: 'STARTED',
                        slackChannel: env.SLACK_CHANNEL,
                        slackToken: env.SLACK_TOKEN
                    )
                    script {
                        def cdStrategy = determineCDStrategy(
                            productName: env.PRODUCT_NAME
                        )
                        env.ARTIFACT_VERSION = cdStrategy.get(0)
                        env.CREATE_AND_UPLOAD_ARTIFACT = cdStrategy.get(1)
                    }
                }
            }

            stage("Build") {
                steps {
                    buildNpmPackage(sourceDirectory: "${env.SOURCE_DIRECTORY}/${env.PRODUCT_NAME_LOWER}")
                }
            }

            stage("Unit Test") {
                when { expression { env.SKIP_UNIT_TESTS == "no" } }
                steps {
                    runNpmTests(testProjectDirectory: "${env.TEST_PROJECT_DIRECTORY}/${env.PRODUCT_NAME_LOWER}")
                }
            }

            stage("Publish") {
                when { expression { env.CREATE_AND_UPLOAD_ARTIFACT == "yes" } }
                steps {
                    publishNpmPackage(
                        sourceDirectory: "./dist/${env.PRODUCT_NAME_LOWER}/",
                        tarFile: "legalzoom-${env.PRODUCT_NAME_LOWER}-${env.ARTIFACT_VERSION}.tgz",
                        tag: "latest",
                        packageName: "${env.PRODUCT_NAME}",
                        version: "${env.ARTIFACT_VERSION}"
                    )
                }
            }
        }

        post {
            always {
                script {
                    buildStatus = currentBuild.result ?: 'SUCCESSFUL'
                    subject = "${buildStatus}: ${env.JOB_NAME} [BUILD #${env.BUILD_NUMBER}]"
                    summary = "${subject} (${env.BUILD_URL})"
                    sendSlackMessage(
                        buildStatus: buildStatus,
                        slackChannel: env.SLACK_CHANNEL,
                        slackToken: env.SLACK_TOKEN
                    )
                    if (currentBuild.result == 'FAILURE') {
                        emailext(
                            body: summary,
                            recipientProviders: [[$class: 'CulpritsRecipientProvider']],
                            subject: subject
                        )
                        statusMessage(status: "${env.PRODUCT_NAME} CICD Pipeline Failed", level: "failure")
                    } else if (currentBuild.result == 'SUCCESS' || currentBuild.result == null) {
                        statusMessage(status: "${env.PRODUCT_NAME} CICD Pipeline Complete", level: "success")
                    }
                }
            }
        }
    }
}
