#!/usr/bin/env groovy

/**
 * A generic pipeline function for running Rundeck jobs
 */

def call(Map map = [:]) {
    // mandatory
    jobId = map.jobId
    jobOptions = map.jobOptions
    // optional
    rundeckInstance = map.rundeckInstance ?: "rundeck"
    shouldWaitForRundeckJob = false
    shouldFailTheBuild = map.shouldFailTheBuild ?: false
    tailLog = map.tailLog ?: false
    colors = colorCodes()

    try {
        assert jobId != null
        assert jobOptions != null
        assert rundeckInstance != null
    } catch(e) {
        ansiColor('xterm') {
            error("${colors.red}One or more required parameters were null:${colors.none} ${e}")
        }
    }

    header = "Triggering Rundeck Job"
    footer = "Rundeck Job Triggered"

    statusMessage(status: "${header}", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}RUNDECK EXECUTION PARAMS:${colors.none}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}RUNDECK_INSTANCE:${colors.none} ${rundeckInstance}
${colors.magenta}SHOULD_FAIL_BUILD:${colors.none} ${shouldFailTheBuild}
${colors.magenta}SHOULD_WAIT_FOR_RUNDECK_JOB:${colors.none} ${shouldWaitForRundeckJob}
${colors.magenta}TAIL_LOG:${colors.none} ${tailLog}
${colors.magenta}JOB_ID:${colors.none} ${jobId}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}

${colors.bold}RUNDECK JOB OPTIONS:${colors.none}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.bold}${jobOptions}${colors.none}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }

    try {
      walleEndpoint = "https://luigiweb.devops.legalzoom.com/walle/work/5"
      workload = '{"rundeck_job_id": "' + jobId +'", "arg_strings": "' + jobOptions + '"}'
      def response = httpRequest acceptType: 'APPLICATION_JSON', contentType: 'APPLICATION_JSON', httpMode: 'POST', requestBody: workload, url: walleEndpoint
   } catch(e) {
        ansiColor('xterm') {
            error("${colors.red}Exception occurred while trying to queue ${jobId}:${colors.none} ${e}")
        }
   }

}
