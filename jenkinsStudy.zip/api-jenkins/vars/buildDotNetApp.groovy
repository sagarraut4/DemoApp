#!/usr/bin/env groovy

/**
 * A generic pipeline function for building .Net applications
 */

def call(Map map = [:]) {
    appName = map.appName ?: env.APP_NAME
    targetEnvironment = map.targetEnvironment
    solutionFile = map.solutionFile ?: env.SOLUTION_FILE
    sourceBinaries = map.sourceBinaries ?: env.SOURCE_BINARIES
    destinationBinaries = map.destinationBinaries ?: "${env.DESTINATION_BINARIES}\\${targetEnvironment}"
    targetArtifactDir = map.targetArtifactDir ?: ".\\artifact\\${targetEnvironment}\\${appName}"
    additionalSourceDirectories = map.additionalSourceDirectories ?: null
    colors = colorCodes()

    try {
        assert appName != null
        assert targetEnvironment != null
        assert solutionFile != null
        assert sourceBinaries != null
        assert destinationBinaries != null
    } catch(NullPointerException e) {
        error("One or more required parameters were missing: ${e}")
    }

    statusMessage(status: "Building", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}APP_NAME:${colors.none} ${appName}
${colors.magenta}SOLUTION_FILE:${colors.none} ${solutionFile}
${colors.magenta}TARGET_BUILD_ENVIRONMENT:${colors.none} ${targetEnvironment}
${colors.magenta}SOURCE_BINARIES:${colors.none} ${sourceBinaries}
${colors.magenta}DESTINATION_BINARIES:${colors.none} ${destinationBinaries}
${colors.magenta}ADDITIONA_SOURCE_DIRECTORIES:${colors.none} ${additionalSourceDirectories}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }

    if (additionalSourceDirectories != null) {
        statusMessage(status: "Building Additional Source Directories", level: "info")
        additionalSourceDirectories.each { srcDir ->
            ansiColor('xterm') {
                echo "${colors.bold}Building ${srcDir}${colors.none}"
            }
            try {
                dir("${srcDir}") {
                    powershell("msbuild /p:OutDir='${env.DESTINATION_BINARIES}\\${targetEnvironment}'")
                }
            } catch (e) {
                error("Failed to build \"${srcDir}\": ${e}")
            }
        }
    }

    ansiColor('xterm') {
        echo "${colors.bold}(Step 1 of 2) Copying Binaries${colors.none}"
    }

    try {
        powershell("new-item -type dir $destinationBinaries -force")
        powershell("copy-item ${sourceBinaries} ${destinationBinaries}")
    } catch(e) {
        error("Failed to copy binaries: ${e}")
        return
    }

    ansiColor('xterm') {
        echo "${colors.bold}(Step 2 of 2) Building ${appName} (${targetEnvironment}) Solution${colors.none}"
    }

    try {
        powershell("""
            msbuild ${solutionFile} /m /p:OutDir=${destinationBinaries}\\ /p:Configuration="${targetEnvironment}" /p:Platform="Any CPU" /p:DeployOnBuild=True /p:CreatePackageOnPublish=True /p:SkipInvalidConfigurations=true /p:IncludeSetAclProviderOnDestination=False
        """)
    } catch(e) {
        error("Failed to build visual studio project/solution for ${appName}: ${e}")
        return
    }

}
