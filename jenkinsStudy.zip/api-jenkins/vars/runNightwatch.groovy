#!/usr/bin/env groovy

/**
 * A generic pipeline function for running lighthouse against changed files
 */

def call(Map map = [:]) {
    // mandatory
    def configFile = map.configFile ?: 'nightwatch.customDev'
    // optional
    def sourceDirectory = map.sourceDirectory ?: "${env.WORKSPACE}/build/${env.ENVIRONMENT}"
    def colors = colorCodes()

    try {
        assert configFile != null
        assert sourceDirectory != null
    } catch(NullPointerException e) {
        error("One or more required parameters were missing: ${e}")
    }

    map.each{println it.key +" "+it.value}

    statusMessage(status: "Running automation tests", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}CONFIG_FILE:${colors.none} ${configFile}
${colors.magenta}SOURCE_DIRECTORY:${colors.none} ${sourceDirectory}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }
    dir(sourceDirectory) {
        sh "ls -lth"
        ansiColor('xterm') {
            echo "${colors.bold}Run nightwatch automation tests${colors.none}"
        }
        try {
            sh("node ./node_modules/.bin/nightwatch --config ${configFile}.js --reporter html-reporting.dev.js")
            sh("sudo /usr/sbin/nginx -s stop")            
        } catch (e) {
            sh("sudo /usr/sbin/nginx -s stop")
            error("Running automation tests failed: ${e}")
            return
        }
    }
    echo "Finished running automation tests"
}
