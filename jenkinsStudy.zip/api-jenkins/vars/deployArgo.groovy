#!/usr/bin/env groovy

/**
 * A generic pipeline function for executing the angular deploy job in Rundeck
 */

def call(Map map = [:]) {
    project = map.project ?: env.SERVICE_NAME
    env = map.env ?: env.ENVIRONMENT
    org = map.org
    repo = map.repo
    imageTag = map.imageTag ?: 'latest'
    argoCredentialsId = map.argoCredentialsId
    colors = colorCodes()
    repoName = map.gitRepoName ?: "${org}/${project}-deployment"
    argoAppName = null
    // update this value for argo CD version changes
    argoCdVersion = "v2.0.0"
    secretPath = map.secretPath ?: null

    try { 
        assert project != null
        assert env != null
        assert org != null
        assert repo != null
        assert imageTag != null
        argoAppName = map.awsRegion == null ? "${project}-${env}" : "${project}-${map.awsRegion}-${env}"
    } catch (e) {
        error("One or more required parameters were null: ${e}")
    }

    statusMessage(status: "Deploying", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}PROJECT_NAME:${colors.none} ${project}
${colors.magenta}TARGET_ENVIRONMENT:${colors.none} ${env}
${colors.magenta}ORG:${colors.none} ${org}
${colors.magenta}REPO:${colors.none} ${repo}
${colors.magenta}IMAGE TAG:${colors.none} ${imageTag}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }

    stage("Argo CD sync | ${env}") {
        credentials = [usernamePassword(
            credentialsId: '685757ba-4b94-45ec-a37a-4f48b340ef83',
            passwordVariable: 'PASSWORD',
            usernameVariable: 'USER'
        )]

        if(secretPath == null && argoCredentialsId != null && argoCredentialsId != "") {
            credentials.add(string(
                credentialsId: "${argoCredentialsId}",
                variable: 'ARGOCD_AUTH_TOKEN'
            ))
        }
        
        withCredentials(credentials) {
            dir("deployment") {
                gitCredentialsUrl = "https://${USER}:${PASSWORD}@github.legalzoom.com/${repoName}"
                git url: "https://${USER}:${PASSWORD}@github.legalzoom.com/${repoName}"
                container('kustomize') {
                    sh """
                    cd envs/${env} && /app/kustomize edit set image artifactory.legalzoom.com/docker/${org}/${repo}/${project}=artifactory.legalzoom.com/docker/${org}/${repo}/${project}:${imageTag}
                    """
                }
                sh """
                    git config --global user.email "dl-devops@legalzoom.com"
                    git config --global user.name "Jenkins Pipeline"
                    git add .
                    if [ -z \$(git status --porcelain) ];
                    then
                        echo "No change to commit"
                    else
                        git commit -m "Update ${env} container to version ${imageTag}"
                        git push ${gitCredentialsUrl}
                    fi
                """
            }
            container('alpine') {
                if (secretPath != null) {
                    def secrets = [
                        [path: secretPath, engineVersion: 1, secretValues: [
                            [envVar: 'ARGOCD_AUTH_TOKEN', vaultKey: 'authToken'],
                        ]],
                    ]
                    def configuration = [vaultUrl: 'https://vault.legalzoom.com',
                                vaultCredentialId: 'vault',
                                engineVersion: 1]
                    // inside this block your credentials will be available as env variables
                    withVault([configuration: configuration, vaultSecrets: secrets]) {
                        sh """
                        apk add curl
                        #argo app sync
                        curl -sSL -o /usr/local/bin/argocd https://github.com/argoproj/argo-cd/releases/download/${argoCdVersion}/argocd-linux-amd64
                        chmod +x /usr/local/bin/argocd
                        ARGOCD_SERVER=argo.devops.prd.aws-01.legalzoom.com  /usr/local/bin/argocd app sync ${argoAppName}
                        ARGOCD_SERVER=argo.devops.prd.aws-01.legalzoom.com  /usr/local/bin/argocd app wait ${argoAppName}
                        echo "Done with argo deployment"
                        """
                    }
                }
                else {
                    sh """
                        apk add curl
                        #argo app sync
                        curl -sSL -o /usr/local/bin/argocd https://github.com/argoproj/argo-cd/releases/download/${argoCdVersion}/argocd-linux-amd64
                        chmod +x /usr/local/bin/argocd
                        ARGOCD_SERVER=argo.devops.prd.aws-01.legalzoom.com  /usr/local/bin/argocd app sync ${argoAppName}
                        ARGOCD_SERVER=argo.devops.prd.aws-01.legalzoom.com  /usr/local/bin/argocd app wait ${argoAppName}
                        echo "Done with argo deployment"
                        """
                }
            }
        }
    }
}
