#!/usr/bin/env groovy

/**
 * A generic pipeline function for building versioned gulp applications
 */

def call(Map map = [:]) {
    // mandatory
    def targetEnvironment = map.targetEnvironment
    def gulpVars     = map.gulpVars
    def gulpTasks   = map.gulpTasks
    def branchVersion = map.branchVersion
    def appName = map.appName
    def useNewCdn = map.useNewCdn ?: "false"
    // optional
    def sourceDirectory = map.sourceDirectory ?: env.SOURCE_DIRECTORY
    def npmRegistryName = map.npmRegistryName ?: env.NPM_REGISTRY_NAME
    def npmRegistryUrl = map.npmRegistryUrl ?: env.NPM_REGISTRY_URL
    def buildWorkspace = map.buildWorkspace ?: "${env.WORKSPACE}/build/${targetEnvironment}"
    def artifactWorkspace = map.artifactWorkspace ?: "${env.WORKSPACE}/artifact/${targetEnvironment}"    
    def stashedWorkspace = map.stashedWorkspace ?: env.ANGULAR_BUILD_WORKSPACE
    def outputDirectory = "${env.WORKSPACE}/artifact"
    def colors = colorCodes()

    try {
        assert targetEnvironment != null
        assert sourceDirectory != null
        assert npmRegistryName != null
        assert npmRegistryUrl != null
    } catch(NullPointerException e) {
        error("One or more required parameters were missing: ${e}")
    }

    map.each{println it.key +" "+it.value}


    statusMessage(status: "Building", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}TARGET_BUILD_ENVIRONMENT:${colors.none} ${targetEnvironment}
${colors.magenta}BUILD_WORKSPACE:${colors.none} ${buildWorkspace}
${colors.magenta}VERSION:${colors.none} ${branchVersion}
${colors.magenta}NPM_REGISTRY_NAME:${colors.none} ${npmRegistryName}
${colors.magenta}NPM_REGISTRY_URL:${colors.none} ${npmRegistryUrl}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }
    dir(buildWorkspace) {
        unstash stashedWorkspace
        sh "ls -lth"
        ansiColor('xterm') {
            echo "${colors.bold}(Step 1 of 3) Installing Dependencies${colors.none}"
        }
        try {
            sh("node -v")
            sh("npm config set registry ${npmRegistryUrl}")
            dir("${env.SOURCE_DIRECTORY}") {
                sh("rm -rf node_modules")
                sh("npm install")            
            }
        } catch (e) {
            error("Failed to install dependencies: ${e}")
            return
        }

        ansiColor('xterm') {
            echo "${colors.bold}(Step 2 of 3) Building website${colors.none}"
        }     
        try {
            dir("${env.SOURCE_DIRECTORY}") {
                gulpEnvVars = targetEnvironment == "dev" ? "${gulpVars}.${targetEnvironment}" : gulpVars 
                sh("cp ${gulpEnvVars}.js gulpVars.js")
                gulpTasks.each { task ->
                    sh("gulp ${task} --env=${targetEnvironment}")
                }
            }      
        }  catch (e) {
            error("Failed to build website: ${e}")
            return
        }

        ansiColor('xterm') {
            echo "${colors.bold}(Step 3 of 3) Copying Compiled ${targetEnvironment} Static Files To ${artifactWorkspace}${colors.none}"
        }     
        try {
            dir("${env.SOURCE_DIRECTORY}") {
                sh("mkdir -p ${outputDirectory}")
                sh("rsync -avz ${buildWorkspace}/artifact/* ${artifactWorkspace}")

                if (targetEnvironment == "dev" && useNewCdn == "true") {
                    withCredentials([[
                        $class: 'AmazonWebServicesCredentialsBinding',
                        credentialsId: 's3-cdn-access',
                        accessKeyVariable: 'AWS_ACCESS_KEY_ID',
                        secretKeyVariable: 'AWS_SECRET_ACCESS_KEY'
                    ]]) {
                        sh("aws s3 sync ${artifactWorkspace} s3://preprod.legalzoomcdn.net/${appName}/dev/")
                    }
                }
            }      
        }  catch (e) {
            error("Failed to copy artifact: ${e}")
            return
        }        
    }
    echo "Build Complete"
}
