#!/usr/bin/env groovy

/**
 * A generic pipeline function prints a nice banner from a map
 */

def call(Map map = [:]) {
    def c = colorCodes()
    decoration = "=" * 80
    result = ''
    result = result + """${c.bold}${c.blue}${decoration}${c.none}\n"""
    map.each { key, val ->
        result = result + """${c.magenta}${key}: ${val} ${c.none}\n"""
    }
    result = result + """${c.bold}${c.blue}${decoration}${c.none}\n"""
    ansiColor('xterm') {
        echo "${result}"
    }
}
