#!/usr/bin/env groovy

/**
 * A generic pipeline function for building AWS services
 */

def call(Map map = [:]) {
    appName = map.appName ?: env.PRODUCT_NAME
    colors = colorCodes()

    try {
        assert appName != null
    } catch (NullPointerException e) {
        ansiColor('xterm') {
            error("${colors.red}One or more required parameters were null:${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }

    statusMessage(status: 'Building AWS Service', level: 'info')

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}APP:${colors.none} ${appName}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }

    ansiColor('xterm') {
        echo "${colors.bold}(Step 1 of 2) Restoring Packages${colors.none}"
    }
    try {
        sh 'dotnet restore'
        sh 'dotnet --version'
    } catch (e) {
        ansiColor('xterm') {
            error("${colors.red}Unable to restore ${appName} packages:${colors.none} ${colors.bold}${e}${colors.none}")
        }
        return
    }

    ansiColor('xterm') {
        echo "${colors.bold}(Step 2 of 2) Compiling AWS Service${colors.none}"
    }
    retry(5) {
        try {
            sh 'dotnet build'
        } catch (e) {
            ansiColor('xterm') {
                error("${colors.red}Unable to build ${appName}:${colors.none} ${colors.bold}${e}${colors.none}")
            }
        }
    }
}
