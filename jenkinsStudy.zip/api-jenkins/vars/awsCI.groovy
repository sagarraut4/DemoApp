#!/usr/bin/env groovy

/**
 * A generic pipeline for AWS services
 */

def call(body) {
    // evaluate the body block, and collect configuration into the object
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    config.nodeLabel = config.nodeLabel ?: 'dotnet3_1'

    // this pipeline uses the linux nodes to build and deploy the .net core based aws serverless applications
    def operatingSystem = 'linux'
    def arch = 'amd64'
    def dotnetContainerVersion = ''
    def storageClassName = 'encrypted-gp3'

    def pythonGitImage = 'artifactory.legalzoom.com/docker/devops/jenkins/python-git-linux:latest'
    def jnlpImage = 'artifactory.legalzoom.com/docker/dotnet-linux:1.7.0'
    def dockerImage = 'artifactory.legalzoom.com/docker-remote/docker:dind'

    colors = colorCodes()

    // get slackChannel from luigiweb if one isn't provided
    if (config.slackChannel == null) {
        try {
            slackChannelEndpoint = "https://luigiweb.devops.legalzoom.com/awsservices/${config.appName}/slackchannel"
            slackChannel = readJSON(text: httpRequest("${slackChannelEndpoint}").content)[0]
        } catch (e) {
            ansiColor('xterm') {
                echo "${colors.yellow}WARNING: failed to get slack channel from ${slackChannelEndpoint}:${colors.none} ${colors.bold}${e}${colors.none}"
                echo "${colors.yellow}No slack channel notifications will be made throughout the build process${colors.none}"
            }
            slackChannel = ''
        }
    } else {
        slackChannel = config.slackChannel
    }

    echo 'Printing config'
    echo config.dump()
    echo 'Printed config'

    try {
        assert config.appName != null
        assert config.appDir != null
        assert slackChannel != null
    } catch (NullPointerException e) {
        ansiColor('xterm') {
            error("${colors.red}One or more required parameters were null:${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }

    if (config.nodeLabel == 'dotnet3_1') {
        dotnetContainerVersion = 'artifactory.legalzoom.com/docker-mcr-remote/dotnet/sdk:3.1'
        jnlpImage = 'artifactory.legalzoom.com/docker/dotnet-linux:1.7.0'
    }

    if (config.nodeLabel == 'dotnet6') {
        dotnetContainerVersion = 'artifactory.legalzoom.com/docker-mcr-remote/dotnet/sdk:6.0'
        jnlpImage = 'artifactory.legalzoom.com/docker/dotnet6-linux:1.0.0'
    }

    // AWS vars/defaults
    awsTransformationScript = config.awsTransformationScript ?: './aws/aws-transformations.ps1'
    awsTransformationDirectory = config.awsTransformationDirectory ?: './build-tools'

    // cicd vars/defaults
    createAndUploadArtifact = config.createAndUploadArtifact ?: null
    deployArtifact = config.deployArtifact ?: null
    artifactVersion = config.artifactVersion ?: null
    targetEnvironment = config.targetEnvironment ?: null
    nodeLabel = 'dotnet-linux'
    skipUnitTests = config.skipUnitTests ?: 'no'
    skipSNSDeliveryStatus = config.skipSNSDeliveryStatus ?: true
    jobName = JOB_NAME.replace('/', '_').replace('%2F', '_')
    awsCfChildStacks = config.awsCfChildStacks ?: null
    awsCfSubstitutions = config.awsCfSubstitutions ?: null

    pipeline {
        options {
            buildDiscarder(logRotator(numToKeepStr: '30'))
            disableConcurrentBuilds()
            timeout(time: 45, unit: 'MINUTES')
            timestamps()
        }

        environment {
            // mandatory
            PRODUCT_NAME = "${config.appName}"
            PRODUCT_NAME_LOWER = "${config.appName}".toLowerCase()
            APPLICATION_DIRECTORY = "${config.appDir}"
            AWS_APP_PROJECT_DIRECTORY = "${config.appProjectDirectory}"
            AWS_TRANSFORMATION_SCRIPT = "${awsTransformationScript}"
            AWS_TRANSFORMATION_DIRECTORY = "${awsTransformationDirectory}"
            SLACK_CHANNEL = "${config.slackChannel}"
            NODE_LABEL = "${config.nodeLabel}"
            TEST_PROJECT_DIRECTORY = "${config.testProjectDirectory}"
            AWS_PROFILE = "${config.awsEnv}"
            AWS_ENV = "${config.awsEnv}"
            AWS_REGION = "${config.awsRegion}"
            AWS_S3_BUCKET = "${config.awsS3Bucket}"
            AWS_CF_STACK = "${config.awsCfStack}"
            AWS_CF_PARAMS = "${config.awsCfParams}"
            AWS_CF_CHILD_STACKS = "${awsCfChildStacks}"
            AWS_CF_SUBS = "${awsCfSubstitutions}"
            AWS_IAM_ROLE_SNS_DELIVERY_STATUS = "${config.awsIamRoleSnsDeliveryStatus}"
            BRANCH_NAME = "${env.GIT_BRANCH}"

            // constant
            SLACK_TOKEN = credentials('slack-token')
        }

        agent {
            kubernetes {
                slaveConnectTimeout 300
                yaml """\
                apiVersion: v1
                kind: Pod
                metadata:
                  labels:
                    jenkins-agent: awsCI
                spec:
                  securityContext:
                    fsGroup: 1000
                    seLinuxOptions:
                      user: system_u
                      role: system_r
                      type: super_t
                      level: s0
                  containers:
                  - name: docker
                    image: ${dockerImage}
                    securityContext:
                      privileged: true
                  - name: python-git
                    image: ${pythonGitImage}
                    imagePullPolicy: Always
                    tty: true
                  - name: jnlp
                    image: ${jnlpImage}
                    imagePullPolicy: Always
                  nodeSelector:
                    kubernetes.io/os: ${operatingSystem}
                    kubernetes.io/arch: ${arch}
                  volumes:
                  - name: ssl-certs
                    hostPath:
                      path: /etc/ssl/certs/ca-bundle.crt
                """.stripIndent()
                workspaceVolume dynamicPVC(accessModes: 'ReadWriteOnce', requestsSize: '30Gi', storageClassName: storageClassName)
            }
        }

        stages {
            stage('Prepare') {
                steps {
                    // checkout delivery-services/build repo, it has the AWS transformation script
                    checkout(
                        changelog: false,
                        poll: false,
                        scm: [
                            $class: 'GitSCM',
                            branches: [[name: '*/master']],
                            doGenerateSubmoduleConfigurations: false,
                            extensions: [
                                [$class: 'RelativeTargetDirectory', relativeTargetDir: 'build-tools'],
                                [$class: 'CleanBeforeCheckout']
                            ],
                            submoduleCfg: [],
                            userRemoteConfigs: [
                                [credentialsId: 'f707bcaf-9685-472b-b7d5-646406d2cc21', url: 'https://github.legalzoom.com/delivery-services/build.git']
                            ]
                        ]
                    )

                    script {
                        def cdStrategy = determineCDStrategy(productName: env.PRODUCT_NAME, productType: 'aws')
                        env.ARTIFACT_VERSION = artifactVersion ?: cdStrategy.get(0)
                        env.CREATE_AND_UPLOAD_ARTIFACT = createAndUploadArtifact ?: cdStrategy.get(1)
                        env.DEPLOY_ARTIFACT = deployArtifact ?: cdStrategy.get(2)
                        env.TARGET_AWS_ENVIRONMENT = targetEnvironment ?: cdStrategy.get(3)
                        env.ARTIFACT_NAME = "${env.PRODUCT_NAME_LOWER}-${env.ARTIFACT_VERSION}.zip"
                        env.AWS_PROFILE = "${env.TARGET_AWS_ENVIRONMENT}".toUpperCase()
                    }
                }
            }

            stage('Build') {
                steps {
                    script {
                        // run AWS tranformation script
                        awsConfigMgmt(
                            awsProfile: env.AWS_PROFILE,
                            awsTransformationScript: env.AWS_TRANSFORMATION_SCRIPT,
                            awsTransformationDirectory: env.AWS_TRANSFORMATION_DIRECTORY
                        )

                        // ...then build
                        buildAWS(appName: env.PRODUCT_NAME)
                    }
                }
            }

            stage('Unit Test') {
                steps {
                    script {
                        if (skipUnitTests == 'yes') {
                            echo "SKIPPING UNIT TESTS: a 'skipUnitTests' parameter was provided and set to 'yes' in this build's Jenkinsfile"
                        } else {
                            echo 'Starting unit tests execution'

                            runUnitTests(appDir: env.TEST_PROJECT_DIRECTORY)

                            echo 'completed unit tests execution'
                        }
                    }
                }
            }

            stage('Deploy') {
                steps {
                    script {
                        //setup AWS Access Keys
                        setupAWSProfile(
                            awsProfile: env.AWS_PROFILE,
                            awsRegion: env.AWS_REGION
                        )

                        echo "template substitutions ${env.AWS_CF_SUBS}"

                        //deploy the app
                        deployAWS(
                            awsProfile: env.AWS_PROFILE,
                            awsRegion: env.AWS_REGION,
                            awsS3Bucket: env.AWS_S3_BUCKET,
                            awsCfStack: env.AWS_CF_STACK,
                            awsCfParams: env.AWS_CF_PARAMS,
                            awsCfSubstitutions : env.AWS_CF_SUBS,
                            awsIamRoleSnsDeliveryStatus: env.AWS_IAM_ROLE_SNS_DELIVERY_STATUS,
                            awsCfChildStacks: env.AWS_CF_CHILD_STACKS,
                        )
                    }
                }
            }
        }

        post {
            always {
                sendSlackMessage(
                    buildStatus: currentBuild.result ?: 'SUCCESSFUL',
                    slackChannel: env.SLACK_CHANNEL,
                    slackToken: env.SLACK_TOKEN
                )
                script {
                    if (currentBuild.result == 'FAILURE') {
                        emailext(
                            body: summary,
                            recipientProviders: [[$class: 'CulpritsRecipientProvider']],
                            subject: subject
                        )
                        statusMessage(status: "${env.PRODUCT_NAME} CICD Pipeline Failed", level: 'failure')
                    } else if (currentBuild.result == 'SUCCESS' || currentBuild.result == null) {
                        statusMessage(status: "${env.PRODUCT_NAME} CICD Pipeline Complete", level: 'success')
                    }
                }
            }
        }
    }
}
