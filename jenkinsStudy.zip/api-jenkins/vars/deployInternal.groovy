#!/usr/bin/env groovy

/**
 * A generic pipeline function for executing the angular deploy job in Rundeck
 */

def call(Map map = [:]) {
    // optional
    app = map.componentName ?: env.COMPONENT_NAME
    artifact = map.artifactName ?: env.ARTIFACT_NAME
    environment = map.environment ?: env.ENVIRONMENT
    slackChannel = map.slackChannel ?: env.SLACK_CHANNEL
    internalAppDomain = map.internalAppDomain
    colors = colorCodes()

    try {
        assert app != null
        assert artifact != null
        assert environment != null
        assert internalAppDomain != null
    } catch (e) {
        error("One or more required parameters were null: ${e}")
    }

    // luigiweb endpoints
    luigiWebBaseUrl = "https://luigiweb.devops.legalzoom.com"
    serverEndpoint = "${luigiWebBaseUrl}/internal-apps/domains/${internalAppDomain}/servers/${environment}"

    try {
        server = httpRequest("${serverEndpoint}").getContent()[1..-3].split(',')[0].replace('"','')
    } catch (e) {
        error("failed to get a site for the ${siteBranch} branch and/or a server for the target ${environment} environment: ${e}")
    }

    statusMessage(status: "Deploying", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}APP_NAME:${colors.none} ${app}
${colors.magenta}ARTIFACT:${colors.none} ${artifact}
${colors.magenta}APP_DOMAIN:${colors.none} ${internalAppDomain}
${colors.magenta}TARGET_ENVIRONMENT:${colors.none} ${environment}
${colors.magenta}TARGET_SERVER:${colors.none} ${server}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }

    slackMessage = "by jenkins <${env.BUILD_URL}|build #${env.BUILD_NUMBER}>"

    runRundeckJob(
        jobId: "3775a6b1-d10d-44af-b2b0-6aededce3965",
        jobOptions: "app=${app}\nartifact=${artifact}\nenvironment=${environment}\ndomain=${internalAppDomain}\nservers=${server}\nslack_channel=${slackChannel}\nslack_message=${slackMessage}"
    )

}
