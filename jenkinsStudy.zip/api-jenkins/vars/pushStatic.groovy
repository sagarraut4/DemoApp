#!/usr/bin/env groovy

/**
 * A generic pipeline function for pushing git diffs to dest repos
 */

def call(Map map = [:]) {
    // mandatory
    destDir = map.destDir
    sourceDir = map.sourceDir
    destRepo = map.destRepo
    // optional
    gitBranch = map.gitBranch ?: env.BRANCH_NAME
    // calculated
    gitCommit = sh(script: "git rev-parse --short HEAD", returnStdout: true).trim()
    colors = colorCodes()

    withCredentials([
        usernamePassword(
            credentialsId: '685757ba-4b94-45ec-a37a-4f48b340ef83',
            passwordVariable: 'PASSWORD',
            usernameVariable: 'USER'
        )
    ]) {
        gitCredentialsUrl = "https://${USER}:${PASSWORD}@github.legalzoom.com"
    }

    gitUrl = "https://github.legalzoom.com/${destRepo}.git"

    try {
        assert destDir != null
        assert sourceDir != null
        assert gitBranch != null
        assert destRepo != null
    } catch(e) {
        error("One or more required parameters were null: ${e}")
    }

    statusMessage(status: "Pushing To Dest Repo", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}DEST_DIRECTORY:${colors.none} ${destDir}
${colors.magenta}SOURCE_DIRECTORY:${colors.none} ${sourceDir}
${colors.magenta}GIT_BRANCH:${colors.none} ${gitBranch}
${colors.magenta}DEST_REPO:${colors.none} ${destRepo}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }

    ansiColor('xterm') {
        echo "${colors.bold}(Step 1 of 3) Cloning Dest Repo${colors.none}"
    }
    try {
        sh """
            set +x
            echo "${gitCredentialsUrl}" > ~/.git-credentials
            set -x
            
            chmod 600 ~/.git-credentials
            
            if [ -d "$destDir" ]
            then
              echo "removing $destDir"
              rm -fr $destDir
            fi
            
            echo "Cloning engineering/site-external-questionnaire-dest"
            if ! git clone -b $gitBranch --single-branch $gitUrl $destDir ; then
                git clone -b develop --single-branch $gitUrl $destDir
            fi
            cd $destDir
            git config push.default simple
            git config user.name "jenkins"
            git config user.email "jenkins@legalzoom.com"
            git config credential.helper 'store --file ~/.git-credentials'
            
            git checkout $gitBranch 2>/dev/null || git checkout -b $gitBranch
        """
    } catch(e) {
        error("Exception occurred while cloning the dest repo: ${e}")
        return
    }

    ansiColor('xterm') {
        echo "${colors.bold}(Step 2 of 3) Copying Build To Cloned Dest Repo${colors.none}"
    }
    try {
        sh "rsync -avz --exclude '*.zip' ${sourceDir}/* ${destDir}"
    } catch(e) {
        error("Exception occurred while copying build to the cloned dest repo: ${e}")
        return
    }

    ansiColor('xterm') {
        echo "${colors.bold}(Step 3 of 3) Pushing Diff To Dest Repo${colors.none}"
    }
    try {

        retry(2) {
            dir(destDir) {
                sh """
                    git status 
                    git add .
                    if [ -n "\$(git status --porcelain)" ]; then 
                        git commit -m "Results of commit id ${gitCommit}, build number ${env.BUILD_NUMBER}"
                        # only git pull origin branch if it exists
                        if [ -n "\$(git ls-remote --heads ${gitUrl} ${gitBranch})" ] ; then
                            git pull origin ${gitBranch}
                        fi
                        git push --set-upstream origin ${gitBranch}
                    fi
                """
            }
        }
    } catch(e) {
        error("Exception occurred while pushing to the dest repo: ${e}")
        return
    }
}
