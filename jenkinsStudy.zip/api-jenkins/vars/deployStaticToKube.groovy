#!/usr/bin/env groovy

/**
 * A generic pipeline function for executing the angular deploy job in Rundeck
 */

def call(Map map = [:]) {
    // optional
    project = map.project ?: env.SERVICE_NAME
    artifact = map.artifactName ?: env.ARTIFACT_NAME
    environment = map.environment ?: env.ENVIRONMENT
    imageEnvironment = map.imageEnvironment ?: environment
    deploymentRepo = map.deploymentRepo
    extension = "zip"
    deployFilesOnly = 'true'
    colors = colorCodes()
    commit = env.GIT_COMMIT
    try { 
        assert project != null
        assert artifact != null
        assert environment != null
    } catch (e) {
        error("One or more required parameters were null: ${e}")
    }

    // luigiweb endpoints
    luigiWebBaseUrl = "https://luigiweb.devops.legalzoom.com"
    extensionEndpoint = "${luigiWebBaseUrl}/services/website/${project}/attributes?key=artifactory.ext"
    extension = httpRequest("${extensionEndpoint}").getContent()[1..-3].replace('"','')
    repoEndpoint = "${luigiWebBaseUrl}/services/website/${project}/attributes?key=artifactory.repo"
    repo = httpRequest("${repoEndpoint}").getContent()[1..-3].replace('"','').toLowerCase()

    statusMessage(status: "Deploying", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}PROJECT_NAME:${colors.none} ${project}
${colors.magenta}ARTIFACT:${colors.none} ${artifact}
${colors.magenta}TARGET_ENVIRONMENT:${colors.none} ${environment}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }
    
    if(environment != "prod") {
        withCredentials([
                usernamePassword(
                    credentialsId: '685757ba-4b94-45ec-a37a-4f48b340ef83',
                    passwordVariable: 'PASSWORD',
                    usernameVariable: 'USER'
                )
            ]) {
            git url: "https://${USER}:${PASSWORD}@github.legalzoom.com/${deploymentRepo}"
            container('kustomize') {
                sh """
                cd envs/${environment} && /app/kustomize edit set image artifactory.legalzoom.com/docker/engineering/${repo}/${repo}-${imageEnvironment}=artifactory.legalzoom.com/docker/engineering/${repo}/${repo}-${imageEnvironment}:${commit}
                """
            }
            gitCredentialsUrl = "https://${USER}:${PASSWORD}@github.legalzoom.com/${deploymentRepo}"
            sh """
                git config --global user.email "dl-devops@legalzoom.com"
                git config --global user.name "Jenkins Pipeline"
                git add envs
                if [ -z \$(git status --porcelain) ];
                then
                    echo "No change to commit"
                else
                    git commit -m "Update ${environment} container to version ${commit}"
                    git push ${gitCredentialsUrl}
                fi
            """
        }
        echo "Deployment Complete"
    }
}
