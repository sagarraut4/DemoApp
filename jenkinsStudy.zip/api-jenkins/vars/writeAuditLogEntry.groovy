#!/usr/bin/env groovy

/**
 * A generic pipeline function for writing audit log entries
 */

def call(Map map = [:]) {
    // mandatory
    productName = map.productName
    artifactName = map.artifactName
    // optional
    username = map.username
    action = map.action ?: 'build'
    environment = map.env ?: ""
    notes = map.notes ?: ""
    colors = colorCodes()

    try {
        assert productName != null
        assert artifactName != null
        assert username != null
        assert action != null
    } catch(e) {
        ansiColor('xterm') {
            error("${colors.red}One or more required parameters were null:${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }

    statusMessage(status: "Logging Build In Audit Log", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}ACTION:${colors.none} ${action}
${colors.magenta}PRODUCT:${colors.none} ${productName}
${colors.magenta}BUILD_USER:${colors.none} ${username}
${colors.magenta}ARTIFACT:${colors.none} ${artifactName}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }

    try {
        // write audit log entry by executing the 'AuditLog' Rundeck Job
        auditLogJobId = "90fb5a8f-9bac-4a57-a2d7-94a044df1430"
        runRundeckJob(
            jobId: "${auditLogJobId}",
            jobOptions: "action=${action}\nproduct=${productName}\nusername=${username}\nartifact=${artifactName}\nenvironment=${environment}\nnotes=${notes}"
        )
    } catch(e) {
        ansiColor('xterm') {
            error("${colors.red}Exception occurred while writing audit log entry:${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }

}
