#!/usr/bin/env groovy

/**
 * A generic pipeline function for getting commit info
 */

def call() {
    getAuthor = """git show -s --pretty=%an"""
    getAuthorEmail = """git log -1 --pretty=format:'%ae'"""
    getCommitSha = """git log --pretty=format:'%h' -n 1"""
    colors = colorCodes()

    statusMessage(status: "Getting Commit Info", level: "info")

    dir(env.WORKSPACE) {
        try {
            if (isUnix()) {
                author = sh(returnStdout: true, script: getAuthor).trim()
                authorEmail = sh(returnStdout: true, script: getAuthorEmail).trim()
                commitSha = sh(returnStdout: true, script: getCommitSha).trim()
            } else {
                author = powershell(returnStdout: true, script: getAuthor).trim()
                authorEmail = powershell(returnStdout: true, script: getAuthorEmail).trim()
                commitSha = powershell(returnStdout: true, script: getCommitSha).trim()
            }
        } catch(e) {
            ansiColor('xterm') {
                error("${colors.red}failed to get commit info:${colors.none} ${colors.bold}${e}${colors.none}")
            }
        }
    }

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}AUTHOR:${colors.none} ${author}
${colors.magenta}AUTHOR_EMAIL:${colors.none} ${authorEmail}
${colors.magenta}COMMIT_SHA:${colors.none} ${commitSha}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }

    return [author: author, authorEmail: authorEmail, commitSha: commitSha]

}
