#!/usr/bin/env groovy

/**
 * A generic pipeline function for executing the angular deploy job in Rundeck
 */

def call(Map map = [:]) {
    // optional
    environment = map.environment ?: env.ENVIRONMENT
    projectName = map.projectName ?: null
    deploymentRepo = map.deploymentRepo
    image = map.image
    extension = "zip"
    deployFilesOnly = 'true'
    colors = colorCodes()
    commit = env.GIT_COMMIT
    tag = env.TAG_NAME
    awsRegion = map.awsRegion ?: 'usw2'
    try { 
        assert environment != null
        assert projectName != null
        assert image != null
        assert deploymentRepo != null
        assert commit != null
    } catch (e) {
        error("One or more required parameters were null: ${e}")
    }

    statusMessage(status: "Deploying", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}TARGET_ENVIRONMENT:${colors.none} ${environment}
${colors.magenta}IMAGE:${colors.none} ${image}
${colors.magenta}COMMIT:${colors.none} ${commit}
${colors.magenta}TAG:${colors.none} ${tag}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }
    
    if(environment != "prod") {
        withCredentials([
                usernamePassword(
                    credentialsId: '685757ba-4b94-45ec-a37a-4f48b340ef83',
                    passwordVariable: 'PASSWORD',
                    usernameVariable: 'USER'
                )
            ]) {
            git url: "https://${USER}:${PASSWORD}@github.legalzoom.com/${deploymentRepo}"
            commitMessageVersion = ''
            container('kustomize') {
                if (environment == 'dev') {
                    sh """
                    cd envs/${environment} && /app/kustomize edit set image ${image}=${image}:${commit}
                    """
                    commitMessageVersion = commit
                } else {
                    sh """
                    cd envs/${environment} && /app/kustomize edit set image ${image}=${image}:${tag}
                    """
                    commitMessageVersion = tag
                }
            }
            gitCredentialsUrl = "https://${USER}:${PASSWORD}@github.legalzoom.com/${deploymentRepo}"
            sh """
                git config --global user.email "dl-devops@legalzoom.com"
                git config --global user.name "Jenkins Pipeline"
                git add envs
                if [ -z \$(git status --porcelain) ];
                then
                    echo "No change to commit"
                else
                    git commit -m "Update ${environment} container to version ${commitMessageVersion}"
                    git push ${gitCredentialsUrl}
                fi
            """
            container('alpine') {
                def secrets = [
                    [path: "argocd/${projectName}/jenkins", engineVersion: 1, secretValues: [
                        [envVar: 'ARGOCD_AUTH_TOKEN', vaultKey: 'authToken'],
                    ]],
                ]
                def configuration = [vaultUrl: 'https://vault.legalzoom.com',
                            vaultCredentialId: 'vault',
                            engineVersion: 1]
                // inside this block your credentials will be available as env variables
                withVault([configuration: configuration, vaultSecrets: secrets]) {
                    sh """
                    apk add curl
                    echo "pulling argocd package version 2.1.3"
                    curl -sSL -o /usr/local/bin/argocd https://github.com/argoproj/argo-cd/releases/download/v2.1.3/argocd-linux-amd64
                    chmod +x /usr/local/bin/argocd
                    echo "syncing argo project ${projectName}-${awsRegion}-${environment}"
                    ARGOCD_SERVER=argo.devops.prd.aws-01.legalzoom.com /usr/local/bin/argocd app sync ${projectName}-${awsRegion}-${environment}
                    echo "waiting for project"
                    ARGOCD_SERVER=argo.devops.prd.aws-01.legalzoom.com /usr/local/bin/argocd app wait ${projectName}-${awsRegion}-${environment}
                """
                }
            }
        }
        echo "Deployment Complete"
    }
}
