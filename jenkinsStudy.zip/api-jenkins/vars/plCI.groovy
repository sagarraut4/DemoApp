#!/usr/bin/env groovy

/**
 * A generic pipeline for versioned gulp applications
 */

def call(body) {
    // evaluate the body block, and collect configuration into the object
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    nodeLabel = config.nodeLabel ?: "frontend-angular-npm"
    sourceDirectory = config.sourceDirectory ?: "./"
    target = config.target
    gulpTasks = config.gulpTasks ?: null
    destRepo = config.destRepo ?: null
    npmRegistryName = config.npmRegistryName ?: "@legalzoom:registry"
    npmRegistryUrl = config.npmRegistryUrl ?: "https://artifactory.legalzoom.com/artifactory/api/npm/npm/"
    customTargetEnvironment = config.customTargetEnvironment ?: null
    angularAppName = config.angularAppName ?: "lib-glo-ng-bootstrap"
    serviceName = config.serviceName ?: null

    try {
        assert config.appName != null
        assert config.slackChannel != null
    } catch(NullPointerException e) {
        error("One or more required parameters were missing: ${e}")
    }

    pipeline {
        options{
            buildDiscarder(logRotator(numToKeepStr: '30'))
            disableConcurrentBuilds()
            timeout(time: 20, unit: 'MINUTES')
            timestamps()
        }

        environment {
            // mandatory
            PRODUCT_NAME = "${config.appName}"
            PRODUCT_NAME_LOWER = "${config.appName}".toLowerCase()
            COMPONENT_NAME = "${config.appName}"
            TARGET = "${config.target}"
            SOURCE_DIRECTORY = "${sourceDirectory}"
            SLACK_CHANNEL= "${config.slackChannel}"
            NODE_LABEL = "${nodeLabel}"
            // constant
            SLACK_TOKEN = credentials('slack-token')
            NPM_REGISTRY_NAME = "${npmRegistryName}"
            NPM_REGISTRY_URL = "${npmRegistryUrl}"
            ANGULAR_BUILD_WORKSPACE = "angularBuildWorkspace"
            NPM_SOURCE_DIRECTORY = "${npmSourceDirectory}"
            ANGULAR_APP_NAME = "${angularAppName}"
            SERVICE_NAME = "${config.serviceName}"
        }

        agent {
            node {
                label("${nodeLabel}")
                customWorkspace("/home/jenkins/8e52cda1/workspace/${env.JOB_NAME}/")
            }
        }

        stages {

            stage('Prepare') {
                steps {
                    sendSlackMessage(
                        buildStatus: 'STARTED',
                        slackChannel: env.SLACK_CHANNEL,
                        slackToken: env.SLACK_TOKEN
                    )
                    script {
                        def cdStrategy = determineCDStrategy(
                            productName: env.PRODUCT_NAME,
                            productType: "angular",
                            customTargetEnvironment: customTargetEnvironment,
                        )
                        env.SEMANTIC_VERSION = cdStrategy.get(0)
                        env.CREATE_AND_UPLOAD_ARTIFACT = cdStrategy.get(1)
                        env.DEPLOY_ARTIFACT = cdStrategy.get(2)
                        env.ENVIRONMENT = cdStrategy.get(3)
                        env.SEMANTIC_VERSION = env.SEMANTIC_VERSION == null || env.SEMANTIC_VERSION == 'none' ? 'latest' : env.SEMANTIC_VERSION
                    }
                }
            }

            stage("Build") {
                steps {
                    stash name: env.ANGULAR_BUILD_WORKSPACE
                    script {
                        env.ARTIFACT_NAME = "${env.PRODUCT_NAME_LOWER}-${env.ENVIRONMENT}-${env.SEMANTIC_VERSION}.zip"
                        buildPL(
                            targetEnvironment: env.ENVIRONMENT,
                            gulpTasks: gulpTasks,
                            branchVersion: env.SEMANTIC_VERSION,
                            angularApp: env.ANGULAR_APP_NAME
                        )
                    }
                }
            }

             stage("Publish to NPM") {
                when { expression { env.TAG_NAME || (env.SEMANTIC_VERSION ==~ /^[0-9]+.[0-9]+.[0-9]+$/ && env.ENVIRONMENT == "qa")} }
                steps {
                    publishNpmPackage(
                        sourceDirectory: "${env.WORKSPACE}/build/${env.ENVIRONMENT}/angular/${ANGULAR_APP_NAME}/dist/${ANGULAR_APP_NAME}/",
                        tarFile: "legalzoom-${ANGULAR_APP_NAME}-${env.SEMANTIC_VERSION}.tgz",
                        tag: env.TAG_NAME || "latest",
                        packageName: "${env.ANGULAR_APP_NAME}",
                        version: "${env.SEMANTIC_VERSION}"
                    )
                }
            }

            stage("Create Artifact") {
                when { expression { env.CREATE_AND_UPLOAD_ARTIFACT == "yes" } }
                steps {
                    createArtifact(
                        artifactName: "${env.ARTIFACT_NAME}",
                        artifactSource: "${env.WORKSPACE}/artifact/${env.ENVIRONMENT}"
                    )
                }
            }

            stage('Upload Artifact') {
                when { expression { env.CREATE_AND_UPLOAD_ARTIFACT == "yes" } }
                steps {
                    uploadArtifact(
                        targetRepo: "${env.PRODUCT_NAME}/${env.ARTIFACT_NAME}",
                        sourceArtifact: "${env.WORKSPACE}/artifact/${env.ENVIRONMENT}/${env.ARTIFACT_NAME}",
                        productName: "${env.PRODUCT_NAME}"
                    )
                }
            }

            stage("Push To Dest Repo") {
                when { expression { destRepo != null } }
                steps {
                    pushStatic (
                        destDir: "${env.WORKSPACE}/dest",
                        sourceDir: "${env.WORKSPACE}/artifact/${env.ENVIRONMENT}",
                        destRepo: "${destRepo}"
                    )
                }
            }

            stage('Rundeck: Start Deploy Job'){
                when { expression { env.DEPLOY_ARTIFACT == "yes" && env.SEMANTIC_VERSION ==~ /^[0-9]+.[0-9]+.[0-9]+$/ } }
                steps {
                    script {
                        deployStatic()
                    }
                }
            }

        }

        post {
            always {
                script {
                    buildStatus = currentBuild.result ?: 'SUCCESSFUL'
                    subject = "${buildStatus}: ${env.JOB_NAME} [BUILD #${env.BUILD_NUMBER}]"
                    summary = "${subject} (${env.BUILD_URL})"
                    sendSlackMessage(
                        buildStatus: buildStatus,
                        slackChannel: env.SLACK_CHANNEL,
                        slackToken: env.SLACK_TOKEN
                    )
                    if (currentBuild.result == 'FAILURE') {
                        emailext(
                            body: summary,
                            recipientProviders: [[$class: 'CulpritsRecipientProvider']],
                            subject: subject
                        )
                        statusMessage(status: "${env.PRODUCT_NAME} CICD Pipeline Failed", level: "failure")
                    } else if (currentBuild.result == 'SUCCESS' || currentBuild.result == null) {
                        statusMessage(status: "${env.PRODUCT_NAME} CICD Pipeline Complete", level: "success")
                    }
                }
            }
        }
    }
}
