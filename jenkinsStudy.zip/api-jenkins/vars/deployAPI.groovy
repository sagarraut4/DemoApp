#!/usr/bin/env groovy

/**
 * A generic pipeline function for executing the angular deploy job in Rundeck
 */

def call(Map map = [:]) {
    // optional
    serviceName = map.serviceName ?: env.PRODUCT_NAME
    artifactName = map.artifactName ?: env.ARTIFACT_NAME
    environment = map.environment ?: env.ENVIRONMENT
    slackChannel = map.slackChannel ?: env.SLACK_CHANNEL
    port = map.port ?: null
    colors = colorCodes()

    try {
        assert serviceName != null
        assert artifactName != null
        assert environment != null
    } catch (e) {
        ansiColor('xterm') {
            error("${colors.red}One or more required parameters were null:${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }

    statusMessage(status: "Triggering Artifact Deployment", level: "info")

    // luigiweb endpoints
    luigiWebBaseUrl = "https://luigiweb.devops.legalzoom.com"
    portEndpoint = "${luigiWebBaseUrl}/apiservices/${serviceName}/port"
    serverGroupEndpoint = "${luigiWebBaseUrl}/services/API/${serviceName}/attributes?key=server_group.${environment}"

    // to run the deploy job we must collect the api service's 'port' and 'servers' attributes from Luigiweb
    try {
        serverGroup = httpRequest("${serverGroupEndpoint}").getContent()[1..-3].replace('"','')
        port = port ?: httpRequest("${portEndpoint}").getContent()[1..-3].replace('"','')
        serverEndpoint = "${luigiWebBaseUrl}/services/api/servers/${environment}/${serverGroup}"
        servers = httpRequest("${serverEndpoint}").getContent()[1..-3].replace('"','')
    } catch (e) {
        ansiColor('xterm') {
            error("${colors.red}failed to get a port for ${serviceName} and/or servers for the target ${environment} " +
                    "environment:${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}API_SERVICE:${colors.none} ${serviceName}
${colors.magenta}ARTIFACT:${colors.none} ${artifactName}
${colors.magenta}PORT:${colors.none} ${port}
${colors.magenta}ENVIRONMENT:${colors.none} ${environment}
${colors.magenta}SERVERS:${colors.none} ${servers}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }

    /* deploy job options:
       ---------------------
        service [mandatory] = the name of the API
        build [mandatory] = the API artifact to deploy - i.e. storageservice-1.0.0.zip
        port [mandatory] = the port the API's IIS app pool will listen on
        environment [mandatory] = the environment to deploy to
        servers [mandatory] = the target environment's servers (comma-delimited lists of servers are allowed)
        slack_channel [optional] = the slack channel to send deployment notifications to (null values allowed)
    */

    slackMessage = "by jenkins <${env.BUILD_URL}|build #${env.BUILD_NUMBER}>"

    runRundeckJob(
        jobId: "73ac6d75-ba57-477d-99a0-18b2150224ca",
        jobOptions: "service=${serviceName}\nbuild=${artifactName}\nport=${port}\nenvironment=${environment}\nservers=${servers}\nslack_channel=${slackChannel}\nslack_message=${slackMessage}"
    )

}
