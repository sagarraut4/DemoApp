# Shared Pipeline Library
A list of available pipeline functions, general info about them, and their usage.

## buildApiService(Map map = [:])
### Description
Builds API services.
 
### Args
```groovy
apiServiceName          (String: optional) - the API service name [default = env.PRODUCT_NAME]
appVersion              (String: optional) - the desired version of the build [default = env.PRODUCT_VERSION]
sourceDirectory         (String: optional) - the API service source directory to build [default = env.SOURCE_DIRECTORY]
runtimeIdentifier       (String: optional) - the runtime identifier [default = env.RUNTIME_IDENTIFIER]
``` 
 
### Usage
``` groovy
buildApiService(
    apiServiceName: "<api-service-name>"                  
    appVersion: "<app-version>"                           
    sourceDirectory: "</path/to/build/source/dir>" 
    runtimeIdentifier: "<runtime-identifier>"            
)
```

## runUnitTests(Map map = [:])
### Description
Runs API Service unit tests
 
### Args
```groovy
testProjectDirectory    (String: optional) - the directory to run unit test from [default = env.TEST_PROJECT_DIRECTORY]
``` 
 
## Usage
``` groovy
runUnitTests(
    testProjectDirectory: "</path/to/unit/tests>"                  
)
```

## createArtifact(Map map = [:])
### Description
Creates API service artifacts.
 
### Args
```groovy
artifactName      (String: required) - the desired name of the artifact
apiServiceName    (String: optional) - the API service name [default = env.PRODUCT_NAME]
buildSource       (String: optional) - the path of the directory to build [default =  ".\bin\${apiServiceName}"]
``` 
 
## Usage
``` groovy
createArtifact(
    artifactName: "<aritifact-name>"
    apiServiceName: "<api-service-name>"
    buildSource: "<build-source>"
)
```

## uploadArtifact(Map map = [:])
### Description
Uploads an artifact and publishes its build info to Artifactory.
 
### Args
```groovy
targetRepo            (String: required) - the target repository and/or sub-directory tree to upload the Artifact to
sourceArtifact        (String: required) - the path to the artifact you wish to upload 
buildName             (String: optional) - the name of the build [default = env.PRODUCT_NAME]
artifactoryServerId   (String: optional) - the pre-configured atricactory instance to upload to [default = 'artifactory']
``` 
 
### Usage
``` groovy
uploadArtifact(
    buildName: "<build-name>"                    
    targetRepo: "<target/repo/path>"              
    sourceArtifact: "</path/to/local/artifact>"  
)
```

## runRundeckJob(Map map = [:])
### Description
Runs a job on a target Rundeck instance
 
### Args
```groovy
jobID             (String: required) - the job ID to run
jobOptions        (String: required) - the job options. Must be string of '\n' separated '<option>=<value>' pairs   
rundeckInstance   (String: optional) - the pre-configured target Rundeck instance
``` 
 
### Usage
``` groovy
runRundeckJob(
    jobId: "<job-id>"                    
    jobOptions: "foo=<value-foo>\nbar=<value-bar>\nbaz=<value-baz>"              
    rundeckInstance: "rundeck"
)
```
