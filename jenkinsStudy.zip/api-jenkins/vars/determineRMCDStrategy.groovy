#!/usr/bin/env groovy

/**
 * A generic pipeline function for determining a continous delivery/deployment strategy
 */

def call(Map map = [:]) {
    productName = map.productName ?: env.PRODUCT_NAME
    skipDeploy = map.skipDeploy ?: null
    baseImage = map.baseImage ?: null
    commit = map.commit ?: env.GIT_COMMIT
    tag = map.tag ?: env.TAG_NAME
    colors = colorCodes()

    try {
        assert productName != null
        assert baseImage != null
        assert commit != null
    } catch(NullPointerException e) {
        ansiColor('xterm') {
            error("${colors.red}One or more required parameters were null:${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }

    statusMessage(status: "Determining Continuous Delivery/Deployment Strategy", level: "info")
    try {
        commitExists = sh(script: "docker manifest inspect $baseImage:$commit > /dev/null ; echo \$?", returnStatus: true) == 0 ? true : false
        if (tag != null) {
            tagExists = sh(script: "docker manifest inspect $baseImage:$tag > /dev/null ; echo \$?", returnStatus: true) == 0 ? true : false
        } else {
            tagExists = false
        }

        echo "commit exists: ${commitExists}"
        echo "tag exists: ${tagExists}"

        if (env.TAG_NAME ==~ /^rc-*[0-9]+.[0-9]+.[0-9]+$/) { //release candidates go to qa
            version = "${env.TAG_NAME}".find("[0-9]+.[0-9]+.[0-9]+[h]?")
            if (version == null) {
                ansiColor('xterm') {
                    error("${colors.red}unable to extract a version from tag '${env.TAG_NAME}'. " +
                            "Please use the release manager in backstage to generate the tags.${colors.none}")
                }
                return
            }
            if (!tagExists && !commitExists) {
                createAndUploadArtifact = "yes"
            } else {
                createAndUploadArtifact = "no"
                echo "Skip build, commit exists"
            }

            if (tagExists) {
                deployArtifact = "no"
            } else {
                deployArtifact = "yes"
            }
            
            targetEnvironment = "qa"
        } else if (env.TAG_NAME ==~ /^version-*[0-9]+.[0-9]+.[0-9]+$/) { //release versions go to prod
            version = "${env.TAG_NAME}".find("[0-9]+.[0-9]+.[0-9]+[h]?")
            if (version == null) {
                ansiColor('xterm') {
                    error("${colors.red}unable to extract a version from tag '${env.TAG_NAME}'. " +
                            "Please use the release manager in backstage to generate the tags.${colors.none}")
                }
                return
            }
            if (!tagExists && !commitExists) {
                createAndUploadArtifact = "yes"
            } else {
                createAndUploadArtifact = "no"
                echo "Skip build, commit exists"
            }

            if (tagExists) {
                deployArtifact = "no"
            } else {
                deployArtifact = "yes"
            }

            deployArtifact = "yes"
            targetEnvironment = "prd"
        } else if (env.BRANCH_NAME ==~ /^develop$/) { //develop goes to dev
            version = "snapshot"
            createAndUploadArtifact = "yes"
            deployArtifact = "yes"
            targetEnvironment = "dev"

            if (commitExists) {
                createAndUploadArtifact = "no"
                deployArtifact = "no"
                echo "Skip build, commit exists"
            }
        } else { //nothing else gets deployed
            version = "none"
            createAndUploadArtifact = "no"
            deployArtifact = "no"
            targetEnvironment = "dev"
        }
        if (skipDeploy == "yes"){
            deployArtifact = "no"
        }
    } catch(e) {
        ansiColor('xterm') {
            error("${colors.red}Failed to determine strategy:${colors.none} ${colors.bold}${e}${colors.none}")
        }
        return
    }

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}Version:${colors.none} ${version}
${colors.magenta}Create and Upload Artifact:${colors.none} ${createAndUploadArtifact}
${colors.magenta}Deploy Artifact:${colors.none} ${deployArtifact}
${colors.magenta}Target Environment:${colors.none} ${targetEnvironment}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }

    return [version, createAndUploadArtifact, deployArtifact, targetEnvironment]
}
