#!/usr/bin/env groovy

/**
 * A generic pipeline for angular applications
 */

def call(body) {
    // evaluate the body block, and collect configuration into the object
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    nodeLabel = config.nodeLabel ?: "msbuild"
    sourceBinaries = config.sourceBinaries ?: "D:\\binaries\\*"
    buildProperties = config.buildProperties ?: "Configuration=Debug;Platform=AnyCPU"
    packagesToRestore = config.packagesToRestore ?: null
    getBranchSitesFromLuigiweb = config.getBranchSitesFromLuigiweb ?: "yes"
    packagesToInstall = config.packagesToInstall ?: [
        "Microsoft.ReportViewer.Common",
        "Microsoft.ReportViewer.ProcessingObjectModel",
        "Microsoft.ReportViewer.WebForms"
    ]
    artifactShouldContainAppFolder = config.artifactShouldContainAppFolder ?: "yes"
    internalApp = config.internalApp ?: "no"
    internalAppDomain = config.internalAppDomain ?: null
    additionalSourceDirectories = config.additionalSourceDirectories ?: null
    customTargetEnvironment = config.customTargetEnvironment ?: null
    skipNugetPackBuild = config.skipNugetPackBuild ?: "no"
    serviceName = config.serviceName ?: null

    try {
        assert config.appName != null
        assert config.productName != null
        assert config.solutionFile != null
        assert config.packagesToRestore != null
        assert config.sourceDirectory != null
        assert config.slackChannel != null
    } catch(NullPointerException e) {
        error("One or more required parameters were missing: ${e}")
    }

    jobName = JOB_NAME.replace('/', '_').replace('%2F', '_')

    pipeline {
        options{
            buildDiscarder(logRotator(numToKeepStr: '30'))
            disableConcurrentBuilds()
            timeout(time: 20, unit: 'MINUTES')
            timestamps()
        }

        environment {
            // mandatory
            APP_NAME = "${config.appName}"
            PRODUCT_NAME = "${config.productName}"
            PRODUCT_NAME_LOWER = "${config.productName}".toLowerCase()
            COMPONENT_NAME = "${config.productName}"
            SOLUTION_FILE = "${config.solutionFile}"
            BUILD_PROPERTIES = "${buildProperties}"
            DESTINATION_BINARIES = "${WORKSPACE}\\Binaries"
            SOURCE_DIRECTORY = "${config.sourceDirectory}"
            SOURCE_BINARIES = "${sourceBinaries}"
            LZWEB_BIN = "${WORKSPACE}\\LZ25\\bin"
            SLACK_CHANNEL= "${config.slackChannel}"
            NODE_LABEL = "${nodeLabel}"
            // constant
            SLACK_TOKEN = credentials('slack-token')
            SERVICE_NAME = "${config.serviceName}"
        }

        agent {
            node {
                label("${nodeLabel}")
                customWorkspace("D:\\Jenkins\\8e52cda1\\workspace\\${jobName}\\")
            }
        }

        stages {
            stage('Prepare') {
                steps {
                    sendSlackMessage(
                        buildStatus: 'STARTED',
                        slackChannel: env.SLACK_CHANNEL,
                        slackToken: env.SLACK_TOKEN
                    )
                    script {
                        def cdStrategy = determineCDStrategy(
                            productName: env.PRODUCT_NAME,
                            productType: "dotnet",
                            getBranchSitesFromLuigiweb: getBranchSitesFromLuigiweb,
                            customTargetEnvironment: customTargetEnvironment,
                        )
                        env.ARTIFACT_VERSION = cdStrategy.get(0)
                        env.CREATE_AND_UPLOAD_ARTIFACT = cdStrategy.get(1)
                        env.DEPLOY_ARTIFACT = cdStrategy.get(2)
                        env.TARGET_DOTNET_ENVIRONMENT = cdStrategy.get(3)
                        env.BUILD_ENVIRONMENTS = cdStrategy.get(4)
                    }
                }
            }

            stage("Build") {
                steps {
                    script {
                        // restore and install nuget packages
                        installNugetPackages(
                            buildProperties: "${env.BUILD_PROPERTIES}",
                            sourceDirectory: "${env.SOURCE_DIRECTORY}", packagesToRestore: packagesToRestore,
                            packagesToInstall: packagesToInstall,
                            skipNugetPackBuild: skipNugetPackBuild,
                        )

                        // if app is LZWeb build LZ.Web.Business
                        if (env.APP_NAME == "LZ25") {
                            dir(".\\LZ.Web.Business\\") {
                                powershell("msbuild /p:OutDir='${env.LZWEB_BIN}'")
                            }
                        }

                        // build environment specific artifact
                        def buildEnvironments = env.BUILD_ENVIRONMENTS.split(",")
                        buildEnvironments.each { buildEnvironment ->
                            targetArtifactDir = ".\\artifact\\${buildEnvironment}\\${env.APP_NAME}"
                            buildDotNetApp(
                                appName: "${env.APP_NAME}",
                                targetEnvironment: buildEnvironment,
                                solutionFile: "${env.SOLUTION_FILE}",
                                sourceBinaries: "${env.SOURCE_BINARIES}",
                                destinationBinaries: "${env.DESTINATION_BINARIES}\\${buildEnvironment}",
                                targetArtifactDir: targetArtifactDir,
                                additionalSourceDirectories: additionalSourceDirectories,
                            )

                            // move resulting msbuild artifact into "${targetArtifactDir}" for archival
                            if (env.APP_NAME == "LZ25") {
                                msbuildArtifact = ".\\LZ25_deploy\\obj\\${buildEnvironment}\\TempBuildDir"
                            } else if (env.APP_NAME == "BrainNET") {
                                msbuildArtifact = ".\\LZ.Brain.Web\\obj\\${buildEnvironment}\\Package\\PackageTmp"
                            } else if (env.APP_NAME == "AttorneyServicesManager") {
                                msbuildArtifact = ".\\LZ.AttorneyServicesManager.Web\\obj\\${buildEnvironment}\\Package\\PackageTmp"
                            } else if (env.APP_NAME == "RACorporateCenter") {
                                msbuildArtifact = ".\\LZ.WebSite.RA.Web_Deploy\\obj\\${buildEnvironment}\\TempBuildDir"
                            } else {
                                msbuildArtifact = ".\\${env.SOURCE_DIRECTORY}\\obj\\${buildEnvironment}\\Package\\PackageTmp"
                            }

                            try {
                                powershell("""
                                mkdir "${targetArtifactDir}" -Force
                                Move-Item -Path "${msbuildArtifact}\\*" -Destination "${targetArtifactDir}" -ErrorAction Stop
                            """)
                            } catch (e) {
                                error("Failed to move \"${msbuildArtifact}\" to \"${targetArtifactDir}\": ${e}")
                                return
                            }

                            // create artifact
                            artifactName = "${env.PRODUCT_NAME_LOWER}-${buildEnvironment}-${env.ARTIFACT_VERSION}.zip"
                            if (artifactShouldContainAppFolder == "yes") {
                                artifactSource = "${targetArtifactDir}"
                            } else {
                                artifactSource = "${targetArtifactDir}\\*"
                            }
                            createArtifact(
                                artifactName: artifactName,
                                artifactSource: artifactSource,
                            )
                        }
                    }
                }
            }

            stage("Archive") {
                when { expression { env.CREATE_AND_UPLOAD_ARTIFACT == "yes" } }
                steps {
                    uploadArtifact(
                        targetRepo: "${env.PRODUCT_NAME}/",
                        sourceArtifact: ".\\${env.PRODUCT_NAME_LOWER}-*.zip",
                        productName: "${env.PRODUCT_NAME}"
                    )
                }
            }

            stage('Rundeck: Start Deploy Job') {
                when {
                    expression { (env.DEPLOY_ARTIFACT == "yes") }
                }
                steps {
                    script {
                        if (env.TARGET_DOTNET_ENVIRONMENT == "poc") {
                            artifactName = "${env.PRODUCT_NAME_LOWER}-dev-${env.ARTIFACT_VERSION}.zip"
                        } else if (env.TARGET_DOTNET_ENVIRONMENT == "performance") {
                            artifactName = "${env.PRODUCT_NAME_LOWER}-prod-${env.ARTIFACT_VERSION}.zip"
                        } else {
                            artifactName = "${env.PRODUCT_NAME_LOWER}-${env.TARGET_DOTNET_ENVIRONMENT}-${env.ARTIFACT_VERSION}.zip"
                        }
                        if (internalApp == "yes") {
                            deployInternal(
                                environment: "${env.TARGET_DOTNET_ENVIRONMENT}",
                                artifactName: artifactName,
                                componentName: "${env.PRODUCT_NAME}",
                                internalAppDomain: internalAppDomain,
                            )
                        } else {
                            deployStatic(
                                environment: "${env.TARGET_DOTNET_ENVIRONMENT}",
                                artifactName: artifactName,
                                componentName: "${env.PRODUCT_NAME}",
                                serviceName: "${env.SERVICE_NAME}"
                            )
                        }
                    }
                }
            }
        }

        post {
            always {
                script {
                    buildStatus = currentBuild.result ?: 'SUCCESSFUL'
                    subject = "${buildStatus}: ${env.JOB_NAME} [BUILD #${env.BUILD_NUMBER}]"
                    summary = "${subject} (${env.BUILD_URL})"
                    sendSlackMessage(
                        buildStatus: buildStatus,
                        slackChannel: env.SLACK_CHANNEL,
                        slackToken: env.SLACK_TOKEN
                    )
                    if (currentBuild.result == 'FAILURE') {
                        emailext(
                            body: summary,
                            recipientProviders: [[$class: 'CulpritsRecipientProvider']],
                            subject: subject
                        )
                        statusMessage(status: "${env.PRODUCT_NAME} CICD Pipeline Failed", level: "failure")
                    } else if (currentBuild.result == 'SUCCESS' || currentBuild.result == null) {
                        statusMessage(status: "${env.PRODUCT_NAME} CICD Pipeline Complete", level: "success")
                    }
                }
            }
        }
    }
}
