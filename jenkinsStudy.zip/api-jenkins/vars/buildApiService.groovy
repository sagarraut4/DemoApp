#!/usr/bin/env groovy

/**
 * A generic pipeline function for building API services
 */

def call(Map map = [:]) {
    runtimeVersion = map.runtimeVersion ?: env.ARTIFACT_VERSION
    branchName = map.branchName ?: ""
    apiServiceName = map.apiName ?: env.PRODUCT_NAME
    sourceDirectory = map.sourceDirectory ?: env.SOURCE_DIRECTORY
    runtimeIdentifier = map.runtimeIdentifier ?: env.RUNTIME_IDENTIFIER
    isTransformWebConfigDisabled = map.isTransformWebConfigDisabled ?: env.IS_TRANSFORM_WEB_CONFIG_DISABLED
    outputDirectory = map.outputDirectory ?: "${WORKSPACE}/artifact/${apiServiceName}"
    targetEnvironment = map.targetEnvironment ?: env.TARGET_API_ENVIRONMENT
    additionalPackages = map.additionalPackages ?: []
    colors = colorCodes()
    nodeLabel=map.nodeLabel?: ""

    try {
        assert runtimeVersion != null
        assert apiServiceName != null
        assert sourceDirectory != null
        assert runtimeIdentifier != null
        assert isTransformWebConfigDisabled != null
    } catch(NullPointerException e) {
        ansiColor('xterm') {
            error("${colors.red}One or more required parameters were null:${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }

    if ( targetEnvironment in ["stg", "prod"] ) {
        apiBuildConfig = 'Release'
    } else {
        apiBuildConfig = 'Debug'
    }

    /*
     if it begins with an alphabetic character prepend a faux version to it:
     */
    if ( runtimeVersion ==~ /^[A-Za-z].*/ ) {
        runtimeVersion = "0.0.0-${runtimeVersion}"
    /*
     if it's "X.X.Xh", replace "h" with "-hotfix":
     */
    } else if ( runtimeVersion ==~ /^[0-9]+.[0-9]+.[0-9]+h$/ ) {
        runtimeVersion = "${runtimeVersion}".replace("h", "-hotfix")
    /*
     otherwise if it's neither "X.X.X" or "X.X.X-hotfix", assume it's invalid and fail the build
     */
    } else if ( ! ( runtimeVersion ==~ /^[0-9]+.[0-9]+.[0-9]+(-hotfix)?$/ ) ) {
        ansiColor('xterm') {
            error("${colors.red}the runtime version appears invalid - ${runtimeVersion} :${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }

    statusMessage(status: "Building API", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}API:${colors.none} ${apiServiceName}
${colors.magenta}RUNTIME_VERSION:${colors.none} ${runtimeVersion}
${colors.magenta}RUNTIME_IDENTIFIER:${colors.none} ${runtimeIdentifier}
${colors.magenta}IS_TRANSFORM_WEB_CONFIG_DISABLED:${colors.none} ${isTransformWebConfigDisabled}
${colors.magenta}API_BUILD_CONFIG:${colors.none} ${apiBuildConfig}
${colors.magenta}OUTPUT_DIRECTORY:${colors.none} ${outputDirectory}
${colors.magenta}TARGET_ENVIRONMENT:${colors.none} ${targetEnvironment}
${colors.magenta}ADDITIONAL_PACKAGES:${colors.none} ${additionalPackages}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }

    ansiColor('xterm') {
        echo "${colors.bold}(Step 1 of 3) Adding Packages${colors.none}"
    }

    try {
        if (additionalPackages.size() == 0) {
            echo "skipping, there were no additional packages requested in the Jenkinsfile"
        } else {
            additionalPackages.each { additionalPackage, version ->
                dir(sourceDirectory) {
                    if(isUnix()) {
                        sh "dotnet add package ${additionalPackage} --version ${version}"
                    } else {
                        bat "dotnet add package ${additionalPackage} --version ${version}"
                    }
                }
            }
        }
    } catch(e) {
        ansiColor('xterm') {
            error("${colors.red}Unable to add one ore more packages:${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }

    ansiColor('xterm') {
        echo "${colors.bold}(Step 2 of 3) Restoring Packages${colors.none}"
    }
    try {
        if(isUnix()) {
          if(nodeLabel == "dotnet3_1") {
            sh """
            dotnet tool install -g CycloneDX --version 2.7.0
            /root/.dotnet/tools/dotnet-CycloneDX ./${apiServiceName}.sln -j -dgl -o ./
            """
          } else {
            sh """
            dotnet tool install -g CycloneDX --version 2.8.1
            /root/.dotnet/tools/dotnet-CycloneDX ./${apiServiceName}.sln -j -dgl -o ./
            """
          }


          if(branchName == "develop") {
            dependencyTrackPublisher artifact: 'bom.json', projectName: apiServiceName, projectVersion: 'develop', synchronous: true, dependencyTrackApiKey: 'T2YngpC58lZTSdIdOcj6dAnumNxHrtip'
          }
          sh "dotnet restore"
          sh "dotnet --version"
        } else {
          bat "dotnet restore"
          bat "dotnet --version"
        }
    } catch(e) {
        ansiColor('xterm') {
            error("${colors.red}Unable to restore ${apiServiceName} packages:${colors.none} ${colors.bold}${e}${colors.none}")
        }
        return
    }

    ansiColor('xterm') {
        echo "${colors.bold}(Step 3 of 3) Compiling API${colors.none}"
    }
    retry(5) {
        try {
            dir(sourceDirectory) {
                if(isUnix()) {
                  sh """
                      dotnet publish -c ${apiBuildConfig} -r ${runtimeIdentifier} -o ${outputDirectory} /p:Version=${runtimeVersion} /p:IsTransformWebConfigDisabled=${isTransformWebConfigDisabled}
                  """
                } else {
                  bat """
                      dotnet publish -c ${apiBuildConfig} -r ${runtimeIdentifier} -o ${outputDirectory} ^
                          /p:Version=${runtimeVersion} /p:IsTransformWebConfigDisabled=${isTransformWebConfigDisabled}
                  """
                }
            }
        } catch(e) {
            ansiColor('xterm') {
                error("${colors.red}Unable to build ${apiServiceName}:${colors.none} ${colors.bold}${e}${colors.none}")
            }
        }
    }

}
