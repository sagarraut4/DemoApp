#!/usr/bin/env groovy

/**
 * A generic pipeline function for executing the angular deploy job in Rundeck
 */

def call(Map map = [:]) {
    // optional
    project = map.project ?: env.SERVICE_NAME
    artifact = map.artifactName ?: env.ARTIFACT_NAME
    environment = map.environment ?: env.ENVIRONMENT
    deploymentRepo = map.deploymentRepo
    containerGithubUrl = map.containerGithubUrl ?: "github.legalzoom.com/devops/nginx-app.git"
    extension = "zip"
    deployFilesOnly = 'true'
    colors = colorCodes()
    commit = env.GIT_COMMIT
    ssiPath = map.ssiPath ?: "NONE"
    try { 
        assert project != null
        assert artifact != null
        assert environment != null
    } catch (e) {
        error("One or more required parameters were null: ${e}")
    }

    // luigiweb endpoints
    luigiWebBaseUrl = "https://luigiweb.devops.legalzoom.com"
    extensionEndpoint = "${luigiWebBaseUrl}/services/website/${project}/attributes?key=artifactory.ext"
    extension = httpRequest("${extensionEndpoint}").getContent()[1..-3].replace('"','')
    repoEndpoint = "${luigiWebBaseUrl}/services/website/${project}/attributes?key=artifactory.repo"
    repo = httpRequest("${repoEndpoint}").getContent()[1..-3].replace('"','')
    repo_lower = repo.toLowerCase()

    statusMessage(status: "Deploying", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}PROJECT_NAME:${colors.none} ${project}
${colors.magenta}ARTIFACT:${colors.none} ${artifact}
${colors.magenta}TARGET_ENVIRONMENT:${colors.none} ${environment}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }
    container('docker') {
        dir("empty-dir") {
            withCredentials([usernamePassword(credentialsId: '685757ba-4b94-45ec-a37a-4f48b340ef83', passwordVariable: 'password', usernameVariable: 'user')]) {
                git url: "https://${user}:${password}@${containerGithubUrl}"
                sh """
                    docker build -t artifactory.legalzoom.com/docker/engineering/${repo_lower}/${repo_lower}-${environment}:${commit} --build-arg ARTIFACT_ENV=${environment} --build-arg ARTIFACT_REPOSITORY=${repo} --build-arg ARTIFACT_NAME=${artifact} --build-arg USER=${USER} --build-arg PASSWORD=${password} --build-arg SSI_FILES=${ssiPath} .
                """
            }
        }
        publishContainer(project: project, environment: environment, org: 'engineering', repo: repo_lower, imageTag: commit)
    }
}
