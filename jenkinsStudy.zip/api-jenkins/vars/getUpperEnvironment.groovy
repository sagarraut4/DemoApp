#!/usr/bin/env groovy

/**
 * A generic pipeline function that returns a given environment's direct upper environment
 */

def call(Map map = [:]) {
    environment = map.environment
    environmentMap = [
        poc: 'poc',  // used for testing
        predev: 'dev',
        dev: 'qa',
        qa: 'stg',
        stg: 'prod',
    ]

    try {
        assert environment != null
    } catch(NullPointerException e) {
        ansiColor('xterm') {
            error("${colors.red}One or more required parameters were null:${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }

    return environmentMap."${environment}"

}
