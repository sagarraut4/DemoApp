#!/usr/bin/env groovy

/**
 * A generic pipeline for angular applications
 */

def call(body) {
    // evaluate the body block, and collect configuration into the object
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    nodeLabel = config.nodeLabel ?: "frontend-angular"
    sourceDirectory = config.sourceDirectory ?: "./src"
    angularVersion = config.angularVersion ?: 4
    verbosity = config.verbosity ?: "development"
    gulpTasks = config.gulpTasks ?: null
    destRepo = config.destRepo ?: null
    npmRegistryName = config.npmRegistryName ?: "@legalzoom:registry"
    npmRegistryUrl = config.npmRegistryUrl ?: "https://artifactory.legalzoom.com/artifactory/api/npm/npm/"
    customTargetEnvironment = config.customTargetEnvironment ?: null
    serviceName = config.serviceName ?: null
    appendConfig = config.appendConfig ?: null
    addHashToFiles = config.addHashToFiles?: "false"
    useNewCdn = config.useNewCdn ?: "false"
    kubeDeploy = config.kubeDeploy ?: "false"
    multipleDeploy = config.multipleDeploy ?: "false"
    colors = colorCodes()
    skipDeploy = config.skipDeploy ?: null
    addPeerDependencies = config.addPeerDependencies ?: null
    runUnitTests = config.runUnitTests ?: "false"
    runCypressTests = config.runCypressTests ?: "false"
    testCommand = config.testCommand ?: null
    cypressTestCommand = config.cypressTestCommand ?: null
    deploymentRepo = config.deploymentRepo ?: null
    createAndUploadArtifact = config.createAndUploadArtifact ?: "false"
    ssiPath = config.ssiPath ?: "NONE"

    try {
        assert config.appName != null
        assert config.platforms != null
        assert config.href != null
        assert config.slackChannel != null
    } catch(NullPointerException e) {
        error("One or more required parameters were missing: ${e}")
    }

    pipeline {
        agent {
            kubernetes {
              yaml """\
                apiVersion: v1
                kind: Pod
                metadata:
                  labels:
                    build-groovy: angularCI
                spec:
                  securityContext:
                    fsGroup: 2000
                  containers:
                  - name: angular
                    image: artifactory.legalzoom.com/docker/jenkinsagentangularcentos:latest
                    tty: true
                    command:
                    - cat
                    resources:
                      requests:
                        cpu: '6'
                        memory: '14Gi'
                      limits:
                        cpu: '6'
                        memory: '14Gi'
                  - name: docker
                    image: artifactory.legalzoom.com/docker-remote/docker:dind
                    securityContext:
                      privileged: true
                  - name: kustomize
                    image: k8s.gcr.io/kustomize/kustomize:v3.8.7
                    tty: true
                    command:
                    - cat
                  - name: cypress
                    image: artifactory.legalzoom.com/docker-remote/cypress/included:8.7.0
                    tty: true
                    command:
                    - cat
                  nodeSelector:
                    kubernetes.io/os: linux
                    kubernetes.io/arch: amd64
                """.stripIndent()
                workspaceVolume dynamicPVC(accessModes: 'ReadWriteOnce', requestsSize: '30Gi')
            }
        }

        environment {
            // mandatory
            PRODUCT_NAME = "${config.appName}"
            PRODUCT_NAME_LOWER = "${config.appName}".toLowerCase()
            COMPONENT_NAME = "${config.appName}"
            ANGULAR_VERSION = "${angularVersion}"
            HOME = "."
            HREF = "${config.href}"
            SOURCE_DIRECTORY = "${sourceDirectory}"
            SLACK_CHANNEL= "${config.slackChannel}"
            NODE_LABEL = "${nodeLabel}"
            // constant
            SLACK_TOKEN = credentials('slack-token')
            NPM_REGISTRY_NAME = "${npmRegistryName}"
            NPM_REGISTRY_URL = "${npmRegistryUrl}"
            ANGULAR_BUILD_WORKSPACE = "angularBuildWorkspace"
            SERVICE_NAME = "${config.serviceName}"
            APPEND_CONFIG = "${config.appendConfig}"
            ADD_HASH_TO_FILES = "${config.addHashToFiles}"
        }

        stages {
            stage('Prepare') {

                steps {
                    sendSlackMessage(
                        buildStatus: 'STARTED',
                        slackChannel: env.SLACK_CHANNEL,
                        slackToken: env.SLACK_TOKEN
                    )
                    script {
                        def cdStrategy = determineCDStrategy(
                            productName: env.PRODUCT_NAME,
                            productType: "angular",
                            customTargetEnvironment: customTargetEnvironment,
                            skipDeploy: skipDeploy
                        )
                        env.SEMANTIC_VERSION = cdStrategy.get(0)
                        env.CREATE_AND_UPLOAD_ARTIFACT = cdStrategy.get(1)
                        env.DEPLOY_ARTIFACT = cdStrategy.get(2)
                        env.TARGET_ENVIRONMENT = cdStrategy.get(3)
                        env.BUILD_ENVIRONMENTS = cdStrategy.get(4)
                    }
                }
            }

            stage("Build") {
                steps {
                    stash name: env.ANGULAR_BUILD_WORKSPACE
                    script {
                        container('angular') {
                            //def buildStage = [:]
                            def buildEnvironments = env.BUILD_ENVIRONMENTS.split(",")
                            buildEnvironments.each { buildEnvironment ->
                                //buildStage[buildEnvironment] = {
                                    if (buildEnvironment in ["qa", "stg", "prod"]) {
                                        verbosity = "production"
                                    }
                                    buildAngularApp(
                                        platforms: config.platforms,
                                        href: config.href,
                                        targetEnvironment: buildEnvironment,
                                        outputDirectory: "${env.WORKSPACE}/artifact/${buildEnvironment}",
                                        gulpTasks: gulpTasks,
                                        verbosity: verbosity,
                                        appendConfig: "${env.APPEND_CONFIG}",
                                        addHashToFiles: "${env.ADD_HASH_TO_FILES}",
                                        addPeerDependencies: addPeerDependencies,
                                        useNewCdn: useNewCdn
                                    )
                                //}
                            }
                        }
                    }
                }
            }

            stage("Unit tests") {
                when { expression { runUnitTests == "true" } }
                steps {
                    container('angular') {
                        dir("${env.SOURCE_DIRECTORY}") {
                            sh("rm -rf node_modules")
                            sh("npm install")
                            runNpmTests(testProjectDirectory: "./", testCommand: testCommand)
                        }
                    }
                }
            }

            stage("Archive") {
                when { 
                    anyOf {
                        expression { env.CREATE_AND_UPLOAD_ARTIFACT == "yes" } 
                        expression { createAndUploadArtifact == "true" }
                    }
                }
                steps {
                    script {
                        container('angular') {
                            def archiveStage = [:]
                            def buildEnvironments = env.BUILD_ENVIRONMENTS.split(",")
                            sourceArtifact = "${env.WORKSPACE}/artifact/*/*.zip"
                            if (addPeerDependencies == "yes"){
                                sourceArtifact = "${env.WORKSPACE}/build/*/dist/*.tgz"
                            }
                            buildEnvironments.each { buildEnvironment ->
                                archiveStage[buildEnvironment] = {
                                    def artifactName = "${env.PRODUCT_NAME_LOWER}-${buildEnvironment}-${env.SEMANTIC_VERSION}.zip"
                                    def artifactSource = "${env.WORKSPACE}/artifact/${buildEnvironment}"
                                    if (addPeerDependencies == "yes"){
                                        artifactName = "${env.PRODUCT_NAME_LOWER}-${buildEnvironment}-${env.SEMANTIC_VERSION}.tgz"
                                        artifactSource = "${env.WORKSPACE}/build/${buildEnvironment}/dist"
                                    }
                                    dir ("${artifactSource}"){
                                        sh "ls -lth"
                                        createArtifact(
                                            artifactName: "${artifactName}",
                                            artifactSource: "${artifactSource}",
                                            addPeerDependencies: "${addPeerDependencies}"
                                        )
                                    }
                                }
                            }
                            parallel archiveStage
                            uploadArtifact(
                                targetRepo: "${env.PRODUCT_NAME}/",
                                sourceArtifact: "${sourceArtifact}",
                                productName: "${env.PRODUCT_NAME}"
                            )
                        }
                        if (kubeDeploy == "true") {
                            def buildEnvironments = env.BUILD_ENVIRONMENTS.split(",")
                            buildEnvironments.each { buildEnvironment -> 
                                def artifactName = "${env.PRODUCT_NAME_LOWER}-${buildEnvironment}-${env.SEMANTIC_VERSION}.zip"
                                buildStaticAssetContainer(environment: buildEnvironment, artifactName: artifactName, project: "${env.SERVICE_NAME}", deploymentRepo: deploymentRepo, ssiPath: ssiPath)
                            }
                        }
                    }
                }
            }

            stage("Cypress tests") {
                when { expression { runCypressTests == "true" } }
                steps {
                    container('docker') {
                        dir("${env.SOURCE_DIRECTORY}") {
                            sh """
                            docker network create angularapp
                                docker run \
                                    --name wwwlocal.legalzoom.com \
                                    --rm \
                                    --detach \
                                    --network angularapp \
                                    -p 8443:8443 \
                                    -p 8080:8080 \
                                    -d artifactory.legalzoom.com/docker/engineering/${env.SERVICE_NAME}/${env.SERVICE_NAME}-${env.TARGET_ENVIRONMENT}:${env.GIT_COMMIT}
                            """
                            statusMessage(status: "Starting Cypress Tests", level: "info")
                            sh 'docker run -v $PWD:/e2e -w /e2e --network angularapp --entrypoint="" cypress/included:8.7.0 /bin/bash -c ' + cypressTestCommand
                        }
                    }
                }
                post {
                    always {
                        archiveArtifacts allowEmptyArchive: true, artifacts:'cypress/screenshots/**, cypress/videos/**', caseSensitive: false
                    }
                }
            }

            stage('Rundeck: Start Deploy Job'){
                when { expression { env.DEPLOY_ARTIFACT == "yes" } }
                steps {
                    script {
                        if (env.TARGET_ENVIRONMENT == "poc") {
                            artifactName = "${env.PRODUCT_NAME_LOWER}-dev-${env.SEMANTIC_VERSION}.zip"
                            imageEnvironment = "dev"
                        } else {
                            artifactName = "${env.PRODUCT_NAME_LOWER}-${env.TARGET_ENVIRONMENT}-${env.SEMANTIC_VERSION}.zip"
                            imageEnvironment = "${env.TARGET_ENVIRONMENT}"
                        }
                        def awsDeploy = false
                        try {
                            websiteAttributeUrl = "https://luigiweb.devops.legalzoom.com/services/website/${env.PRODUCT_NAME}/attributes?key=aws-deploy"
                            awsDeployString = httpRequest("${websiteAttributeUrl}").getContent()
                            awsDeploy = awsDeployString.toBoolean()
                        } catch(e) {
                            ansiColor('xterm') {
                                error("${colors.red}failed to get deployment type from ${websiteAttributeUrl} :${colors.none} ${colors.bold}${e}${colors.none}")
                            }
                        }
                        if (awsDeploy) {
                          deployStaticToAws(environment: "${env.TARGET_ENVIRONMENT}", artifactName: artifactName, project: "${env.SERVICE_NAME}")
                        } else if (kubeDeploy == "true") {
                          deployStaticToKube(environment: "${env.TARGET_ENVIRONMENT}", imageEnvironment: imageEnvironment, artifactName: artifactName, project: "${env.SERVICE_NAME}", deploymentRepo: deploymentRepo)
                          if (multipleDeploy == "true") {
                              deployStatic(environment: "${env.TARGET_ENVIRONMENT}", artifactName: artifactName, serviceName: "${env.SERVICE_NAME}")
                          }
                        } else {
                          deployStatic(environment: "${env.TARGET_ENVIRONMENT}", artifactName: artifactName, serviceName: "${env.SERVICE_NAME}")
                        }
                    }
                }
            }
        }

        post {
            always {
                script {
                    buildStatus = currentBuild.result ?: 'SUCCESSFUL'
                    subject = "${buildStatus}: ${env.JOB_NAME} [BUILD #${env.BUILD_NUMBER}]"
                    summary = "${subject} (${env.BUILD_URL})"
                    sendSlackMessage(
                        buildStatus: buildStatus,
                        slackChannel: env.SLACK_CHANNEL,
                        slackToken: env.SLACK_TOKEN
                    )
                    if (currentBuild.result == 'FAILURE') {
                        emailext(
                            body: summary,
                            recipientProviders: [[$class: 'CulpritsRecipientProvider']],
                            subject: subject
                        )
                        statusMessage(status: "${env.PRODUCT_NAME} CICD Pipeline Failed", level: "failure")
                    } else if (currentBuild.result == 'SUCCESS' || currentBuild.result == null) {
                        statusMessage(status: "${env.PRODUCT_NAME} CICD Pipeline Complete", level: "success")
                    }
                    junit testResults: '**/target/**/*.xml', allowEmptyResults: true
                }
            }
        }
    }
}
