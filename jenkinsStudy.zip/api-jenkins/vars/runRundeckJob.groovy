#!/usr/bin/env groovy

/**
 * A generic pipeline function for running Rundeck jobs
 */

def call(Map map = [:]) {
    // mandatory
    jobId = map.jobId
    jobOptions = map.jobOptions
    // optional
    rundeckInstance = map.rundeckInstance ?: "rundeck"
    shouldWaitForRundeckJob = map.shouldWaitForRundeckJob ?: false
    shouldFailTheBuild = map.shouldFailTheBuild ?: false
    tailLog = map.tailLog ?: false
    colors = colorCodes()

    try {
        assert jobId != null
        assert jobOptions != null
        assert rundeckInstance != null
    } catch(e) {
        ansiColor('xterm') {
            error("${colors.red}One or more required parameters were null:${colors.none} ${e}")
        }
    }

    if (shouldWaitForRundeckJob) {
        header = "Starting Rundeck Job"
        footer = "Rundeck Job Complete"
    } else {
        header = "Triggering Rundeck Job"
        footer = "Rundeck Job Triggered"
    }

    statusMessage(status: "${header}", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}RUNDECK EXECUTION PARAMS:${colors.none}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}RUNDECK_INSTANCE:${colors.none} ${rundeckInstance}
${colors.magenta}SHOULD_FAIL_BUILD:${colors.none} ${shouldFailTheBuild}
${colors.magenta}SHOULD_WAIT_FOR_RUNDECK_JOB:${colors.none} ${shouldWaitForRundeckJob}
${colors.magenta}TAIL_LOG:${colors.none} ${tailLog}
${colors.magenta}JOB_ID:${colors.none} ${jobId}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}

${colors.bold}RUNDECK JOB OPTIONS:${colors.none}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.bold}${jobOptions}${colors.none}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }

    try {
        step([
            $class: 'RundeckNotifier',
            includeRundeckLogs: true,
            jobId: jobId,
            options: "${jobOptions}",
            rundeckInstance: rundeckInstance,
            shouldFailTheBuild: shouldFailTheBuild,
            shouldWaitForRundeckJob: shouldWaitForRundeckJob,
            tailLog: tailLog
        ])
   } catch(e) {
        ansiColor('xterm') {
            error("${colors.red}Exception occurred while trying to run ${jobId} on ${rundeckInstance}:${colors.none} ${e}")
        }
   }

}
