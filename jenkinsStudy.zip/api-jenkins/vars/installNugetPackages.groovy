#!/usr/bin/env groovy

/**
 * A generic pipeline function for building .Net applications
 */

def call(Map map = [:]) {
    // nuget params
    buildProperties = map.buildProperties ?: env.BUILD_PROPERTIES
    sourceDirectory = map.sourceDirectory ?: env.SOURCE_DIRECTORY
    nugetPackagesDirectory = map.nugetPackagesDirectory ?: "${env.WORKSPACE}\\packages"
    // LZWEB
    packagesToRestore = map.packagesToRestore ?: env.PACKAGES_TO_RESTORE
    packagesToInstall = map.packagesToInstall ?: env.PACKAGES_TO_INSTALL
    skipNugetPackBuild = map.skipNugetPackBuild ?: "no"
    colors = colorCodes()

    try {
        assert packagesToInstall != null
        assert packagesToRestore != null
        assert buildProperties != null
        assert sourceDirectory != null
    } catch(NullPointerException e) {
        error("One or more required parameters were missing: ${e}")
    }

    statusMessage(status: "Installing Nuget Packages", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}SOURCE_DIRECTORY:${colors.none} ${sourceDirectory}
${colors.magenta}BUILD_PROPERTIES:${colors.none} ${buildProperties}
${colors.magenta}NUGET_PACKAGES_DIRECTORY:${colors.none} ${nugetPackagesDirectory}
${colors.magenta}NUGET_PACKAGES_TO_RESTORE:${colors.none} ${packagesToRestore}
${colors.magenta}NUGET_PACKAGES_TO_INSTALL:${colors.none} ${packagesToInstall}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }

    ansiColor('xterm') {
        echo "${colors.bold}(Step 1 of 4) Preparing Workspace For Nuget Restore/Installs${colors.none}"
    }

    try {
        // if it doesn't exist, create the nuget packages directory
        powershell("""
            if (!(test-path "${nugetPackagesDirectory}")){
                echo "${nugetPackagesDirectory} does not exist, creating"
                new-item -type directory ${nugetPackagesDirectory} -force
            }
        """)
    } catch(e) {
        error("Failed to prepare workspace: ${e}")
        return
    }

    ansiColor('xterm') {
        echo "${colors.bold}(Step 2 of 4) Restoring Nuget Packages${colors.none}"
    }
    packagesToRestore.each { pkg ->
        try {
            powershell("nuget restore ${pkg} -outputDirectory ${nugetPackagesDirectory}")
        } catch(e) {
            error("Failed to restore ${pkg}: ${e}")
            return
        }
    }

    ansiColor('xterm') {
        echo "${colors.bold}(Step 3 of 4) Building Nuget Packages${colors.none}"
    }
    if (skipNugetPackBuild == "yes") {
        echo "the 'skipNugetPackBuild' parameter provided is 'yes', skipping nuget build step..."
    } else {
        try {
            dir("${sourceDirectory}") {
                powershell("""
                nuget pack -build -includereferencedprojects -outputdirectory "${nugetPackagesDirectory}" -properties "${buildProperties}" -Symbols
            """)
            }
        } catch(e) {
            error("Failed to build nuget packages: ${e}")
            return
        }
    }

    ansiColor('xterm') {
        echo "${colors.bold}(Step 4 of 4) Installing Nuget Packages${colors.none}"
    }
    packagesToInstall.each { pkg ->
        try {
            powershell("nuget install ${pkg} -OutputDir ${nugetPackagesDirectory}")
        } catch(e) {
            echo "Failed to install the '${pkg}' nuget package: ${e}"
        }
    }

}
