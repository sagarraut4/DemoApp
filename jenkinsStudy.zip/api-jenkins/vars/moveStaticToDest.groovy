#!/usr/bin/env groovy

/**
 * A generic pipeline function for pushing git diffs to dest repos
 */

def call(Map map = [:]) {
    // mandatory
    destDir = map.destDir
    sourceDir = map.sourceDir
    destRepo = map.destRepo
    artifactName = map.artifactFile
    artifactFolder = map.artifactFolder
    // optional
    gitBranch = map.gitBranch ?: env.BRANCH_NAME
    // calculated
    gitCommit = sh(script: "git rev-parse --short HEAD", returnStdout: true).trim()
    //have any pages been actually changed - via a git diff
    changedPages = ""
    colors = colorCodes()

    withCredentials([
        usernamePassword(
            credentialsId: 'f707bcaf-9685-472b-b7d5-646406d2cc21',
            passwordVariable: 'PASSWORD',
            usernameVariable: 'USER'
        )
    ]) {
        gitCredentialsUrl = "https://${USER}:${PASSWORD}@github.legalzoom.com"
    }

    gitUrl = "https://github.legalzoom.com/${destRepo}.git"

    try {
        assert destDir != null
        assert sourceDir != null
        assert gitBranch != null
        assert destRepo != null
    } catch(e) {
        error("One or more required parameters were null: ${e}")
    }

    statusMessage(status: "Pushing To Dest Repo", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}DEST_DIRECTORY:${colors.none} ${destDir}
${colors.magenta}SOURCE_DIRECTORY:${colors.none} ${sourceDir}
${colors.magenta}GIT_BRANCH:${colors.none} ${gitBranch}
${colors.magenta}DEST_REPO:${colors.none} ${destRepo}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }

    ansiColor('xterm') {
        echo "${colors.bold}(Step 1 of 3) Cloning Dest Repo${colors.none}"
    }
    try {
        sh """
            set +x
            echo "${gitCredentialsUrl}" > ~/.git-credentials
            set -x
            
            chmod 600 ~/.git-credentials
            
            if [ -d "$destDir" ]
            then
              echo "removing $destDir"
              rm -fr $destDir
            fi
            
            echo "Cloning engineering/site-external-html2-dest"
            git clone $gitUrl $destDir
            cd $destDir
            git config push.default simple
            git config user.name "jenkins"
            git config user.email "jenkins@legalzoom.com"
            git config credential.helper 'store --file ~/.git-credentials'
            
            git checkout $gitBranch 2>/dev/null || git checkout -b $gitBranch
        """
    } catch(e) {
        error("Exception occurred while cloning the dest repo: ${e}")
        return
    }

    ansiColor('xterm') {
        echo "${colors.bold}(Step 2 of 3) Copying Build To Cloned Dest Repo${colors.none}"
    }
    try {
        sh "rsync -avz --exclude '*.zip' ${sourceDir}/* ${destDir}"
    } catch(e) {
        error("Exception occurred while copying build to the cloned dest repo: ${e}")
        return
    }

    ansiColor('xterm') {
        echo "${colors.bold}(Step 3 of 3) Create new archive out of file diff${colors.none}"
    }
    try {
        dir("${destDir}") {
            //add -N is intent to add
            sh "git add -N ."
            changedPages = sh(script: "git diff --name-only HEAD --diff-filter=ACMRTUXB", returnStdout: true).trim()
            echo "Changed files are: ${changedPages}"
            if (changedPages?.trim()) {
                sh "mkdir -p ${artifactFolder}"
                sh "zip ${artifactFolder}/${artifactName} `git diff --name-only HEAD --diff-filter=ACMRTUXB`"                
            }
        }    
    } catch(e) {
        error("Exception occurred while copying archive to artifact folder: ${e}")
        return
    }

    return changedPages
}