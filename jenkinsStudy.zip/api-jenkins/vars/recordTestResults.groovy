#!/usr/bin/env groovy

/**
 * A generic pipeline function to record test automation results in our CICD database and slack them
 */

def call(Map map = [:]) {
    appName = map.appName
    environment = map.environment
    testType = map.testType
    artifactName = map.artifactName ?: null
    slackChannel = map.slackChannel ?: null // supports multiple slack channels via '+' delimited string - i.e. foo_channel+bar_channel
    waitUntilBuildIsComplete = map.waitUntilBuildIsComplete ?: "yes"
    colors = colorCodes()

    try {
        assert appName != null
        assert environment != null
        assert testType != null
    } catch(NullPointerException e) {
        error("One or more required parameters were null: ${e}")
    }

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}APP_NAME:${colors.none} ${appName}
${colors.magenta}ENVIRONMENT:${colors.none} ${environment}
${colors.magenta}TEST_TYPE:${colors.none} ${testType}
${colors.magenta}ARTIFACT_NAME:${colors.none} ${artifactName}
${colors.magenta}SLACK_CHANNEL:${colors.none} ${slackChannel}
${colors.magenta}WAIT_FOR_BUILD_TO_COMPLETE:${colors.none} ${waitUntilBuildIsComplete}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }

    ansiColor('xterm') {
        echo "${colors.bold}Posting Test Results To Slack Channel(s): ${slackChannel}${colors.none}"
    }

    try {
        /** We already have a fabric task that can report test results, so rather than convoluting
         the pipeline with additional logic to execute it, we instead just trigger a rundeck job that will
         do it for us. The job will record test results in our CICD database and slack test results to the channels
         provided.
         [ JOB URL ] :
         https://rundeck.legalzoom.com/project/Deploy/job/show/6f2362fa-5f57-4282-91d2-85bbc4950cc5#definition
         **/
        runRundeckJob(
            jobId: "6f2362fa-5f57-4282-91d2-85bbc4950cc5",
            jobOptions: "app=${appName}\n" +
                "environment=${environment}\n" +
                "test_type=${testType}\n" +
                "artifact=${artifactName}\n" +
                "build_name=${env.JOB_NAME}\n" +
                "build_number=${env.BUILD_NUMBER}\n" +
                "slack_channel=${slackChannel}\n" +
                "wait_until_build_is_complete=${waitUntilBuildIsComplete}"
        )
    } catch (e) {
        error(
            "failed to post test results to '${slackChannel}' slack channel(s): ${e}"
        )
    }

}
