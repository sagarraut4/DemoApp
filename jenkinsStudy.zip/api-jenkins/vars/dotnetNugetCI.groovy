#!/usr/bin/env groovy

/**
 * A generic pipeline for API services
 */

def call(body) {
    // evaluate the body block, and collect configuration into the object
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    buildProperties = config.buildProperties ?: 'Configuration=Debug;Platform=AnyCPU'
    skipNugetPackBuild = config.skipNugetPackBuild ?: 'no'
    packagesToRestore = config.packagesToRestore ?: null
    appName = config.appName ?: null
    multipleSolutions = config.multipleSolutions ?: false
    solutionDirectories = config.solutionDirectories ?: null
    config.useLinux = config.useLinux ?: 'false'
    colors = colorCodes()

    try {
        assert config.appName != null
        assert config.sourceDirectory != null
        assert config.nugetDirectory != null
        assert config.packagesToRestore != null
        assert config.buildConfiguration != null
        assert config.nodeLabel != null
    } catch (NullPointerException e) {
        ansiColor('xterm') {
            error("${colors.red}One or more required parameters were null:${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }

    sourceDirectory = config.sourceDirectory
    nugetDirectory = config.nugetDirectory
    buildConfiguration = config.buildConfiguration
    nodeLabel = config.nodeLabel
    jobName = JOB_NAME.replace('/', '_').replace('%2F', '_')
    packagesToInstall = config.packagesToInstall ?: [
    ]

    def dotnetContainerVersion = ''
    def pythonGitImage = ''
    def jnlpImage = ''
    def dockerImage = ''
    def storageClassName = ''
    def operatingSystem = 'windows'
    def arch = 'amd64'

    if (config.nodeLabel == 'dotnet3_1') {
        dotnetContainerVersion = 'artifactory.legalzoom.com/docker-mcr-remote/dotnet/sdk:3.1'
    }

    if (config.nodeLabel == 'dotnet6') {
        dotnetContainerVersion = 'artifactory.legalzoom.com/docker-mcr-remote/dotnet/sdk:6.0'
    }

    if (config.useLinux == 'true') {
        operatingSystem = 'linux'
        pythonGitImage = 'artifactory.legalzoom.com/docker/devops/jenkins/python-git-linux:latest'
        jnlpImage = 'jenkins/inbound-agent:4.6-1'
        dockerImage = 'artifactory.legalzoom.com/docker-remote/docker:dind'
        storageClassName = 'encrypted-gp3'
    }
    else {
        operatingSystem = 'windows'
        pythonGitImage = 'artifactory.legalzoom.com/docker/devops/jenkins/python-git:latest'
        jnlpImage = 'artifactory.legalzoom.com/docker/jenkins/inbound-agent:windowsservercore-1809'
        storageClassName = 'windows-ebs'
    }

    def podYaml = ''

    if (config.useLinux == 'true') {
        podYaml = """\
                apiVersion: v1
                kind: Pod
                metadata:
                    labels:
                        jenkins-agent: apiCI
                spec:
                    securityContext:
                        fsGroup: 1000
                        seLinuxOptions:
                            user: system_u
                            role: system_r
                            type: super_t
                            level: s0
                    containers:
                      - name: dotnet
                        image: '${dotnetContainerVersion}'
                        tty: true
                        resources:
                            requests:
                            cpu: '2'
                            memory: 4Gi
                            limits:
                            cpu: '2'
                            memory: 4Gi
                        env:
                          - name: DOTNET_HOSTBUILDER__RELOADCONFIGONCHANGE
                            value: 'false'
                          - name: DOTNET_USE_POLLING_FILE_WATCHER
                            value: '1'
                        volumeMounts:
                          - name: ssl-certs
                            mountPath: /etc/ssl/certs/ca-certificates.crt
                            readOnly: true
                      - name: docker
                        image: '${dockerImage}'
                        securityContext:
                          privileged: true
                      - name: python-git
                        image: '${pythonGitImage}'
                        imagePullPolicy: Always
                        tty: true
                      - name: jnlp
                        image: '${jnlpImage}'
                        imagePullPolicy: Always
                    nodeSelector:
                        kubernetes.io/os: ${operatingSystem}
                        kubernetes.io/arch: ${arch}
                    volumes:
                      - name: ssl-certs
                        hostPath:
                          path: /etc/ssl/certs/ca-bundle.crt
                """.stripIndent()
    }
    else
    {
        podYaml = """\
                apiVersion: v1
                kind: Pod
                metadata:
                  labels:
                    jenkins-agent: apiCI
                spec:
                  securityContext:
                    fsGroup: 1000
                    seLinuxOptions:
                      user: system_u
                      role: system_r
                      type: super_t
                      level: s0
                  containers:
                  - name: dotnet
                    image: ${dotnetContainerVersion}
                    tty: true
                    resources:
                      requests:
                        cpu: '2'
                        memory: '4Gi'
                      limits:
                        cpu: '2'
                        memory: '4Gi'
                    env:
                    - name: DOTNET_HOSTBUILDER__RELOADCONFIGONCHANGE
                      value: 'false'
                    - name: DOTNET_USE_POLLING_FILE_WATCHER
                      value: '1'
                  - name: python-git
                    image: ${pythonGitImage}
                    imagePullPolicy: Always
                    tty: true
                  - name: jnlp
                    image: ${jnlpImage}
                    imagePullPolicy: Always
                  nodeSelector:
                    kubernetes.io/os: ${operatingSystem}
                    kubernetes.io/arch: ${arch}
                """.stripIndent()
    }

    pipeline {
        options {
            buildDiscarder(logRotator(numToKeepStr: '30'))
            disableConcurrentBuilds()
            timeout(time: 45, unit: 'MINUTES')
            timestamps()
        }

        environment {
            // mandatory
            PRODUCT_NAME = "${config.appName}"
            PRODUCT_NAME_LOWER = "${config.appName}".toLowerCase()
            SOURCE_DIRECTORY = "${sourceDirectory}"
            BUILD_PROPERTIES = "${buildProperties}"
        }

        agent {
            kubernetes {
                slaveConnectTimeout 300
                yaml podYaml
                workspaceVolume dynamicPVC(accessModes: 'ReadWriteOnce', requestsSize: '30Gi', storageClassName: storageClassName)
            }
        }

        stages {
            stage('Build') {
                steps {
                    script {
                        container('dotnet') {
                            if (multipleSolutions) {
                                for (solutionDir in solutionDirectories) {
                                    dir(sourceDirectory + solutionDir) {
                                        if (isUnix()) {
                                            sh """
                                                dotnet build --configuration ${buildConfiguration}
                                            """
                                        } else {
                                            bat """
                                                dotnet build --configuration ${buildConfiguration}
                                            """
                                        }
                                    }
                                }
                            } else {
                                dir(sourceDirectory) {
                                    if (isUnix()) {
                                        sh """
                                            dotnet build --configuration ${buildConfiguration}
                                        """
                                    } else {
                                        bat """
                                            dotnet build --configuration ${buildConfiguration}
                                        """
                                    }
                                }
                            }
                        }
                    }
                }
            }

            stage('Nuget Push') {
                steps {
                    script {
                        container('dotnet') {
                            def nugetSource = 'https://artifactory.legalzoom.com/artifactory/api/nuget/nuget-local'
                            withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:'Artifactory', usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
                                if (isUnix()) {
                                    sh """
                                        dotnet nuget add source ${nugetSource} -n ArtifactoryRemote -u ${USERNAME} -p ${PASSWORD} --store-password-in-clear-text
                                    """
                                } else {
                                    bat """
                                        dotnet nuget add source ${nugetSource} -n ArtifactoryRemote -u ${USERNAME} -p ${PASSWORD} --store-password-in-clear-text
                                    """
                                }

                                for (nugetDir in nugetDirectory) {
                                    dir(nugetDir) {
                                        if (isUnix()) {
                                            sh """
                                                dotnet nuget push '*.nupkg' -s ArtifactoryRemote -k ${USERNAME}:${PASSWORD}
                                            """
                                        } else {
                                            def nugetFileOutput = bat(returnStdout: true, script: 'dir *.nupkg /B').trim()
                                            def nugetFile = nugetFileOutput.readLines().drop(1).join('').trim()

                                            echo "publishing nuget file ${nugetFile}"

                                            bat """
                                                dotnet nuget push ${nugetFile} -s ArtifactoryRemote -k ${USERNAME}:${PASSWORD}
                                            """
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
