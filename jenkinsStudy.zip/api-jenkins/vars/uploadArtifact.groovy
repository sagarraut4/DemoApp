#!/usr/bin/env groovy

/**
 * A generic pipeline function for uploading to Artifactory
 */

def call(Map map = [:]) {
    // mandatory
    def targetRepo = map.targetRepo
    def sourceArtifact = map.sourceArtifact
    def productName = map.productName
    // optional
    def artifactoryServerId = map.artifactoryServerId ?: 'artifactory'
    def logCommitInfo = map.logCommitInfo ?: false
    // calculated
    def artifactName = targetRepo.split('/').last()
    def colors = colorCodes()

    try {
        assert targetRepo != null
        assert sourceArtifact != null
        assert productName != null
        assert artifactName != null
    } catch(e) {
        ansiColor('xterm') {
            error("${colors.red}One or more required parameters were null:${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }

    def uploadSpec = """
        {
            "files": [{
                "pattern": "${sourceArtifact}",
                "target": "${targetRepo}"
            }]
        }
    """

    statusMessage(status: "Uploading Artifact", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}ARTIFACTORY_SERVER_ID:${colors.none} ${artifactoryServerId}
${colors.magenta}SOURCE_ARTIFACT:${colors.none} ${sourceArtifact}
${colors.magenta}TARGET_REPO:${colors.none} ${targetRepo}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }

    try {
        def artifactory = Artifactory.server(artifactoryServerId)
        def buildInfo = artifactory.upload(uploadSpec)
        buildInfo.name = "${productName}"
        buildInfo.number = "${env.BUILD_NUMBER}"
        buildInfo.env.capture = true
        artifactory.publishBuildInfo(buildInfo)
    } catch(e) {
        ansiColor('xterm') {
            error("${colors.red}Exception occurred while uploading ${sourceArtifact} to ${targetRepo}:${colors.none} " +
                    "${colors.bold}${e}${colors.none}")
        }
        return
    }

    wrap([$class: 'BuildUser']) {
        if (logCommitInfo == true) {
            commitInfo = getCommitInfo()
            notes = "author==${commitInfo.author},authorEmail==${commitInfo.authorEmail},commitSha==${commitInfo.commitSha}"
        } else {
            notes = ""
        }
        /*
        buildUser = env.BUILD_USER ?: env.USER
        writeAuditLogEntry(
            username: "${buildUser}", artifactName: "${artifactName}", productName: "${productName}", notes: "${notes}"
        )
        */
    }
}
