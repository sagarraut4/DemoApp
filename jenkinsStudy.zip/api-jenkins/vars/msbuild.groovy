#!/usr/bin/env groovy

/**
 * A generic pipeline function for msbuilds
 */

def call(Map map = [:]) {
    buildFile = map.buildFile
    environment = map.environment
    outputDirectory = map.outputDirectory ?: "bin"
    args = map.args ?: "/p:Configuration=${environment} /p:OutputPath=${outputDirectory}\\${environment}"

    try {
        assert buildFile != null
        assert environment != null
    } catch(NullPointerException e) {
        error("One or more required parameters were null: ${e}")
    }

    echo """
Build Info:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
BUILD_FILE = ${buildFile}
ENVIRONMENT = ${environment}
OUTPUT_DIRECTORY = ${outputDirectory}
ARGS = ${args}
"""

    echo "Starting Build"
    try {
        bat("msbuild \"${buildFile}\" ${args}")
    } catch (e) {
        error("Exception occurred while building ${buildFile}: ${e}")
        return
    }
    echo "Build Complete"

}
