#!/usr/bin/env groovy

/**
 * Pipeline for website V2.
 */
def call(body) {
    // evaluate the body block, and collect configuration into the object
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    containerGithubUrl = config.containerGithubUrl ?: null
    deploymentRepo = config.deploymentRepo ?: null
    ssiPath = config.ssiPath ?: "NONE"
    productName = config.appName ?: 'WebsiteV2'
    productNameLower = productName.toLowerCase()
    slackChannel = config.slackChannel ?: 'cj_website_v2'
    buildNotifications = config.buildNotifications ?: 'yes'

    // Constants
    def PIPELINE_CONFIG = [
        [
            name: 'develop',
            envs: 'dev',
            pattern: /^develop$/,
            version: 'snapshot',
            argo_deploy: true,
            artifact: true,
        ],
        [
            name: 'dev',
            envs: 'dev',
            pattern: /^dev.*v[0-9]+.[0-9]+.[0-9]+$/,
            version_pattern: "[0-9]+.[0-9]+.[0-9]+[h]?",
            artifact: false,
            argo_deploy: false,
        ],
        [
            name: 'release',
            envs: 'qa,prod', // When we build release branch, we MUST build prod too.
            pattern: /^release.*v[0-9]+.[0-9]+.[0-9]+$/,
            version_pattern: "[0-9]+.[0-9]+.[0-9]+[h]?",
            artifact: true,
            argo_deploy: false,
        ],
    ]

    pipeline {

        // Environment vars must be single quoted,
        // double quoted or function calls.
        environment {
            BUILD_WORKSPACE = 'build-workspace'
            SLACK_TOKEN = credentials('slack-token')
        }

        options {
            buildDiscarder(logRotator(numToKeepStr: '10'))
            disableConcurrentBuilds()
            timeout(time: 20, unit: 'MINUTES')
            timestamps()
        }

        /**
         * Kubernetes images for the Agent.
         *
         * Containers:
         *
         * jnlp: Jenkins Agent. Build process will run inside this container.
         *       NOTE: DO NOT CHANGE jnlp container name. If changed, the pipeline
         *       will not find the proper container and build process will be stuck
         *       in a loop.
         *
         * docker: required to run remote docker containers.
         *
         * kustomize: required for Argo Deployments (deployStaticToKube function)
         *
         */
        agent {
            kubernetes {
              yaml """\
                apiVersion: v1
                kind: Pod
                metadata:
                  labels:
                    some-label: some-label-value
                spec:
                  securityContext:
                    fsGroup: 2000
                  containers:
                  - name: jnlp
                    image: artifactory.legalzoom.com/docker/jenkins-agents/node14-centos7:1.0.0
                    imagePullPolicy: Always
                    tty: true
                    resources:
                    requests:
                      cpu: '3'
                      memory: '6Gi'
                    limits:
                      cpu: '3'
                      memory: '6Gi'
                  - name: docker
                    image: artifactory.legalzoom.com/docker-remote/docker:dind
                    securityContext:
                      privileged: true
                  - name: kustomize
                    image: k8s.gcr.io/kustomize/kustomize:v3.8.7
                    tty: true
                    command:
                    - cat
                  nodeSelector:
                    kubernetes.io/os: linux
                    kubernetes.io/arch: amd64
                """.stripIndent()
                workspaceVolume dynamicPVC(accessModes: 'ReadWriteOnce', requestsSize: '30Gi')
            }
        }

        stages {

            /**
             * Prepare Stage.
             *
             * Notifies configured Slack channel of build start
             * and extracts required information from the pipeline
             * configuration.
             *
             */
            stage('Prepare') {
                steps {
                    script {
                        if (buildNotifications == 'yes') {
                            sendSlackMessage(
                                buildStatus: 'STARTED',
                                slackChannel: slackChannel,
                                slackToken: env.SLACK_TOKEN,
                            )
                        }

                        conf = getConfig(env.BRANCH_NAME, PIPELINE_CONFIG)
                        env.VERSION = conf.version
                        env.CREATE_AND_UPLOAD_ARTIFACT = conf.artifact ? 'yes' : 'no'
                        env.DEPLOY_ARTIFACT = conf.argo_deploy ? 'yes' : 'no'
                        env.ENVIRONMENTS = conf.envs

                        printBannerFromMap(
                            BRANCH_NAME: conf.branch_name,
                            TARGET_ENVIRONMENT: conf.envs,
                            VERSION: conf.version,
                            CREATE_AND_UPLOAD_ARTIFACT: env.CREATE_AND_UPLOAD_ARTIFACT,
                            DEPLOY_ARTIFACT: env.DEPLOY_ARTIFACT,
                        )
                    }
                }
            }

            /**
             * Build Stage.
             *
             * Builds source by calling jenkins-build.sh script.
             * Stash / Unstash required for Artifact creation / upload.
             *
             * Multi-environment support.
             */
            stage("Build") {
                steps {
                    script {
                        stash name: env.BUILD_WORKSPACE
                        statusMessage(status: "Building", level: "info")
                        def targetEnvs = env.ENVIRONMENTS.split(',')
                        targetEnvs.each { targetEnv ->
                            print targetEnv
                            dir("${env.WORKSPACE}/$targetEnv") {
                                unstash env.BUILD_WORKSPACE
                                container('jnlp') {
                                    sh "pwd && ls -lth"
                                    try {
                                        sh("TARGET_ENV=$targetEnv bash jenkins-build.sh")
                                        echo "Build Complete"
                                    } catch (e) {
                                        error("Failed to build: ${e}")
                                        return
                                    }
                                }
                            }

                        }
                    }
                }
            }

            /**
             * Create Artifact Stage.
             *
             * It creates the zip artifact containing the build result for later usage.
             *
             * Multi-environment support.
             */
            stage("Create Artifact") {
                when { expression { env.CREATE_AND_UPLOAD_ARTIFACT == 'yes' } }
                steps {
                    script {
                        def targetEnvs = env.ENVIRONMENTS.split(',')
                        targetEnvs.each { targetEnv ->
                            def artifactName = "${productNameLower}-${targetEnv}-${env.VERSION}.zip"
                            dir ("${env.WORKSPACE}/artifact/${targetEnv}"){
                                sh "ls -lth"
                                createArtifact(
                                    artifactName: "${artifactName}",
                                    artifactSource: "${env.WORKSPACE}/artifact/${targetEnv}",
                                )
                            }
                        }
                    }
                }
            }

            /**
             * Upload Artifact Stage.
             *
             * Uploads the zip artifact and then builds the static asset container.
             * The static asset container is an Nginx Docker Image that serves
             * the files generated by the build process.
             *
             * Dockerfile and config is stored in a separate repository.
             * TODO: Move Static Asset Container to html2 repo.
             *
             * Multi-environment support.
             */
            stage('Upload Artifact') {
                when { expression { env.CREATE_AND_UPLOAD_ARTIFACT == 'yes' } }
                steps {
                    script {
                        uploadArtifact(
                            targetRepo: "${productName}/",
                            sourceArtifact: "${env.WORKSPACE}/artifact/*/*.zip",
                            productName: productName
                        )

                        def targetEnvs = env.ENVIRONMENTS.split(',')
                        targetEnvs.each { targetEnv ->
                            def artifactName = "${productNameLower}-${targetEnv}-${env.VERSION}.zip"
                            buildStaticAssetContainer(
                                environment: "${targetEnv}",
                                artifactName: "${artifactName}",
                                project: productName,
                                deploymentRepo: deploymentRepo,
                                ssiPath: ssiPath,
                                containerGithubUrl: containerGithubUrl,
                            )
                        }
                    }
                }
            }

            /**
             * Deploy Stage.
             *
             * Deploys the generated artifact to K8S using Argo CD + Kustomize
             * image required on the Agent configuration.
             *
             */
            stage('Rundeck: Start Deploy Job'){
                when { expression { env.DEPLOY_ARTIFACT == 'yes' } }
                steps {
                    script {
                        def targetEnvs = env.ENVIRONMENTS.split(',')
                        targetEnvs.each { targetEnv ->
                            if (targetEnv != 'prod') { // Deployments to prod are manual, for now.
                                deployStaticToKube(
                                    project: productName,
                                    artifactName: "${env.ARTIFACT_NAME}",
                                    environment: "${targetEnv}",
                                    deploymentRepo: deploymentRepo,
                                )
                            }
                        }
                    }
                }
            }

        }

        post {
            always {
                script {
                    if (buildNotifications == 'yes') {
                        buildStatus = currentBuild.result ?: 'SUCCESSFUL'
                        subject = "${buildStatus}: ${env.JOB_NAME} [BUILD #${env.BUILD_NUMBER}]"
                        summary = "${subject} (${env.BUILD_URL})"
                        sendSlackMessage(
                            buildStatus: buildStatus,
                            slackChannel: slackChannel,
                            slackToken: env.SLACK_TOKEN
                        )
                        if (currentBuild.result == 'FAILURE') {
                            emailext(
                                body: summary,
                                recipientProviders: [[$class: 'CulpritsRecipientProvider']],
                                subject: subject
                            )
                            statusMessage(status: "${productName} CICD Pipeline Failed", level: "failure")
                        } else if (currentBuild.result == 'SUCCESS' || currentBuild.result == null) {
                            statusMessage(status: "${productName} CICD Pipeline Complete", level: "success")
                        }
                    }
                }
            }
        }
    }
}

def getConfig(branchName, pipeConfig) {
    for ( config in pipeConfig ) {
        if (branchName ==~ config.pattern) {
            config.version = config.containsKey('version_pattern') ?
                branchName.find(config.version_pattern) : config.version
            config.branch_name = branchName
            return config;
        }
    }

    return [
        name: 'default',
        argo_deploy: false,
        artifact: false,
        envs: ['dev'],
        version: 'latest',
        branch_name: branch_name
    ]
}
