#!/usr/bin/env groovy

/**
 * A generic pipeline for API services
 * Save new version
 */

def call(body) {
    // evaluate the body block, and collect configuration into the object
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()
    def operatingSystem = "windows"
    def arch = "amd64"
    def podYaml = ''
    def dotnetContainerVersion = "artifactory.legalzoom.com/docker-mcr-remote/dotnet/sdk:2.1"
    def dockerImage = "artifactory.legalzoom.com/docker/devops/jenkins/python-git:latest" //not used in windows
    def dotnetRuntimeContainerVersion = "artifactory.legalzoom.com/docker-mcr-remote/dotnet/core/aspnet:2.1"
    def pythonGitImage = "artifactory.legalzoom.com/docker/devops/jenkins/python-git:latest"
    def jnlpImage = "artifactory.legalzoom.com/docker/jenkins/inbound-agent:windowsservercore-1809"
    def storageClassName = "windows-ebs"
    def kustomizeImage = "artifactory.legalzoom.com/docker/devops/jenkins/python-git:latest" //not used in windows
    colors = colorCodes()

    if(config.useLinux == "true") {
        operatingSystem = "linux"
        storageClassName = "encrypted-gp3"
        dotnetContainerVersion = "artifactory.legalzoom.com/docker/devops/dotnet/sdk:2.1"
        pythonGitImage = "artifactory.legalzoom.com/docker/devops/jenkins/python-git-linux:latest"
        jnlpImage = "jenkins/inbound-agent:4.6-1"
        dockerImage = "artifactory.legalzoom.com/docker-remote/docker:dind"
        kustomizeImage = "artifactory.legalzoom.com/docker-remote/line/kubectl-kustomize:latest"

        if(config.nodeLabel == "dotnet3_1") {
          //arch = "arm64"
          //jnlpImage = "artifactory.legalzoom.com/docker/devops/jenkins-inbound-agent-arm:latest"
          //pythonGitImage = "artifactory.legalzoom.com/docker/devops/jenkins/python-git-linux:multiarch"
          dotnetRuntimeContainerVersion = "artifactory.legalzoom.com/docker-mcr-remote/dotnet/core/aspnet:3.1"
        }
    }

    if (config.nodeLabel == "dotnetframework4") {
        dotnetContainerVersion = "artifactory.legalzoom.com/docker-mcr-remote/dotnet/framework/sdk:4.8"
    }

    if (config.nodeLabel == "dotnet6") {
        arch = "amd64"
        kustomizeImage = "artifactory.legalzoom.com/docker-remote/line/kubectl-kustomize:latest"
        jnlpImage = "jenkins/inbound-agent:4.6-1"
        pythonGitImage = "artifactory.legalzoom.com/docker/devops/jenkins/python-git-linux:latest"
        dotnetContainerVersion = "artifactory.legalzoom.com/docker-mcr-remote/dotnet/sdk:6.0"
        dotnetRuntimeContainerVersion = "artifactory.legalzoom.com/docker-mcr-remote/dotnet/aspnet:6.0"
    }

    if (config.nodeLabel == "dotnet6-arm") {
        arch = "arm64"
        kustomizeImage = "artifactory.legalzoom.com/docker-remote/line/kubectl-kustomize:latest"
        jnlpImage = "artifactory.legalzoom.com/docker/devops/jenkins-inbound-agent-arm:latest"
        pythonGitImage = "artifactory.legalzoom.com/docker/devops/jenkins/python-git-linux:multiarch"
        dotnetContainerVersion = "artifactory.legalzoom.com/docker-mcr-remote/dotnet/sdk:6.0"
        dotnetRuntimeContainerVersion = "artifactory.legalzoom.com/docker-mcr-remote/dotnet/aspnet:6.0"
    }

    if (config.nodeLabel == "dotnet7-arm") {
        arch = "arm64"
        kustomizeImage = "artifactory.legalzoom.com/docker-remote/line/kubectl-kustomize:latest"
        jnlpImage = "artifactory.legalzoom.com/docker/devops/jenkins-inbound-agent-arm:latest"
        pythonGitImage = "artifactory.legalzoom.com/docker/devops/jenkins/python-git-linux:multiarch"
        dotnetContainerVersion = "artifactory.legalzoom.com/docker-mcr-remote/dotnet/sdk:7.0"
        dotnetRuntimeContainerVersion = "artifactory.legalzoom.com/docker-mcr-remote/dotnet/aspnet:7.0"
    }

    if (config.nodeLabel == "dotnet1") {
        dotnetContainerVersion = "artifactory.legalzoom.com/docker-mcr-remote/dotnet/core/sdk:1.1"
        dotnetRuntimeContainerVersion = "artifactory.legalzoom.com/docker-mcr-remote/dotnet/core/runtime:1.1"
    }

    if (config.nodeLabel == "dotnet2") {
        dotnetContainerVersion = "artifactory.legalzoom.com/docker/devops/dotnet/core/sdk:2.2"
        dotnetRuntimeContainerVersion = "artifactory.legalzoom.com/docker-mcr-remote/dotnet/core/aspnet:2.2"
    }

    if (config.nodeLabel == "dotnet3_1") {
        dotnetContainerVersion = "artifactory.legalzoom.com/docker-mcr-remote/dotnet/sdk:3.1"
        dotnetRuntimeContainerVersion = "artifactory.legalzoom.com/docker-mcr-remote/dotnet/core/aspnet:3.1"
    }

    if (operatingSystem == "windows") {
            podYaml = """\
                apiVersion: v1
                kind: Pod
                metadata:
                  labels:
                    jenkins-agent: apiCI
                spec:
                  securityContext:
                    fsGroup: 1000
                    seLinuxOptions:
                      user: system_u
                      role: system_r
                      type: super_t
                      level: s0
                  containers:
                  - name: dotnet
                    image: ${dotnetContainerVersion}
                    tty: true
                    resources:
                      requests:
                        cpu: '2'
                        memory: '4Gi'
                      limits:
                        cpu: '2'
                        memory: '4Gi'
                    env:
                    - name: DOTNET_HOSTBUILDER__RELOADCONFIGONCHANGE
                      value: 'false'
                    - name: DOTNET_USE_POLLING_FILE_WATCHER
                      value: '1'
                  - name: python-git
                    image: ${pythonGitImage}
                    imagePullPolicy: Always
                    tty: true
                  - name: jnlp
                    image: ${jnlpImage}
                    imagePullPolicy: Always
                  nodeSelector:
                    kubernetes.io/os: ${operatingSystem}
                    kubernetes.io/arch: ${arch}
                """.stripIndent()
    }

    if (operatingSystem == "linux") {
            podYaml = """\
                apiVersion: v1
                kind: Pod
                metadata:
                  labels:
                    jenkins-agent: apiCI
                spec:
                  securityContext:
                    fsGroup: 1000
                    seLinuxOptions:
                      user: system_u
                      role: system_r
                      type: super_t
                      level: s0
                  containers:
                  - name: dotnet
                    image: '${dotnetContainerVersion}'
                    tty: true
                    resources:
                      requests:
                        cpu: '2'
                        memory: '4Gi'
                      limits:
                        cpu: '2'
                        memory: '4Gi'
                    env:
                    - name: DOTNET_HOSTBUILDER__RELOADCONFIGONCHANGE
                      value: 'false'
                    - name: DOTNET_USE_POLLING_FILE_WATCHER
                      value: '1'
                    volumeMounts:
                    - name: ssl-certs
                      mountPath: /etc/ssl/certs/ca-certificates.crt
                      readOnly: true
                  - name: docker
                    image: '${dockerImage}'
                    securityContext:
                      privileged: true
                  - name: python-git
                    image: '${pythonGitImage}'
                    imagePullPolicy: Always
                    tty: true
                  - name: jnlp
                    image: '${jnlpImage}'
                    imagePullPolicy: Always
                  - name: kustomize
                    image: '${kustomizeImage}'
                    tty: true
                    command:
                      - cat
                  nodeSelector:
                    kubernetes.io/os: ${operatingSystem}
                    kubernetes.io/arch: ${arch}
                  volumes:
                  - name: ssl-certs
                    hostPath:
                      path: /etc/ssl/certs/ca-bundle.crt
                """.stripIndent()
    }



    // get slackChannel from luigiweb if one isn't provided
    if (config.slackChannel == null) {
        try {
            slackChannelEndpoint = "https://luigiweb.devops.legalzoom.com/apiservices/${config.apiName}/slackchannel"
            slackChannel = httpRequest("${slackChannelEndpoint}").getContent()[1..-3].replace('"','')
        } catch(e) {
            ansiColor('xterm') {
                echo "${colors.yellow}WARNING: failed to get slack channel from ${slackChannelEndpoint}:${colors.none} ${colors.bold}${e}${colors.none}"
                echo "${colors.yellow}No slack channel notifications will be made throughout the build process${colors.none}"
            }
            slackChannel = ""
        }
    } else {
        slackChannel = config.slackChannel
    }

    // get unitTest code coverage report value from luigiweb
    if (config.codeCoverageReport == null) {
        try {
            codeCoverageReportEndpoint = "https://luigiweb.devops.legalzoom.com/services/API/${config.apiName}/attributes?key=unit_tests.code_coverage_report"
            codeCoverageReport = httpRequest("${codeCoverageReportEndpoint}").getContent()
            echo "${colors.bold}CODE COVERAGE REPORT VALUE: ${codeCoverageReport}${colors.none}"
        } catch(e) {
            echo "${colors.yellow}WARNING: failed to get code coverage report variable${colors.none}"
            codeCoverageReport = false
        }
    } else {
        codeCoverageReport = config.codeCoverageReport
    }

    try {
        assert config.apiName != null
        assert config.testProjectDirectory != null
        assert slackChannel != null
        assert codeCoverageReport != null
    } catch(NullPointerException e) {
        ansiColor('xterm') {
            error("${colors.red}One or more required parameters were null:${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }
    runtimeIdentifier = config.runtimeIdentifier ?: "win81-x64"
    nodeLabel = config.nodeLabel ?: "msbuild_dotnet1_1"
    isTransformWebConfigDisabled = config.isTransformWebConfigDisabled ?: "true"
    skipUnitTests = config.skipUnitTests ?: "no"
    skipE2ETests = config.skipE2ETests ?: "no"
    forceFeatureBranchDeployment = config.forceFeatureBranchDeployment ?: "no"
    sourceDirectory = config.sourceDirectory ?: "./src/${config.apiName}"
    additionalPackages = config.additionalPackages ?: [:]
    jobName = JOB_NAME.replace('/', '_').replace('%2F', '_')
    commit = env.GIT_COMMIT

    pipeline {
        options{
            buildDiscarder(logRotator(numToKeepStr: '30'))
            disableConcurrentBuilds()
            timeout(time: 45, unit: 'MINUTES')
            timestamps()
        }

        environment {
            // mandatory
            PRODUCT_NAME = "${config.apiName}"
            PRODUCT_NAME_LOWER = "${config.apiName}".toLowerCase()
            SOURCE_DIRECTORY = "${sourceDirectory}"
            TEST_PROJECT_DIRECTORY = "${config.testProjectDirectory}"
            IS_TRANSFORM_WEB_CONFIG_DISABLED = "${isTransformWebConfigDisabled}"
            SLACK_CHANNEL= "${slackChannel}"
            NODE_LABEL = "${nodeLabel}"
            // optional
            RUNTIME_IDENTIFIER= "${runtimeIdentifier}"
            // constant
            SLACK_TOKEN = credentials('slack-token')
        }

        agent {
            kubernetes {
              slaveConnectTimeout 300
              yaml podYaml
              workspaceVolume dynamicPVC(accessModes: 'ReadWriteOnce', requestsSize: '30Gi', storageClassName: storageClassName)
            }
        }

        stages {
            stage('Prepare') {
                steps {
                    sendSlackMessage(
                        buildStatus: 'STARTED',
                        slackChannel: env.SLACK_CHANNEL,
                        slackToken: env.SLACK_TOKEN
                    )
                    script {
                        def cdStrategy = determineCDStrategy(
                            productName: env.PRODUCT_NAME,
                            forceFeatureBranchDeployment: forceFeatureBranchDeployment,
                        )
                        env.ARTIFACT_VERSION = cdStrategy.get(0)
                        env.CREATE_AND_UPLOAD_ARTIFACT = cdStrategy.get(1)
                        env.DEPLOY_ARTIFACT = cdStrategy.get(2)
                        env.TARGET_API_ENVIRONMENT = cdStrategy.get(3)
                        env.ARTIFACT_NAME = "${env.PRODUCT_NAME_LOWER}-${env.ARTIFACT_VERSION}.zip"

                        datadogAPMAttributes = getDatadogAPMAttributes(productName: config.apiName, productType: "api")
                        includeDatadogAPMPackage = config.includeDatadogAPMPackage ?: datadogAPMAttributes.includeDatadogAPMPackage
                        if (includeDatadogAPMPackage == "yes") {
                            additionalPackages << [
                                "${datadogAPMAttributes.datadogAPMPackageName}": datadogAPMAttributes.datadogAPMPackageVersion
                            ]
                        } else {
                            ansiColor('xterm') {
                                echo "${colors.bold}Skipping Datadog APM Integration, it's disabled in api-services.yaml ${colors.none}"
                            }
                        }

                    }
                }
            }

            stage("Unit Test") {
                steps {
                    script {
                        container('dotnet') {
                            if (skipUnitTests == "yes") {
                                echo "SKIPPING UNIT TESTS: a 'skipUnitTests' parameter was provided and set to 'yes' in this build's Jenkinsfile"
                            } else {
                                runUnitTests(testProjectDirectory: env.TEST_PROJECT_DIRECTORY, codeCoverageReport: codeCoverageReport)
                            }
                        }
                    }
                }
            }

            stage("DD Deployment Version Tag") {
                when { expression { operatingSystem == "linux" } }
                steps {
                    container('python-git') {
                        echo "Running script"
                        script {
                            dir("${WORKSPACE}/artifact/${env.PRODUCT_NAME}") {
                                sh """
                                ls -la
                                pwd
                                """
                                sh """
                                echo " {
    \\""DD_VERSION"\\": \\""${env.ARTIFACT_VERSION}.${BUILD_NUMBER}"\\"
    }" > datadog.json
                                ls -la
                                cat datadog.json
                                """
                            }
                        }
                    }
                }
            }

            stage("Build") {
                steps {
                    container('dotnet') {
                        buildApiService(
                            runtimeVersion: env.ARTIFACT_VERSION,
                            apiServiceName: env.PRODUCT_NAME,
                            targetEnvironment: env.TARGET_API_ENVIRONMENT,
                            sourceDirectory: env.SOURCE_DIRECTORY,
                            runtimeIdentifier: env.RUNTIME_IDENTIFIER,
                            isTransformWebConfigDisabled: env.IS_TRANSFORM_WEB_CONFIG_DISABLED,
                            additionalPackages: additionalPackages,
                            branchName: env.BRANCH_NAME,
                            nodeLabel:config.nodeLabel
                        )
                    }
                    apiConfigMgmt(
                        api: env.PRODUCT_NAME,
                        apiRef : env.BRANCH_NAME,
                        forceFeatureBranchDeployment: forceFeatureBranchDeployment,
                        datadogAPMIntegration: includeDatadogAPMPackage,
                        srcFile: "${WORKSPACE}/${sourceDirectory}/appsettings.json",
                        webConfigOrig: "${WORKSPACE}/${sourceDirectory}/web.config",
                    )
                }
            }

            stage("Build Container") {
                when { expression { operatingSystem == "linux" } }
                steps {
                    script {
                        container('docker') {
                            sh """
                            echo "
FROM ${dotnetContainerVersion} as buildenv
WORKDIR /app
COPY . ./
RUN dotnet restore
RUN cd ${sourceDirectory} && dotnet publish -c Release -o /app/out /p:IsTransformWebConfigDisabled=${env.IS_TRANSFORM_WEB_CONFIG_DISABLED}
FROM ${dotnetRuntimeContainerVersion}
ENV TZ=America/Los_Angeles
WORKDIR /app
COPY --from=buildenv /app/out .
RUN apt-get update && apt-get install curl unzip -y
RUN curl -LO https://github.com/DataDog/dd-trace-dotnet/releases/download/v2.15.0/datadog-dotnet-apm_2.15.0_${arch}.deb
RUN dpkg -i ./datadog-dotnet-apm_2.15.0_${arch}.deb
RUN curl -LO https://s3.amazonaws.com/rds-downloads/rds-combined-ca-bundle.pem #Added for DocumentDB
RUN curl -LO https://github.com/open-telemetry/opentelemetry-dotnet-instrumentation/releases/download/v0.6.0/otel-dotnet-auto-install.sh
RUN chmod +x otel-dotnet-auto-install.sh
RUN ./otel-dotnet-auto-install.sh
RUN rm -f /usr/lib/x86_64-linux-gnu/libssl.so.1.0.2 #force libssl 1
ENV CORECLR_PROFILER={846F5F1C-F9AE-4B07-969E-05C26BC060D8}
ENV CORECLR_PROFILER_PATH=/opt/datadog/Datadog.Trace.ClrProfiler.Native.so
ENV DD_INTEGRATIONS=/opt/datadog/integrations.json
ENV DD_DOTNET_TRACER_HOME=/opt/datadog
ENV DD_VERSION=${env.GIT_COMMIT}
ENV DD_PROPAGATION_STYLE_INJECT=B3
ENV DD_PROPAGATION_STYLE_EXTRACT=B3
ENV DD_LOGS_INJECTION=true
ENV CORECLR_ENABLE_PROFILING=1
#ENV CORECLR_PROFILER='{918728DD-259F-4A6A-AC2B-B85E1B658318}'
#ENV CORECLR_PROFILER_PATH=/opt/otel-dotnet-autoinstrumentation/OpenTelemetry.AutoInstrumentation.ClrProfiler.Native.so
ENV OTEL_DOTNET_AUTO_HOME=/root/.otel-dotnet-auto
ENV OTEL_DOTNET_AUTO_INTEGRATIONS_FILE=/root/.otel-dotnet-auto/integrations.json
ENV OTEL_PROPAGATORS=b3
ENV OTEL_VERSION=${env.GIT_COMMIT}
ENV OTEL_SERVICE_NAME=${env.PRODUCT_NAME_LOWER}
ENV OTEL_DOTNET_AUTO_LOGS_ENABLED=false
ENTRYPOINT [\\"dotnet\\", \\"${env.PRODUCT_NAME}.dll\\"]" > Dockerfile
                            docker build -t artifactory.legalzoom.com/docker/engineering/${env.PRODUCT_NAME_LOWER}:${env.GIT_COMMIT} .
                        """
                           withCredentials([
                               usernamePassword(
                                   credentialsId: 'Artifactory',
                                   passwordVariable: 'PASSWORD',
                                   usernameVariable: 'USER'
                               )
                           ]) {
                               sh """
                               docker login artifactory.legalzoom.com -u ${USER} -p ${PASSWORD}
                               docker push artifactory.legalzoom.com/docker/engineering/${env.PRODUCT_NAME_LOWER}:${env.GIT_COMMIT}
                               """
                           }
                       }
                    }
                }
            }

            stage("Archive") {
                when { expression { env.CREATE_AND_UPLOAD_ARTIFACT == "yes" && operatingSystem == "windows" } }
                steps {
                    createArtifact(
                        artifactName: "${env.ARTIFACT_NAME}",
                        artifactSource: "${WORKSPACE}/artifact/${env.PRODUCT_NAME}"
                    )
                    uploadArtifact(
                        targetRepo: "${env.PRODUCT_NAME}/${env.ARTIFACT_NAME}",
                        sourceArtifact: "${env.ARTIFACT_NAME}",
                        productName: "${env.PRODUCT_NAME}",
                        logCommitInfo: true,
                    )
                }
            }

            stage("Archive - Linux") {
                when { expression { env.CREATE_AND_UPLOAD_ARTIFACT == "yes" && operatingSystem == "linux" } }
                steps {
                    script {
                          container('dotnet') {
                              sh "apt-get update && apt-get install zip -y"
                              createArtifact(
                                  artifactName: "${env.ARTIFACT_NAME}",
                                  artifactSource: "${WORKSPACE}/artifact/${env.PRODUCT_NAME}",
                                  productName: "${env.PRODUCT_NAME}",
                                  windowsCompatible: "true"
                              )
                              sh """chown 1000:1000 ${WORKSPACE}/artifact/${env.ARTIFACT_NAME} && cp ${WORKSPACE}/artifact/${env.ARTIFACT_NAME} ${env.ARTIFACT_NAME}"""
                          }
                          uploadArtifact(
                              targetRepo: "${env.PRODUCT_NAME}/${env.ARTIFACT_NAME}",
                              sourceArtifact: "${env.ARTIFACT_NAME}",
                              productName: "${env.PRODUCT_NAME}",
                              logCommitInfo: true,
                          )
                    }
                }
            }

            stage('Rundeck: Start Deploy Job'){
                when { expression { env.DEPLOY_ARTIFACT == "yes" } }
                steps {
                    script {

                        if(config.deploymentRepo != null && env.TARGET_API_ENVIRONMENT != "predev") {
                            dir("${env.WORKSPACE}/deployment-repo") {
                                deployApiToKube(
                                    image: "artifactory.legalzoom.com/docker/engineering/${env.PRODUCT_NAME_LOWER}",
                                    deploymentRepo: config.deploymentRepo,
                                    commit: env.GIT_COMMIT,
                                    environment: env.TARGET_API_ENVIRONMENT
                                )
                            }
                        } else {
                            deployAPI(environment: env.TARGET_API_ENVIRONMENT)
                        }
                    }
                }
            }

            stage('Rundeck: Run E2E Tests'){
                when { expression { env.DEPLOY_ARTIFACT == "yes" } }
                steps {
                    script {
                        if(skipE2ETests == "yes"){
                            echo "SKIPPING E2E TESTS: a 'skipE2ETests' parameter was provided and set to 'yes' in this build's Jenkinsfile"
                        } else {
                            def testJob = ""
                            container('docker') {
                                dir('e2e-test-automation') {
                                    withCredentials([usernamePassword(credentialsId: '685757ba-4b94-45ec-a37a-4f48b340ef83', passwordVariable: 'password', usernameVariable: 'user')]) {
                                        git url: "https://${USER}:${PASSWORD}@github.legalzoom.com/devops/configurationFiles.git"
                                        sh """
                                            apk add yq
                                        """
                                        testJob = sh(returnStdout: true, script: "yq eval '.${config.apiName}.test_automation.job' apis/api-services.yaml").toString().trim()
                                        echo "${testJob}"
                                    }
                                }
                            }

                            build job: "${testJob}", parameters: [
                                string(name: 'TEST_ENVIRONMENT', value: 'dev'),
                                string(name: 'PROMOTE_API_IF_TESTS_PASS', value: 'no'),
                                string(name: 'SLACK_CHANNELS', value: env.SLACK_CHANNEL)
                            ], wait: false
                        }
                    }
                }
            }
        }

        post {
            always {
                script {
                    buildStatus = currentBuild.result ?: 'SUCCESSFUL'
                    subject = "${buildStatus}: ${env.JOB_NAME} [BUILD #${env.BUILD_NUMBER}]"
                    summary = "${subject} (${env.BUILD_URL})"
                    sendSlackMessage(
                        buildStatus: buildStatus,
                        slackChannel: env.SLACK_CHANNEL,
                        slackToken: env.SLACK_TOKEN
                    )
                    if (currentBuild.result == 'FAILURE') {
                        emailext(
                            body: summary,
                            recipientProviders: [[$class: 'CulpritsRecipientProvider']],
                            subject: subject
                        )
                        statusMessage(status: "${env.PRODUCT_NAME} CICD Pipeline Failed", level: "failure")
                    } else if (currentBuild.result == 'SUCCESS' || currentBuild.result == null) {
                        statusMessage(status: "${env.PRODUCT_NAME} CICD Pipeline Complete", level: "success")
                    }
                }
            }
        }
    }
}
