#!/usr/bin/env groovy

/**
 * A generic pipeline function for building versioned gulp applications
 */

def call(Map map = [:]) {
    // mandatory
    def targetEnvironment = map.targetEnvironment
    def gulpTasks = map.gulpTasks
    def branchVersion = map.branchVersion
    // optional
    def appName = map.appName ?: env.PRODUCT_NAME
    def angularAppName = map.angularApp
    def sourceDirectory = map.sourceDirectory ?: env.SOURCE_DIRECTORY
    def npmRegistryName = map.npmRegistryName ?: env.NPM_REGISTRY_NAME
    def npmRegistryUrl = map.npmRegistryUrl ?: env.NPM_REGISTRY_URL
    def buildWorkspace = map.buildWorkspace ?: "${env.WORKSPACE}/build/${targetEnvironment}"
    def artifactWorkspace = map.artifactWorkspace ?: "${env.WORKSPACE}/artifact/${targetEnvironment}"
    def stashedWorkspace = map.stashedWorkspace ?: env.ANGULAR_BUILD_WORKSPACE
    def outputDirectory = "${env.WORKSPACE}/artifact"
    def colors = colorCodes()

    try {
        assert targetEnvironment != null
        assert appName != null
        assert sourceDirectory != null
        assert npmRegistryName != null
        assert npmRegistryUrl != null
        assert angularAppName != null
    } catch(NullPointerException e) {
        error("One or more required parameters were missing: ${e}")
    }

    map.each{println it.key +" "+it.value}


    statusMessage(status: "Building", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}APP_NAME:${colors.none} ${appName}
${colors.magenta}TARGET_BUILD_ENVIRONMENT:${colors.none} ${targetEnvironment}
${colors.magenta}BUILD_WORKSPACE:${colors.none} ${buildWorkspace}
${colors.magenta}VERSION:${colors.none} ${branchVersion}
${colors.magenta}NPM_REGISTRY_NAME:${colors.none} ${npmRegistryName}
${colors.magenta}NPM_REGISTRY_URL:${colors.none} ${npmRegistryUrl}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }
    dir(buildWorkspace) {
        unstash stashedWorkspace
        sh "ls -lth"
        ansiColor('xterm') {
            echo "${colors.bold}(Step 1 of 3) Installing Dependencies${colors.none}"
        }
        try {
            sh("npm config set registry ${npmRegistryUrl}")
            dir("${env.SOURCE_DIRECTORY}") {
                sh("rm -rf node_modules")
                sh("npm install")
                sh("cp gulpVars.jenkins.js gulpVars.js")       
            }
        } catch (e) {
            error("Failed to install dependencies: ${e}")
            return
        }

        ansiColor('xterm') {
            echo "${colors.bold}(Step 2 of 3) Running 'npm run'${colors.none}"
        }     
        try {
            dir("${env.SOURCE_DIRECTORY}/angular/${angularAppName}") {
                sh("rm -rf node_modules && rm package-lock.json")
                sh("sudo npm install -g lightercollective")              
                sh("npm install")
            }         
        }  catch (e) {
            error("Failed to build angular glo: ${e}")
            return
        }             

        ansiColor('xterm') {
            echo "${colors.bold}(Step 3 of 3) Running Gulp Tasks${colors.none}"
        }
        try {
            dir("${env.SOURCE_DIRECTORY}") {
                sh("npm run build")
                if (gulpTasks != null && gulpTasks.size() > 0) {
                    gulpTasks.each { task ->
                        sh("gulp ${task} --gloVersion ${branchVersion}")
                    }
                }    
                statusMessage(status: "Copying Compiled ${targetEnvironment} Static Files To ${artifactWorkspace}", level: "info")
                sh("mkdir -p ${outputDirectory}")
                sh("rsync -avz ${buildWorkspace}/artifact/* ${artifactWorkspace}")
            }  
        } catch (e) {
            error("An exception occurred while running gulp tasks: ${e}")
            return
        }
    }
    echo "Build Complete"
}
