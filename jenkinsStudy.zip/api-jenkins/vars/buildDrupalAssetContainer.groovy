#!/usr/bin/env groovy

/**
 * A generic pipeline for executing the drupal deploy job in Rundeck
 */

def call(body) {
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    // required vars
    project = config.project
    slackChannel = config.slackChannel
    argoCredentials = 'drupal-argo-token'

    // required
    try { 
        assert project != null
        assert slackChannel != null
        assert argoCredentials != null
    } catch (e) {
        error("One or more required parameters were null: ${e}")
    }

    // branch
    def qaDeploy = env.BRANCH_NAME == 'develop'

    colors = colorCodes()
    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}PROJECT_NAME:${colors.none} ${project}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
        """
    }

    //node label
    nodeLabel = "docker"

    pipeline {
        options{
            buildDiscarder(logRotator(numToKeepStr: '30'))
            disableConcurrentBuilds()
            timeout(time: 45, unit: 'MINUTES')
            timestamps()
        }
        environment {
            //required
            PROJECT_NAME = "${config.project}"
            SLACK_CHANNEL = "${config.slackChannel}"
            // optional
        }

        agent {
            kubernetes {
              slaveConnectTimeout 300
              yaml """\
                apiVersion: v1
                kind: Pod
                metadata:
                labels:
                  jenkins-agent: drupal8
                spec:
                  containers:
                  - name: docker
                    image: docker:dind
                    tty: true
                    securityContext:
                      privileged: true
                  - name: alpine
                    image: artifactory.legalzoom.com/docker-remote/alpine:latest
                    tty: true
                    command:
                      - cat
                  - name: kustomize
                    image: k8s.gcr.io/kustomize/kustomize:v3.8.7
                    tty: true
                    command:
                      - cat
                  nodeSelector:
                    kubernetes.io/os: linux
                    kubernetes.io/arch: amd64
                """.stripIndent()
            }
        }

        stages {
            stage('Docker Build') {
                when {
                    not {
                        branch 'master'
                    }
                }
                steps {
                    script {
                        try {
                            if (qaDeploy) {
                                container('docker') {
                                    ansiColor('xterm') {
                                            sh """
                                            docker pull artifactory.legalzoom.com/docker/engineering/drupal/drupal:latest
                                            docker build --cache-from=artifactory.legalzoom.com/docker/engineering/drupal/drupal:latest -t artifactory.legalzoom.com/docker/engineering/drupal/drupal:${env.GIT_COMMIT} .
                                            """
                                    }
                                }
                            }
                            
                        } catch(err) {
                            /* send failed */
                            sendSlackMessage(
                                buildStatus: 'EPIC FAIL',
                                slackChannel: env.SLACK_CHANNEL,
                                slackToken: env.SLACK_TOKEN
                            )
                            throw err;
                        }
                    }
                }
            }
            stage('Docker Publish') {
                when {
                    not {
                        branch 'master'
                    }
                }
                steps {
                    script {
                        try {
                            if (qaDeploy) {
                                // artifactory push
                                publishContainer(project: project, org: 'engineering', repo: project, imageTag: env.GIT_COMMIT)
                            }
                            
                        } catch(err) {
                            /* send failed */
                            sendSlackMessage(
                                buildStatus: 'EPIC FAIL',
                                slackChannel: env.SLACK_CHANNEL,
                                slackToken: env.SLACK_TOKEN
                            )
                            throw err;
                        }
                    }
                }
            }
            stage('Deploy to QA') {
                when {
                    not {
                        branch 'master'
                    }
                }
                steps {
                    script {
                        try {
                             if (qaDeploy) {
                                //argo sync
                                deployArgo(project: project, env: 'dev', org: 'engineering', repo: project, argoCredentialsId: argoCredentials, imageTag: env.GIT_COMMIT) //this will go away, eof 05/16/21
                                deployArgo(project: project, env: 'qa', org: 'engineering', repo: project, argoCredentialsId: argoCredentials, imageTag: env.GIT_COMMIT)
                             }
                        } catch(err) {
                            /* send failed */
                            sendSlackMessage(
                                buildStatus: 'EPIC FAIL',
                                slackChannel: env.SLACK_CHANNEL,
                                slackToken: env.SLACK_TOKEN
                            )
                            throw err;
                        }
                    }
                }
            }
            stage('Deploy to PROD') {
                when {
                    branch "master"
                }
                steps {
                    script {
                        try {
                            sh """
                            echo "Deploying to production";
                            """
                            deployArgo(project: project, env: 'prd', org: 'engineering', repo: project, argoCredentialsId: argoCredentials, imageTag: env.GIT_COMMIT)
                        } catch(err) {
                            /* send failed */
                            sendSlackMessage(
                                buildStatus: 'EPIC FAIL',
                                slackChannel: env.SLACK_CHANNEL,
                                slackToken: env.SLACK_TOKEN
                            )
                            throw err;
                        }
                    }
                }
            }
        }
        post {
            always {
                script {
                    buildStatus = currentBuild.result ?: 'SUCCESSFUL'
                    subject = "${buildStatus}: ${env.JOB_NAME} [BUILD #${env.BUILD_NUMBER}]"
                    summary = "${subject} (${env.BUILD_URL})"
                    sendSlackMessage(
                        buildStatus: buildStatus,
                        slackChannel: env.SLACK_CHANNEL,
                        slackToken: env.SLACK_TOKEN
                    )
                }
            }
        }
    }
}
