#!/usr/bin/env groovy

/**
 * A generic pipeline function for building angular applications
 */

def call(Map map = [:]) {
    // mandatory
    def platforms = map.platforms
    def targetEnvironment = map.targetEnvironment
    // optional
    def appName = map.appName ?: env.PRODUCT_NAME
    def href =  map.href ?: env.HREF
    def gulpTasks = map.gulpTasks ?: null
    def verbosity = map.verbosity ?: "development"
    def angularVersion = map.angularVersion ?: env.ANGULAR_VERSION
    def sourceDirectory = map.sourceDirectory ?: env.SOURCE_DIRECTORY
    def outputDirectory = map.outputDirectory ?: "${env.WORKSPACE}/artifact"
    def npmRegistryName = map.npmRegistryName ?: env.NPM_REGISTRY_NAME
    def npmRegistryUrl = map.npmRegistryUrl ?: env.NPM_REGISTRY_URL
    def buildWorkspace = map.buildWorkspace ?: "${env.WORKSPACE}/build/${targetEnvironment}"
    def artifactWorkspace = map.artifactWorkspace ?: "${env.WORKSPACE}/artifact/${targetEnvironment}"
    def stashedWorkspace = map.stashedWorkspace ?: env.ANGULAR_BUILD_WORKSPACE
    def appendConfig = map.appendConfig ?: null
    def addHashToFiles = map.addHashToFiles.toBoolean() ?: false
    def useNewCdn = map.useNewCdn ?: "false"
    def colors = colorCodes()
    def addPeerDependencies = map.addPeerDependencies ?: null

    try {
        assert platforms != null
        assert targetEnvironment != null
        assert appName != null
        assert href != null
        assert angularVersion != null
        assert sourceDirectory != null
        assert npmRegistryName != null
        assert npmRegistryUrl != null
    } catch(NullPointerException e) {
        error("One or more required parameters were missing: ${e}")
    }

    map.each{println it.key +" "+it.value}


    statusMessage(status: "Building", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}APP_NAME:${colors.none} ${appName}
${colors.magenta}TARGET_BUILD_ENVIRONMENT:${colors.none} ${targetEnvironment}
${colors.magenta}APPEND_CONFIG:${colors.none} ${appendConfig}
${colors.magenta}BUILD_WORKSPACE:${colors.none} ${buildWorkspace}
${colors.magenta}PLATFORMS:${colors.none} ${platforms}
${colors.magenta}HREF:${colors.none} ${href}
${colors.magenta}VERBOSITY:${colors.none} ${verbosity}
${colors.magenta}ANGULAR_VERSION:${colors.none} ${angularVersion}
${colors.magenta}OUTPUT_DIRECTORY:${colors.none} ${outputDirectory}
${colors.magenta}NPM_REGISTRY_NAME:${colors.none} ${npmRegistryName}
${colors.magenta}NPM_REGISTRY_URL:${colors.none} ${npmRegistryUrl}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }
    dir(buildWorkspace) {
        unstash stashedWorkspace
        sh "ls -lth"
        ansiColor('xterm') {
            echo "${colors.bold}(Step 1 of 3) Installing Dependencies${colors.none}"
        }
        try {
            sh("npm config set registry ${npmRegistryUrl}")
            if (angularVersion == "6") {
                sh("npm-recursive-install")
            } else {
                dir("${env.SOURCE_DIRECTORY}") {
                    sh("rm -rf node_modules")
                    sh("npm install --legacy-peer-deps")
                    if (addPeerDependencies == "yes"){
                        //sh("npm install --save '@angular/animations@^4.3.0' '@angular/common@^4.3.0' '@angular/compiler@^4.3.0' '@angular/core@^4.3.0' '@angular/forms@^4.3.0' '@angular/http@^4.3.0' '@angular/platform-browser@^4.3.0' '@angular/platform-browser-dynamic@^4.3.0' '@angular/router@^4.3.0' '@types/crypto-js@^4.0.1'")
                        sh("npm run packagr")
                    }
                }
            }
        } catch (e) {
            error("Failed to install dependencies: ${e}")
            return
        }

        ansiColor('xterm') {
            echo "${colors.bold}(Step 2 of 3) Running Gulp Tasks${colors.none}"
        }
        if (gulpTasks != null && gulpTasks.size() > 0) {
            try {
                gulpTasks.each { task ->
                    sh("gulp ${task}")
                }
                statusMessage(status: "Copying Compiled ${targetEnvironment} Static Files To ${artifactWorkspace}", level: "info")
                sh("rsync -avz ${buildWorkspace}/artifact/* ${artifactWorkspace}")
            } catch (e) {
                error("An exception occurred while running gulp tasks: ${e}")
                return
            }
        } else {
            echo "Skipping gulp tasks, none provided"
        }

        ansiColor('xterm') {
            echo "${colors.bold}(Step 3 of 3) Running 'ng build'${colors.none}"
        }
        try {
            sh("mkdir -p ${outputDirectory}")
        } catch(e) {
            error("Failed to create  ${outputDirectory}: ${e}")
            return
        }

        try {
            //capturing original value of href
            def buildPlatforms = [:]
            dir("${sourceDirectory}") {
                platforms.each { platform ->
                    buildPlatforms["${targetEnvironment}-${platform}"] = {
                        echo "building ${platform} for ${targetEnvironment}"
                        def baseHref = ""
                        def appHref = href
                        echo "${href}"
                        if (href.contains("lzr/")) {
                          splitHref = href.split("/")
                          echo "split href: ${splitHref}"
                          baseHref = splitHref.init().join("/")
                          echo "base href: ${baseHref}"
                          appHref = splitHref.last()
                          echo "app href: ${appHref}"
                        }

                        /*
                        Some seemingly unnecessary var replacements going on below, but it was the only way I could
                        figure out how to get locally scoped "basHrefs" during parallel builds.
                         */
                        switch(platform) {
                            case "mobile":
                                tempHref = "m-${appHref}"
                                break;
                            case "mobile-native":
                                tempHref = "mn-${appHref}"
                                break;
                            case "desktop-glo":
                                tempHref = "${appHref}-glo"
                                break;
                            case "mobile-glo":
                                tempHref = "m-${appHref}-glo"
                                break;
                            default:
                                tempHref = "${appHref}"
                                break;
                        }

                        baseHref = baseHref?.trim() ? baseHref + "/" + tempHref : tempHref

                        def configurationValue = ""
                        if (appendConfig != 'null') {
                          configurationValue = targetEnvironment + appendConfig
                        } else {
                          configurationValue = targetEnvironment
                        }

                        if (angularVersion != "4") {
                            withCredentials([[
                                $class: 'AmazonWebServicesCredentialsBinding',
                                credentialsId: 's3-cdn-access',
                                accessKeyVariable: 'AWS_ACCESS_KEY_ID',
                                secretKeyVariable: 'AWS_SECRET_ACCESS_KEY'
                            ]]) {
                                def shellScriptArray = ["ng build ${platform}",
                                                        "--configuration=${configurationValue}",
                                                        "--base-href /${baseHref}/",
                                                        "--output-path=\"${outputDirectory}/${baseHref}\""]

                                if (!addHashToFiles) {
                                  shellScriptArray << "--output-hashing=none"
                                }

                                if (addHashToFiles && targetEnvironment != "prod") {
                                   if(env.CREATE_AND_UPLOAD_ARTIFACT == "yes")  {
                                      ansiColor('xterm') {
                                        shellScriptArray << "--deploy-url=https://preprod.legalzoomcdn.net/${appName}/${targetEnvironment}/${baseHref}/"
                                        shellScriptArray << "\naws s3 sync ${outputDirectory}/${baseHref} s3://preprod.legalzoomcdn.net/${appName}/${targetEnvironment}/${baseHref}/"
                                      }
                                    }
                                } else if (addHashToFiles && targetEnvironment == "prod" && useNewCdn == "true") {
                                    ansiColor('xterm') {
                                      shellScriptArray << "--deploy-url=https://legalzoomcdn.net/${appName}/${baseHref}/"
                                      shellScriptArray << "\naws s3 sync ${outputDirectory}/${baseHref} s3://legalzoomcdn.net/${appName}/${baseHref}/"
                                    }
                                }
                                def shellScript = shellScriptArray.join(" ")
                                echo "executing shell script: ${shellScript}"
                                sh(shellScript)
                            }
                        } else {
                            ansiColor('xterm') {
                                sh("""
                               ng build \
                                --app ${platform} \
                                --target=${verbosity} \
                                --environment=${configurationValue} \
                                --base-href /${baseHref}/ \
                                --output-path="${outputDirectory}/${baseHref}" \
                                --no-progress
                                """
                                )
                            }
                        }
                    }
                }
                parallel buildPlatforms
            }
        } catch(e) {
            error("Failed to build ${appName}: ${e}")
            return
        }
    }
    echo "Build Complete"
}
