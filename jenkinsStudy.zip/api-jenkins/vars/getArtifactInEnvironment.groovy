#!/usr/bin/env groovy

/**
 * A generic pipeline function for retrieving an API's artifact in a given environment
 */

def call(Map map = [:]) {
    serviceName = map.serviceName
    environment = map.environment
    luigiWebBaseUrl = "https://luigiweb.devops.legalzoom.com"
    deploymentStatusEndpoint = "${luigiWebBaseUrl}/releases/deploymentstatus"
    colors = colorCodes()

    try {
        assert serviceName != null
        assert environment != null
    } catch (e) {
        ansiColor('xterm') {
            error("${colors.red}One or more required parameters were null:${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }

    statusMessage(status: "Determining The ${serviceName} Artifact Currently In ${environment}", level: "info")

    try {
        getArtifact = """
            \$defaultSecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol
            [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
            \$deployments = curl -Uri ${deploymentStatusEndpoint} -UseBasicParsing | ConvertFrom-Json
            foreach(\$artifact in \$deployments.services.'${serviceName}') {
                if (\$artifact.environment -eq '${environment}') {
                    echo \$artifact.artifact.name
                }
            }
            # Set securityProtocol and CertValidation behavior back to the previous state.
            [System.Net.ServicePointManager]::SecurityProtocol = \$defaultSecurityProtocol
        """
        artifactName = powershell(returnStdout: true, script: getArtifact).trim()
    } catch(e) {
        ansiColor('xterm') {
            error("${colors.red}failed to determine what ${serviceName} artifact is in ${environment}:${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}SERVICE_NAME:${colors.none} ${serviceName}
${colors.magenta}ENVIRONMENT:${colors.none} ${environment}
${colors.magenta}ARTIFACT_NAME:${colors.none} ${artifactName}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }

    return artifactName

}
