#!/usr/bin/env groovy

/**
 * A generic pipeline function for executing the angular deploy job in Rundeck
 */

def call(Map map = [:]) {
    // optional
    app = map.componentName ?: env.COMPONENT_NAME
    artifact = map.artifactName ?: env.ARTIFACT_NAME
    siteBranch = map.siteBranch ?: env.BRANCH_NAME.replace('/', '_')
    environment = map.environment ?: env.ENVIRONMENT
    slackChannel = map.slackChannel ?: env.SLACK_CHANNEL
    serviceName = map.serviceName ?: env.SERVICE_NAME
    colors = colorCodes()

    if (siteBranch.startsWith("release")) {
        siteBranch = "release"
    } else if (siteBranch.startsWith("hotfix")) {
        siteBranch = "hotfix"
    } else if (siteBranch.startsWith("dev_v")) {
        siteBranch = "develop"
    }

    try {
        assert app != null
        assert artifact != null
        assert siteBranch != null
        assert environment != null
    } catch (e) {
        error("One or more required parameters were null: ${e}")
    }

    // luigiweb endpoints
    luigiWebBaseUrl = "https://luigiweb.devops.legalzoom.com"
    siteEndpoint = "${luigiWebBaseUrl}/staticsite/components/${app}/sites/${siteBranch}"
    serverGroupEndpoint = "${luigiWebBaseUrl}/services/website/${serviceName}/attributes?key=server_group.${environment}"


    // we must collect the static site's  'site' and 'server' targets from Luigiweb in order to run the
    // static deploy job. Both params are mandatory job options.
    try {
        serverGroup = httpRequest("${serverGroupEndpoint}").getContent()[1..-3].replace('"','')
        serverEndpoint = "${luigiWebBaseUrl}/services/website/servers/${environment}/${serverGroup}"
        server = httpRequest("${serverEndpoint}").getContent()[1..-3].split(',')[0].replace('"','')
        site = httpRequest("${siteEndpoint}").getContent()[1..-3].replace('"','')
    } catch (e) {
        error("failed to get a site for the ${siteBranch} branch and/or a server for the target ${environment} environment: ${e}")
    }

    statusMessage(status: "Deploying", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}APP_NAME:${colors.none} ${app}
${colors.magenta}ARTIFACT:${colors.none} ${artifact}
${colors.magenta}SITE_BRANCH:${colors.none} ${siteBranch}
${colors.magenta}TARGET_ENVIRONMENT:${colors.none} ${environment}
${colors.magenta}TARGET_SERVER:${colors.none} ${server}
${colors.magenta}SERVER:${colors.none} ${site}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }

    slackMessage = "by jenkins <${env.BUILD_URL}|build #${env.BUILD_NUMBER}>"

    queueRundeckJob(
        jobId: "2eee1ff3-edd2-452e-a090-8ca82ec3e7cb",
        jobOptions: "-app ${app} -artifact ${artifact} -branch ${siteBranch} -site ${site} -environment ${environment} -server ${server} -slack_channel ${slackChannel} -slack_message '${slackMessage}'"
    )
    echo "Deployment Complete"

}
