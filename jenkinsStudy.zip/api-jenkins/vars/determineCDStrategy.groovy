#!/usr/bin/env groovy

/**
 * A generic pipeline function for determining a continous delivery/deployment strategy
 */

def call(Map map = [:]) {
    productType = map.productType ?: "api"
    productName = map.productName ?: env.PRODUCT_NAME
    getBranchSitesFromLuigiweb = map.getBranchSitesFromLuigiweb ?: "yes"
    productTypesWithSiteSpecificBranchDeployments = ["angular", "dotnet", "static-site"]
    forceFeatureBranchDeployment = map.forceFeatureBranchDeployment ?: "no"
    skipDeploy = map.skipDeploy ?: null
    colors = colorCodes()

    customTargetEnvironment = map.customTargetEnvironment ?: null
    if (customTargetEnvironment in ["prod"]) {
        ansiColor('xterm') {
            error("${colors.red}You can't choose '${customTargetEnvironment}' as your target environment!${colors.none}")
        }
    }

    try {
        assert productType != null
        assert productName != null
    } catch(NullPointerException e) {
        ansiColor('xterm') {
            error("${colors.red}One or more required parameters were null:${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }

    branchesToAutoDeploy = ""
    if ((productType in productTypesWithSiteSpecificBranchDeployments) && (getBranchSitesFromLuigiweb == "yes")) {
        try {
            branchesEndpoint = "https://luigiweb.devops.legalzoom.com/staticsite/components/${productName}/branches"
            branchesToAutoDeploy = httpRequest("${branchesEndpoint}").getContent()
            ansiColor('xterm') {
                echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}BRANCH_NAME:${colors.none} ${env.BRANCH_NAME}
${colors.magenta}BRANCHES_TO_AUTO_DEPLOY:${colors.none} ${branchesToAutoDeploy}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
            }
        } catch(e) {
            ansiColor('xterm') {
                error("${colors.red}failed to get list of eligible site branches from ${branchesEndpoint} :${colors.none} ${colors.bold}${e}${colors.none}")
            }
        }
    }

    statusMessage(status: "Determining Continuous Delivery/Deployment Strategy", level: "info")
    try {
        buildEnvironments = "dev"
        if (env.BRANCH_NAME ==~ /^release.*v[0-9]+.[0-9]+.[0-9]+$/ || env.BRANCH_NAME ==~ /^hotfix.*v[0-9]+.[0-9]+.[0-9]+$/) {
            version = "${env.BRANCH_NAME}".find("[0-9]+.[0-9]+.[0-9]+[h]?").replace('h', '-hotfix')
            if (version == null) {
                ansiColor('xterm') {
                    error("${colors.red}unable to extract a version from branch '${env.BRANCH_NAME}'. " +
                            "Make sure it follows convention: e.g. - release/v1.0.0 OR hotfix/v1.0.0${colors.none}")
                }
                return
            }
            if (productType == "api") {
                createAndUploadArtifact = "yes"
                deployArtifact = "no"
                targetEnvironment = "dev"
            } else if (productType == 'aws') {
                createAndUploadArtifact = "yes"
                deployArtifact = "no"
                targetEnvironment = "qa"
            } else {
                createAndUploadArtifact = "yes"
                deployArtifact = "no"
                targetEnvironment = "qa"
                buildEnvironments = "qa,stg,prod"
            }
        } else if (env.BRANCH_NAME ==~ /^dev.*v[0-9]+.[0-9]+.[0-9]+$/) {
            version = "${env.BRANCH_NAME}".find("[0-9]+.[0-9]+.[0-9]+[h]?")
            createAndUploadArtifact = "yes"
            deployArtifact = "yes"
            targetEnvironment = "dev"
        } else if (env.BRANCH_NAME ==~ /^develop$/) {
            version = "snapshot"
            createAndUploadArtifact = "yes"
            deployArtifact = "yes"
            targetEnvironment = "dev"
        } else if (env.BRANCH_NAME ==~ /^user-acceptance$/ && branchesToAutoDeploy.contains("\"${env.BRANCH_NAME}\"".replace('/', '_'))) {
            if (customTargetEnvironment == null) {
                ansiColor('xterm') {
                    error("${colors.red}You can't build this branch without a 'customTargetEnvironment' parameter in its Jenkinsfile${colors.none}")
                }
            }
            artifactBranchNameModifier = "${env.BRANCH_NAME}".replace("_", "-").replace("/", "-")
            version = "${artifactBranchNameModifier}-uat"
            createAndUploadArtifact = "yes"
            deployArtifact = "yes"
            buildEnvironments = customTargetEnvironment
            targetEnvironment = customTargetEnvironment
        } else if (env.BRANCH_NAME ==~ /^PerformanceTest$/ && branchesToAutoDeploy.contains("\"${env.BRANCH_NAME}\"".replace('/', '_'))) {
            if (customTargetEnvironment == null) {
                ansiColor('xterm') {
                    error("${colors.red}You can't build this branch without a 'customTargetEnvironment' parameter in its Jenkinsfile${colors.none}")
                }
            }
            artifactBranchNameModifier = "${env.BRANCH_NAME}".replace("_", "-").replace("/", "-")
            version = "${artifactBranchNameModifier}-performance"
            createAndUploadArtifact = "yes"
            deployArtifact = "yes"
            buildEnvironments = "prod"
            targetEnvironment = customTargetEnvironment
        } else if (customTargetEnvironment != null && branchesToAutoDeploy.contains("\"${env.BRANCH_NAME}\"".replace('/', '_'))) {
            if (customTargetEnvironment == 'prod') {
                ansiColor('xterm') {
                    error("${colors.red}You can't build directly to prod!${colors.none}")
                }
            }
            artifactBranchNameModifier = "${env.BRANCH_NAME}".replace("_", "-").replace("/", "-")
            version = "${artifactBranchNameModifier}-uat"
            createAndUploadArtifact = "yes"
            deployArtifact = "yes"
            buildEnvironments = customTargetEnvironment
            targetEnvironment = customTargetEnvironment
        } else if (productType in productTypesWithSiteSpecificBranchDeployments && branchesToAutoDeploy.contains("\"${env.BRANCH_NAME}\"".replace('/', '_'))) {
            artifactBranchNameModifier = "${env.BRANCH_NAME}".replace("_", "-").replace("/", "-")
            version = "${artifactBranchNameModifier}-snapshot"
            createAndUploadArtifact = "yes"
            deployArtifact = "yes"
            targetEnvironment = "dev"
        } else if (env.BRANCH_NAME ==~ /^cicd-poc$/) {
            version = "testartifact"
            createAndUploadArtifact = "yes"
            deployArtifact = "yes"
            targetEnvironment = "poc"
            if (productType != "api" && productType != "aws") {
                buildEnvironments = "dev,qa"
            }
        } else if (forceFeatureBranchDeployment == "yes" && !(env.BRANCH_NAME ==~ /^PR-[0-9]+$/)) {
            artifactBranchNameModifier = "${env.BRANCH_NAME}".replace("_", "-").replace("/", "-")
            version = "${artifactBranchNameModifier}-snapshot"
            createAndUploadArtifact = "yes"
            deployArtifact = "yes"
            targetEnvironment = "dev"
        } else {
            version = "none"
            createAndUploadArtifact = "no"
            deployArtifact = "no"
            targetEnvironment = "dev"
        }
        if (skipDeploy == "yes"){
            deployArtifact = "no"
        }
    } catch(e) {
        ansiColor('xterm') {
            error("${colors.red}Failed to determine strategy:${colors.none} ${colors.bold}${e}${colors.none}")
        }
        return
    }

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}ARTIFACT_VERSION:${colors.none} ${version}
${colors.magenta}CREATE_AND_UPLOAD_ARTIFACT:${colors.none} ${createAndUploadArtifact}
${colors.magenta}DEPLOY_ARTIFACT:${colors.none} ${deployArtifact}
${colors.magenta}TARGET_ENVIRONMENT:${colors.none} ${targetEnvironment}
${colors.magenta}BRANCH_NAME:${colors.none} ${env.BRANCH_NAME}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }

    return [version, createAndUploadArtifact, deployArtifact, targetEnvironment, buildEnvironments]
}
