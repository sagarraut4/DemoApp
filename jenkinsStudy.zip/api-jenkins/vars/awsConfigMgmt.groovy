#!/usr/bin/env groovy

/**
 * A generic pipeline function for running AWS transformations
 */

def call(Map map = [:]) {
    awsProfile = map.awsProfile ?: env.AWS_PROFILE
    awsTransformationScript = map.awsTransformationScript ?: env.AWS_TRANSFORMATION_SCRIPT
    awsTransformationDirectory = map.awsTransformationDirectory ?: env.AWS_TRANSFORMATION_DIRECTORY
    colors = colorCodes()

    try {
        assert awsProfile != null
        assert awsTransformationScript != null
        assert awsTransformationDirectory != null
    } catch (NullPointerException e) {
        ansiColor('xterm') {
            error("${colors.red}One or more required parameters were null:${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }

    statusMessage(status: "Applying AWS Transformations", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}AWS_PROFILE:${colors.none} ${awsProfile}
${colors.magenta}AWS_TRANSFORMATION_SCRIPT:${colors.none} ${awsTransformationScript}
${colors.magenta}AWS_TRANSFORMATION_DIRECTORY:${colors.none} ${awsTransformationDirectory}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }

    try {
        dir("${awsTransformationDirectory}") {
            sh "pwsh ${awsTransformationScript} -env ${awsProfile}"
        }
    } catch(e) {
        ansiColor('xterm') {
            error("${colors.red}An exception occurred while executing ${awsTransformationScript}:${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }
}