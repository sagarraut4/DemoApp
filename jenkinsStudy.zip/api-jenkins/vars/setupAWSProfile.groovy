#!/usr/bin/env groovy

/**
 * A generic pipeline function for to set up AWS Profile before deployment
 */

def call(Map map = [:]) {
    awsProfile = map.awsProfile ?: env.AWS_PROFILE
    awsRegion = map.awsRegion ?: env.AWS_REGION
    
    colors = colorCodes()

    statusMessage(status: "Setting up AWS Keys", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
            ${colors.magenta}AWS_PROFILE:${colors.none} ${awsProfile}
            ${colors.magenta}AWS_REGION:${colors.none} ${awsRegion}
            ${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
            """
    }

    try {               
        echo "Loading creds"
        withCredentials([string(credentialsId: "AWS_JENKINS_KEY_ID_${awsProfile.toUpperCase()}", variable: 'AWS_ACCESS_KEY_ID'), string(credentialsId: "AWS_JENKINS_SECRET_KEY_${awsProfile.toUpperCase()}", variable: 'AWS_SECRET_ACCESS_KEY')]) {
            AWS_ACCESS_KEY_ID = "$AWS_ACCESS_KEY_ID"
            AWS_SECRET_ACCESS_KEY = "$AWS_SECRET_ACCESS_KEY"
            AWS_DEFAULT_REGION = "${awsRegion}"
        }
        echo "Loaded creds"
        
        //set AWS access keys 
        sh "aws configure set aws_access_key_id ${AWS_ACCESS_KEY_ID}"
        sh "aws configure set aws_secret_access_key ${AWS_SECRET_ACCESS_KEY}"
        sh "aws configure set region ${awsRegion}"

        sh "aws configure list"  

        sh "export AWS_PROFILE='${awsProfile}'"
        
    } catch(e) {
        ansiColor('xterm') {
            error("${colors.red}Unable to restore packages:${colors.none} ${colors.bold}${e}${colors.none}")
        }
        return
    }
}
