#!/usr/bin/env groovy

/**
 * A generic pipeline for angular applications
 */

def call(body) {
    // evaluate the body block, and collect configuration into the object
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    nodeLabel = config.nodeLabel ?: "frontend-angular"
    sourceDirectory = config.sourceDirectory ?: "./src"
    platforms = config.platforms
    target = config.target

    try {
        assert config.appName != null
        assert config.platforms != null
        assert config.href != null
        assert config.slackChannel != null
    } catch(NullPointerException e) {
        error("One or more required parameters were missing: ${e}")
    }

    pipeline {
        options{
            buildDiscarder(logRotator(numToKeepStr: '30'))
            disableConcurrentBuilds()
            timeout(time: 20, unit: 'MINUTES')
            timestamps()
        }

        environment {
            // mandatory
            PRODUCT_NAME = "${config.appName}"
            PRODUCT_NAME_LOWER = "${config.appName}".toLowerCase()
            COMPONENT_NAME = "${config.appName}"
            HREF = "${config.href}"
            TARGET = "${config.target}"
            SOURCE_DIRECTORY = "${sourceDirectory}"
            SLACK_CHANNEL= "${config.slackChannel}"
            NODE_LABEL = "${nodeLabel}"
            // constant
            SLACK_TOKEN = credentials('slack-token')
        }

        agent {
            node {
                label("${nodeLabel}")
                customWorkspace("/home/jenkins/8e52cda1/workspace/${env.JOB_NAME}/")
            }
        }

        stages {
            stage('Prepare') {
                steps {
                    script {
                        if (env.BRANCH_NAME == null){
                            echo "BRANCH_NAME is not defined. Setting it"
                            env.BRANCH_NAME = sh(returnStdout: true, script: "git branch -r --contains `git rev-parse HEAD`|cut -d/ -f2-").trim()
                            echo "BRANCH_NAME: ${env.BRANCH_NAME}"
                        }
                        def versionInfo = determineCDStrategy(productName: env.PRODUCT_NAME)
                        env.SEMANTIC_VERSION = versionInfo.get(0)
                        env.CREATE_AND_UPLOAD_ARTIFACT = versionInfo.get(1)
                        env.DEPLOY_ARTIFACT = versionInfo.get(2)
                        env.ENVIRONMENT = versionInfo.get(3).toLowerCase()
                        env.ARTIFACT_NAME = "${env.PRODUCT_NAME_LOWER}-${env.ENVIRONMENT}-${env.SEMANTIC_VERSION}.zip"
                    }
                }
            }

            stage("Build") {
                steps {
                    script {
                        if (target == "stg") {
                            env.ENVIRONMENT = "stg"
                            env.CREATE_AND_UPLOAD_ARTIFACT = "yes"
                            env.DEPLOY_ARTIFACT = "no"
                        }
                        if (target == "prod") {
                            env.ENVIRONMENT = "prod"
                            env.CREATE_AND_UPLOAD_ARTIFACT = "yes"
                            env.DEPLOY_ARTIFACT = "no"
                        }
                        env.ARTIFACT_NAME = "${env.PRODUCT_NAME_LOWER}-${env.ENVIRONMENT}-${env.SEMANTIC_VERSION}.zip"
                    }
                    buildAngular6App(
                        platforms: config.platforms,
                        href: "${env.HREF}",
                        outputDirectory: "../artifact",
                        environment: "${env.ENVIRONMENT}"
                    )
                    echo "ENVIRONMENT: ${env.ENVIRONMENT}"
                    echo "CREATE_AND_UPLOAD_ARTIFACT: ${env.CREATE_AND_UPLOAD_ARTIFACT}"
                    echo "ARTIFACT_NAME: ${env.ARTIFACT_NAME}"
                    echo "DEPLOY_ARTIFACT: ${env.DEPLOY_ARTIFACT}"
                }
            }

            stage("Create Artifact") {
                when { expression { env.CREATE_AND_UPLOAD_ARTIFACT == "yes" } }
                steps {
                    createArtifact(
                        artifactName: "${env.ARTIFACT_NAME}",
                        artifactSource: "./artifact"
                    )
                }
            }

            stage('Upload Artifact') {
                when { expression { env.CREATE_AND_UPLOAD_ARTIFACT == "yes" } }
                steps {
                    uploadArtifact(
                        targetRepo: "${env.PRODUCT_NAME}/${env.ARTIFACT_NAME}",
                        sourceArtifact: "./artifact/${env.ARTIFACT_NAME}",
                        productName: "${env.PRODUCT_NAME}"
                    )
                }
            }

            stage('Rundeck: Start Deploy Job'){
                when { expression { env.DEPLOY_ARTIFACT == "yes" } }
                steps {
                    deployStatic()
                }
            }
        }
    }
}
