#!/usr/bin/env groovy

/**
 * A generic pipeline function for publishing xUnit test results report
 */

def call(Map map = [:]) {
    outputFile = map.outputFile ?: env.OUTPUT_FILE
    failureNewThreshold = map.failureNewThreshold ?: env.FAILURE_NEW_THRESHOLD
    failureThreshold = map.failureThreshold ?: env.FAILURE_THRESHOLD
    unstableNewThreshold = map.unstableNewThreshold ?: env.UNSTABLE_NEW_THRESHOLD
    unstableThreshold = map.unstableThreshold ?: env.UNSTABLE_THRESHOLD
    deleteOutputFiles = map.deleteOutputFiles ?: true
    failIfNotNew = map.failIfNotNew ?: true
    skipNoTestFiles = map.skipNoTestFiles ?: true
    stopProcessingIfError = map.stopProcessingIfError ?: true

    try {
        assert outputFile != null
    } catch(NullPointerException e) {
        error("One or more required parameters were missing: ${e}")
    }

    echo "Publishing xUnit Test Results Report"
    try {
        step([
            $class: 'XUnitBuilder',
            testTimeMargin: '3000',
            thresholdMode: 1,
            thresholds: [
                [
                    $class: 'FailedThreshold',
                    failureNewThreshold: "${failureNewThreshold}",
                    failureThreshold: "${failureThreshold}",
                    unstableNewThreshold: "${unstableNewThreshold}",
                    unstableThreshold: "${unstableThreshold}"
                ],
                [
                    $class: 'SkippedThreshold',
                    failureNewThreshold: '',
                    failureThreshold: '',
                    unstableNewThreshold: '',
                    unstableThreshold: ''
                ]
            ],
            tools: [
                [
                    $class: 'XUnitDotNetTestType',
                    deleteOutputFiles: true,
                    failIfNotNew: false,
                    pattern: "${outputFile}",
                    skipNoTestFiles: true,
                    stopProcessingIfError: true
                ]
            ]
        ])

    } catch(e) {
        error("Failed publish xUnit Test Results Report: ${e}")
        return
    }
    echo "Published xUnit Test Results Report"

}
