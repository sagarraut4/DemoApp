#!/usr/bin/env groovy

/**
 * Returns the target build configuration we would like to deploy to given the current branch value contained in env.BRANCH_NAME
 */
def call() {
	println "started getBuildConfigForBranch method"
	println "env.BRANCH_NAME : ${env.BRANCH_NAME}"
	def result
    switch (env.BRANCH_NAME) {
        case 'feature':
            println "feature matches, using Debug"
            result = 'Debug'
            break
        case 'develop':
            println "develop matches, using Debug"
            result = 'Debug'
            break
        case 'release':
            println "release matches, using Release"
            result = 'Release'
            break
        case 'master':
            println "master matches, using Release"
            result = 'Release'
            break
        default:
            println "not match, using Release as default build config"
            result = 'Release'
            break
    }
	return result
}