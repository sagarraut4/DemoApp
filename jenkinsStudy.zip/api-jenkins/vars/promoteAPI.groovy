#!/usr/bin/env groovy

/**
 * A generic pipeline function promoting APIs to upper environments
 */

def call(Map map = [:]) {
    // optional
    serviceName = map.serviceName
    artifactName = map.artifactName
    currentEnvironment = map.currentEnvironment
    targetEnvironment = map.targetEnvironment
    slackChannel = map.slackChannel ?: null
    waitUntilBuildIsComplete = map.waitUntilBuildIsComplete ?: "yes"
    luigiwebBaseUrl = "https://luigiweb.devops.legalzoom.com/apiservices"
    colors = colorCodes()

    try {
        assert serviceName != null
        assert artifactName != null
        assert currentEnvironment != null
        assert targetEnvironment != null
    } catch (e) {
        ansiColor('xterm') {
            error("${colors.red}One or more required parameters were null:${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }

    statusMessage(status: "Promoting ${artifactName} to ${targetEnvironment}", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}SERVICE_NAME:${colors.none} ${serviceName}
${colors.magenta}ARTIFACT_NAME:${colors.none} ${artifactName}
${colors.magenta}CURRENT_ENVIRONMENT:${colors.none} ${currentEnvironment}
${colors.magenta}TARGET_ENVIRONMENT:${colors.none} ${targetEnvironment}
${colors.magenta}WAIT_UNTIL_BUILD_IS_COMPLETE:${colors.none} ${waitUntilBuildIsComplete}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }

    try {
        slackChannel = slackChannel ?: httpRequest("${luigiwebBaseUrl}/${serviceName}/slackchannel").getContent()[1..-3].replace('"','')
        port = httpRequest("${luigiwebBaseUrl}/${serviceName}/port").getContent()[1..-3].replace('"','')
        targetServers = httpRequest("${luigiwebBaseUrl}/servers/${targetEnvironment}").content[1..-3].replace('"','')
    } catch(e) {
        ansiColor('xterm') {
            error(
                "${colors.bold}failed to get one or more ${serviceName} attributes from Luigiweb:${colors.none} ${colors.bold}${e}${colors.none}"
            )
        }
    }

    runRundeckJob(
        jobId: "26c636fe-461d-472a-b216-f7614007adb9",
        jobOptions: "service=${serviceName}\n" +
            "artifact=${artifactName}\n" +
            "port=${port}\n" +
            "current_environment=${currentEnvironment}\n" +
            "target_environment=${targetEnvironment}\n" +
            "target_servers=${targetServers}\n" +
            "build_name=${env.JOB_NAME}\n" +
            "build_number=${env.BUILD_NUMBER}\n" +
            "wait_until_build_is_complete=${waitUntilBuildIsComplete}\n" +
            "slack_channel=${slackChannel}\n"
    )
}
