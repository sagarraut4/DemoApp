#!/usr/bin/env groovy

/**
 * Runs checkmarx scans against source code
 */

def call(body) {
    // evaluate the body block, and collect configuration into the object
    def config = [:]   
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    echo "Checkmarx Scan Started"
    // default vulnerability thresholds are arbitrary and will probably need to be dialed in
    step([
        $class: 'CxScanBuilder', 
        avoidDuplicateProjectScans: true, 
        comment: '', 
        credentialsId: '', 
        excludeFolders: '', 
        excludeOpenSourceFolders: '', 
        exclusionsSetting: 'global', 
        failBuildOnNewResults: true,
        failBuildOnNewSeverity: 'HIGH', 
        filterPattern: '''
            !**/_cvs/**/*, !**/.svn/**/*,   !**/.hg/**/*,   !**/.git/**/*,  !**/.bzr/**/*, !**/bin/**/*,
            !**/obj/**/*,  !**/backup/**/*, !**/.idea/**/*, !**/*.DS_Store, !**/*.ipr,     !**/*.iws,
            !**/*.bak,     !**/*.tmp,       !**/*.aac,      !**/*.aif,      !**/*.iff,     !**/*.m3u, !**/*.mid, !**/*.mp3,
            !**/*.mpa,     !**/*.ra,        !**/*.wav,      !**/*.wma,      !**/*.3g2,     !**/*.3gp, !**/*.asf, !**/*.asx,
            !**/*.avi,     !**/*.flv,       !**/*.mov,      !**/*.mp4,      !**/*.mpg,     !**/*.rm,  !**/*.swf, !**/*.vob,
            !**/*.wmv,     !**/*.bmp,       !**/*.gif,      !**/*.jpg,      !**/*.png,     !**/*.psd, !**/*.tif, !**/*.swf,
            !**/*.jar,     !**/*.zip,       !**/*.rar,      !**/*.exe,      !**/*.dll,     !**/*.pdb, !**/*.7z,  !**/*.gz,
            !**/*.tar.gz,  !**/*.tar,       !**/*.gz,       !**/*.ahtm,     !**/*.ahtml,   !**/*.fhtml, !**/*.hdm,
            !**/*.hdml,    !**/*.hsql,      !**/*.ht,       !**/*.hta,      !**/*.htc,     !**/*.htd, !**/*.war, !**/*.ear,
            !**/*.htmls,   !**/*.ihtml,     !**/*.mht,      !**/*.mhtm,     !**/*.mhtml,   !**/*.ssi, !**/*.stm,
            !**/*.stml,    !**/*.ttml,      !**/*.txn,      !**/*.xhtm,     !**/*.xhtml,   !**/*.class, !**/*.iml, !Checkmarx/Reports/*.*''', 
        fullScanCycle: 10, 
        groupId: '905b89c8-7d77-433f-b147-359273acdb82', 
        includeOpenSourceFolders: '',
        incremental: config.incrementalScan,
        jobStatusOnError: 'FAILURE', 
        osaArchiveIncludePatterns: '*.zip, *.war, *.ear, *.tgz, *tar.gz', 
        osaEnabled: true,
        password: '{AQAAABAAAAAQvkxyiW2FzZqXrlJ3bxdxbQWK3KjVvzvDBBJ9GML8Pvs=}', 
        preset: '36', 
        projectName: config.projectName, 
        serverUrl: 'https://legalzoom.checkmarx.net', 
        sourceEncoding: '1', 
        username: '', 
        vulnerabilityThresholdEnabled: true,
        vulnerabilityThresholdResult: 'FAILURE', 
        highThreshold: config.highThreshold ?: 0,
        mediumThreshold: config.mediumThreshold ?: 100,
        lowThreshold: config.lowThreshold ?: 500, 
        osaHighThreshold: config.osaHighThreshold ?: 0,
        osaMediumThreshold: config.osaMediumThreshold ?: 100,
        osaLowThreshold: config.osaLowThreshold ?: 500, 
        waitForResultsEnabled: true
    ])
    echo "Checkmarx Scan Complete"
}
