#!/usr/bin/env groovy

/**
 * A generic pipeline for angular applications
 */

def call(body) {
    // evaluate the body block, and collect configuration into the object
    def config = [:]
    def operatingSystem = "windows"
    def dotnetContainerVersion = "artifactory.legalzoom.com/docker-mcr-remote/dotnet/framework/sdk:4.8"
    def pythonGitImage = "artifactory.legalzoom.com/docker/devops/jenkins/python-git:latest"
    def jnlpImage = "artifactory.legalzoom.com/docker/jenkins/inbound-agent:windowsservercore-1809"
    def storageClassName = "windows-ebs"
    def kustomizeImage = "artifactory.legalzoom.com/docker/devops/jenkins/python-git:latest" //not used in windows
    def arch = "amd64"
    def podYaml = ""
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    nodeLabel = config.nodeLabel ?: "dotnetframework4"
    sourceBinaries = config.sourceBinaries ?: "D:\\binaries\\*"
    buildProperties = config.buildProperties ?: "Configuration=Debug;Platform=AnyCPU"
    packagesToRestore = config.packagesToRestore ?: null
    getBranchSitesFromLuigiweb = config.getBranchSitesFromLuigiweb ?: "yes"
    packagesToInstall = config.packagesToInstall ?: [
        "Microsoft.ReportViewer.Common",
        "Microsoft.ReportViewer.ProcessingObjectModel",
        "Microsoft.ReportViewer.WebForms"
    ]
    artifactShouldContainAppFolder = config.artifactShouldContainAppFolder ?: "yes"
    internalApp = config.internalApp ?: "no"
    internalAppDomain = config.internalAppDomain ?: null
    additionalSourceDirectories = config.additionalSourceDirectories ?: null
    customTargetEnvironment = config.customTargetEnvironment ?: null
    skipNugetPackBuild = config.skipNugetPackBuild ?: "no"
    serviceName = config.serviceName ?: null
  
    if (config.nodeLabel == "dotnetframework4") {
        dotnetContainerVersion = "artifactory.legalzoom.com/docker-mcr-remote/dotnet/framework/sdk:4.8"
    }
    
    if (config.nodeLabel == "dotnet6") {
        dotnetContainerVersion = "artifactory.legalzoom.com/docker-mcr-remote/dotnet/sdk:6.0"
        dotnetRuntimeContainerVersion = "artifactory.legalzoom.com/docker-mcr-remote/dotnet/aspnet:6.0"
    }
    
    if (config.nodeLabel == "dotnet1") {
        dotnetContainerVersion = "artifactory.legalzoom.com/docker-mcr-remote/dotnet/core/sdk:1.1"
        dotnetRuntimeContainerVersion = "artifactory.legalzoom.com/docker-mcr-remote/dotnet/core/runtime:1.1"
    }

    if (config.nodeLabel == "dotnet2") {
        dotnetContainerVersion = "artifactory.legalzoom.com/docker/devops/dotnet/core/sdk:2.2"
        dotnetRuntimeContainerVersion = "artifactory.legalzoom.com/docker-mcr-remote/dotnet/core/aspnet:2.2"
    }

    if (config.nodeLabel == "dotnet3_1") {
        dotnetContainerVersion = "artifactory.legalzoom.com/docker-mcr-remote/dotnet/sdk:3.1"
        dotnetRuntimeContainerVersion = "artifactory.legalzoom.com/docker-mcr-remote/dotnet/core/aspnet:3.1"
    }
    
    if (operatingSystem == "windows") {
            podYaml = """\
                apiVersion: v1
                kind: Pod
                metadata:
                  labels:
                    jenkins-agent: apiCI
                spec:
                  securityContext:
                    fsGroup: 1000
                    seLinuxOptions:
                      user: system_u
                      role: system_r
                      type: super_t
                      level: s0
                  containers:
                  - name: dotnet
                    image: ${dotnetContainerVersion}
                    tty: true
                    resources:
                      requests:
                        cpu: '2'
                        memory: '4Gi'
                      limits:
                        cpu: '2'
                        memory: '4Gi'
                    env:
                    - name: DOTNET_HOSTBUILDER__RELOADCONFIGONCHANGE
                      value: 'false'
                    - name: DOTNET_USE_POLLING_FILE_WATCHER
                      value: '1'
                  - name: python-git
                    image: ${pythonGitImage}
                    imagePullPolicy: Always
                    tty: true
                  - name: jnlp
                    image: ${jnlpImage}
                    imagePullPolicy: Always
                  nodeSelector:
                    kubernetes.io/os: ${operatingSystem}
                    kubernetes.io/arch: ${arch}
                """.stripIndent()
    }
    
    try {
        assert config.appName != null
        assert config.productName != null
        assert config.solutionFile != null
        assert config.packagesToRestore != null
        assert config.sourceDirectory != null
        assert config.slackChannel != null
    } catch(NullPointerException e) {
        error("One or more required parameters were missing: ${e}")
    }

    jobName = JOB_NAME.replace('/', '_').replace('%2F', '_')

    pipeline {
        options{
            buildDiscarder(logRotator(numToKeepStr: '30'))
            disableConcurrentBuilds()
            timeout(time: 20, unit: 'MINUTES')
            timestamps()
        }

        environment {
            // mandatory
            APP_NAME = "${config.appName}"
            PRODUCT_NAME = "${config.productName}"
            PRODUCT_NAME_LOWER = "${config.productName}".toLowerCase()
            COMPONENT_NAME = "${config.productName}"
            SOLUTION_FILE = "${config.solutionFile}"
            BUILD_PROPERTIES = "${buildProperties}"
            DESTINATION_BINARIES = "${WORKSPACE}\\Binaries"
            SOURCE_DIRECTORY = "${config.sourceDirectory}"
            SOURCE_BINARIES = "${sourceBinaries}"
            LZWEB_BIN = "${WORKSPACE}\\LZ25\\bin"
            SLACK_CHANNEL= "${config.slackChannel}"
            NODE_LABEL = "${nodeLabel}"
            // constant
            SLACK_TOKEN = credentials('slack-token')
            SERVICE_NAME = "${config.serviceName}"
        }

        agent {
            kubernetes {
              slaveConnectTimeout 300
              yaml podYaml
              workspaceVolume dynamicPVC(accessModes: 'ReadWriteOnce', requestsSize: '30Gi', storageClassName: storageClassName)
            }
        }

        stages {
            stage('Prepare') {
                steps {
                    sendSlackMessage(
                        buildStatus: 'STARTED',
                        slackChannel: env.SLACK_CHANNEL,
                        slackToken: env.SLACK_TOKEN
                    )
                    script {
                        def cdStrategy = determineCDStrategy(
                            productName: env.PRODUCT_NAME,
                            productType: "dotnet",
                            getBranchSitesFromLuigiweb: getBranchSitesFromLuigiweb,
                            customTargetEnvironment: customTargetEnvironment,
                        )
                        env.ARTIFACT_VERSION = cdStrategy.get(0)
                        env.CREATE_AND_UPLOAD_ARTIFACT = cdStrategy.get(1)
                        env.DEPLOY_ARTIFACT = cdStrategy.get(2)
                        env.TARGET_DOTNET_ENVIRONMENT = cdStrategy.get(3)
                        env.BUILD_ENVIRONMENTS = cdStrategy.get(4)
                    }
                }
            }

            stage("Build") {
                steps {
                    script {
                        // restore and install nuget packages
                        installNugetPackages(
                            buildProperties: "${env.BUILD_PROPERTIES}",
                            sourceDirectory: "${env.SOURCE_DIRECTORY}", packagesToRestore: packagesToRestore,
                            packagesToInstall: packagesToInstall,
                            skipNugetPackBuild: skipNugetPackBuild,
                        )

                        // if app is LZWeb build LZ.Web.Business
                        if (env.APP_NAME == "LZ25") {
                            dir(".\\LZ.Web.Business\\") {
                                powershell("msbuild /p:OutDir='${env.LZWEB_BIN}'")
                            }
                        }

                        // build environment specific artifact
                        def buildEnvironments = env.BUILD_ENVIRONMENTS.split(",")
                        buildEnvironments.each { buildEnvironment ->
                            targetArtifactDir = ".\\artifact\\${buildEnvironment}\\${env.APP_NAME}"
                            buildDotNetApp(
                                appName: "${env.APP_NAME}",
                                targetEnvironment: buildEnvironment,
                                solutionFile: "${env.SOLUTION_FILE}",
                                sourceBinaries: "${env.SOURCE_BINARIES}",
                                destinationBinaries: "${env.DESTINATION_BINARIES}\\${buildEnvironment}",
                                targetArtifactDir: targetArtifactDir,
                                additionalSourceDirectories: additionalSourceDirectories,
                            )

                            // move resulting msbuild artifact into "${targetArtifactDir}" for archival
                            if (env.APP_NAME == "LZ25") {
                                msbuildArtifact = ".\\LZ25_deploy\\obj\\${buildEnvironment}\\TempBuildDir"
                            } else if (env.APP_NAME == "BrainNET") {
                                msbuildArtifact = ".\\LZ.Brain.Web\\obj\\${buildEnvironment}\\Package\\PackageTmp"
                            } else if (env.APP_NAME == "AttorneyServicesManager") {
                                msbuildArtifact = ".\\LZ.AttorneyServicesManager.Web\\obj\\${buildEnvironment}\\Package\\PackageTmp"
                            } else if (env.APP_NAME == "RACorporateCenter") {
                                msbuildArtifact = ".\\LZ.WebSite.RA.Web_Deploy\\obj\\${buildEnvironment}\\TempBuildDir"
                            } else {
                                msbuildArtifact = ".\\${env.SOURCE_DIRECTORY}\\obj\\${buildEnvironment}\\Package\\PackageTmp"
                            }

                            try {
                                powershell("""
                                mkdir "${targetArtifactDir}" -Force
                                Move-Item -Path "${msbuildArtifact}\\*" -Destination "${targetArtifactDir}" -ErrorAction Stop
                            """)
                            } catch (e) {
                                error("Failed to move \"${msbuildArtifact}\" to \"${targetArtifactDir}\": ${e}")
                                return
                            }

                            // create artifact
                            artifactName = "${env.PRODUCT_NAME_LOWER}-${buildEnvironment}-${env.ARTIFACT_VERSION}.zip"
                            if (artifactShouldContainAppFolder == "yes") {
                                artifactSource = "${targetArtifactDir}"
                            } else {
                                artifactSource = "${targetArtifactDir}\\*"
                            }
                            createArtifact(
                                artifactName: artifactName,
                                artifactSource: artifactSource,
                            )
                        }
                    }
                }
            }

            stage("Archive") {
                when { expression { env.CREATE_AND_UPLOAD_ARTIFACT == "yes" } }
                steps {
                    uploadArtifact(
                        targetRepo: "${env.PRODUCT_NAME}/",
                        sourceArtifact: ".\\${env.PRODUCT_NAME_LOWER}-*.zip",
                        productName: "${env.PRODUCT_NAME}"
                    )
                }
            }

            stage('Rundeck: Start Deploy Job') {
                when {
                    expression { (env.DEPLOY_ARTIFACT == "yes") }
                }
                steps {
                    script {
                        if (env.TARGET_DOTNET_ENVIRONMENT == "poc") {
                            artifactName = "${env.PRODUCT_NAME_LOWER}-dev-${env.ARTIFACT_VERSION}.zip"
                        } else if (env.TARGET_DOTNET_ENVIRONMENT == "performance") {
                            artifactName = "${env.PRODUCT_NAME_LOWER}-prod-${env.ARTIFACT_VERSION}.zip"
                        } else {
                            artifactName = "${env.PRODUCT_NAME_LOWER}-${env.TARGET_DOTNET_ENVIRONMENT}-${env.ARTIFACT_VERSION}.zip"
                        }
                        if (internalApp == "yes") {
                            deployInternal(
                                environment: "${env.TARGET_DOTNET_ENVIRONMENT}",
                                artifactName: artifactName,
                                componentName: "${env.PRODUCT_NAME}",
                                internalAppDomain: internalAppDomain,
                            )
                        } else {
                            deployStatic(
                                environment: "${env.TARGET_DOTNET_ENVIRONMENT}",
                                artifactName: artifactName,
                                componentName: "${env.PRODUCT_NAME}",
                                serviceName: "${env.SERVICE_NAME}"
                            )
                        }
                    }
                }
            }
        }

        post {
            always {
                script {
                    buildStatus = currentBuild.result ?: 'SUCCESSFUL'
                    subject = "${buildStatus}: ${env.JOB_NAME} [BUILD #${env.BUILD_NUMBER}]"
                    summary = "${subject} (${env.BUILD_URL})"
                    if (currentBuild.result == 'FAILURE') {
                        emailext(
                            body: summary,
                            recipientProviders: [[$class: 'CulpritsRecipientProvider']],
                            subject: subject
                        )
                        statusMessage(status: "${env.PRODUCT_NAME} CICD Pipeline Failed", level: "failure")
                    } else if (currentBuild.result == 'SUCCESS' || currentBuild.result == null) {
                        statusMessage(status: "${env.PRODUCT_NAME} CICD Pipeline Complete", level: "success")
                    }
                }
            }
        }
    }
}
