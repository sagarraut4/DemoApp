#!/usr/bin/env groovy

/**
 * A generic pipeline function for building NPM Packages
 */

def call(Map map = [:]) {
    def sourceDirectory = map.sourceDirectory
    def gulpTasks = map.gulpTasks
    def colors = colorCodes()

    try {
        assert sourceDirectory != null
    } catch(NullPointerException e) {
        ansiColor('xterm') {
            error("${colors.red}One or more required parameters were null:${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }

    statusMessage(status: "Building NPM Package", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}SOURCE_DIRECTORY:${colors.none} ${sourceDirectory}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }
    
  if (gulpTasks != null && gulpTasks.size() > 0) {
        try {
            sh("cp gulpVars.jenkins.js gulpVars.js")
        } catch (e) {
            error("An exception occurred while running gulp tasks: ${e}")
            return
        }
  }
  else {
       echo "Skipping gulp tasks, none provided"
  }

    try {
        dir(sourceDirectory) {
            sh "npm install"
        }
    } catch(e) {
        ansiColor('xterm') {
            error("${colors.red}Failed to build NPM Package in ${sourceDirectory}:${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }

    try {
        dir(sourceDirectory) {
            sh "npm run package"       
            sh "pwd"
        }  
        dir ('./dist'){
            sh "pwd"
            sh "ls"
            sh "ls -lth"
        }
    } catch(e) {
        ansiColor('xterm') {
            error("${colors.red}Failed to build/run NPM Package in ${sourceDirectory}:${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }    
    
}
