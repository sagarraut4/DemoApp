#!/usr/bin/env groovy

/**
 * A generic pipeline for our test automations
 */

def call(body) {
    // evaluate the body block, and collect configuration into the object
    def config = [:]
    body.resolveStrategy = Closure.DELEGATE_FIRST
    body.delegate = config
    body()

    try {
        assert config.testType != null
        assert config.testEnvironments != null
        assert config.solutionFile != null
        assert config.buildFiles != null
        assert config.sourceBin != null
        assert config.nodeLabel != null
        assert config.unitTestingTool != null
    } catch(NullPointerException e) {
        error("One or more required parameters were missing: ${e}")
    }

    testType = config.testType
    testEnvironments = config.testEnvironments
    solutionFile = config.solutionFile
    buildFiles = config.buildFiles
    sourceBin = config.sourceBin
    nodeLabel = config.nodeLabel
    unitTestingTool = config.unitTestingTool
    artifactDirectory = config.artifactDirectory ?: ".\\artifact"
    artifactoryRepo = config.artifactoryRepo ?: "TestAutomation"
    mailRecipients = config.mailRecipients ?: "DL-TestAutomation-All@legalzoom.com,dl-devops@legalzoom.com"
    colors = colorCodes()

    pipeline {
        options{
            buildDiscarder(logRotator(numToKeepStr: '30'))
            disableConcurrentBuilds()
            timeout(time: 30, unit: 'MINUTES')
            timestamps()
        }

        environment {
            TEST_TYPE = "${config.testType}"
            SOLUTION_FILE = "${solutionFile}"
            ARTIFACT_DIRECTORY = "${artifactDirectory}"
            ARTIFACTORY_REPO = "${artifactoryRepo}"
            NODE_LABEL = "${nodeLabel}"
        }

        agent {
            node {
                label "${nodeLabel}"
                customWorkspace "D:\\Jenkins\\8e52cda1\\workspace\\${JOB_NAME}\\"
            }
        }

        stages {

            stage("Build") {
                steps {
                    script {
                        try {
                            testEnvironments.each { environment ->
                                echo "clean"
                                msbuild(
                                    buildFile: "${solutionFile}",
                                    environment: "${environment}",
                                    args: "/t:Clean /t:restore /p:Configuration=${environment}"
                                )
                                echo "restore"
                                bat("nuget.exe restore \"${solutionFile}\"")

                                echo "build"
                                buildFiles.each { buildFile ->
                                    msbuild(
                                        buildFile: "${buildFile}",
                                        environment: "${environment}",
                                    )
                                }
                            }
                        } catch (e) {
                            error("Exception occurred while building: ${e}")
                        }
                    }
                }
            }

            stage("Create Artifacts") {
                steps {
                    script {
                        try {
                            testEnvironments.each { environment ->
                                def destinationDirectory = "${env.ARTIFACT_DIRECTORY}\\${environment}"

                                echo "Preparing '${environment}' Artifact"
                                powershell("""
                                    New-item -type directory -path ${destinationDirectory}
                                    Copy-Item -Path .\\EditOutput.ps1 -Destination ${destinationDirectory} -force -Recurse
                                    Copy-Item -Path .\\${sourceBin}\\${environment}\\* -Destination ${destinationDirectory} -force -Recurse
                                    Copy-Item -Path .\\packages\\${unitTestingTool} -Destination ${destinationDirectory} -force -Recurse
                                    Copy-Item -Path .\\packages\\ReportUnit.1.2.3 -Destination ${destinationDirectory} -force -Recurse
                                """)

                                environmentLower = environment.toLowerCase()
                                createArtifact(
                                    artifactSource: "artifact\\${environment}\\*",
                                    artifactName: "test-automation-${env.TEST_TYPE}-${environmentLower}-snapshot.zip"
                                )
                            }
                        } catch(e) {
                            error("Exception occurred while creating artifacts: ${e}")
                        }
                    }
                }
            }

            stage('Upload Artifacts') {
                steps {
                    script {
                        try {
                            environment_specific_artifacts_to_upload = []
                            if (env.BRANCH_NAME == "develop") {
                                environment_specific_artifacts_to_upload = ["dev"]
                            } else if (env.BRANCH_NAME == "QA") {
                                environment_specific_artifacts_to_upload = ["qa"]
                            } else if (env.BRANCH_NAME == "master") {
                                environment_specific_artifacts_to_upload = ["stg", "prod"]
                            }
                            if (environment_specific_artifacts_to_upload.size() > 0) {
                                environment_specific_artifacts_to_upload.each { environment ->
                                    uploadArtifact(
                                        targetRepo: "${env.ARTIFACTORY_REPO}",
                                        sourceArtifact: "test-automation-${env.TEST_TYPE}-${environment}*.zip",
                                        productName: "TestAutomation"
                                    )
                                }
                            }
                        } catch(e) {
                            error("Exception occurred while uploading artifacts: ${e}")
                        }
                    }
                }
            }
        }
        post {
            failure {
                emailext(
                    body: "Build Log: ${env.BUILD_URL}console",
                    recipientProviders: [[$class: 'CulpritsRecipientProvider']],
                    subject: "[JENKINS]: ${env.JOB_NAME} (#${env.BUILD_NUMBER}) has failed!",
                    to: "${mailRecipients}",
                    replyTo: "${mailRecipients}",
                )
                statusMessage(status: "Test Automation CICD Pipeline Failed", level: "failure")
            }
            success {
                statusMessage(status: "Test Automation CICD Pipeline Complete", level: "success")
            }
        }
    }
}
