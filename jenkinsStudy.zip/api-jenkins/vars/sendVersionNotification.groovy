#!/usr/bin/env groovy

/**
 * Create message allowing those subscribed to channel to see version updates per env
 */
def call(Map map = [:]) {
	version = map.appVersion ?: env.PRODUCT_VERSION
	serviceEnv = map.serviceEnv ?: env.API_SERVICE_ENV
	slackToken = map.slackToken ?: env.SLACK_TOKEN
	slackChannel = map.slackChannel ?: env.SLACK_CHANNEL

	def colorCode = '#00FF00' // Green
	def message = "Deployed Version *${version}* to *${serviceEnv}*"

	echo "Sending slack message"
	// Send notification
	slackSend (channel: slackChannel, color: colorCode, message: message, teamDomain: "legalzoom", token: slackToken )
	echo "Slack message sent"
}
