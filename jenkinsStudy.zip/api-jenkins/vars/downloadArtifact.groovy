#!/usr/bin/env groovy

/**
 * A generic pipeline function for downloading from Artifactory
 */

def call(Map map = [:]) {
    // mandatory
    sourceRepo = map.sourceRepo
    sourceArtifact = map.sourceArtifact
    // optional
    targetPath = map.targetPath ?: './' + sourceArtifact
    artifactoryServerId = map.artifactoryServerId ?: 'artifactory'
    // calculated
    artifactName = sourceRepo + "/" + sourceArtifact

    try {
        assert sourceRepo != null
        assert sourceArtifact != null
        assert targetPath != null
    } catch(e) {
        error("One or more required parameters were null: ${e}")
    }

    downloadSpec = """
        {
            "files": [{
                "pattern": "${artifactName}",
                "target": "${targetPath}"
            }]
        }
    """

    echo "Downloading ${sourceArtifact} from Artifactory's '${sourceRepo}' repository"
    try {
        def artifactory = Artifactory.server(artifactoryServerId)
        artifactory.download(downloadSpec)
    } catch(e) {
        error("Exception occurred while downloading ${sourceArtifact} from ${sourceRepo}: ${e}")
        return
    }
    echo "Downloaded ${sourceArtifact}"
}
