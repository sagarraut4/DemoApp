#!/usr/bin/env groovy

/**
 * A generic pipeline function for running lighthouse against changed files
 */

def call(Map map = [:]) {
    // mandatory
    def artifact = map.artifact
    def testUrls = map.pathUrls ?: null
    def webFolder = map.webFolder ?: '/legalzoom/website'
    def lighthouseFolder = map.lighthouseFolder ?: '/legalzoom/lighthouse'
    def checkoutBranch = map.siteBranch ?: env.BRANCH_NAME.replace('/', '_')
    def lighthouseBranch = map.lighthouseBranchName ?: 'develop'
    def colors = colorCodes()

    if (checkoutBranch.startsWith("release")) {
        checkoutBranch = "release"
    } else if (checkoutBranch.startsWith("hotfix")) {
        checkoutBranch = "hotfix"
    } else if (checkoutBranch.startsWith("dev_v")) {
        checkoutBranch = "develop"
    }

    try {
        assert artifact != null
        assert lighthouseBranch != null
    } catch(NullPointerException e) {
        error("One or more required parameters were missing: ${e}")
    }

    map.each{println it.key +" "+it.value}

    statusMessage(status: "Executing lighthouse steps", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}ARTIFACT_LOCATION:${colors.none} ${artifact}
${colors.magenta}WEB_FOLDER:${colors.none} ${webFolder}
${colors.magenta}BRANCH:${colors.none} ${checkoutBranch}
${colors.magenta}LIGHTHOUSE_FOLDER:${colors.none} ${lighthouseFolder}
${colors.magenta}LIGHTHOUSE_BRANCH:${colors.none} ${lighthouseBranch}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }
    dir(webFolder) {
        sh "ls -lth"
        ansiColor('xterm') {
            echo "${colors.bold}(Step 1 of 2) Fetch latest resource files and Unzip artifact${colors.none}"
        }
        try {
            sh("git clean -fd && git reset --hard HEAD")
            sh("git fetch origin")
            //check if equivalent branch exists in resource repo
            branchExists = sh(script: "git ls-remote --heads origin ${checkoutBranch}", returnStdout: true)
            //otherwise default to develop
            resourceBranch = branchExists?.trim() ? checkoutBranch : 'develop'
            echo "Pulling from ${resourceBranch}"
            sh("git checkout ${resourceBranch}")
            sh("git pull origin ${resourceBranch}")
            sh("unzip ${artifact} -d ${webFolder}")
        } catch (e) {
            error("Failed to checkout repo and unzip artifact: ${e}")
            return
        }
    }    
    dir(lighthouseFolder) {
        ansiColor('xterm') {
            echo "${colors.bold}(Step 2 of 2) Run lighthouse against html files${colors.none}"
        }     
        try {
            sh("git clean -fd && git reset --hard HEAD")
            sh("git fetch origin")
            sh("git checkout ${lighthouseBranch}")
            sh("git pull origin ${lighthouseBranch}")
            sh("rm -rf node_modules/")
            sh("npm install")
            sh("sudo npm install -g jest")
            sh("echo '127.0.0.1 local.legalzoom.com' | sudo tee -a /etc/hosts")
            sh("sudo /usr/sbin/nginx")
            if (testUrls != null && testUrls.size() > 0) {
                sh("jest lightHouseperf.test.js --config jest.config.jenkins.js --color --url=${testUrls.join(',')}")
            } else {
                sh("jest lightHouseperf.test.js --config jest.config.jenkins.js --color")
            }
        }  catch (e) {
            sh("sudo /usr/sbin/nginx -s stop")
            error("Failed to fetch lighthouse repo and run lighthouse: ${e}")
            return
        }
    }
    echo "Build Complete"
}
