#!/usr/bin/env groovy

/******************************************************************
* A generic function to build dependencies for a node application 
* Four (4) Parameters are required:
* gulpVars    = load gulpVars.template.js. Must exist in the repo being testing
* gulpScript  = select gulp build dependency script. Must exist in the repo being testing
* buildNumber = Used to provide a unique build number associated with the artifact
*               passed in
* productName = this is the name of the product that the
                tar is being generatedf or   
**********************************************************/
//main function being called, expects four parameters from calling function
//there are default options for some 

// map passed in function contains vars passed from calling function
def call(Map map = [:]){ 
    //map is key value pairs
    //Parameters are passed from calling function. The Jenkinsfile within respective repo
    //should provide appropriate parameters
    // map.gulpVars
    // map.gulpScript
    // map.buildNumber
    // map.productName
    
    //set local values
    gulpVars     = map.gulpVars
    gulpScript   = map.gulpScript
    buildNumber  = map.buildNumber ?: env.BUILD_NUMBER
    productName  = map.productName
    buildDir     = map.buildDir
    artifactFile = map.artifactFile
    npmRegistryName = map.npmRegistryName ?: env.NPM_REGISTRY_NAME
    npmRegistryUrl = map.npmRegistryUrl ?: env.NPM_REGISTRY_URL

    //check if parameters were passed in
    try {
        assert gulpVars     != null
        assert gulpScript   != null
        assert buildNumber  != null
        assert productName  != null
        assert buildDir     != null
        assert artifactFile != null
        assert npmRegistryName != null
        assert npmRegistryUrl != null
    } catch(e) {
        error("One or more required parameters were null: ${e}. See buildHTML.groovy")
    }
     
    //defines the zip file name used below  
       
    //Output for debugging purposes
    echo "Gulp Vars file    : ${gulpVars}"
    echo "Gulp Script to use: ${gulpScript}"
    echo "Build Number      : ${buildNumber}"
    echo "Product Name      : ${productName}"           

    echo "Destination Path  : ${buildDir}"
    echo "Artifact File: ${artifactFile}"

    echo "printing out env variables"
    sh 'printenv'

    //Try block for the bash commands executed for HTML build, exception will be thrown if errors occur in shell block
    try{
        //BASH portion to build dependencies for application
        echo "REACHED SHELL TRY STATEMENT"  
                             
        //shell block to tar up directory 
        ansiColor('xterm') {
            sh """
                if [ -d ${buildDir} ]; then rm -fr ${buildDir}; fi
                mkdir ${buildDir}
                ls -lt

                node -v
                npm config set registry ${npmRegistryUrl}
                npm install
                cp ${gulpVars} gulpVars.js
                ./${gulpScript} 2>&1 > ./${gulpScript}-output.txt

                pwd
                ls -lt

                echo "Creating artifactFile  ${artifactFile}"
                echo "ZIP       ****************************************"
                cd ${buildDir}
                zip -r ../${artifactFile} . -x *.git* *README*
                echo "AFTER ZIP ****************************************"
                pwd
            """
         }
         archiveArtifacts allowEmptyArchive: true, artifacts: "${gulpScript}-output.txt", onlyIfSuccessful: true
         //end shell block
    } catch(e){
        error("There was an error while running the bash portion for the HTML static build. See buildHTML.groovy in api-jenkins repo: ${e}")
    }
}
