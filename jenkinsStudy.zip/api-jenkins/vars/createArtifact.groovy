#!/usr/bin/env groovy

/**
 * A generic pipeline function for creating artifacts
 */

def call(Map map = [:]) {
    def artifactName = map.artifactName
    def artifactSource = map.artifactSource
    def addPeerDependencies = map.addPeerDependencies
    def windowsCompatible = map.windowsCompatible ?: "false"
    def productName = map.productName ?: ""
    def colors = colorCodes()

    try {
        assert artifactName != null
        assert artifactSource != null
    } catch(NullPointerException e) {
        ansiColor('xterm') {
            error("${colors.red}One or more required parameters were null:${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }

    statusMessage(status: "Creating Artifact", level: "info")

    ansiColor('xterm') {
        echo """${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
${colors.magenta}ARTIFACT_NAME:${colors.none} ${artifactName}
${colors.magenta}ARTIFACT_SOURCE:${colors.none} ${artifactSource}
${colors.bold}${colors.blue}~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~${colors.none}
"""
    }

    try {
        if (isUnix()) {
            if ( addPeerDependencies == "yes"){
                sh "cd ${artifactSource} && npm pack"
                sh "mv *.tgz ${artifactName}"
            } else if (windowsCompatible == "true") {
                sh "cd ${artifactSource}/.. && zip -r ${artifactName} ${productName}"
            } else{
                sh "cd ${artifactSource} && zip -r ${artifactName} . -x *.git* *README*"
            }     
        } else {
            powershell "Compress-Archive -Path ${artifactSource} -DestinationPath ${artifactName} -Force"
        }
    } catch(e) {
        ansiColor('xterm') {
            error("${colors.red}Failed to Zip Artifact From ${artifactSource} to ${artifactName}:${colors.none} ${colors.bold}${e}${colors.none}")
        }
    }

}