#!/usr/bin/env groovy

/**
 * A generic pipeline function for deploying tarball to IIS server
 */

def call(Map map = [:]) {
    // mandatory inputs
    tarPath = map.tarPath
    deployPath = map.deployPath
   
    try {
        assert tarPath != null
        assert deployPath != null
    } catch(e) {
        error("One or more required parameters were null: ${e}")
    }
  
    echo "Deploying ${tarPath} to ${deployPath}"

    try {
        msg = powershell(returnStdout: true, script: """
            7z x -y ${tarPath}

            # tarfile is defined to be the tar extracted from the command above
            # expected to be a single file
            \$tarFile = 7z l ${tarPath} | Select-Object -Last 3 | Select-Object -First 1 | %{ [regex]::split(\$_, '\\s+')[-1]; }
            Write-Output "The tarfile is \$tarFile"

            # Untar the tarFile to the desired path
            7z x -y -bb3 -o"${deployPath}" \$tarFile
        """)
        println msg 
    } catch(e) {
        error("Failed to deploy ${tarPath} to ${deployPath}: ${e}")
        return
    }

    echo "Tarball deployment complete"

}
