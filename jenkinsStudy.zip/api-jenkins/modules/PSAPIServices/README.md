# PSAPIServices

### Purpose: Powershell module designed to expose commandlets for interacting with LZ APIs, LoadBalancers, and artifact locations. These commandlets are used by jenkins jobs.

### Setup: How to use the commandlets provided by the module

1. Clone the repository with the module
```

C:\GitSource>git clone https://github.legalzoom.com/engineering/api-jenkins.git

```


2. Import the module into runspace
```

Import-Module C:\GitSource\api-jenkins\modules\PSAPIServices -Force -Verbose

```

You can now setup parameters and invoke the commandlets provided by the module