Function Get-APIServiceEXEPath ($ServiceName,$ServiceHostName,$ServicesDirectory)
{
    $exeLocation = $ServicesDirectory + $ServiceName + '\'  + $ServiceName + '\' +  $ServiceHostName
    return $exeLocation
}