Function Get-FormattedDate {
    return Get-Date -Format "yyyyMMdd HH:mm:ss"
}