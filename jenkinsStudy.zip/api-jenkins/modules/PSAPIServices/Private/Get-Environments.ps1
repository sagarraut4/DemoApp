function Get-Environments ([switch] $predev){

  #param([switch] $predev)

  write-output "Get-Environments: predev: $predev"

  $base_path="D:\Services2"
  $environments=$(Get-ChildItem $base_path -Name)
  #https://stackoverflow.com/a/2363131
  $global:environment=""

  if ($environments.Count -eq 1){
    $global:environment = $environments
    write-host "environment: $global:environment"
  }
  #dev server scenario - predev and dev subdirs in Services2
  elseif ($environments.Count -gt 1){
    if ($predev){
      $global:environment= if ($environments -contains "predev" ) { "predev" } 
    }
    else{
      $global:environment = if ($environments -contains "dev" ) { "dev" }
    }  
    <# This was to allow input
    write-host "There are multiple environments; They are:"
    foreach ($env in $environments){
      write-host $env
    }

    write-host "environment: $environment"
    #https://www.codykonior.com/2013/01/10/powershell-how-to-search-a-list-of-objects-with-an-array-of-wildcards/
    while (!($environment | Where-Object {$_ -in $environments})){
      $environment=(Read-Host -Prompt "Please enter an environment")
      write-host "environment: $environment"
    }
    #>
    write-host "environment: $global:environment"
  }
  else {
    write-host "No environments. Exiting"
    exit 1
  }
}
