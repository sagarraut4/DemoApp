function Get-Port ([string]$api){
  $global:port=""

  #. $PSScriptRoot\api-name-port.ps1


  write-output "Get-Port environment: $environment"
  #port number will be changed if the environment is predev or branch is feature
  #if ( (${env} -ne "predev") -or (${branch} -ne "feature")){
  if ($environment -ne "predev") {
    $global:port=$($apis.Get_Item("${api}"))
  }
  else{
    $global:port=($($apis.Get_Item("${api}"))).substring(0,3) + "50"
  }

  echo "Get-port port: $global:port"

}
