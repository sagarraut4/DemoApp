Function Get-APIServiceRoot ($ServiceName,$ServiceHostName,$ServicesDirectory)
{
    $packageLocation = $servicesDirectory + $ServiceName + '\'  + $ServiceName + '\'
    return $packageLocation
}