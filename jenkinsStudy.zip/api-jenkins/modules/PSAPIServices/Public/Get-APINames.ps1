function Get-APINames {
  foreach ($api in $apis.Keys | sort){
    write-output $api
  }
}
