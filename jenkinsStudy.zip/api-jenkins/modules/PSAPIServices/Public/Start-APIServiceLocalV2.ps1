Function Start-APIServiceLocalV2 {
    [cmdletbinding()]
    param(
        [Parameter(Mandatory=$True)][string]$ServiceName,
        [switch] $predev
    )

    $ErrorActionPreference = "Stop"
    $ServiceHostName=$ServiceName

    write-output "predev: $predev"

    #https://stackoverflow.com/a/38009162
    Get-Environments -predev:$predev
    echo "start-api environment $environment"
    Get-Port $ServiceName

    write-output "testing: api: ${ServiceName} port: ${port} environment: $environment"
    $ServicesDirectory="D:\Services2\$environment\"

    $exeLocation = $(Get-APIServiceExePath -ServiceName $ServiceName -ServiceHostName $ServiceHostName -ServicesDirectory $ServicesDirectory)
    $publishLocation = $(Get-APIServiceRoot  -ServiceName $ServiceName -ServiceHostName $serviceHostName -ServicesDirectory $servicesDirectory)

    $proc = Get-WmiObject -query "SELECT * FROM Meta_Class WHERE __Class = 'Win32_Process'"

    #From https://social.technet.microsoft.com/wiki/contents/articles/7703.powershell-running-executables.aspx
    #hidden window
    $startup=[wmiclass]"Win32_ProcessStartup"
    $startup.Properties['ShowWindow'].value=$False

    $command = "$exeLocation --server.urls http://*:$port --environment $environment"
    Write-Host "command : ${command}"
    Write-Host "publishLocation : ${publishLocation}"
    $newlyCreatedProcess=$proc.Create(${command},${publishLocation},$startup)

    write-output "$(Get-FormattedDate) - Started $ServiceHostName on $ComputerName with PID : " $newlyCreatedProcess.processid

    if ($newlyCreatedProcess.returnvalue -ne "0"){
        Write-Host "Did not successfully start service : " $proc.commandline
        throw('Create method exited with an returnvalue not equal to 0. returnvalue : ' + $newlyCreatedProcess.returnvalue)
    }
}
