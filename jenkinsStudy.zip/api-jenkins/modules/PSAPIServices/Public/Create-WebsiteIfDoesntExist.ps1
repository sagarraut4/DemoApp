Function Create-WebsiteIfDoesntExist {
    [cmdletbinding()]
    param(
        [Parameter(Mandatory = $True)][string]$ServiceName,
        [Parameter(Mandatory = $True)][int]$Port,
        [Parameter(Mandatory = $True)][string]$ServicesDirectory,
        [Parameter(Mandatory = $True)][string]$ComputerName,
        [ValidateSet("predev", "dev", "qa", "stg", "prod")]
        [Parameter(Mandatory = $True)][string]$Environment,
        [System.Management.Automation.PSCredential]
        $Credential = [System.Management.Automation.PSCredential]::Empty 
    )
    $ErrorActionPreference = "Stop"
    Write-Host "Start Create-WebsiteIfDoesntExist"

    $null = Invoke-Command -ComputerName $ComputerName -Credential $Credential -ScriptBlock {
        param($ServiceName, $Port, $ServicesDirectory, $Environment)
        
        $ErrorActionPreference = "Stop"
        Import-Module WebAdministration
        
        # Using composite key here to ensure that service name is distict per api per env
        $serviceIdentifier = "${ServiceName}" + "-" + "${Environment}"
        $serviceIdentifier
        Write-Host "serviceIdentifier: $serviceIdentifier"

        # If Website doesnt exist, create it
        if ($(Get-Website | Where-Object { $_.Name -eq $serviceIdentifier }) -eq $null) {
            Write-Host "$serviceIdentifier does not exist. Therefore, creating app pool and site using standardized convention..."
            $servicePhysicalPath = "$servicesDirectory" + "$ServiceName" + "\" + "$ServiceName"

            #create dir if doesnt exist
            if (!(Test-Path -path $servicePhysicalPath)) {
                Write-Host "Folder doesnt exist. Creating necessary folder $servicePhysicalPath to hold service publish output"
                mkdir $servicePhysicalPath -Force
            }

            # create site
            New-Website -Name $serviceIdentifier -Port $Port -IPAddress "*" -HostHeader "" -PhysicalPath "$servicePhysicalPath"

            # create app pool
            New-Item -Path "IIS:\AppPools" -Name $serviceIdentifier -Type AppPool
            
            # ASP.NET Core doesn't rely on loading the desktop CLR, and since this we have option to set, we take accept option here
            # empty string for -value ==> "No Managed Code". 
            Set-ItemProperty -Path "IIS:\AppPools\$serviceIdentifier" -name "managedRuntimeVersion" -value ""
            
            # Start the application pool automatically when a request is made
            Set-ItemProperty -Path "IIS:\AppPools\$serviceIdentifier" -name "autoStart" -value $true
            
            # Set the account the application pool will run as
            # TODO use account passed as credential
            # set iis app pool identity to whatever
            # identitytype -
            # 0 - localsystem
            # 1 - localservice
            # 2 - networkservice
            # 3 - specificuser
            # 4 - applicationpoolidentity
            $un = ${env:API_User}
            $pw = ${env:API_Passwd}
            # Set-ItemProperty -Path "IIS:\AppPools\$serviceIdentifier" -name "processModel" -value @{identitytype = "ApplicationPoolIdentity"}
            Set-ItemProperty -Path "IIS:\AppPools\$serviceIdentifier" -name processModel -value @{userName = "$un"; password = "$pw"; identitytype = 3} 

            # Ensure we load user profile to allow environment variables to be avail to asp.net core
            Set-ItemProperty -Path "IIS:\AppPools\$serviceIdentifier" -name "processModel.loadUserProfile" -Value "True"

            # Assign the app pool to the newly created website
            Set-ItemProperty -Path "IIS:\Sites\$serviceIdentifier" -name "applicationPool" -value $serviceIdentifier
            
            # Must wait to ensure that when this commandlet is called in a foreach repeatedly, it doesnt throw at Set-ItemProperty
            Write-Host "Sleeping for 5 seconds..."
            Start-Sleep 5

            Write-Host "Starting Website $serviceIdentifier"
            Start-Website -Name $serviceIdentifier
            Write-Host "Started Website"
        }

    } -ArgumentList $ServiceName, $Port, $ServicesDirectory, $Environment
    Write-Host "End Create-WebsiteIfDoesntExist"
}