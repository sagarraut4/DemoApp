Function Restart-APIServiceAllLocal {
  [cmdletbinding()]

  param(
    [switch] $predev
  )

  $ErrorActionPreference = "Continue"

  foreach ($api in (Get-APINames)){
    Restart-APIServiceLocal $api -predev:$predev
  }

}
