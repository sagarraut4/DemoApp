Function Archive-APIServiceLogs {
    [cmdletbinding()]

    param(
        [string]$GlobalAPILogTarget = 'D:\logs',
        [string]$LogZipArchiveTarget = 'D:\logs'
    )
    $ErrorActionPreference = "Stop"
    
    $servicesWithLogs = New-Object 'System.Collections.Generic.List[String]'
    Get-ChildItem $GlobalAPILogTarget -Filter *.json | 
        Foreach-Object {
        $string = $_.Name
        $logNameSplit = $string.split('_')
        if ($servicesWithLogs -notcontains $logNameSplit[0].ToString()) {
            $servicesWithLogs.Add($logNameSplit[0].ToString())
        }
    }

    # For each of those services, zip all files associated with that service and place into folder named ServiceName contained within existing log target
    # TODO swallow exception on a per service basis, to inform invoker of this function of what was partial, what was complete
    $atLeastOneServiceFailedToHaveAllLogsArchived = $false  

    Foreach ($serviceName in $servicesWithLogs) {
        try {
            Write-Host "Archiving old logs for $serviceName"
            Archive-PreviousMonthsLogs -ServiceName $serviceName -GlobalAPILogTarget $GlobalAPILogTarget -LogZipArchiveTarget $LogZipArchiveTarget
        }
        catch {
            $atLeastOneServiceFailedToHaveAllLogsArchived = $true
        }
    } 

    # Since we swallowed the exception
    if ($atLeastOneServiceFailedToHaveAllLogsArchived) {
        throw 'One or more services failed to have ALL of its logs archived.'
    }
}
