Function Get-APIServiceProcess {
    [cmdletbinding()]
    param(
        [Parameter(Mandatory=$True)][string]$ServiceHostName,
        [Parameter(Mandatory=$True)][string]$ComputerName,
        [ValidateSet("predev","dev","qa")]
        [Parameter(Mandatory=$True)][string]$Environment
    )
    $ErrorActionPreference = "Stop"
    $processWithServiceName = Get-WmiObject Win32_Process -Filter "name = '${ServiceHostName}.exe'" -ComputerName $ComputerName -ErrorAction silentlycontinue
    $environmentAwareCommand = "*\$Environment*\$ServiceHostName*"

    Write-Host ("Searching for process with command line args {0} " -f $environmentAwareCommand)
    foreach ($process in $processWithServiceName) {
        Write-Host ("Found {0}" -f $process.commandline)
        if ($process.commandline -like $environmentAwareCommand){
            Write-Host ("Identified process")
            $process.processid
        }
    }
}