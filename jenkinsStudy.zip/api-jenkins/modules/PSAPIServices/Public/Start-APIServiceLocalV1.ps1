Function Start-APIServiceLocalV1 {
  [cmdletbinding()]
  param(
    [Parameter(Mandatory=$True)][string]$Api,
    [switch] $predev
  )

  $ErrorActionPreference = "Stop"
  $ComputerName=$env:COMPUTERNAME

  write-output "predev: $predev"

  #https://stackoverflow.com/a/38009162
  Get-Environments -predev:$predev
  echo "start-api environment $environment"
  Get-Port $Api

  write-output "testing: api: ${Api} port: ${port} environment: $environment"

  if ($api_branch -like "feature*"){
    $api_command="*\$api\$api_branch\$api.exe*"
    $api_dir_root_lfs="D:\Features"
    $api_dir_root_unc="d$\Features"
  }
  else {
    $api_command="*\$api\$api.exe*"
    $api_dir_root_lfs="D:\Services"
    $api_dir_root_unc="d$\Services"
  }

  echo "api_dir_root_lfs: $api_dir_root_lfs"
  echo "api_dir_root_unc: $api_dir_root_unc"

  $api_base=$api -replace "Service", ""
  echo "api_base: $api_base"

  $api_dir_test= (Get-ChildItem -Path "$api_dir_root_lfs" -Name | select-string -Pattern "_" -NotMatch | Select-String -Pattern $api_base)
  echo "api_dir_test: $api_dir_test"

  $api_dir_root_lfs=$api_dir_root_lfs+"\$api_base"
  $api_dir_root_unc=$api_dir_root_unc+"\$api_base"

  if ( $api_branch -notlike "feature*"){
    $api_sym_link="$api_dir_root_lfs\$api"
    $api_sym_link_unc="$api_dir_root_unc\$api"
    $api_dir_lfs="$api_dir_root_lfs\$api_dir_name"
    $api_dir_unc="$api_dir_root_unc\$api_dir_name"
    $api_start="$api_sym_link\$api.exe"
    $api_start_dir=$api_sym_link
  }
  else {
    $api_sym_link="$api_dir_root_lfs\$api\$api_branch"
    $api_sym_link_unc="$api_dir_root_unc\$api\$api_branch"
    $api_dir_lfs="$api_dir_root_lfs\$api\$api_dir_name"
    $api_dir_unc="$api_dir_root_unc\$api\$api_dir_name"
    $api_start="$api_sym_link\$api.exe"
    $api_start_dir=$api_sym_link
  }

  $wmi_name="${Api}.exe"

  echo "$(Get-Date -Format "yyyyMMdd HH:mm:ss") - Starting $api API"
  $proc = Get-WmiObject -query "SELECT * FROM Meta_Class WHERE __Class = 'Win32_Process'"

  $command="$api_start"
  $currentdirectory="$api_start_dir"

  echo $command
  echo $currentdirectory
    
  #From https://social.technet.microsoft.com/wiki/contents/articles/7703.powershell-running-executables.aspx
  #hidden window
  $startup=[wmiclass]"Win32_ProcessStartup"
  $startup.Properties['ShowWindow'].value=$False

  $api_proc=$proc.Create($command,$currentdirectory,$startup)
  $api_pid=$api_proc.processid

  if ($api_proc.returnvalue -eq "0"){
    echo "$(Get-Date -Format "yyyyMMdd HH:mm:ss") - $api API is running with PID $api_pid. Waiting five seconds to check to see if it is still running."
    start-sleep -s 5

    $api_proc_verify = (Get-WmiObject Win32_Process -Filter "name = '$wmi_name'")
    foreach ($i in $api_proc_verify){
      if ($i.commandline -like $api_command){
        $api_pid_verify=$i.processid
        break
      }
    }

    if ($api_pid -eq $api_pid_verify){
      echo "$(Get-Date -Format "yyyyMMdd HH:mm:ss") - $api API is running on $destination_server with PID $api_pid"
    }
    else{
      echo "$(Get-Date -Format "yyyyMMdd HH:mm:ss") - $api API is not running. Please check for port conflict in hosting.json"
    }
  }
  else{
    echo "$(Get-Date -Format "yyyyMMdd HH:mm:ss") - $api API is not running. $api.exe is probably missing."
  }
}
