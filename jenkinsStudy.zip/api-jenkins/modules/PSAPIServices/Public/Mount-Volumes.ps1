Function Mount-Volumes {
    [cmdletbinding()]
    param(
        [Parameter(Mandatory=$True)][string]$ServiceName,
        [Parameter(Mandatory=$True)][string]$ComputerName,
        [ValidateSet("predev","dev","qa","stg","prod")]
        [Parameter(Mandatory=$True)][string]$Environment,
        [Parameter(Mandatory=$True)][string]$un,
        [Parameter(Mandatory=$True)][string]$pw
    )
    $ErrorActionPreference = "Stop"

    if (($ServiceName -ne "StorageService") -And ($ServiceName -ne "DocumentDeliveryService") -And ($ServiceName -ne "DocumentGenerationUtilityService")){
        Write-Host "The remote mount access workaround for API $ServiceName running as user $un on $ComputerName (${Environment}) is not needed."
    }
    else{
        Write-Host "Implementing remote mount access workaround for API $ServiceName running as user $un on $ComputerName (${Environment})"
        #$proc = Get-WmiObject Win32_Process -Filter "name = '${ServiceName}.exe'" -ComputerName $ComputerName -ErrorAction silentlycontinue -Credential $Credential
        $credentials = New-Object System.Management.Automation.PSCredential -ArgumentList @($un,(ConvertTo-SecureString -String $pw -AsPlainText -Force))
        $proc = Get-WmiObject -query "SELECT * FROM Meta_Class WHERE __Class = 'Win32_Process'" -computername $ComputerName -credential $credentials

        switch (${ServiceName}){
            "Storageservice" {
                #if ($Environment -ne "prod"){
                    Write-Output "mounting \\laiw12ws498d.legalzoom.com\CMS\P8Services\boxpublish"
                    $command="net use \\laiw12ws498d.legalzoom.com\CMS\P8Services\boxpublish /user:$un $pw /persistent:yes"
                    $ServiceName_proc=$proc.Create($command,$currentdirectory)
                #}
                #else {
                    Write-Output "mounting \\laiw2k8fs037p.legalzoom.com\CMS\P8Services\boxpublish"
                    $command="net use \\laiw2k8fs037p.legalzoom.com\CMS\P8Services\boxpublish /user:$un $pw /persistent:yes"
                    $ServiceName_proc=$proc.Create($command,$currentdirectory)
                #} #end of if ($Environment -ne "prod")
            } #end of StorageService
            #For DocumentDeliveryService and DocumentGenerationUtilityService
            default {
                #setting servername based on Environment
                if ($Environment -ne "prod"){
                    $scapplog_server="SCAppLog-dqs"
                }
                else{
                    $scapplog_server="SCAppLog-p"
                }

                $mounts = ("input", "ProductXSDSchema", "output\DISK")

                foreach ($mount in $mounts){
                    #Checking if environment is not predev for correct path creation
                    if ($Environment -ne "predev"){
                        $path = "\\${scapplog_server}\${environment}\${mount}"
                    }
                    else{
                        $path = "\\${scapplog_server}\dev\${mount}"
                    }

                    Write-Output "Mounting $path"
                    $command="net use $path /user:$un $pw /persistent:yes"
                    $ServiceName_proc_rm=$proc.Create($command,$currentdirectory)
                } #end of foreach ($mount in $mounts)
            } #end of default
        } #end of switch (${ServiceName})
    } # end of if (($ServiceName -ne "StorageService") -And ($ServiceName -ne "DocumentDeliveryService") -And ($ServiceName -ne "DocumentGenerationUtilityService")) else
} # end of Function Mount-Volumes
