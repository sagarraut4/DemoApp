Function Archive-PreviousMonthsLogs {
    [cmdletbinding()]
    param(
        [Parameter(Mandatory = $True)][string]$ServiceName,
        [Parameter(Mandatory = $True)][string]$GlobalAPILogTarget,
        [Parameter(Mandatory = $True)][string]$LogZipArchiveTarget
    )

    #Requires -Version 5.0
    $ErrorActionPreference = "Stop"
    Write-Host "Start Archive-PreviousPeriodLogs"

    # Capture current month information so that we have something to ignore
    $currentMonthsYear = Get-Date -UFormat "%Y"
    $currentMonth = Get-Date -UFormat "%m"
    $currentYYMMMM = "$currentMonthsYear" + "$currentMonth"

    # Obtain a list of distinct yyyyMM that have already lapsed for given service
    $distinctDatesWithLogsForService = New-Object 'System.Collections.Generic.List[String]'
    Get-ChildItem $GlobalAPILogTarget -Filter *.json | 
        Foreach-Object {
        $logName = $_.Name
        $logNameSplit = $logName.split('_')
        
        # Get all distinct dateWithoutJson for given service
        if ($logNameSplit[0].ToLower() -eq $ServiceName.ToLower()) {
            $dateWithoutJson = $logNameSplit[1].ToString().Replace(".json", "")
            if ($distinctDatesWithLogsForService -notcontains $dateWithoutJson) {

                # Skip current month
                $logsYYMMMM = $logNameSplit[1].ToString().Replace(".json", "").Substring(0, 6)
                if($logsYYMMMM -ne $currentYYMMMM){
                    Write-Host "Adding $dateWithoutJson since it was determined to be in past"
                    $distinctDatesWithLogsForService.Add($dateWithoutJson)
                }                
            }
        }
    }

    # Order them to simplify debugging
    $distinctDatesWithLogsForService = $distinctDatesWithLogsForService | Sort-Object

    # Create another list, this time with a distinct list of yyyyMM
    $distinctMonthsWithLogs = New-Object 'System.Collections.Generic.List[String]'
    Foreach ($logDate in $distinctDatesWithLogsForService) {
        $logDateWithoutDay = $logDate.ToString().Substring(0, 6);

        if ($distinctMonthsWithLogs -notcontains $logDateWithoutDay) {
            $distinctMonthsWithLogs.Add($logDateWithoutDay)
        }
    }
    
    $yearAndMonthsWithLogsList = New-Object 'System.Collections.Generic.Dictionary[String,[System.Collections.Generic.List[String]]]]'
    Foreach ($distinctMonth in $distinctMonthsWithLogs) {
        $yearAndMonthsWithLogsList.Add($distinctMonth, "")
    }
     
    # Add files to dictionary that apply to yearAndMonth
    $listOfFilesApplicableToService = New-Object 'System.Collections.Generic.List[String]'  
    Get-ChildItem $GlobalAPILogTarget -Filter *.json | 
        Foreach-Object {
        $logName = $_.Name
        $logNameSplit = $logName.split('_')
        $logsYYMMMM = $logNameSplit[1].ToString().Replace(".json", "").Substring(0, 6)
        if($logsYYMMMM -ne $currentYYMMMM){
            if ($logNameSplit[0].ToLower() -eq $ServiceName.ToLower()) {
                $listOfFilesApplicableToService.Add($_.FullName)
            }
        }
    }

    # For each of the files that we have found, lets update the yearAndMonthsWithLogsList with each respective file into its value collection
    Foreach ($fullName in $listOfFilesApplicableToService) {
        $logNameSplit = $fullName.split('_') 
        $yyyyMM = $logNameSplit[1].ToString().Replace(".json", "").Substring(0, 6)
        $count = $yearAndMonthsWithLogsList[$yyyyMM].Count
      
        if ($count -eq 0) {
            $newDictionary = New-Object 'System.Collections.Generic.List[String]'
            $newDictionary.Add($fullName)
            $yearAndMonthsWithLogsList[$yyyyMM] = $newDictionary
        }
        if ($count -ne 0) {
            $existingServiceDictionary = $yearAndMonthsWithLogsList[$yyyyMM]
            $existingServiceDictionary.Add($fullName)
            $yearAndMonthsWithLogsList[$yyyyMM] = $existingServiceDictionary
        }
    }

    # Ensure we have way of allowing those services without log archive conflicts to have their log archived, while others throw exceptions, it it happens
    $atLeastOneZipFailed = $false
    foreach ($yearMonth in $yearAndMonthsWithLogsList.Keys) {
        try {
            Write-Host ""
            Write-Host "Attemping to zip files created in yyyyMM: " $yearMonth
    
            $currentMonthsLogs = $yearAndMonthsWithLogsList[$yearMonth]
            Write-Host "Number of files to be zipped: " $currentMonthsLogs.Count
    
            $nameOfZipToCreate = $ServiceName + "_" + $yearMonth
            
            $part1 = Join-Path "$LogZipArchiveTarget" "$ServiceName"
            $expectedNewZipTarget = Join-Path "$part1" "$nameOfZipToCreate"
            $expectedNewZipTarget
            Write-Host "Checking for pre-existance of zip at path :" $expectedNewZipTarget
            if ((Test-Path -path $expectedNewZipTarget)) {
                Write-Host "pre-existing zip already found!! uh oh..something went wrong. cannot replace an existing zip since archiving an month only happens once"
                throw('Artifact already existing for given service for given yyyyMM')
            }
        
            # Create the folder necessary for all services to reside under. Should only occur once
            if (!(Test-Path -path $part1)) {
                Write-Host ("Folder doesnt exist. Creating necessary folder {0} for all app service logs to reside" -f $part1)
                mkdir $part1 -Force
            }
    
            $currentMonthsLogs|where {$_ -ne ""} | Compress-Archive -DestinationPath $expectedNewZipTarget

            # TODO Consider finding substitute function to take care of zipping a collection/set of files into a DestinationPath that works with powershell version 4
            # if we are unable to install powershell 5.X onto the backend servers
            
            WRite-Host "FIles zipped"
            $currentMonthsLogs|where {$_ -ne ""} | Remove-Item
            Write-Host "zipped files removed"
            Write-Host "End of zipping archive" $nameOfZipToCreate
            Write-Host ""
        }
        catch {
            # Swallow exception to avoid a situation where a deploy attempt an application server results in all remaining deployments to fail
            echo $_.Exception|format-list -force
            $atLeastOneZipFailed = $true
        }
    }

    # Since we swallowed the exception
    if ($atLeastOneZipFailed) {
        throw 'One or more service yyyyMMM failed to be created'
    }

    Write-Host "End Archive-PreviousPeriodLogs"
}
