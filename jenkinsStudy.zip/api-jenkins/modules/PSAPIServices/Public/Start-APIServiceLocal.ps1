Function Start-APIServiceLocal {
    [cmdletbinding()]
    param(
        [Parameter(Mandatory=$True)][string]$ServiceName,
        [switch]$predev
    )

    $ComputerName=$env:COMPUTERNAME

    #write-output "testing: api: ${ServiceName} port: $($apis.Get_Item("${ServiceName}"))"
    write-output "predev: $predev"

    $ErrorActionPreference = "Stop"

    #https://stackoverflow.com/a/38009162
    Get-Environments -predev:$predev

    echo "start-api environment $environment"
    #$port=$($apis.Get_Item("${ServiceName}"))
    Get-Port $ServiceName
    $ServiceHostName=$ServiceName
    write-output "testing: api: ${ServiceName} port: ${port}"

    $ServicesDirectory="D:\Services2\$environment\"

    $exeLocation = $(Get-APIServiceExePath -ServiceName $ServiceName -ServiceHostName $ServiceHostName -ServicesDirectory $ServicesDirectory)
    #$proc = Get-WmiObject -query "SELECT * FROM Meta_Class WHERE __Class = 'Win32_Process'" -ComputerName $ComputerName -Credential $Credential
    $proc = Get-WmiObject -query "SELECT * FROM Meta_Class WHERE __Class = 'Win32_Process'"

    #From https://social.technet.microsoft.com/wiki/contents/articles/7703.powershell-running-executables.aspx
    #hidden window
    $startup=[wmiclass]"Win32_ProcessStartup"
    $startup.Properties['ShowWindow'].value=$False



    $command = "$exeLocation --server.urls http://*:$port --environment $environment"
    $publishLocation = $(Get-APIServiceRoot  -ServiceName $ServiceName -ServiceHostName $serviceHostName -ServicesDirectory $servicesDirectory)
    Write-Host "command : ${command}"
    Write-Host "publishLocation : ${publishLocation}"
    $newlyCreatedProcess=$proc.Create(${command},${publishLocation},$startup)

    Write-Host "$(Get-FormattedDate) - Started $ServiceHostName on $ComputerName with PID : " $newlyCreatedProcess.processid

    if ($newlyCreatedProcess.returnvalue -ne "0"){
        Write-Host "Did not successfully start service : " $proc.commandline
        throw('Create method exited with an returnvalue not equal to 0. returnvalue : ' + $newlyCreatedProcess.returnvalue)
    }
    # The process doesnt typically start for about 3 seconds from time of creation, therefore wait
    Start-Sleep -s 10
}
