Function Start-APIServiceIIS {
    [cmdletbinding()]
    param(
        [Parameter(Mandatory = $True)][string]$ServiceName,
        [Parameter(Mandatory = $True)][string]$ComputerName,
        [ValidateSet("predev", "dev", "qa", "stg", "prod")]
        [Parameter(Mandatory = $True)][string]$Environment,
        [System.Management.Automation.PSCredential]
        $Credential = [System.Management.Automation.PSCredential]::Empty 
    )
    $ErrorActionPreference = "Stop"
    Write-Host "Start Start-APIServiceIIS"
    $null = Invoke-Command -ComputerName $ComputerName -Credential $Credential -ScriptBlock {
        param($ServiceName, $Environment)
        
        $ErrorActionPreference = "Stop"
        Import-Module WebAdministration

        # Distint identifier using composite key. WebAppPool and Website using same name for now
        $serviceNameIdentifier = ${ServiceName}+ "-" + ${Environment}
        Write-Host "Starting WebAppPool/Website $serviceIdentifier"
        Start-WebAppPool -Name $serviceNameIdentifier
        Start-Website -Name $serviceNameIdentifier

    } -ArgumentList $ServiceName, $Environment
    Write-Host "End Start-APIServiceIIS"
}