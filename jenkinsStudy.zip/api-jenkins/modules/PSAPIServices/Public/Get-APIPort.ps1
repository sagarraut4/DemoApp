function Get-APIPort {
  param(
    [Parameter(Mandatory=$True)][string]$api,
    [switch]$predev
  )

  if (!($predev)) {
    $port=$($apis.Get_Item("${api}"))
  }
  else{
    $port=($($apis.Get_Item("${api}"))).substring(0,3) + "50"
  }

  write-output $port
}
