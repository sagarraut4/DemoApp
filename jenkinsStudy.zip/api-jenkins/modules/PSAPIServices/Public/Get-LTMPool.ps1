Function Get-LTMPool {
    [cmdletbinding()]
    param(
        [Parameter(Mandatory=$True)][string]$LoadBalancerServer,
        [Parameter(Mandatory=$True)][string]$Pool,
        [Parameter(Mandatory=$True)]
        [ValidateNotNull()]
        [System.Management.Automation.PSCredential]
        [System.Management.Automation.Credential()]
        $Credential = [System.Management.Automation.PSCredential]::Empty 
    )
    $ErrorActionPreference = "Stop"

    $lbServerSession = (New-SshSession -Computername $LoadBalancerServer -Credential $Credential -Force)
    $command = "list ltm pool $Pool"
    $result = Invoke-SSHCommand -index $lbServerSession.sessionid -command $command
    Write-Host ("Printing result of command '{0}'" -f $command)
    $result.Output
    if($result.ExitStatus -ne 0)
    {
        Write-Host "Error during command execution"
    }
    $quitResult = Invoke-SSHCommand -Index $lbServerSession.sessionid -Command "quit"
    Remove-SSHSession -Sessionid $lbServerSession.sessionid  > $null
}