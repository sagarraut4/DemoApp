Function Restart-APIServiceLocal {
  [cmdletbinding()]
  param(
    [Parameter(Mandatory=$True)][string]$Api,
    [switch] $predev
  )

  $ErrorActionPreference = "Continue"

  Get-Environments

  $env=$environment
  echo "env: $env"
  echo "Restart-APIServiceLocal predev: $predev"

  try{
    Stop-APIServiceLocal $Api
  }
  catch{
    write-output "Continuing"
  }
  write-output "un: $env:API_User passwd: $env:API_Passwd"

  $credentials = New-Object System.Management.Automation.PSCredential -ArgumentList @($env:API_User,(ConvertTo-SecureString -String $env:API_Passwd -AsPlainText -Force))
  
  $servicesDirectoryIIS="D:\wwwroot\services\${env}\"
  $servicesDirectoryV2="D:\Services2\${env}\"
  $servicesDirectoryV1="D:\Services"
 
  if ( ((Get-ChildItem ${servicesDirectoryIIS}).Name).Contains("${Api}") ){
    write-output "Servicename: $Api"
    write-output "Environment: $env"
    write-output "${Api} IIS - starting service"
    Start-APIServiceIIS -ServiceName $Api -Computername localhost -Environment $env -Credential $credentials
    Mount-VolumesLocal -ServiceName ${Api}
  }
  elseif ( ((Get-ChildItem ${servicesDirectoryV2}).Name).Contains("${Api}") ){
    write-output "${Api} V2 - starting service"
    write-output "env: $env"
    write-output "predev: $predev"
    invoke-command -ComputerName localhost -Credential $credentials -ScriptBlock {
      param($Api,$predev)
      import-module PSAPIServices -Force
      write-output "invoke command predev: $predev"
      Start-APIServiceLocal $Api -predev:$predev } -ArgumentList $Api,$predev
    Mount-VolumesLocal -ServiceName ${Api}
  }
  elseif ( ((Get-ChildItem "$servicesDirectoryV1").Name).Contains($(${Api} -replace 'Service', '')) )  {
    write-output "${Api} V1 - starting service"
    write-output "env: $env"
    write-output "predev: $predev"
    invoke-command -ComputerName localhost -Credential $credentials -ScriptBlock {
      param($Api,$predev)
      import-module PSAPIServices -Force
      Start-APIServiceLocalV1 $Api  -predev:$predev} -ArgumentList $Api, $predev
    Mount-VolumesLocal -ServiceName ${Api}
  }
  else{
    write-host "API ${Api} does not exist. Here is a listing of Apis that can be restarted:"
    Get-APINames
  }
}
