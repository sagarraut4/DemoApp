Function Start-APIService {
    [cmdletbinding()]
    param(
        [Parameter(Mandatory=$True)][string]$ServiceName,
        [Parameter(Mandatory=$True)][string]$ServiceHostName,
        [Parameter(Mandatory=$True)][int]$Port,
        [Parameter(Mandatory=$True)][string]$ComputerName,
        [Parameter(Mandatory=$True)][string]$ServicesDirectory,
        [ValidateSet("predev","dev","qa","stg","prod")]
        [Parameter(Mandatory=$True)][string]$Environment,
        [System.Management.Automation.PSCredential]
        $Credential = [System.Management.Automation.PSCredential]::Empty
    )
    $ErrorActionPreference = "Stop"
    $exeLocation = $(Get-APIServiceExePath -ServiceName $ServiceName -ServiceHostName $ServiceHostName -ServicesDirectory $ServicesDirectory)
    $proc = Get-WmiObject -query "SELECT * FROM Meta_Class WHERE __Class = 'Win32_Process'" -ComputerName $ComputerName -Credential $Credential
    $command = "$exeLocation --server.urls http://*:$Port --environment $Environment"
    $publishLocation = $(Get-APIServiceRoot  -ServiceName $ServiceName -ServiceHostName $serviceHostName -ServicesDirectory $servicesDirectory)
    Write-Host "command : ${command}"
    Write-Host "publishLocation : ${publishLocation}"
    $newlyCreatedProcess=$proc.Create(${command},${publishLocation})

    Write-Host "$(Get-FormattedDate) - Started $ServiceHostName on $ComputerName with PID : " $newlyCreatedProcess.processid

    if ($newlyCreatedProcess.returnvalue -ne "0"){
        Write-Host "Did not successfully start service : " $proc.commandline
        throw('Create method exited with an returnvalue not equal to 0. returnvalue : ' + $newlyCreatedProcess.returnvalue)
    }
    # The process doesnt typically start for about 3 seconds from time of creation, therefore wait
    Start-Sleep -s 10
}