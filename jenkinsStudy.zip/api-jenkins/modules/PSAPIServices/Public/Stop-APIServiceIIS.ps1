Function Stop-APIServiceIIS {
    [cmdletbinding()]
    param(
        [Parameter(Mandatory = $True)][string]$ServiceName,
        [Parameter(Mandatory = $True)][string]$ComputerName,
        [ValidateSet("predev", "dev", "qa", "stg", "prod")]
        [Parameter(Mandatory = $True)][string]$Environment,
        [System.Management.Automation.PSCredential]
        $Credential = [System.Management.Automation.PSCredential]::Empty 
    )
    $ErrorActionPreference = "Stop"
    Write-Host "Start Stop-APIServiceIIS"
    $null = Invoke-Command -ComputerName $ComputerName -Credential $Credential -ScriptBlock {
        param($ServiceName, $Environment)
        
        $ErrorActionPreference = "Stop"
        Import-Module WebAdministration

        $serviceIdentifier = "${ServiceName}-${Environment}"
        Write-Host "Invoking Stop-WebAppPool"
        Stop-WebAppPool -Name  $serviceIdentifier

        Write-Host "Validating WebAppPool is stopped"
        do {
            Write-Host (Get-WebAppPoolState $serviceIdentifier).Value
            Write-Host "Waiting 1 second and retrying check.."
            Start-Sleep -Seconds 1
        }
        until ( (Get-WebAppPoolState -Name $serviceIdentifier).Value -eq "Stopped" )
        Write-Host "Validatiion of WebAppPool stopped complete"
    } -ArgumentList $ServiceName, $Environment

    Write-Host "End Stop-APIServiceIIS"
}
