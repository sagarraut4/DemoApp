Function Enable-LTMPoolMember {
    [cmdletbinding()]
    param(
        [Parameter(Mandatory=$True)][string]$Node,
        [Parameter(Mandatory=$True)][string]$LoadBalancerServer,
        [Parameter(Mandatory=$True)][string]$Pool,
        [Parameter(Mandatory=$True)]
        [ValidateNotNull()]
        [System.Management.Automation.PSCredential]
        [System.Management.Automation.Credential()]
        $Credential = [System.Management.Automation.PSCredential]::Empty
    )
    $ErrorActionPreference = "Stop"
    
    # $Node cannot contain .legalzoom.com otherwise this command wont work since LB convention does NOT include having domain name in node value
    if ($Node -match "legalzoom")
    {
        Write-Host "The value for Node cannot contain domain legalzoom.com"
        throw [System.ArgumentException] "Node", "The value for Node cannot contain domain legalzoom.com. Please remove and try again"
    }

    $lbServerSession = (New-SshSession -Computername $LoadBalancerServer -Credential $Credential -Force)
    $result = Invoke-SSHCommand -Index $lbServerSession.sessionid -Command "modify ltm pool $Pool members modify {${Node}:0 {session user-enabled state user-up}}"
    if($result.ExitStatus -ne 0)
    {
        Write-Host "**********************************************************ERROR!**********************************************************"
        Write-Host "**********************************************************ERROR!**********************************************************"
        Write-Host "**********************************************************ERROR!**********************************************************"
        Write-Host "**********************************************************ERROR!**********************************************************"
        Write-Host "Enable-LTMPoolMember failed. PLEASE ENSURE ALL MEMBERS ARE ADDED BACK TO POOL USING ADMIN UI https://lz-lax-internal.legalzoom.com/xui/ "
        Write-Host "**********************************************************ERROR!**********************************************************"
        Write-Host "**********************************************************ERROR!**********************************************************"
        Write-Host "**********************************************************ERROR!**********************************************************"
        Write-Host "**********************************************************ERROR!**********************************************************"
    }
    Start-Sleep -Seconds 2
    Write-Host "Getting pool metadata after command execution"
    (Invoke-SSHCommand -Index $lbServerSession.sessionid -Command "list ltm pool $Pool").output
    (Invoke-SSHCommand -Index $lbServerSession.sessionid -Command "quit").output
    Remove-SSHSession -Sessionid $lbServerSession.sessionid  > $null
    Write-Host "Enabled pool member complete"
}