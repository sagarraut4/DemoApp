Function Stop-APIServiceLocal {
  [cmdletbinding()]
  param(
    [Parameter(Mandatory=$True)][string]$ServiceHostName
  )

  $ErrorActionPreference = "Stop"
  Write-Host "Preparing to stop service"

  #https://stackoverflow.com/a/38009162
  Get-Environments -predev:$predev
  write-output "Stop-APIServiceLocal environment: $environment"

  $processWithServiceName = Get-WmiObject Win32_Process -Filter "name = '${ServiceHostName}.exe'" -ErrorAction silentlycontinue
  $atLeastOneProcessWasTerminated = $false
  # Commandline pattern that would have been started during last deploy given environment and service name
  # Allows us to virtually separate the applications per env since we dont have 1-to-1 environment to machine in place yet
  $environmentAwareCommand = "*\$Environment*\$ServiceHostName*"

  Write-Host "Looking for processes to terminate with command like " $environmentAwareCommand " or process using legacy folder"
  foreach ($process in $processWithServiceName) {
    Write-Host ("Found command line : {0}" -f $process.CommandLine)
    # TODO remove workaround to terminating apis that were started using legacy scripts once we are 100% complete with migration
    if ($process.commandline -like $environmentAwareCommand -or $process.ExecutablePath -like "*\Services\*\$ServiceHostName*" -or $process.ExecutablePath -like "*\features\*\$ServiceHostName*"){            
      Write-Host "$(Get-FormattedDate) - Stopping process on $ComputerName with PID" $process.processid
      if ($process.terminate().returnvalue -ne "0"){
        Write-Host $process.commandline "did not successfully terminate..."
        throw('proc.terminate() exited with an returnvalue :' + $process.terminate().returnvalue)
      }
      $atLeastOneProcessWasTerminated = $true
      Write-host ("$(Get-FormattedDate) - Successfully terminated process.CommandLine : {0}" -f $process.CommandLine)
    }
  }
  if($atLeastOneProcessWasTerminated -eq $false) {
    throw('No process was found to terminate with the given input')
  }
}
