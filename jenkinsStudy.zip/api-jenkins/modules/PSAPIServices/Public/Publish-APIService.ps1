Function Publish-APIService {
    [cmdletbinding()]
    param(
        [Parameter(Mandatory=$True)][string]$ServiceName,
        [Parameter(Mandatory=$True)][string]$ComputerName,
        [Parameter(Mandatory=$False)][bool]$DeleteExistingFiles = $True,
        [Parameter(Mandatory=$True)][string]$ServicesDirectory,
        [Parameter(Mandatory=$True)][string]$ArtifactLocation,
        [System.Management.Automation.PSCredential]
        $Credential = [System.Management.Automation.PSCredential]::Empty 
    )
    $ErrorActionPreference = "Stop"
    Write-Host "Publish-APIService start"

    if(![System.IO.File]::Exists($ArtifactLocation)){
        Write-Host "ArtifactLocation : $ArtifactLocation"
        throw [System.ArgumentException] "ArtifactLocation", "The provided ArtifactLocation does not exist. Please ensure file exists"
    }
    $serviceDirectory = ($ServicesDirectory.Replace(":", "$"))

    # This may contain environment
    $pathForAllServicesOnRemote = "\\" + (join-path $ComputerName $serviceDirectory)
    Write-Host ("Path for all services in given environment : {0} " -f $pathForAllServicesOnRemote)
    $pathToThisServiceFolderOnRemote = (join-path $pathForAllServicesOnRemote $ServiceName)
    Write-Host ("Path to service : {0} in given environment : {1}" -f $ServiceName,$pathToThisServiceFolderOnRemote)
    Write-Host "pathToThisServiceFolderOnRemote $pathToThisServiceFolderOnRemote"
    if($DeleteExistingFiles)
    {
        Write-Host "$(Get-FormattedDate) - invoking script on remote Computer"
        $null = Invoke-Command -ComputerName $ComputerName -Credential $Credential -ScriptBlock {
            param($pathForAllServicesOnRemote, $pathToThisServiceFolderOnRemote)
            $ErrorActionPreference = "Stop"

            # Delete application folder if it exists
            if ((Test-Path -path $pathToThisServiceFolderOnRemote)) {
                Write-Host "Deleting directory : $pathToThisServiceFolderOnRemote"
                rmdir $pathToThisServiceFolderOnRemote -Recurse -Force
            }
            # Create the folder necessary for all services to reside under. Should only occur once
            if (!(Test-Path -path $pathForAllServicesOnRemote)) {
                Write-Host ("Folder doesnt exist. Creating necessary folder {0} for all app services to reside" -f $pathForAllServicesOnRemote)
                mkdir $pathForAllServicesOnRemote -Force
            }

            Write-Host "Creating directory :  $pathToThisServiceFolderOnRemote"
            mkdir $pathToThisServiceFolderOnRemote -Force

        } -ArgumentList $pathForAllServicesOnRemote, $pathToThisServiceFolderOnRemote
    }

    Write-Host "$(Get-FormattedDate) - Expanding Archive $ArtifactLocation to $pathToThisServiceFolderOnRemote"
    Expand-Archive $ArtifactLocation -DestinationPath $pathToThisServiceFolderOnRemote -Force
    Write-Host "Publish-APIService end"   
}