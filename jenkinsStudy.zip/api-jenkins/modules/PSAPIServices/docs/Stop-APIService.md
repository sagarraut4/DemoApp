# Stop-APIService

## SYNOPSIS
Stops a service process in a given environment on a given server

## EXAMPLES

### Example 1: Attepts to find and stop 
```
$serviceHostName = "CartService"
$server = "laiw12ap527s"
$environment = "stg"
$backendServerPass = ConvertTo-SecureString "MyPassword123*" -AsPlainText -Force
$backendServerCredential = New-Object System.Management.Automation.PSCredential ("LZUser", $loadBalancerPass)

Stop-APIService -ServiceHostName $serviceHostName -ComputerName  $server -Environment $environment -Credential $backendServerCredential

```