# Archive-APIServiceLogs

## SYNOPSIS
Archives all log files for all services by convention to folder {GlobalAPILogTarget}/{ServiceName}/{ServiceName}_{yyyyMM}.
This command will only archive logs for months that have passed.


## EXAMPLES

### Example 1: Archive all logs for all services for months that have already passed
```
Import-Module PSAPIServices -Force -Verbose
Archive-APIServiceLogs -GlobalAPILogTarget "C:\logs" -Verbose -LogZipArchiveTarget "C:\logs"

```