# Start-APIServiceIIS

## SYNOPSIS
Starts a webapi service that is hosted in IIS

## EXAMPLES

### Example 1: Start the current DummyService deployed to predev
```
$serviceName = "DummyService"
$serviceHostName = "DummyService"
$server = "laiw12ap517d"
$environment = "predev"

$backendServerPass = ConvertTo-SecureString DaddyDadda1234" -AsPlainText -Force
$backendServerCredential = New-Object System.Management.Automation.PSCredential ("cookies", $backendServerPass)

Start-APIServiceIIS -ServiceHostName $serviceHostName -ComputerName $server -Environment $environment -Credential $backendServerCredential


```
