# Publish-APIService

## SYNOPSIS
Replaces an application directory contents with the contents of a new deployment artifact, invoking remote commands on the desired computer to remove old application files and directories. Also will initialize a new directory if this is first time deploying service in a given environment

## EXAMPLES

### Example 1: Publish an application files and folder from an artifact location
```
$serviceName = "CartService"
$server = "laiw12ap527s"
$servicesDirectory = "D:\Services2\stg"
$artifactLocation = "\\tfsbuild1\d$\BuildDrops\APIs2\qa\CartService\CartService-release-1.zip"
$backendServerPass  = ConvertTo-SecureString "MyPassword123*" -AsPlainText -Force
$backendServerCredential = New-Object System.Management.Automation.PSCredential ("LEGALZOOM\klee", $loadBalancerPass)
Publish-APIService -ServiceName $serviceName -ComputerName  $server -ServicesDirectory $servicesDirectory -ArtifactLocation $artifactLocation -Credential $backendServerCredential
```