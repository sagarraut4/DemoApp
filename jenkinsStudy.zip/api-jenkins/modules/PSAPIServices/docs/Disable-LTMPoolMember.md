# Disable-LTMPoolMember

## SYNOPSIS
Disables a pool member from a given pool.

## EXAMPLES

### Example 1: Disables a pool member from a given pool in staging
```
$node = "laiw12ap527s"
$loadBalancerServer = "lz-lax-internal"
$poolName = "BAPI-STG"
$loadBalancerPass = ConvertTo-SecureString "MyPassword123*" -AsPlainText -Force
$loadBalancerCredential = New-Object System.Management.Automation.PSCredential ("LZUser", $loadBalancerPass)

Disable-LTMPoolMember -Node $node -LoadBalancerServer $loadBalancerServer -Pool $poolName -Credential $loadBalancerCredential -Verbose
```

### Example 2: Disables a pool member from a given pool in production
```
$node = "laiw12ap528p"
$loadBalancerServer = "lz-lax-internal"
$poolName = "BAPI-PROD"
$loadBalancerPass = ConvertTo-SecureString "MyPassword123*" -AsPlainText -Force
$loadBalancerCredential = New-Object System.Management.Automation.PSCredential ("LZUser", $loadBalancerPass)

Disable-LTMPoolMember -Node $node -LoadBalancerServer $loadBalancerServer -Pool $poolName -Credential $loadBalancerCredential -Verbose
```