# Archive-PreviousPeriodLogs

## SYNOPSIS
Archives all log files for given asp.net core web api service by convention to folder {GlobalAPILogTarget}/{ServiceName}_{yyyyMM}
Above, GlobalAPILogTarget refers to the sirilog target log location specified in appsettings.json within each respective api repository
All apis use the same target, D:\logs

## EXAMPLES

### Example 1: Archive all AttributionService logs
```
Import-Module PSAPIServices -Force -Verbose
Archive-PreviousPeriodLogs -ServiceName "AttributionService" -GlobalAPILogTarget "C:\logs" -Verbose -LogZipArchiveTarget "C:\logs"

```