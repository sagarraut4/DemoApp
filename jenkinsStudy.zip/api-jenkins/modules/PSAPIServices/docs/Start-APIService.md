# Start-APIService

## SYNOPSIS
Creates/Starts a process on a windows server using an existing application which has already been deployed to the application server.

## EXAMPLES

### Example 1: Start the current CartService currently deployed to stage
```
$serviceName = "CartService"
$serviceHostName = "CartService"
$port = "14000"
$server = "laiw12ap527s"
$servicesDirectory = "D:\Services2\stg\"
$environment = "stg"

Start-APIService -ServiceName $serviceName -ServiceHostName $serviceHostName -Port $port -ComputerName $server -ServicesDirectory $servicesDirectory -Environment $environment
```
