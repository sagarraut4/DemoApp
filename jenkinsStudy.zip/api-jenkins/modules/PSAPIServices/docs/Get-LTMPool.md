# Get-LTMPool

## SYNOPSIS
Obtain all members that are associated with pool and their status

## EXAMPLES

### Example 1: Get list of members within a ltm pool and their associated status
```
$loadBalancerServer = "lz-lax-internal"
$poolName = "BAPI-STG"
$loadBalancerPass = ConvertTo-SecureString "MyPassword123*" -AsPlainText -Force
$loadBalancerCredential = New-Object System.Management.Automation.PSCredential ("LZUser", $loadBalancerPass)

Get-LTMPool -LoadBalancerServer $loadBalancerServer -Pool $poolName -Credential $loadBalancerCredential

ltm pool BAPI-STG {
    description stg-bapi.legalzoom.com
    members {
        laiw12ap527s:any {
            address 10.1.75.53
            session monitor-enabled
            state up
        }
        laiw12ap537s:any {
            address 10.1.75.71
            session monitor-enabled
            state up
        }
    }
    monitor gateway_icmp 
}

```