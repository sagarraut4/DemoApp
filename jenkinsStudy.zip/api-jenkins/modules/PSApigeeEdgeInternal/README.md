# PSApigeeEdgeInternal

### Purpose: Powershell module designed to allow build server to automate apigee apiproxy and target server deploy automation for on-prem apigee deployments. Iitial patterns/functions were cloned from https://github.com/DinoChiesa/Edge-Powershell-Admin/, which was unfortunately only designed for cloud. 

### Setup: Install module to build server, ensure powershell is in directory where 'APIGEE' folder is located within api service solution

```
Install-Module PSApigeeEdgeInternal

$Org = "legalzoom"
...
...
...
$ApiProxyName = "CartApi"

#must be called before any functions, such as Update-TargetServer, are invoked
Set-EdgeConnection -MgmtUri $MgmtUri -OAuthToken $OAuthToken -OAuthUrl $OAuthUrl
Update-TargetServer -Env $Env -Source .\TargetServer.json -Verbose


```