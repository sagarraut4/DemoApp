Function Get-TargetServer {
    [cmdletbinding()]
    param(
        [Parameter(Mandatory=$True)][string]$Name,
        [Parameter(Mandatory=$True)][string]$Env,
        [string]$Source #path to TargetServer.json
    )
    $ErrorActionPreference = "Stop"
    #TODO: Validate necessary variables are set
    $MgmtUri = $MyInvocation.MyCommand.Module.PrivateData.Connection['MgmtUri']
    $Org = $MyInvocation.MyCommand.Module.PrivateData.Connection['Org']

    $BaseUri = Join-Parts -Separator '/' -Parts $MgmtUri, '/v1/o', $Org,'e',$Env, 'targetservers',$Name
    $IRMParams = @{
        Uri = "${BaseUri}"
        Method = 'Get'
        Headers = @{
            Accept = 'application/json'
        }
    }
    
    #Adds aauth header to IRMParams variable before passing into Invoke-WebRequest as param
    Apply-EdgeAuthorization -MgmtUri $MgmtUri -IRMParams $IRMParams

    Write-Debug ([string]::Format("Params {0}`n", $(ConvertTo-Json $IRMParams -Compress ) ) )

    Try {
        $TempResult = Invoke-WebRequest @IRMParams -UseBasicParsing

        Write-Debug "Raw:`n$($TempResult | Out-String)"
    }
    Catch {
        if ($_.Exception.Response.StatusCode.value__ -eq 404) {
            Write-Debug("web request resulted in 404")
            return
        }
        #Throw $_
    }
    Finally {
        Remove-Variable IRMParams
    }
    if ($TempResult.StatusCode -eq 200) {
        ConvertFrom-Json $TempResult.Content
    }
    else {
        $TempResult
    }
}
