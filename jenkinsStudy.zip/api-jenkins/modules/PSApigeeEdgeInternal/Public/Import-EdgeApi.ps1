Function Import-EdgeApi {
    [cmdletbinding()]
    param(
        [Parameter(Mandatory=$True)][string]$Name,
        [string]$Source, #The directory that contains the APIProxy
        [string]$Org
    )
    $ErrorActionPreference = "Stop"
    if ($PSBoundParameters['Debug']) {
        $DebugPreference = 'Continue'
    }

    #Validate necessary variables are set
    if (!$PSBoundParameters['Name']) {
      throw [System.ArgumentNullException] "Name", "You must specify the -Name option."
    }
    if (!$PSBoundParameters['Source']) {
      throw [System.ArgumentNullException] "Source", "You must specify the -Source option."
    }

    $ZipFile = ""
    $isFile = $False
    $mypath = $(Resolve-Path $Source)
    if (! $mypath) {
        throw [System.ArgumentException] "Source", "The provided Source does not resolve."
    }

    if([System.IO.File]::Exists($mypath)){
        $isFile = $True
        $ZipFile = $mypath
        Write-Debug ([string]::Format("Source is file {0}`n", $ZipFile))
    }
    elseif ([System.IO.Directory]::Exists($mypath)) {
        # Validate that there is an apiproxy directory
        $apiproxyPaths = @(Join-Path -Path $mypath -ChildPath "apiproxy" -Resolve)
        if ($apiproxyPaths.count -ne 1) {
            throw [System.ArgumentException] "Cannot find apiproxy directory under the Source directory."
        }
        Write-Debug ([string]::Format("Source is directory {0}`n", $mypath))
        #The zip has very specific entries that it needs to be in. This takes care of zipping into that format as required by EdgeAPI
        $ZipFile = Zip-DirectoryEx -SourceDir $mypath
        Write-Debug ([string]::Format("Zipfile {0}`n", $ZipFile))
    }
    else {
      throw [System.ArgumentException] "Source", $([string]::Format("Source file refers to '{0}', not a readable file or directory.", $mypath))
    }
    
    if( ! $PSBoundParameters.ContainsKey('Org')) {
      if( ! $MyInvocation.MyCommand.Module.PrivateData.Connection['Org']) {
        throw [System.ArgumentNullException] 'Org', "use the -Org parameter to specify the organization."
      }
      $Org = $MyInvocation.MyCommand.Module.PrivateData.Connection['Org']
    }
    if( ! $MyInvocation.MyCommand.Module.PrivateData.Connection['MgmtUri']) {
      throw [System.ArgumentNullException] 'MgmtUri', 'use Set-EdgeConnection to specify the Edge connection information.'
    }

    $MgmtUri = $MyInvocation.MyCommand.Module.PrivateData.Connection['MgmtUri']

    $BaseUri = Join-Parts -Separator '/' -Parts $MgmtUri, '/v1/o', $Org, 'apis'

    $IRMParams = @{
        Uri = "${BaseUri}?action=import&name=${Name}"
        Method = 'POST'
        Headers = @{
            Accept = 'application/json'
            'content-type' = 'application/octet-stream'
        }
        InFile = $ZipFile
    }
    
    #Adds a header to IRMParams variable before passing into restclient
    Apply-EdgeAuthorization -MgmtUri $MgmtUri -IRMParams $IRMParams

    Write-Debug ([string]::Format("Params {0}`n", $(ConvertTo-Json $IRMParams -Compress ) ) )

    Try {
        $TempResult = Invoke-WebRequest @IRMParams -UseBasicParsing

        Write-Debug "Raw:`n$($TempResult | Out-String)"
    }
    Catch {
        Throw $_
    }
    Finally {
        Remove-Variable IRMParams
        if (! $isFile ) {
            # Source was a dir, the zipfile is a temp file. Clean it up.
            [System.IO.File]::Delete($ZipFile)
            # TODO: Consider archiving along with other web api artifacts, perhaps using naming convention similar to that of web api services assemblies that felix is working on
        }
    }
    if ($TempResult.StatusCode -eq 201) {
      ConvertFrom-Json $TempResult.Content
    }
    else {
      $TempResult
    }
}
