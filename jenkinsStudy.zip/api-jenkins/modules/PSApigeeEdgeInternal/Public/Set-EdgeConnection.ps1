Function Set-EdgeConnection {
    [cmdletbinding()]
    [Diagnostics.CodeAnalysis.SuppressMessage("PSAvoidUsingUserNameAndPassWordParams","")]
    [Diagnostics.CodeAnalysis.SuppressMessage("PSAvoidUsingConvertToSecureStringWithPlainText","")]

    PARAM(
        [Parameter(Mandatory=$True)][string]$MgmtUri,
        [Parameter(Mandatory=$True)][string]$OAuthToken,
        [Parameter(Mandatory=$True)][string]$OAuthUrl
    )

    PROCESS {        
        if ($PSBoundParameters['Debug']) {
            $DebugPreference = 'Continue'
        }
        $ErrorActionPreference = "Stop"
        $MyInvocation.MyCommand.Module.PrivateData.Connection['MgmtUri'] = $MgmtUri
        $MyInvocation.MyCommand.Module.PrivateData.Connection['OAuthToken'] = $OAuthToken
        $MyInvocation.MyCommand.Module.PrivateData.Connection['OAuthUrl'] = $OAuthUrl

        #TODO: Consider creating token here as was done in PSApigeeAdge, or create and call separate function so as not to have side effects in this function
    }
}
