Function Get-EdgeRefreshedAdminToken {
    <#
    .SYNOPSIS
        Gets an OAuth token from lz for Edge Administration.

    .DESCRIPTION
        Gets an OAuth token for Edge Administration. Object is to work with on prem.
        You must have previously called Set-EdgeConnection to specify the user + password.

    .LINK
        Set-EdgeConnection

    .LINK
        Get-EdgeNewAdminToken

    .LINK
        Get-EdgeStashedAdminToken

    .FUNCTIONALITY
        ApigeeEdge

    #>

    [cmdletbinding()]

    PARAM( [String] $UserToken )

    PROCESS {
        #TODO: Consider refactoring this function to actually work with this module. The code below has not been tested
        if ($PSBoundParameters['Debug']) {
            $DebugPreference = 'Continue'
        }
        $ErrorActionPreference = "Stop"
        $OAuthUrl = $MyInvocation.MyCommand.Module.PrivateData.Connection['OAuthUrl']
        $ClientID = $MyInvocation.MyCommand.Module.PrivateData.Connection['ClientID']
        $ClientSecret = $MyInvocation.MyCommand.Module.PrivateData.Connection['ClientSecret']
        $User = $MyInvocation.MyCommand.Module.PrivateData.Connection['User']        
        $Pass = $MyInvocation.MyCommand.Module.PrivateData.Connection['OAuthPass']   
        
        #Invoke-RestMethod add Content-Type header by default if one is not specified
        $IRMParams = @{
            Uri = $OAuthUrl
            Method = 'POST'
            Headers = @{
                Accept = 'application/json'
            }
            Body = @{
                client_id = $ClientID
                client_secret = $ClientSecret 
                grant_type = "password"
                username = $User
                password = $Pass               
            }
        }

        Write-Debug ( "Running $($MyInvocation.MyCommand).`n" +
                      "Invoke-RestMethod parameters:`n$($IRMParams | Format-List | Out-String)" )

        Try {
            $TokenResult = Invoke-RestMethod @IRMParams
            Write-Debug "Raw:`n$($TokenResult | Out-String)"

            Write-Debug ("TokenResult type: " + $TokenResult.GetType().ToString())
            if ($TokenResult -and $TokenResult.psobject -and $TokenResult.psobject.properties) {
                Add-Member -InputObject $TokenResult -MemberType NoteProperty -Name "issued_at" -Value $(Get-NowMilliseconds)
                Write-Debug "Updated:`n$($TokenResult | Out-String)"

                Write-EdgeTokenStash -User $User -NewToken $TokenResult
                $MyInvocation.MyCommand.Module.PrivateData.Connection['MostRecentRefresh'] = $(Get-NowMilliseconds)
            }
        }
        Catch {
            Throw $_
        }
        Finally {
            Remove-Variable UserToken
        }

        Get-EdgeStashedAdminToken
    }
}
