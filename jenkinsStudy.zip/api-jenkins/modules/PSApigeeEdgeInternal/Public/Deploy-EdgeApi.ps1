Function Deploy-EdgeApi {
    [cmdletbinding()]
    param(
        [Parameter(Mandatory=$True)][string]$Name,
        [Parameter(Mandatory=$True)][string]$Env,
        [Parameter(Mandatory=$True)][string]$Revision,
        [string]$Org,
        [string]$Basepath,
        [Hashtable]$Params
    )
    $ErrorActionPreference = "Stop"
    if ($PSBoundParameters['Debug']) {
        $DebugPreference = 'Continue'
    }
    #simple wrapper around another function that allows to upload revision to asset (abstracted away)
    Deploy-EdgeAsset -AssetType 'apis' -Name $Name -Env $Env -Revision $Revision -Org $Org -Basepath $Basepath -Params $Params
}
