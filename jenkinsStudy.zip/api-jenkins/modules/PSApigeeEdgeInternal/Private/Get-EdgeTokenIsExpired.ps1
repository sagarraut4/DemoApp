function Get-EdgeTokenIsExpired
{
    [cmdletbinding()]
    PARAM( [string] $UserToken )
    PROCESS {
        if ($PSBoundParameters['Debug']) {
            $DebugPreference = 'Continue'
        }
        # Return false so that the branch works as we need it to for now
        return $false;
        if (!$usertoken) {
            throw [System.ArgumentNullException] "You must pass a usertoken [string]."
        }
    }
}
