# LLC docs Home Page

(TODO: this is only runbook for now, we can organize comprehensive documentation later maybe, depending on how we want to structure things in backstage et al. For more on mkdocs, visit https://www.mkdocs.org/#getting-started)

For setup, build, and testing, see [README.md](https://github.legalzoom.com/engineering/site-external-questionnaire-llc-src/blob/develop/README.md).

## LLC Runbook

Contributing to LLC app:
* Changes should be done in a separate feature branch
* Make sure all work is thoroughly developer tested and all unit tests pass.
* Create a Pull Request
  * At least one reviewer needs to approve before it can be merged into develop. 
  * All code that is merged into develop should be production-ready (it can be feature-flagged and hidden if not ready for prime time, but it certainly shouldn't break anything).  

Once the changes are in develop, follow this process to deploy LLC to production. Keep in mind that many teams touch the LLC app, so to help coordinate releases, visit [the #llc-releases Slack channel](https://legalzoom.slack.com/archives/C01MRAG25JP). Unless we're talking birthday parties, it's better to over-communicate than to surprise another team!

### Create RWI

To track any release, we use Release Work Items (RWI) in Azure Devops. The overall process is described here: [RWI Release Process](https://legalzoom.atlassian.net/wiki/spaces/LA/pages/676757564/RWI+Release+Process).

If an RWI has already been created *for the LLC app* for the date you want to release, you can simply add your work with reference to the Jira ticket to the existing RWI; otherewise, create a new one. Most projects will have a template you can use as a starting point. Create and manage RWIs here: [https://dev.azure.com/legalzoom/](https://dev.azure.com/legalzoom/Release%20Management/_workitems/recentlyupdated/)

![rwi_new](https://github.legalzoom.com/storage/user/394/files/2200e380-b16c-11eb-9736-0ae08c626e9f)

![rwi_template](https://github.legalzoom.com/storage/user/394/files/24633d80-b16c-11eb-9fae-fb5c9655b2e9)

### Cut Release Branch

Check [Jenkins](https://cjm.legalzoom.com/job/Angular_LLC-LZRed_Multibranch/) to make sure `develop` builds successfully. Create the release branch (e.g., via git CLI or directly on github), making sure the version in the name matches the version in the RWI, e.g., `release/v3.31.0`. When it's done building, update the RWI to "ready for dev" to get it pushed all the way to QA. 

### Test and Deploy (and test again)

Once deployed to QA, verify your changes and test accordingly (UAT, RT, et al). Results for test automation can be found [here on Jenkins](https://cjm.legalzoom.com/view/Test%20Automation/job/LZ_Web_Debug/). If all looks good, notify [dev ops](https://legalzoom.slack.com/archives/CB717T10V) that the RWI is ready for rollout. This would be a bad time to leave your computer. Once it's live, verify your changes in production, and monitor for any issues. [Here's a checklist](https://legalzoom.atlassian.net/wiki/spaces/GBCK/pages/2181693832/Checkout+Release+Checklist) from the checkout team that might be helpful.

### Monitoring

#### Datadog
The RUM instrumentation for LLC is injected into the app by the checkout component, which makes everything out of the LLC app look like it belongs to [Global Checkout in Datadog](https://app.datadoghq.com/rum/application/0eb543bf-0137-4fe4-a398-42fa2e54379c/overview/browser?live=true).

#### TrackJS
Error logs are also sent [here to TrackJS](https://my.trackjs.com). Look out for spikes that coincide with the roll out. You can filter logs specifically for the LLC app.

### Opening an Incident
If you notice anything awry in production, particularly if some time has passed since the deployment or if you just deployed and it cannot be resolved by quickly rolling back, do not hesitate to open an incident. [This doc describes how to engage NOC.](https://legalzoom.atlassian.net/wiki/spaces/NOC/pages/719618241/How+to+engage+NOC)

## Further help

Reach out to [Optimize Prime](https://legalzoom.slack.com/archives/CUGS72BSA) team
