# Deprecated as of 03/21/2023 
Link of the new experience https://github.legalzoom.com/engineering/iq-flow

# LLC

## Prerequisites

Git (including Git Bash)
- via Chocolatey: first run this command in PowerShell as Administrator:
    ```
    Set-ExecutionPolicy Bypass -Scope Process -Force; [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072; iex ((New-Object System.Net.WebClient).DownloadString('https://chocolatey.org/install.ps1'))
    ```
- then run
  `choco install git`

- [SSH on github](https://docs.github.com/en/enterprise-server@2.20/github/authenticating-to-github/connecting-to-github-with-ssh) (optional)

Node.js 14 (includes npm)
- via nvm-windows, download **[nvm-setup.zip](https://github.com/coreybutler/nvm-windows/releases)**, open and run executable to install
- install Node
    `nvm install 14.15.1`

    `nvm use 14.15.1`
- set legalzoom npm registry
    `npm config set @legalzoom:registry http://artifactory.legalzoom.com/artifactory/api/npm/npm/`

Angular (Optional)

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 8.3.26.
- npm install -g @angular/cli

*NOTE: If you have Angular installed globally, then you can omit the `npm run` in the below `ng` commands (e.g. `ng serve`)*

Install Dependencies
- npm install

## Development server

Run `npm run ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `npm run ng generate component component-name` to generate a new component. You can also use `npm run ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `npm run ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

## Running unit tests

Run `npm run test:coverage` to execute the unit tests.

## Cypress UI Automation
See documentation [here](cypress/Cypress_Setup.md)

## How to Release
Release documentation can be found [here](https://legalzoom.atlassian.net/wiki/spaces/DEV/pages/2922283255/Releasing+site-external-questionnaire-llc-src)

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).

<br></br>
# Guidelines

## Code Reviews

#### HOW-TO VIDEO
* LZ Engineering Wiki: [PR Review Linking](https://legalzoom.atlassian.net/wiki/spaces/DEV/pages/1145866567/Best+Practices#PR-Review-Linking)

Suggested Reading:
- https://github.com/google/eng-practices/tree/master/review
