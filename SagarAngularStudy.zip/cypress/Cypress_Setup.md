# Cypress UI Automated Testing

## Prerequisites

- LLC setup complete as described in the [README](https://github.legalzoom.com/engineering/site-external-questionnaire-llc-src)

## Executing Tests

The tests require the LLC app to be running on your local dev server either at (`https://wwwlocal.legalzoom.com:4200/llc/`) for Desktop/Tablet or (`https://wwwlocal.legalzoom.com:4300/llc/`) for Mobile. This dependency is defined in the config files here [Desktop](./../cypress.json) and [Mobile](./../cypress.mobile.json).

### Cypress Test Runner
Cypress should be installed in the `./node_modules` directory.  Open it with one of the following

- `./node_modules/.bin/cypress open`
- `$(npm bin)/cypress open`
- `./node_modules/.bin/cypress open --config-file cypress.mobile.json` *( for Mobile)*
- `$(npm bin)/cypress open --config-file cypress.mobile.json` *( for Mobile)*

Any spec file found in the `cypress/integration` directory will show in the Test Runner and can be executed from there.

### Helpers
For ease of use we recommend using the following to launch Cypress and the appropriate LLC App. On first run, you will see message indicating: `Cypress could not verify that this server is running:`, please wait for the angular server to completely start up then click `Try again` in order to run your tests.  Both the app and Cypress will be running until they are manually killed.

 * `npm run cypress:desktop` 
 * `npm run cypress:mobile` 

> Be sure your host file is setup so that `wwwlocal.legalzoom.com` is pointing to your machine.

### Command Line Runner
- `./node_modules/.bin/cypress run`
- `./node_modules/.bin/cypress run --config-file cypress.mobile.json` *( for Mobile)*

### Jenkins CI Pipeline
The following parameters are needed in the Jenkinsfile to enable Cypress tests in CI
- `runCypressTests = "true"`
- `cypressTestCommand = "cypress command to execute tests"`
- `createAndUploadArtifact = "true"`

## Best Practices
- Use descriptive test names `it('should do x when y)`.  This helps tremendously with readability and references in the future.
- No need for the "Arrange/Act/Assert" model as there can/should be multiple assertions per test.
- Tests should focus on functionality under test, so set up state as easily as possible.  Often this is not driving the UI.
- Custom commands (in commands.js) should be small re-usable utilities.  Don't want to have tests be a series of custom commands (like page objects).
- Avoid putting assertions into commands.  They should live in the test themselves.
- List the ID of the Jira story under test in the title of the test (i.e. `describe('blahblahblah test - MA-1234')`.  This is to solve for traceability.  Let's try it and see if it helps.

### Mocking APIs
- There are commands that allow tests to start at certain places in the Questionnaire by mocking the API calls to set state.  The approach that we are trying is the following.  
  - If the test is verifying something *independent* of the setup (e.g. Disclaimers on a page), then mock the setup.
  - If the test is verifying something *dependent* on the setup (e.g. Review Your Order fields) then setup through the UI.

- Cypress has pretty thorough [documentation](https://docs.cypress.io/guides/overview/why-cypress.html#In-a-nutshell)
- Their own best practices [here](https://docs.cypress.io/guides/references/best-practices.html)
