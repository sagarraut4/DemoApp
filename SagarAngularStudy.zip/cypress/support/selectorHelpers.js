Cypress.Commands.add('getByLabel', (label) => {
    return cy.contains(label, { includeShadowDom: true }).invoke('attr', 'for')
        .then((id) => {
            cy.get('#' + id)
        })
})
