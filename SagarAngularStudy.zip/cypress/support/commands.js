import 'cypress-iframe';
/// <reference types="Cypress" />
// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add("login", (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add("drag", { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add("dismiss", { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite("visit", (originalFn, url, options) => { ... })

//Command to set up session and mock API responses in order to navigate directly to Q2.
Cypress.Commands.add('goToQ2', (state = 'California', entityName = 'Bananas') => {

    // Set up mock API responses
    cy.intercept('GET', 'v1/web-sessions/sessions', {fixture: 'v1_web-sessions_sessions_get.json'});
    cy.intercept('GET', 'v1/carts', {fixture: 'v1_carts_get.json'});
    cy.intercept('GET', 'v1/core/processing-orders', {fixture: 'v1_core_processing-orders_get.json'});
    cy.intercept('GET', 'v1/answers', {fixture: 'v1_answers_get.json'});
    // Update entity state
    cy.fixture('v1_questionnaire-storage_get.json').then((questionnaireJson) => {
        let answers = JSON.parse(questionnaireJson.answers);
        answers.entityState = state;
        answers.entityName = entityName;
        questionnaireJson.answers = JSON.stringify(answers);
        cy.intercept('GET', 'v1/questionnaire-storage', questionnaireJson);
    });
    cy.intercept('GET', 'v1/core/orders', {fixture: 'v1_core_orders_get.json'});

    // Set necessary cookies
    cy.setCookie('LZUserIdentification', 'consultation_id=S21DDuun3d364kGr6RwGHRXBDc7b&cid=15738343');
    cy.setCookie('ActiveSession', 'true');

    // Act
    cy.visit('/order/remaining-questions', {
        qs: {
            // Need to pass the following query strings for app initialization
            uo: 510415838,
            cartId: 22559102,
            orderId: 34095553
        }
    });
});

// This command will take user to the desired page in Q1 flow (timeframe page to review-your-order page). 
// This command should not be used in the tests where further actions need to be performed in or beyond the landed page that would result in the app making additional API calls. 
// Provide the name of the page to go to in "PageToGoTo" parameter and make sure to use the name of the page as found in the query string of that page. 
// All other paramters are for providing the answers to the pages visited when navigating to the destination page.
// These paramters are optional and if not provided then default values are applied.
Cypress.Commands.add('goToQ1Page', ({ pageToGoTo = 'registered-agent', skipName = false, name = 'Cypress automated test', state = 'California', startTime = 'soon', 
    isFirstLLC = true, bizPurpose = 'Retail', hireEmp = 'yes', ra = 'Yes', doc = 'OA_EIN_LICENCES', legal = true,  compliance = 'true', pkg = 147, bofa = true, profprintSelect = false ,apiRoute = 'balances' } = {}) => {

    var url;
    // Setting up mock responses for necessary API calls.
    cy.intercept('GET', 'v1/carts/22622758/balances', getCartsApiFixture(pkg, apiRoute));
    cy.intercept('GET', 'v1/web-sessions/sessions', {fixture: 'fixt_pageToGoTo/v1_web-sessions_sessions.json'});
    cy.intercept('GET', 'v1/carts', {fixture: 'fixt_pageToGoTo/v1_carts.json'});
    cy.intercept('GET', 'v1/core/processing-orders', {fixture: 'fixt_pageToGoTo/v1_core_processing-orders.json'});
    cy.intercept('GET', 'v1/answers', {fixture: 'fixt_pageToGoTo/v1_answers.json'});
    cy.intercept('POST', 'v1/core/products/filing-fees/2', { fixture: 'fixt_pageToGoTo/v1_core_products_filing-fees_2.json' });
    cy.intercept('PUT', 'v1/carts/22622758/change-package', { fixture: 'fixt_pageToGoTo/v1_carts_22622758_change-package.json' });    
    cy.intercept('POST', 'v1/answers/questionnaires/27', {fixture: 'fixt_pageToGoTo/v1_answers_questionnaires_27.json'});
    cy.intercept('POST', 'v1/questionnaire-storage', {fixture: 'fixt_pageToGoTo/v1_questionnaire-storage.json'});
    cy.intercept('PUT', 'v1/carts/22622758/questionnaire', getCartsApiFixture(pkg, 'questionnaire'));
    cy.intercept('POST', 'v1/carts/22622758/cart-items', {fixture: 'fixt_pageToGoTo/v1_carts_22622758_cart-items.json'});

    // Set necessary cookies
    cy.setCookie('LZUserIdentification', 'consultation_id=zeW5hGSsTwkG4XV5EArNbPoGTXKo&cid=15909062');
    cy.setCookie('TIMESTRING', '15909062');
    cy.setCookie('ActiveSession', 'true');

    const answers = {
        "isEntityStateSelected": false,
        "isBusinessNameAvailable": true,
        "professionalPrintSelected": false,
        "businessAddress": {},
        "raDetails": {
        "address": {}
        },
        "irsContact": {
        "address": {}
        },
        "isMobile": false,
        "bShowPriceTest": "Null",
        "bShowPriceTest1": "Null",
        "bFunnelTest": "Null",
        "customerPhoneNumber": "",
        "customerEmail": "",
    }

    switch (pageToGoTo) {
        case 'timeframe':
            url = '/business/timeframe';
            cy.fixture('fixt_pageToGoTo/v1_questionnaire-storage.json').then((questionnaireJson) => {
                if(!skipName) {
                    answers.entityName = name;
                }
                answers.isChooseEntityNameLater = skipName;
                answers.currentView = "business/timeframe";
                answers.entityState = state;
                questionnaireJson.answers = JSON.stringify(answers);
                cy.intercept('GET', 'v1/questionnaire-storage', questionnaireJson);
            });
            cy.visit(url, {
                qs: {
                    // Need to pass the following query strings for app initialization
                    uo: 510447944,
                    cartId: 22576931
                }
            });
            break;
        case 'first-llc':
            url = '/business/first-llc';
            cy.fixture('fixt_pageToGoTo/v1_questionnaire-storage.json').then((questionnaireJson) => {
                if(!skipName) {
                    answers.entityName = name;
                }
                answers.isChooseEntityNameLater = skipName;
                answers.currentView = "/business/first-llc";
                answers.entityState = state;
                answers.businessStartTime = startTime;
                questionnaireJson.answers = JSON.stringify(answers);
                cy.intercept('GET', 'v1/questionnaire-storage', questionnaireJson);
            });
            cy.visit(url, {
                qs: {
                    // Need to pass the following query strings for app initialization
                    uo: 510447944,
                    cartId: 22576931
                }
            });
            break;
        case 'industry':
            url = '/business/industry';
            cy.fixture('fixt_pageToGoTo/v1_questionnaire-storage.json').then((questionnaireJson) => {
                if(!skipName) {
                    answers.entityName = name;
                }
                answers.isChooseEntityNameLater = skipName;
                answers.currentView = "business/industry";
                answers.entityState = state;
                answers.businessStartTime = startTime;
                answers.isFirstLLC = isFirstLLC;
                questionnaireJson.answers = JSON.stringify(answers);
                cy.intercept('GET', 'v1/questionnaire-storage', questionnaireJson);
            });
            cy.visit(url, {
                qs: {
                    // Need to pass the following query strings for app initialization
                    uo: 510447944,
                    cartId: 22576931
                }
            });
            break;
        case 'hire-employees':
            url = '/business/hire-employees';
            cy.fixture('fixt_pageToGoTo/v1_questionnaire-storage.json').then((questionnaireJson) => {
                if(!skipName) {
                    answers.entityName = name;
                }
                answers.isChooseEntityNameLater = skipName;
                answers.currentView = "business/hire-employees";
                answers.entityState = state;
                answers.businessStartTime = startTime;
                answers.isFirstLLC = isFirstLLC;
                answers.businessPurpose = bizPurpose;
                questionnaireJson.answers = JSON.stringify(answers);
                cy.intercept('GET', 'v1/questionnaire-storage', questionnaireJson);
            });
            cy.visit(url, {
                qs: {
                    // Need to pass the following query strings for app initialization
                    uo: 510447944,
                    cartId: 22576931
                }
            });
            break;
        case 'registered-agent':
            url = '/essentials/registered-agent';
            cy.fixture('fixt_pageToGoTo/v1_questionnaire-storage.json').then((questionnaireJson) => {
                if(!skipName) {
                    answers.entityName = name;
                }
                answers.isChooseEntityNameLater = skipName;
                answers.currentView = "essentials/registered-agent";
                answers.entityState = state;
                answers.businessStartTime = startTime;
                answers.isFirstLLC = isFirstLLC;
                answers.businessPurpose = bizPurpose;
                answers.hireEmployees = hireEmp;
                questionnaireJson.answers = JSON.stringify(answers);
                cy.intercept('GET', 'v1/questionnaire-storage', questionnaireJson);
            });
            cy.visit(url, {
                qs: {
                    // Need to pass the following query strings for app initialization
                    uo: 510447944,
                    cartId: 22576931
                }
            });
            break;
        case 'critical-docs':
            url = '/essentials/critical-docs';
            cy.fixture('fixt_pageToGoTo/v1_questionnaire-storage.json').then((questionnaireJson) => {
                if(!skipName) {
                    answers.entityName = name;
                }
                answers.isChooseEntityNameLater = skipName;
                answers.currentView = "essentials/critical-docs";
                answers.entityState = state;
                answers.businessStartTime = startTime;
                answers.isFirstLLC = isFirstLLC;
                answers.businessPurpose = bizPurpose;
                answers.hireEmployees = hireEmp;
                answers.lzRA = ra;
                questionnaireJson.answers = JSON.stringify(answers);
                cy.intercept('GET', 'v1/questionnaire-storage', questionnaireJson);
            }); 
            cy.visit(url, {
                qs: {
                    // Need to pass the following query strings for app initialization
                    uo: 510447944,
                    cartId: 22576931
                }
            });
            break;
        case 'Legal':
            url = '/services/legal';
            cy.fixture('fixt_pageToGoTo/v1_questionnaire-storage.json').then((questionnaireJson) => {
                if(!skipName) {
                    answers.entityName = name;
                }
                answers.isChooseEntityNameLater = skipName;
                answers.currentView = "services/legal";
                answers.entityState = state;
                answers.businessStartTime = startTime;
                answers.isFirstLLC = isFirstLLC;
                answers.businessPurpose = bizPurpose;
                answers.hireEmployees = hireEmp;
                answers.lzRA = ra;
                answers.documentsPackage = doc;
                questionnaireJson.answers = JSON.stringify(answers);
                cy.intercept('GET', 'v1/questionnaire-storage', questionnaireJson);
            });
            cy.visit(url, {
                qs: {
                    // Need to pass the following query strings for app initialization
                    uo: 510447944,
                    cartId: 22576931
                }
            });
            break;
        case 'compliance':
            url = '/services/compliance';
            cy.fixture('fixt_pageToGoTo/v1_questionnaire-storage.json').then((questionnaireJson) => {
                if(!skipName) {
                    answers.entityName = name;
                }
                answers.isChooseEntityNameLater = skipName;
                answers.currentView = "services/compliance";
                answers.entityState = state;
                answers.businessStartTime = startTime;
                answers.isFirstLLC = isFirstLLC;
                answers.businessPurpose = bizPurpose;
                answers.hireEmployees = hireEmp;
                answers.lzRA = ra;
                answers.documentsPackage = doc;
                answers.legalAdvice = legal;
                answers.documentsPackage = doc;
                questionnaireJson.answers = JSON.stringify(answers);
                cy.intercept('GET', 'v1/questionnaire-storage', questionnaireJson);
            });
            cy.visit(url, {
                qs: {
                    // Need to pass the following query strings for app initialization
                    uo: 510447944,
                    cartId: 22576931
                }
            });
            break; 
        case 'package-selection':
            url = '/package/package-selection';
            cy.fixture('fixt_pageToGoTo/v1_questionnaire-storage.json').then((questionnaireJson) => {
                if(!skipName) {
                    answers.entityName = name;
                }
                answers.isChooseEntityNameLater = skipName;
                answers.currentView = "/package/package-selection";
                answers.entityState = state;
                answers.businessStartTime = startTime;
                answers.isFirstLLC = isFirstLLC;
                answers.businessPurpose = bizPurpose;
                answers.hireEmployees = hireEmp;
                answers.lzRA = ra;
                answers.documentsPackage = doc;
                answers.legalAdvice = legal;
                answers.totalCompliance = compliance;
                questionnaireJson.answers = JSON.stringify(answers);
                cy.intercept('GET', 'v1/questionnaire-storage', questionnaireJson);
            });
            cy.visit(url, {
                qs: {
                    // Need to pass the following query strings for app initialization
                    uo: 510447944,
                    cartId: 22576931
                }
            });
            break;
        case 'b-of-a-checking':
            url = '/package/b-of-a-checking';
            cy.fixture('fixt_pageToGoTo/v1_questionnaire-storage.json').then((questionnaireJson) => {
                if(!skipName) {
                    answers.entityName = name;
                }
                answers.isChooseEntityNameLater = skipName;
                answers.currentView = "/package/b-of-a-checking";
                answers.entityState = state;
                answers.businessStartTime = startTime;
                answers.isFirstLLC = isFirstLLC;
                answers.businessPurpose = bizPurpose;
                answers.hireEmployees = hireEmp;
                answers.lzRA = ra;
                answers.documentsPackage = doc;
                answers.legalAdvice = legal;
                answers.totalCompliance = compliance;
                answers.packageSelected = pkg;
                questionnaireJson.answers = JSON.stringify(answers);
                cy.intercept('GET', 'v1/questionnaire-storage', questionnaireJson);
            });
            cy.visit(url, {
                qs: {
                    // Need to pass the following query strings for app initialization
                    uo: 510447944,
                    cartId: 22576931
                }
            });
            break;
        case 'review-your-order':
            url = '/checkout/review-your-order';
            cy.fixture('fixt_pageToGoTo/v1_questionnaire-storage.json').then((questionnaireJson) => {
                if(!skipName) {
                    answers.entityName = name;
                }
                answers.isChooseEntityNameLater = skipName;
                answers.currentView = "checkout/review-your-order";
                answers.entityState = state;
                answers.businessStartTime = startTime;
                answers.isFirstLLC = isFirstLLC;
                answers.businessPurpose = bizPurpose;
                answers.hireEmployees = hireEmp;
                answers.lzRA = ra;
                answers.documentsPackage = doc;
                answers.legalAdvice = legal;
                answers.totalCompliance = compliance;
                answers.packageSelected = pkg;
                answers.obtainEIN = "Yes";
                answers.bofa = bofa;
                answers.professionalPrintSelected = profprintSelect;
                answers.bizLicenseOffer = true;
                questionnaireJson.answers = JSON.stringify(answers);
                cy.intercept('GET', 'v1/questionnaire-storage', questionnaireJson);
            });
            cy.visit(url, {
                qs: {
                    // Need to pass the following query strings for app initialization
                    uo: 510447944,
                    cartId: 22576931
                }
            });
            break;
        default:
            console.log("The page name provided is not valid. Please use the page name found in the query string for that page.")
            Cypress.log({
                name: 'goToQ1Page',
                message: 'The page name provided is not valid. Please use the page name found in the query string for that page.'
            });
    };
});

// Helper method for returning specific fixtures based on package type.
const getCartsApiFixture = (pkgType, apiRoute) => {
    switch(pkgType) {                                                                                                                     
        case 145:  // Economy package 
            return (apiRoute == 'balances' ? {fixture: 'fixt_pageToGoTo/v1_carts_22622758_balances_Economy'} : apiRoute == 'printedWelcomePack' ? {fixture: 'fixt_pageToGoTo/v1_carts_22622758_balances_Economy_printingWelcomePack.json'} : {fixture: 'fixt_pageToGoTo/v1_carts_22622758_questionnaire_Economy.json'});
        case 146:  // Standard package
            return (apiRoute == 'balances' ? {fixture: 'fixt_pageToGoTo/v1_carts_22622758_balances_Standard'} : {fixture: 'fixt_pageToGoTo/v1_carts_22622758_questionnaire_Standard.json'});
        case 147:  // Express Gold package
            return (apiRoute == 'balances' ? {fixture: 'fixt_pageToGoTo/v1_carts_22622758_balances_Express'} : {fixture: 'fixt_pageToGoTo/v1_carts_22622758_questionnaire_Express.json'});
        default:
            console.log("Not a valid Package type value. Use 145 for Economy, 146 for Standard or 147 for Express.");
            Cypress.log({
                name: 'goToQ1Page',
                message: 'Not a valid Package type value. Use 145 for Economy, 146 for Standard or 147 for Express'
            });
    };  
};


Cypress.Commands.add('fillOutQuestionnaire1WithOptions', (
  {
    // Set Defaults
    entityName = 'Farse',
    entityState = 'California',
    startBusiness = 'already', // options: already, soon, future
    isFirstLLC = true,
    industry = 'Restaurant',
    hireEmployees = true,
    purchaseRA = true,
    docOptions = 1, // options: 1: Operating agreement, EIN, and licenses
                   //          2: Operating agreement, EIN
                   //          3: Operating agreement
                   //          4: none

    smartEmployer = true, // only used if mockValues.hireEmployees === true
    legalProtect = true,  // only used if mockValues.hireEmployees === false

    totalCompliance = true,
    packageSelection = 1, // options: 1: Tier 1 - Economy
                //          2: Tier 2 - Standard
                //          3: Tier 3 - Express Gold

    boaOffer = false,
    mobile = false,

  } = {}) => {
    // Cleanup optional values
    if (hireEmployees && legalProtect === true) {
        legalProtect = false;
    }
    if (!hireEmployees && smartEmployer === true) {
        smartEmployer = false;
    }

    if (entityName) {
        cy.startQuestionnaireWithAnEntityName(entityName);
        cy.get('.title-2').contains(entityName);
    } else {
        cy.startQuestionnaireWithoutEntity();
    }

    // Set State
    if (mobile) {
        cy.get('#tb-entity-state').select(entityState);
    } else {
        cy.get('#tb-entity-state').type(entityState);
        cy.get('ngb-typeahead-window .dropdown-item').first().click();
    }

    cy.get('#btn-save').click();

    // Name Available
    cy.url().should('include', '/name-available')
    cy.get('.title-2 > span').contains('appears to be available').should('be.visible');
    cy.get('#btn-save').click();

    // When do you want to start your business: options: already, soon, future
    cy.get(`label[for="${ startBusiness }"]`).click();
    cy.get('#btn-save').click();

    // Start with us
    if (mobile) {
        cy.get('#btn-save').click();
    } else {
        cy.get('#llc-overview-next').click();
    }

    // Is this your first LLC
    const firstLLCSelector = 'first-llc-' + (isFirstLLC ? 'yes' : 'no');
    cy.get(`label[for="${ firstLLCSelector }"]`).click();
    cy.get('#btn-save').click();

    // Industry
    cy.get('#tb-biz-industry').type(industry);
    cy.get('#btn-save').click();

    // Hire Employees
    const hireEmployeesSelector = 'hire-employee' + (hireEmployees ? 's-yes' : '-no');
    cy.get(`label[for="${ hireEmployeesSelector }"]`).click();
    cy.get('#btn-save').click();

    // Take Care of Legal Stuff
    cy.get('#btn-save').click();

    // RA
    if (purchaseRA) {
        cy.get('#btn-save').click();
    } else {
        cy.get('#btn-decline-1').click();
        cy.get('#btn-decline-ra').click();
    }

    // Docs
    switch (docOptions) {
        case 1:
        case 2:
        case 3:
        const docOptionsSelector = `rd-docs-${ docOptions }`;
        cy.get(`label[for="${ docOptionsSelector }"]`).click();

        if (mobile) {
            cy.get('#btn-save').click();
        }
        break;

        // Fail
        case 4:
        default:
        cy.get('#btn-decline-1').click();
        break;
    }

    // Legal Protect or Smart Employer Lander
    cy.get('#btn-save').click();

    // Legal Protect or Smart Employer Lander
    if (smartEmployer || legalProtect) {
        cy.get('#btn-save').click();
    } else {
        cy.get('#btn-decline-1').click();
    }

    // Total Compliance
    if (totalCompliance) {
        cy.get('#btn-save').click();
    } else {
        cy.get('#btn-decline-2').click();
    }

    // Package
    const packageSelector = `rd-package-${ packageSelection }`;
    cy.get(`#${ packageSelector }`).click();

    // BOA
    if (boaOffer) {
        cy.get('#btn-accept').click();
    } else {
        cy.get('#btn-decline').click();
    }

    // Wait until on the page, otherwise test is flaky because elements can be detached from DOM
    cy.url().should('include', '/checkout/review-your-order');
});

Cypress.Commands.add('fillOutCheckout', ({
    firstName = 'FN',
    secondName = 'FN',
    email = 'test_' + Date.now().toString() + '@legalzoom.com',
    phone = 8182222222,
    address = '101 N Brand Blvd., Glendale',
    address2 = null,
    city = null,
    state = null,
    zip = null,
    cc = 4111111111111111,
    ccZip = 91203,
    ccExp = '1299',
    ccCSC = '009',
    paymentType = 'multi', // options: multi ( installments )
                        //          single ( one payment )
    proceed = true,
} = {}) => {
    // Personal Info
    cy.get('#fname').type(firstName);
    cy.get('#lname').type(secondName);
    cy.get('#email').type(email);
    cy.get('input#phone').type(phone, {force: true});

    // Address
    cy.get('#address1').type(address);
    cy.get('ngb-typeahead-window .dropdown-item').first().click();

    if (address2 !== null) {
        cy.get('#address2').type(address2);
    }
    if (city !== null) {
        cy.get('#city').type(city);
    }
    if (state !== null) {
        cy.get('#state').select(state);
    }
    if (zip !== null) {
        cy.get('#zip').type(zip);
    }

    // Credit Card
    cy.get('#cc-number').type(cc);
    cy.get('input#billingZip').type(ccZip);
    cy.get('#cc-exp').type(ccExp);
    cy.get('#cc-csc').type(ccCSC);

    // Pay Options
    switch (paymentType) {
        case 'multi':
        cy.get('[for="pay-multi"] .description-option').click();
        break;

        case 'single':
        cy.get('[for="pay-single"] .description-option-single').click();
        break;
    }

    // GeoLocationHandler api call gets CORS error when running the test locally or on docker that results in G-shite page being skipped by the app. 
    // So this is a workaround until the team resolves this error (OPT-383).
    cy.intercept('GET', 'Handlers/geolocationhandler', {
        statusCode: 200
    })

    // Can Proceed
    if (proceed) {
        cy.get('#btn-save').click();
    }
    
});

Cypress.Commands.add('postCheckoutOffers', (isMobile = false) => {
    // API Finalize Order
    cy.intercept('POST', '/v1/orders/cart/*/finalize-order').as('finalizeOrder');

    // Finalize Order API request
    cy.wait('@finalizeOrder', {requestTimeout: 20000}).its('response.body').should('be.true');

    // Express Offers
    cy.url().should('include', '/order/express-offers');

    // Skip EP Products
    cy.get('app-desktop-lz-express-offers .title-2').contains('Awesome').should('be.visible');
    cy.get('#btn-decline').click();

    // Skip G-Suite
    if(isMobile) {
        cy.get('#no-thanks-own-business  .glo-link-action-plain').click();
    }
    else {
        cy.get('#btn-decline-1').click();
    }

    // Order Confirmation
    cy.get('app-order-confirmation .order-confirmation .hero-2').contains('Congrats!').should('be.visible');
    cy.get('button#btn-save').click();
});


// Command to login using "Save Progress" button found in the header of the pages. The arguments are optional and uses default credential if no parameter is passed. 
Cypress.Commands.add('login', ({username = 'cypress@test.com', password = 'test123'} = {}) => {
    cy.get('#lnk-save-progress').click();
    cy.get("[name='email']").type(username);
    cy.get("[name='password']").type(password);
    cy.get("[name='submit']").click();
    cy.get(".auth0-lock-header-logo", { timeout: 10000 }).should('not.exist');
});

// Command to intercept cookieconsentpub call so Accept Cookies banner is not shown
Cypress.Commands.add('hideCookieBanner', () => {
    cy.intercept('GET', 'cookieconsentpub/v1/geo/location', {
        statusCode: 200,
        body: {
            "country": "US",
            "state": "TX",
            "stateName": "Texas",
            "zipcode": "78744",
            "timezone": "America/Chicago",
            "latitude": "30.18260",
            "longitude": "-97.73940",
            "city": "Austin",
            "continent": "NA"
        }
    });
});
