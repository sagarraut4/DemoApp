Cypress.Commands.add('interceptTokensToAllowQ2Interaction', () => {
    // Return "available" from namecheck API
    cy.intercept('GET', 'entitydb/api/v1/availability', { fixture: 'namecheck/available.json' });

    // Intercepting API request to remove 403 requests due to old access tokens
    cy.intercept('POST', '/v1/business-name-check/processing-orders', { fixture: 'namecheck/transaction-log.json' })
        .as('availabilityTransactionLogs');

});

Cypress.Commands.add('businessNameConfirmQ2', () => {
    cy.contains("Cypress automated test", { includeShadowDom: true }).click({ force: true });
    cy.contains("I have reviewed the spelling, spacing, and punctuation of my proposed business name above", { includeShadowDom: true }).click({ force: true });
    cy.contains("Next", { includeShadowDom: true }).click({ force: true });
});

Cypress.Commands.add('assertAddressFormValues', (data, assertion) => {
    data.forEach(item => {
        cy.getByLabel(item[0]).should(assertion, item[1])
    })
});

Cypress.Commands.add('typeAhead', (address, inputLabel) => {
    const autocompleteInput = cy.getByLabel(inputLabel);
    autocompleteInput.clear({ force: true });
    autocompleteInput.type(address, { force: true });
});
