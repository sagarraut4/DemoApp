/**
 * Navigation Commands to move around the application
 */

const StartPage = '/name/state';

Cypress.Commands.add('startQuestionnaireWithAnEntityName', (entityName = 'Farse') => {
  cy.visit(
    StartPage,
    {
      qs: {
        entity: entityName,
      },
    },
  );
});

Cypress.Commands.add('startQuestionnaireWithoutEntity', () => {
  cy.visit(
    StartPage,
    {
      qs: {
        choose_later: true,
      },
    },
  );
});
