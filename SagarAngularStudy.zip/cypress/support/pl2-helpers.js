/**
 * Mobile Pattern Lib2 Helper Selectors
 */

// Choose a PL2 Selector
Cypress.Commands.add('pl2Select', (selector) => {
  cy.get(selector)
    .shadow()
    .find('input + label');
});

// Choose a PL2 Input
Cypress.Commands.add('pl2Input', (selector) => {
  cy.get(selector)
    .shadow()
    .find('input');
});
// Choose a PL2 Input
Cypress.Commands.add('pl2InputError', (selector) => {
  cy.get(selector)
    .shadow()
    .find('.pl-alert');
});

// Choose a PL2 Button
Cypress.Commands.add('pl2Button', (selector) => {
  cy.get(selector)
    .shadow()
    .find('button');
});

// Choose a PL2 Counter
Cypress.Commands.add('pl2Counter', (selector, task) => {
  const tasks = ['increase', 'decrease', 'value'];
  const [increaseTask, decreaseTask, valueTask] = tasks;
  let internalSelector;

  switch (task) {
    case decreaseTask:
      internalSelector = '.pl-prev';
      break;
    case valueTask:
      internalSelector = 'label input[type="number"]';
      break;
    case increaseTask:
      internalSelector = '.pl-next';
      break;

    default:
      throw new Error(`Please provide a valid second parameter. You can only have the following: ${tasks}`);
      break;
  }

  cy.get(selector)
    .shadow()
    .find(internalSelector);
});
