describe('LLC Filing Fee Tests', () => {

    before(() => {
        // Don't show cookie banner
        cy.hideCookieBanner();
    });

    beforeEach(() => {
        // clear session storage before each test
        cy.window().then((win) => {
            win.sessionStorage.clear()
      });
    });

    // Data-driven test using
    // Need to load the data for the test before the test execution begins
    const stateFees = require('../../fixtures/statefilingfees.json');

    stateFees.forEach((stateFee) => {
        
        it('Filing fees should correctly display in Q1 on both Package Selection and checkout pages for ${stateFee.name}. RT-08189, RT-08181',()=> {
            
            cy.visit('/name/state?entity=LLCTest');
            cy.intercept('POST', 'v1/questionnaire-storage').as('apiCall');
            cy.get('#tb-entity-state').type(stateFee.name);
            cy.get('#ngb-typeahead-0-0').click();
            cy.get('#btn-save').click();
            cy.wait('@apiCall').then(() => {
                cy.get('span.ng-star-inserted', { timeout: 10000 }).contains('LLCTest appears to be available').should('be.visible');
                cy.get('#btn-save').click();
                cy.get('label[for="already"]').click();
                cy.get('#btn-save').click();
                cy.get('#llc-overview-next').click();
                cy.get('label[for="first-llc-yes"]').click();
                cy.get('#btn-save').click();
                cy.get('#tb-biz-industry').type('Restaurant');
                cy.get('#btn-save').click();
                cy.get('label[for="hire-employees-yes"]').click();
                cy.get('#btn-save').click();
                cy.get('#btn-save').click();
                cy.get('#btn-decline-1').click();
                cy.get('#btn-decline-ra',{timeout: 10000}).click();
                cy.get('#btn-decline-1').click();
                cy.get('#btn-save').click();
                cy.get('#btn-decline-1').click();
                cy.get('#btn-decline-2').click();
                cy.get('#rd-package-3').click();
                cy.get('#btn-decline').click();
                //Verfiying LLC Package and state filling fees
                cy.get('#item-details-805',{timeout:20000}).contains(stateFee.fee).should('be.visible');
                //Clicking on Edit button on package section to select a different package
                cy.get('#order-item-147').contains('Edit').click({ force: true });
                //Clicking on Standard package and checking the filing fee
                cy.get("label[for='review_llc_package_standard']").click();
                cy.get('#btn-update').click();
                cy.get('#item-details-805',{timeout:10000}).contains(stateFee.fee).should('be.visible');
                cy.get('#order-item-147').contains('Edit').click({ force: true });
                //Clicking on Economy package and checking the filing fee
                cy.get("label[for='review_llc_package_economy']").click();
                cy.get('#btn-update').click();
                cy.get('#item-details-805',{timeout:10000}).contains(stateFee.fee).should('be.visible');
            });
        });
    });
});
