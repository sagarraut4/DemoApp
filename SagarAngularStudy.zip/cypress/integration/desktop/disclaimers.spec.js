describe('Disclaimers - RT-09387', () => {

    before(() => {
        // Don't show cookie banner
        cy.hideCookieBanner();
    });

    beforeEach(() => {
        // clear session storage before each test
        cy.window().then((win) => {
            win.sessionStorage.clear()
        });
        cy.readFile('cypress/fixtures/disclaimers/RT-10906.json').its('RT-10906').then((RT10906)=>{
        });    
    });

    it('should verify disclaimer on RA page (Step 15)', () => {
        cy.goToQ1Page({pageToGoTo: 'registered-agent', hireEmp: 'no'}) // Using custom command that directly takes to the desire page passed as an argument. 
        cy.get('#disclaimer .disclaimer-content').should('not.exist'); // Verifying that the Terms should not be visible when initially landing on the page.
        cy.get('span.glo-link-action-plain').click();

        // Verifying the disclaimer by comparing the disclaimer text captured from the UI with that of the text saved in the text file.
        cy.get('#disclaimer .disclaimer-content').then(($disclaimer) => {
            const actualDisclaimer = $disclaimer.text();
            cy.readFile('cypress/fixtures/disclaimers/RA_terms.txt').should('eq', actualDisclaimer);
        });
    });

    it('should verify disclaimer on Legal Protect page (Step 19)', () => {
        cy.goToQ1Page({pageToGoTo: 'Legal', hireEmp: 'no'}) // Using custom command that directly takes to the desire page passed as an argument. 
        cy.get('#disclaimer .content-3').should('not.exist'); // Verifying that the Terms should not be visible when initially landing on the page.
        cy.get('span .see-terms').click();

        // Verifying the disclaimer by comparing the disclaimer text captured from the UI with that of the text saved in the text file.
        cy.get('#disclaimer .content-3').then(($disclaimer) => {
            const actualDisclaimer = $disclaimer.text();
            cy.readFile('cypress/fixtures/disclaimers/Legal_Protect_terms.txt').should('eq', actualDisclaimer);
        });
    });

    it('should verify disclaimer on Compliance page (Step 20)', () => {
        cy.goToQ1Page({pageToGoTo: 'compliance', hireEmp: 'no'}) // Using custom command that directly takes to the desire page passed as an argument. 
        cy.get('#disclaimer').should('not.exist'); // Verifying that the Terms should not be visible when initially landing on the page
        cy.get('#view-terms').click();

        // Verifying the disclaimer by comparing the disclaimer text captured from the UI with that of the text saved in the text file.
        cy.get('#disclaimer').then(($disclaimer) => {
            const actualDisclaimer = $disclaimer.text();
            cy.readFile('cypress/fixtures/disclaimers/Compliance_terms.txt').should('eq', actualDisclaimer);
        });
    });

    it('should verify disclaimer on Package Selection page (Step 21)', () => {
        cy.goToQ1Page({pageToGoTo: 'package-selection', hireEmp: 'no'}) // Using custom command that directly takes to the desire page passed as an argument. 

        // Verifying the disclaimer by comparing the disclaimer text captured from the UI with that of the text saved in the text file.
        cy.get('div .component--text-muted.mt-9').then(($disclaimer) => {
            const actualDisclaimer = $disclaimer.text();
            cy.readFile('cypress/fixtures/disclaimers/PackageSelection_terms.txt').should('eq', actualDisclaimer); 
        });
    });

    it('should verify disclaimer on Bank of America page (Step 22)', () => {
        cy.goToQ1Page({pageToGoTo: 'b-of-a-checking', hireEmp: 'no'}); // Using custom command that directly takes to the desire page passed as an argument. 
        
        // Verifying the disclaimer by comparing the disclaimer text captured from the UI with that of the text saved in the text file.
        cy.get('div .disclaimer').then(($disclaimer) => {
            const actualDisclaimer = $disclaimer.text();
            cy.readFile('cypress/fixtures/disclaimers/BankOfAmerica_terms.txt').should('eq', actualDisclaimer);
        });
    });

    it('should verify disclaimer on Checkout page (Step 26)', () => {
        cy.goToQ1Page({pageToGoTo: 'review-your-order', hireEmp: 'no'}); // Using custom command that directly takes to the desire page passed as an argument. 
        cy.get('#btn-save', { timeout: 10000 }).click(); // Clicking on "Continue to checkout" button in RYO page to go to the Checkout page

        // Entering data in checkout form.
        cy.get('#fname').type('TestFirstName');
        cy.get('#lname').type('TestLastName');
        cy.get('#email').type('test@qa.com');
        cy.get('input#phone').type('3102223333',{force: true});
        cy.get('#address1').type('101 N Brand Blvd., Glendale');
        cy.get('button.dropdown-item.active').click();
        cy.get('#cc-number').type('4111111111111111');
        cy.get('input#billingZip').type('91203');
        cy.get('#cc-exp').type('0950');
        cy.get('#cc-csc').type('009');
        cy.get('[for="pay-single"] .description-option-single').click();

        // Verifying the disclaimer by comparing the disclaimer text captured from the UI with that of the text saved in the text file.
        cy.get('div.checkout-disclaimer').then(($disclaimer) => {
            const actualDisclaimer = $disclaimer.text();
            cy.readFile('cypress/fixtures/disclaimers/Checkout_terms.txt').should('eq', actualDisclaimer);
        });
     });

     it('Should verify disclaimers in checkout & Smart Employer pages - state: Wisconsin. RT-10906',()=>{
        cy.visit('/name/state?entity=LLC TestOrder');
        cy.intercept('POST', 'v1/questionnaire-storage').as('apiCall');
        cy.get('#tb-entity-state').type('Wisconsin');
        cy.get('#ngb-typeahead-0-0').click();
        cy.get('#btn-save').click();
        cy.wait('@apiCall').then(() => {
            cy.get('span.ng-star-inserted', { timeout: 10000 }).contains('LLC TestOrder appears to be available').should('be.visible');
            //Verifying Agreement in 'Name Available' page  
            cy.fixture('/disclaimers/RT-10906.json').its('RT-10906').then((RT10906)=>{  
                cy.get('p.caption-1.agreement').contains(RT10906.NameAvailableAgreement).should('be.visible');  
                cy.get('#btn-save').click();
                cy.get('label[for="already"]').click();
                cy.get('#btn-save').click();
                cy.get('#llc-overview-next').click();
                cy.get('label[for="first-llc-yes"]').click();
                cy.get('#btn-save').click();
                cy.get('#tb-biz-industry').type('Restaurant');
                cy.get('#btn-save').click();
                cy.get('label[for="hire-employees-yes"]').click();
                cy.get('#btn-save').click();
                cy.get('#btn-save').click();
                //Verifying Disclaimer at Registered Agent page   
                cy.get('div.content-3.col-lg-8.offset-lg-2 > span').contains(RT10906.RegisteredAgentDisc).should('be.visible');  
                cy.get('#btn-save').click();
                cy.get('label[for="rd-docs-1"]').click();
                cy.get('#btn-save').click();
                //Verifying Disclaimer Smart Employer page
                cy.get('div.legal-disclaimer.content-3.text-md-center.col-12.col-lg-8.offset-lg-2 > span').contains(RT10906.SmartEmployerDisc).should('be.visible');
                cy.get('span.glo-link-action-plain.see-terms').click();
                //Verifying terms after clicking on 'View Terms' link at Smart Employer page    
                cy.get('p.content-3 > i').contains(RT10906.SmartEmployerTerms).should('be.visible');
                cy.get('#btn-save').click();    
                cy.get('#btn-save').click();    
                cy.get('#rd-package-3').click();
                cy.get('#btn-decline').click();
                //making sure Wisconsin filling fees are visible
                cy.get("#item-details-805",{timeout:20000}).contains('$155').should('be.visible');
                cy.get('#btn-save', { timeout: 20000 }).click();
                cy.contains('[for="pay-single"] .description-option-single', /[1-9]/).click();
                //Verfiying in the disclaimer if ($15.99/month) is added in checkout page.
                cy.get('.checkout-disclaimer').contains(RT10906.CheckoutDisc).should('be.visible');
            });
        });
    });
}); 