describe('Entity NameCheck [MA-91]', () => {

  before(() => {
    // Don't show cookie banner
    cy.hideCookieBanner();
  });
  
  beforeEach(() => {
    // clear session storage before each test
    cy.window().then((win) => {
      win.sessionStorage.clear();
    });

    // Clear Cookies
    cy.clearCookies();
  });

  describe('e2e with all addons (TN) [MA-100]', () => {
    it('should go through Q1 ( with all addons ) and then lookup an entity name and finalize Q2', () => {
      const COMPANY_NAME = 'Farse';
      const ENTITY_STATE = 'Tennessee';
      const ENTITY_STATE_ABBREVIATION = 'TN';

      // Fill Out Q1
      cy.fillOutQuestionnaire1WithOptions(
        {
          entityName: COMPANY_NAME,
          entityState: ENTITY_STATE,
          industry: 'Caas'
        }
      );

      // Push through RYO
      cy.get('#btn-save').click();

      // Fill Out Checkout Page
      cy.fillOutCheckout({
        state: ENTITY_STATE,
        proceed: false
      });

      // Disclaimer
      cy.get('.tn-disc-confirm > label').click();

      // Submit
      cy.get('#btn-save').click();

      // Post Checkout Options
      cy.postCheckoutOffers();

      // Set up API intercept
      cy.intercept('GET', '/entitydb/api/v1/availability').as('getEntityAvailability');
      cy.intercept('POST', '/v1/business-name-check/processing-orders').as('availabilityTransactionLogs');

      cy.get('#tb-biz-name')
        .should('have.value', COMPANY_NAME);

      cy.get('#business-name-next').click();

      // Await API Responses
      cy.wait('@getEntityAvailability')
        .its('response.body')
        .should('include', { 'status': 'available' });
      cy.wait('@availabilityTransactionLogs')
        .its('response.body')
        .should('include', { 'success': true });

      cy.get('#namecheck-results-confirmation-header').contains(COMPANY_NAME);

      // Tooltip - test visibility
      const toolTipIconRef = '#business-designator-info .pl-tip-icon';
      const toolTipRef = '#business-designator-info .pl-tooltip';

      cy.get(toolTipIconRef).click();
      cy.get(toolTipRef)
        .should('satisfy', ($el) => {
          const classList = Array.from($el[0].classList);
          return classList.includes('pl-show'); // passes
        });
      cy.get(toolTipIconRef).blur();
      cy.get(toolTipRef)
        .should('satisfy', ($el) => {
          const classList = Array.from($el[0].classList);
          return !classList.includes('pl-show'); // passes
        });

      // Select Designator & Checkbox
      cy.get('.radio-text[for="business-name-designator-choice-0"]').click();
      cy.get('label[for="business-name-reviewed-checkbox"]').click({ force: true });

      // Submit Section
      cy.get('#agent-name-next').click();

      // Progress Passed Business Address
      cy.get('#business-address-next').click();

      // Required Business Email for TN
      cy.get('label[for="tb-biz-email"]').type('cypressautomationtest@legalzoom.com');
      cy.get('#biz-email-btn').click();

      // Professional LLC
      cy.get('label[for="rd-pllc-2"]').click();
      cy.get('#business-license-next').click();

      const dataSelectorDelay = 500;

      // Dissolve Date
      cy.get('label[for="rd-dissolve-biz-1"]').click();
      cy.get('#dp-dissolve-date').click();
      cy.wait(dataSelectorDelay);
      cy.get('.ngb-dp-today + .ngb-dp-day').click();
      cy.wait(dataSelectorDelay);
      cy.get('#business-dissolve-next').click();

      // Business Owners
      cy.get('label[for="cb-owner-trust"]').click();
      cy.get('#tb-owner-trust-name-0').type('Abc');
      cy.get('#management-owner-next').click();

      // Business Manager
      cy.get('#tb-manager-name-0').type('Abc', { force: true });
      cy.get('#management-manager-next').click();

      // IRS Contact
      cy.get('label[for="tb-rd-trust0"]').first().click();
      cy.get('#tb-trust-first-name0').type('Abc');
      cy.get('#tb-trust-last-name0').type('Abc');
      cy.get('#tb-trust-phone-number0').type('1234567890');
      cy.get('#tb-trust-ssn-area0').type('123');
      cy.get('#tb-trust-ssn-group0').type('12');
      cy.get('#tb-trust-ssn-serial0').type('1234');
      cy.get('#management-irs-next').click();

      // DBA
      cy.get('label[for="rd-dba-1"]').click();
      cy.get('#tb-dba-name').type('Abc', { force: true });
      cy.get('#irs-dba-next').click();

      // Business Details
      cy.get('label[for="pl-22"]').click({ force: true });
      cy.get('label[for="pl-23"]').click({ force: true });
      cy.get('label[for="pl-24"]').click({ force: true });
      cy.get('label[for="pl-25"]').click({ force: true });
      cy.get('#irs-details-next').click();

      // Employment Hiring
      cy.get('label[for="rd-employees-1"]').click();
      cy.get('#pl-increment-agriculture .pl-next').click();
      cy.get('#pl-increment-agriculture .pl-next').click();
      cy.get('#pl-increment-household .pl-next').click();
      cy.get('#pl-increment-other-employee .pl-next').click();
      cy.get('#irs-hiring-next').click();

      // Start Paying Employees
      cy.get('#dp-emp-pay-date').click();
      cy.wait(dataSelectorDelay);
      cy.get('.ngb-dp-today + .ngb-dp-day').click();
      cy.wait(dataSelectorDelay);
      cy.get('label[for="rd-emp-pay-threshold-1"]').click({ force: true });
      cy.get('#irs-pay-next').click();

      // Fiscal Year
      cy.get('#fiscal-end-next').click();

      // Submit Form
      cy.get('#btn-submit').click();

      // Finalize Order API request
      cy.wait('@finalizeOrder').its('response.body').should('be.true');

      // Special Offers
      cy.get('#consultations-btn').click();

      // Cutting the ribbon & Congrats Page
      cy.get('.ribbon-container').click();
      cy.get('.store-name').should('contain', COMPANY_NAME);
      cy.get('#order-confirmation-next').should('be.visible');
    });
  });

  describe('e2e with all no addons (NV) [MA-101]', () => {
    it('should go through Q1 ( without all addons ) and then lookup an entity name and finalize Q2', () => {
      const COMPANY_NAME = 'Farse';
      const ENTITY_STATE = 'Nevada';
      const ENTITY_STATE_ABBREVIATION = 'NV';

      // Fill Out Q1
      cy.fillOutQuestionnaire1WithOptions(
        {
          entityName: COMPANY_NAME,
          entityState: ENTITY_STATE,
          industry: 'Caas',
          startBusiness: 'future',
          isFirstLLC: false,
          hireEmployees: false,
          docOptions: 4,
          totalCompliance: false,
          packageSelection: 1,
          boaOffer: false
        }
      );

      // Push through RYO
      cy.get('#btn-save').click();

      // Fill Out Checkout Page
      cy.fillOutCheckout({
        state: ENTITY_STATE
      });

      // Post Checkout Options
      cy.postCheckoutOffers();

      // Set up API intercept
      cy.intercept('GET', '/entitydb/api/v1/availability').as('getEntityAvailability');
      cy.intercept('POST', '/v1/business-name-check/processing-orders').as('availabilityTransactionLogs');

      cy.get('#tb-biz-name')
        .should('have.value', COMPANY_NAME);

      cy.get('#business-name-next').click();

      // Await API Responses
      cy.wait('@getEntityAvailability')
        .its('response.body')
        .should('include', { 'status': 'available' });
      cy.wait('@availabilityTransactionLogs')
        .its('response.body')
        .should('include', { 'success': true });


      cy.get('#namecheck-results-confirmation-header').contains(COMPANY_NAME);
      cy.get('#business-name-explanation-container textarea[formcontrolname="businessNameExplanation"]')
        .type('Lorem ipsum and some soup my friend.')
        .click({ force: true });

      // Select Designator & Checkbox
      cy.get('.radio-text[for="business-name-designator-choice-0"]').click();
      cy.get('label[for="business-name-reviewed-checkbox"]').click({ force: true });

      // Submit Section
      cy.get('#agent-name-next').click();

      // Progress Passed Business Address
      cy.get('#business-address-next').click();

      // Professional LLC
      cy.get('label[for="rd-pllc-2"]').click();
      cy.get('#business-license-next').click();

      // Dissolve Date
      cy.get('label[for="rd-dissolve-biz-2"]').click();
      cy.get('#business-dissolve-next').click();

      // Business Owners
      cy.get('label[for="cb-owner-trust"]').click();
      cy.get('#tb-owner-trust-name-0').type('Abc');
      cy.get('#management-owner-next').click();

      // Business Manager
      cy.get('#tb-manager-name-0').type('Abc', { force: true });
      cy.get('#management-manager-next').click();

      // Fiscal Year
      cy.get('#fiscal-end-next').click();

      // Submit Form
      cy.get('#btn-submit').click();

      // Finalize Order API request
      cy.wait('@finalizeOrder').its('response.body').should('be.true');

      // Special Offers
      cy.get('#consultations-btn').click();

      // Cutting the ribbon & Congrats Page
      cy.get('.ribbon-container').click();
      cy.get('.store-name').should('contain', COMPANY_NAME);
      cy.get('#order-confirmation-next').should('be.visible');
    });
  });

  describe('Partial Flow - VA - Happy Path [MA-102]', () => {
    it('should verify business designator options for Q2', () => {
      const testBusinessName = 'Dog Taco and Grooming';

      // Return "available" from namecheck API
      cy.intercept('GET', 'entitydb/api/v1/availability', { fixture: 'namecheck/available.json' });

      // Intercepting API request to remove 403 requests due to old access tokens
      cy.intercept('POST', '/v1/business-name-check/processing-orders', { fixture: 'namecheck/transaction-log.json' })
        .as('availabilityTransactionLogs');

      cy.goToQ2('Virginia', testBusinessName);

      // Advance to Progress screen
      cy.get('#business-name-next').click();

      // Verify all three business designators are appended to business name
      cy.get('#rd-entity0 > label.radio-text').contains(`${testBusinessName} LLC`);
      cy.get('#rd-entity1 > label.radio-text').contains(`${testBusinessName} L.L.C.`);
      cy.get('#rd-entity2 > label.radio-text').contains(`${testBusinessName} Limited Liability Company`);

      // Select 1st business designator option
      cy.get('#rd-entity0 > label.radio-text').click();

      // Click review checkbox
      cy.get('#review-checkbox > label').click({ force: true });

      // Advance to next screen
      cy.get('#agent-name-next').click();

      cy.get('#business-address-panel').should('be.visible');
    });

  });

  describe('Partial Flow - MA - 3 Failures [MA-103]', () => {
    beforeEach(() => {
      // Intercepting API request to remove 403 requests due to old access tokens
      cy.intercept('POST', '/v1/business-name-check/processing-orders', { fixture: 'namecheck/transaction-log.json' })
        .as('availabilityTransactionLogs');
    });

    it('should show validation failed page and can continue to business address after 3 failed namechecks with matching violation', () => {

      cy.goToQ2('Massachusetts', 'SomeMatchingName');

      // Return error with matching
      cy.intercept('GET', 'entitydb/api/v1/availability', { fixture: 'namecheck/unavailable_matching.json' });

      cy.get('#business-name-next').click();

      // Verify that you get the error message
      cy.get('div.error-list span').contains('Close similarities to an existing business name');

      // Try again
      cy.get('#tb-biz-name').clear().type('Some.Matching.Name');
      cy.get('#business-name-next').click();

      // Verify that you get the error message
      cy.get('div.error-list span').contains('Close similarities to an existing business name');

      // And again
      cy.get('#tb-biz-name').clear().type('somematchingname');
      cy.get('#business-name-next').click();

      // Verify that you get the validation failed page
      cy.get('#business-name-description-error')
        .should('be.visible')
        .contains('We\'ll do one more check on');

      // Proceed
      cy.get('#business-name-next').click();

      // Verify on Business Address
      cy.get('#business-address-panel').should('be.visible');
    });

    it('should show validation failed page and can continue to business address after 3 failed namechecks with profanity violation', () => {

      cy.goToQ2('Massachusetts', 'SomeProfaneName');

      // Return error with profanity
      cy.intercept('GET', 'entitydb/api/v1/availability', { fixture: 'namecheck/unavailable_profanity.json' });

      cy.get('#business-name-next').click();

      // Verify that you get the error message
      cy.get('div.error-list span').contains('Inappropriate words or language');

      // Try again
      cy.get('#tb-biz-name').clear().type('Some.Profane.Name');
      cy.get('#business-name-next').click();

      // Verify that you get the error message
      cy.get('div.error-list span').contains('Inappropriate words or language:');

      // And again
      cy.get('#tb-biz-name').clear().type('someprofanename');
      cy.get('#business-name-next').click();

      // Verify that you get the validation failed page
      cy.get('#business-name-description-error')
        .should('be.visible')
        .contains('We\'ll do one more check on');

      // Proceed
      cy.get('#business-name-next').click();

      // Verify on Business Address
      cy.get('#business-address-panel').should('be.visible');
    });
  });

  describe('Submit invalid name three times and continue [MA-205]', () => {
    beforeEach(() => {
      // Intercepting API request to remove 403 requests due to old access tokens
      cy.intercept('POST', '/v1/business-name-check/processing-orders', { fixture: 'namecheck/transaction-log.json' })
        .as('availabilityTransactionLogs');
    });

    it('should show validation failed page and can continue to business address after 3 failed namechecks with matching violation', () => {
      const businessName = 'null';
      cy.goToQ2('Massachusetts', businessName);

      // Return error with matching
      cy.intercept('GET', 'entitydb/api/v1/availability', { fixture: 'namecheck/unavailable_matching.json' });

      cy.get('#business-name-next').click();

      // Verify that you get the error message
      cy.get('div.error-list span').contains('Close similarities to an existing business name');

      // Try again
      cy.get('#business-name-next').click();

      // Verify that you get the error message
      cy.get('div.error-list span').contains('Close similarities to an existing business name');

      // And again
      cy.get('#business-name-next').click();

      // Verify that you get the validation failed page
      cy.get('#business-name-description-error')
        .should('be.visible')
        .contains('We\'ll do one more check on');

      // Proceed
      cy.get('#business-name-next').click();

      // Verify on Business Address
      cy.get('#business-address-panel').should('be.visible');
    });
  });

  describe('Partial Flow - TN - Try Another Name Even with Valid Response [MA-104]', () => {
    it('should verify that user can choose another name even if first name is available', () => {

      cy.goToQ2('Tennessee', 'SomeAvailableName');

      // Return "available" from namecheck
      cy.intercept('GET', 'entitydb/api/v1/availability', { fixture: 'namecheck/available.json' });
      // Intercepting API request to remove 403 requests due to old access tokens
      cy.intercept('POST', '/v1/business-name-check/processing-orders', { fixture: 'namecheck/transaction-log.json' })
        .as('availabilityTransactionLogs');

      cy.get('#business-name-next').click();

      // Choose different name
      cy.get('#check-different-name').should('be.visible').click({ force: true });

      // Name field should be empty tb-biz-name
      cy.get('#tb-biz-name').should('be.empty');

      // Submit a 2nd name
      const bizName = 'Bluth Bananas';
      cy.get('#tb-biz-name').type(bizName);
      cy.get('#business-name-next').click();

      // Verify that name is available
      cy.get('#namecheck-results-confirmation-header').contains(bizName);
      cy.get('#namecheck-results-confirmation-header').contains('appears to be available!');

      // Choose designator and continue
      cy.get('#business-name-designator-choice-0').click({ force: true });
      cy.get('#business-name-reviewed-checkbox').click({ force: true });
      cy.get('#agent-name-next').click();

      // Verify on Business Address
      cy.get('#business-address-panel').should('be.visible');
    });
  });

  describe('Partial Flow - KS - 500 API Error [MA-105]', () => {
    it('Verify "check a different name" link does not display ', () => {
      const testBusinessName = 'Dog Taco and Grooming';

      // Return "available" from namecheck API
      cy.intercept('GET', 'entitydb/api/v1/availability', { statusCode: 500 });
      cy.goToQ2('Kansas', testBusinessName);

      // Advance to Progress screen, then to Validation Failed screen due to API error
      cy.get('#business-name-next').click();

      // Negative assertion
      // Search body for link presence, fail if found
      cy.get('body').then($body => {
        const $checkADifferentNameLink = $body.find('#business-name-new');
        if ($checkADifferentNameLink.length > 0) {
          assert.isNotOk($checkADifferentNameLink.length > 0, '"Check a different name" link should not be displayed');
        } else {
          assert.isOk($checkADifferentNameLink.length === 0, '"Check a different name" link is not displayed');
        }
      });
    });
  });

  describe('Partial Flow - VT - API General Similarity response flow [MA-232]', () => {
    it('should take user to invalid flow', () => {
      const testBusinessName = 'bennington community theather mbe';

    // Intercepting API request to remove 401 requests due to old access tokens
      cy.intercept('POST', '/v1/business-name-check/processing-orders', { fixture: 'namecheck/transaction-log.json' })

      cy.intercept('GET', 'entitydb/api/v1/availability', { 
        statusCode: 200,
        fixture: 'namecheck/general-similarity.json'
      });
      cy.goToQ2('Vermont', testBusinessName);

      // Advance to Progress screen, then to Validation Failed screen due to API error
      cy.get('#business-name-next').click();

      // Verify that you get the error message
      cy.get('div.error-list span').contains('Close similarities to an existing business name');
    });
  });

  describe('Partial Flow - TX - Skip Business Name [MA-107]', () => {
    const getEntityAvailabilityStates = {
      available: 'namecheck/available.json',
      unavailable: 'namecheck/unavailable_matching.json'
    };
    let getEntityAvailabilityState = 'available';

    // Entity Name
    const testBusinessName = 'Farse';

    beforeEach(() => {
      // Reset State
      getEntityAvailabilityState = 'available';

      // Intercept availability response
      cy.intercept(
        'GET',
        'entitydb/api/v1/availability',
        (req) => {
          const fixture = getEntityAvailabilityStates[getEntityAvailabilityState];
          req.reply({ fixture });
        }
      ).as('getEntityAvailability');

      // Intercepting API request to remove 403 requests due to old access tokens
      cy.intercept('POST', '/v1/business-name-check/processing-orders', { fixture: 'namecheck/transaction-log.json' })
        .as('availabilityTransactionLogs');

      cy.goToQ2('Texas', null);
    });

    it('should be able to choose an entity name', () => {
      // Name field should be empty tb-biz-name
      cy.get('#tb-biz-name').should('be.empty');

      // Advance to Progress screen
      cy.get('#business-name-next').click();

      cy.get('.pl-alert-error > div').contains('Business name is required');

      // Allowing Cypress to find a error
      cy.wait(500);

      // Type in Entity Name
      cy.get('#tb-biz-name').type(testBusinessName);

      // Advance to Progress screen
      cy.get('#business-name-next').click();

      // Wait For API requests
      cy.wait('@getEntityAvailability');
      cy.wait('@availabilityTransactionLogs');

      // Verify all three business designators are appended to business name
      cy.get('#rd-entity0 > label.radio-text').contains(`${testBusinessName} LLC`);
      cy.get('#rd-entity1 > label.radio-text').contains(`${testBusinessName} L.L.C.`);
      cy.get('#rd-entity2 > label.radio-text').contains(`${testBusinessName} Limited Liability Company`);

      // Select 1st business designator option
      cy.get('#rd-entity0 > label.radio-text').click();

      // Click review checkbox
      cy.get('#review-checkbox > label').click({ force: true });

      // Advance to next screen
      cy.get('#agent-name-next').click();

      cy.get('#business-address-panel').should('be.visible');
    });

    it('should be able to fail then select a valid entity', () => {
      // Start Availability as Unavailable
      getEntityAvailabilityState = 'unavailable';

      // Name field should be empty tb-biz-name
      cy.get('#tb-biz-name').should('be.empty');

      // Type in Entity Name
      cy.get('#tb-biz-name').type(testBusinessName);

      // Advance to Progress screen
      cy.get('#business-name-next').click();

      // Verify that you get the error message
      cy.get('div.error-list span').contains('Close similarities to an existing business name');

      // Wait For API requests
      cy.wait('@getEntityAvailability');
      cy.wait('@availabilityTransactionLogs').then(
        () => {
          getEntityAvailabilityState = 'available';
        }
      );

      // Try again
      cy.get('#tb-biz-name').clear()
        .type(`${testBusinessName} ${testBusinessName}`);
      cy.get('#business-name-next').click();

      cy.wait('@getEntityAvailability');
      cy.wait('@availabilityTransactionLogs');

      // Select 1st business designator option
      cy.get('#rd-entity0 > label.radio-text').click();

      // Click review checkbox
      cy.get('#review-checkbox > label').click({ force: true });

      // Advance to next screen
      cy.get('#agent-name-next').click();

      cy.get('#business-address-panel').should('be.visible');
    });
  });
});
