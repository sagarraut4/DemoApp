const typeAheadInput = "Address line 1"

describe('Address-Native Form and Autocomplete', () => {

  before(() => {
    // Don't show cookie banner
    cy.hideCookieBanner();
  });

  beforeEach(() => {
    // clear session storage before each test
    cy.window().then((win) => {
      win.sessionStorage.clear();
    });

    // Clear Cookies
    cy.clearCookies();
  });

  // Multiple Assertions here to save setup time
  it('checks business address confirmation form for correct values before and after autocomplete suggestions - [OPT-147]', () => {
    // Checking default values are populated from Q1
    navigateToQ2BusinessAddress();
    cy.assertAddressFormValues([
      ['Address line 1', '101 N Brand Blvd'],
      ['City', 'Glendale'],
      ['State', 'CA'],
      ['ZIP Code', '91203']
    ],
      'have.value');
    conductTypeAheadSelectionsAndAssert();
  });

  // This one needs work
  // There are two sets of address form elements on the page for registered agent address
  // Need to test the correct form elements
  it('checks registered agent address form for correct values before and after autocomplete suggestions - [OPT-147]', () => {
    // Current problem is when asserting and finding by input by label there is more than 1 label on the screen
    // with the same label name except one is hidden and the other is not. 
    goToRegisteredAgentQ2();
    conductTypeAheadSelectionsAndAssert('1')
  });

  it('Should go over Q2 flow and make sure errors appear if required fields are empty, checkmarks are appearing next to the answered questions, and "more info" modals are working properly - RT-14913, RT-14909',() => {

    //Navigating to Business Address page in Q2
    navigateToQ2BusinessAddress();
  
    //error should appear if a radio button is not selected at Business name page
    cy.get('.col-12.has-form-error.business-name-designator-error-required.ng-star-inserted').contains('Please make a selection ').should('be.visible');
    //selecting the first name
    cy.get('label[for="business-name-designator-choice-0"]').click({ multiple: true });
    //making sure error appears after clicking next if checkbox isn't selected
    cy.get('#agent-name-next').click();
    //making sure green color checkmark appears next to business name text
    cy.get('#business-name > svg').should('be.visible');


    //clicking next on business address page and making sure green color checkmark appears next to the text
    cy.get('#business-address-next').click();
    cy.get('#business-address > svg').should('be.visible');


    //clicking on 'more info' hyprelink on Professional License page and making sure it's working properly
    cy.get('#business-license-more').click();
    cy.get('.pl-h3').contains('Professional LLC').should('be.visible');
    //closing the modal
    cy.get("div[id='business-license-modal'] button[type='button']").click();
    //clicking next on business license page without selecting any field and making sure it throws an error
    cy.get('#biz-lic-btn').click();
    cy.get('.mt-3.pl-alert').contains(' Please select an answer. ').should('be.visible');
    //clicking on 'No' button
    cy.get('label[for="rd-pllc-2"]').click();
    //clicing next and making sure green color checkmark appears next to Professional License text
    cy.get('#business-license-next').click();
    cy.get('#business-license> svg').should('be.visible');


    //clicking next on business owner page without selecting an owner, and making sure it throws an error.
    cy.get('#management-owner-next').click();
    cy.get('.pl-alert.mt-2.error-span.ng-star-inserted').contains(' Please add a business owner ').should('be.visible');
    //clicking on Individual Owner plus sign 
    cy.get('#link-individual-add').click();
    cy.get('#management-owner-next').click();
    //making sure first name and last name fields are throwing errors if the fields are empty
    cy.get('#owner-first-name-0').contains('First name required').should('be.visible');
    cy.get('#owner-last-name-0').contains('Last name required').should('be.visible');
    //adding input to first name and last name fields
    cy.get('#owner-first-name-0').type('Cypress');
    cy.get('#owner-last-name-0').type('CypressTest');
    //clicking next and making sure green color checkmark is appearing next to Business owners text
    cy.get('#management-owner-next').click();
    cy.get('#management-owner> svg').should('be.visible');


    //making sure it throws an error on business manager page if an option isnt selected
    cy.get('#management-manager-next').click();
    cy.get('.pl-alert').contains('Selection of management type is required').should('be.visible');
    //clicking on more info modal on business manager page and making sure it's opening up properly
    cy.get('#management-manager-more').click();
    cy.get('.pl-h3').contains('Who will manage your business?').should('be.visible');
    //closing the modal
    cy.get("div[id='management-manager-modal'] button[type='button']").click();
    //selecting a management type
    cy.get('#business-manager-select').select('solelyByOwner');
    //clicking on next and making sure green checkmark is appearing next to the business manager text
    cy.get('#management-manager-next').click();
    cy.get('#management-manager > svg').should('be.visible');
    

    //making sure it throws an error at IRS Contact Information Page if radio button isnt selected
    cy.get('#management-irs-next').click();
    cy.get('.pl-alert.ng-star-inserted').contains('Please make a selection.').should('be.visible');
    //selecting the radio button and clicking on next
    cy.get('#rd-individual0 > label > span').click({force: true});
    cy.get('#management-irs-next').click();
    //Making sure it throws an error if Phone Number and SSN fields are empty 
    cy.get('#rd-individual0 > label > span').click({force: true});
    cy.get('.pl-alert.ng-star-inserted').contains('Phone number is required').should('be.visible');
    cy.get('.pl-alert.ng-star-inserted').contains('SSN is required').should('be.visible');
    //adding required details to Phone Number and SSN fields and clicking next
    cy.get('label[for="tb-individual-phone-number0"]').type('2222222222');
    cy.get('#tb-individual-ssn-area0').type('44444444444');
    cy.get('#management-irs-next').click();
    //making sure green checkmark appears next to 'IRS contact information' text
    cy.get('#management-irs > svg').should('be.visible');


    //opening up 'more info' modal, and making sure it's working properly  
    cy.get('#irs-dba-more').click();
    cy.get('.pl-h3').contains('"Doing business as" name, or DBA').should('be.visible');
    //closing the modal
    cy.get("div[id='irs-details-modal'] button[type='button']").click();
    //making sure it throws an error at Doing Business as page if nothing is selected
    cy.get('#irs-dba-next').click();
    cy.get('#irs-dba-panel').contains('Please select an answer').should('be.visible');
    //selecting 'No' and clicking on next button 
    cy.get('label[for="rd-dba-2"]').click();
    cy.get('#irs-dba-next').click();
    //making sure green checkmark is appearing next to 'Doing Business as' text
    cy.get('#irs-dba > svg').should('be.visible');


    //clicking next on Irs details page and making sure it throws an error if an option isnt selected
    cy.get('#irs-details-next').click();
    cy.get('.pl-alert').contains('Please select at least one option').should('be.visible');
    //choosing 'None of the above' option and clicking on next button
    cy.get('.deny-all').click();
    cy.get('#irs-details-next').click();
    //making sure green checkmark is appearing next to 'business details' text
    cy.get('#irs-details > svg').should('be.visible');
    

    cy.get('#fiscal-end-next').click();
    //clicking on more info modal at 'fiscal year end date' page and making sure it works properly
    cy.get('#fiscal-end-more').click();
    cy.get('.pl-h3').contains('When will your fiscal year end?').should('be.visible');
    //closing the modal
    cy.get("div[id='fiscal-year-modal'] button[type='button']").click();
    //making sure File my LLC button is visible
    cy.contains("File my LLC", { includeShadowDom: true }).should('be.visible').click({force: true});
  });
  
  // Data-driven test using
  // loading test data from below destination before executing the test
  const States = require('../../fixtures/StatesWithPOBoxError.json');

  States.forEach((state) => {

      it('Should error messages appear in address validation page when P.O Boxes are entered as an input in states which doesnt allow P.O Boxes. State='+state.name+'- RT-14764', () => {

          //Setting up API intercept
          cy.intercept('GET', '/v1/questionnaire-storage').as('questionnaire')
        
          // Intercepting API request to remove 403 requests due to old access tokens
          cy.interceptTokensToAllowQ2Interaction();
          
          //Navigating to Business Address page in Q2
          cy.goToQ2(state.name, 'Cypress automated test');
          cy.get("#business-name-next").click({ force: true });

          //making sure text area is filled in if the State is Dist. of Columbia
          if(state.name=='Dist. of Columbia'){
            cy.get('#business-name-explanation-container > textarea',{timeout:15000}).type('Cypress automated test');
          }
          
          cy.businessNameConfirmQ2();
         
          //selecting a name, checking the checkbox, and clicking on next btn
          cy.get('label[for="business-name-designator-choice-0"]').click({ multiple: true });
         // cy.get('.pl-checkbox-border').click({ force: true })
          cy.get('#agent-name-next').click();
          
          //entering neccessary inputs in Address and Postal Code fields and making sure P.O Box error shows up. 
          cy.get('#tb-address1-0').clear().type(state.name+' P.O Box 1111',{force: true});
          cy.get('#tb-state-0').clear().type(state.PostalCode);
          cy.get('#business-address-next').click({ force: true });
          cy.get('abbr[title="Post Office"]').contains('PO').should('be.visible');    
          cy.get('.ng-star-inserted > p > span').contains(' Boxes are not allowed.').should('be.visible');   
          
          // getting entityState value from json's response
          cy.wait('@questionnaire').its('response.body').its('answers').should('include', '"entityState":"'+state.name+'"');
      });
  });
});

function goToRegisteredAgentQ2() {
  cy.goToQ1Page();
  cy.get("#btn-decline-1").click();
  cy.get("#btn-decline-ra").click();
  navigateToQ2BusinessAddress();
  fillOutBusinessAddress();
  pickBusinessLicense();
  fillOutManagementOwner();
  pickManagementOwner();
  fillOutRegisteredAgentName();
}

function fillOutBusinessAddress() {
  cy.typeAhead('101 N Brand Blvd Glendale, CA 91203', typeAheadInput);
  selectSuggestion('101 N Brand Blvd Glendale, CA 91203');
  cy.get("#business-address-next").click();
}

function pickBusinessLicense() {
  cy.get('label[for="rd-pllc-2"]').click({ force: true });
  cy.get("#business-license-next").click();
}

function fillOutManagementOwner() {
  cy.get('label[for="cb-individual-owner"]').click({ force: true })
  cy.get("#tb-owner-first-name-0").type("Test", { force: true })
  cy.get("#tb-owner-last-name-0").type("McTest", { force: true })
  cy.get("#management-owner-next").click();
}

function pickManagementOwner() {
  cy.get("#business-manager-select").select('solelyByOwner')
  cy.get("#management-manager-next").click();
}

function fillOutRegisteredAgentName() {
  cy.get('#rd-ra-individual').click({ force: true })
  cy.get("#tb-ra-first-name").type("Test", { force: true })
  cy.get("#tb-ra-last-name").type("McTest", { force: true })
  cy.get("#agent-name-next").click({ force: true });
}

function conductTypeAheadSelectionsAndAssert() {

  // Testing one selection
  cy.typeAhead('100 Congress Ave', typeAheadInput);
  selectSuggestion('100 Congress Ave Austin, TX 78701');
  cy.assertAddressFormValues(
    [
      ['Address line 1', '100 Congress Ave'],
      ['Address line 2', ''],
      ['City', 'Austin'],
      ['State', 'TX'],
      ['County', 'Travis'],
      ['ZIP Code', '78701'],
    ],
    'have.value')

  // Testing deeper more accurate suggestion
  cy.typeAhead('100 Congress Ave', typeAheadInput);
  selectSuggestion('100 Congress Ave Apt (39 entries) Bath, ME 04530');
  selectSuggestion(' Apt 1 Bath, ME 04530');
  cy.assertAddressFormValues(
    [
      ['Address line 1', '100 Congress Ave'],
      ['Address line 2', 'Apt 1'],
      ['City', 'Bath'],
      ['State', 'ME'],
      ['County', 'Sagadahoc'],
      ['ZIP Code', '04530'],
    ],
    'have.value')

  // Testing deeper suggestion and then go back to a less accurate suggestion (without address2)
  cy.typeAhead('100 Congress Ave', typeAheadInput);
  selectSuggestion('100 Congress Ave Apt (39 entries) Bath, ME 04530');
  selectSuggestion(' Apt 1 Bath, ME 04530');
  cy.typeAhead('500 N Grant', typeAheadInput);
  selectSuggestion('500 N Grant St Stockton, CA 95202');
  cy.assertAddressFormValues(
    [
      ['Address line 1', '500 N Grant St'],
      ['Address line 2', ''],
      ['City', 'Stockton'],
      ['State', 'CA'],
      ['County', 'San Joaquin'],
      ['ZIP Code', '95202'],
    ],
    'have.value')
}

function navigateToQ2BusinessAddress() {
  cy.interceptTokensToAllowQ2Interaction();
  cy.goToQ2("California", "Cypress automated test");
  cy.get('#business-name-next').click();
  cy.businessNameConfirmQ2();
}

function selectSuggestion(address) {
  const suggestion = cy.contains(address);
  suggestion.click({ force: true });
}

