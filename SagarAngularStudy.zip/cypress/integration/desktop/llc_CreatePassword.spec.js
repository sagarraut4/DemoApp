describe('Create password page validation for new user', () => {

    before(() => {
      // Don't show cookie banner
      cy.hideCookieBanner();
    });
  
    beforeEach(() => {
      // clear session storage before each test
      cy.window().then((win) => {
        win.sessionStorage.clear()
      });
    });
  
    it('Create password page validation for new user', () => {
      var companyName = 'Food Packers LLC';
      cy.visit('/hft/state?entity=Food Packers LLC');
      cy.intercept('POST', 'v1/questionnaire-storage').as('apiCall');
      cy.get('select').select('California').should('have.value', 'California');
      cy.get('button[class="btn btn-action btn-cta"]').click();
  
      //Verifying Business Name on 'Name Available' page 
      cy.get('h2.title-2', { timeout: 20000 }).contains('Great news').should('be.visible');
      cy.get('button[class="btn btn-action btn-cta"]',{ timeout: 20000 }).click();
      cy.get('button[class="btn btn-action btn-cta"]',{ timeout: 20000 }).click();
      cy.get('button[class="btn btn-action btn-cta"]',{ timeout: 20000 }).click();
        
      cy.get('label[for="business-start-time-already"]').click();
      cy.get('button[class="btn btn-action btn-cta"]').click();
     
      cy.get('label[for="first-llc-yes"]').click();
      cy.get('button[class="btn btn-action btn-cta"]').click();
  
      cy.get('#state_autocomplete',{ timeout: 1000 }).type('Food Packaging');
      cy.get('button[class="btn btn-action btn-cta"]').click();
  
      cy.get('label[for="online"]',{ timeout: 1000 }).click();
      cy.get('button[class="btn btn-action btn-cta"]').click();
  
      cy.get('label[for="no"]',{ timeout: 1000 }).click();
      cy.get('button[class="btn btn-action btn-cta"]').click();
  
      cy.get('button[class="btn btn-action btn-cta"]').click();
  
      cy.get('button[class="btn btn-action btn-cta"]').click();
  
      cy.get('.card:nth-child(1) .glo-btn-text').click();
      cy.get('button[type="submit"]').contains('No thanks').click();
      
      cy.get('button[class="btn btn-action btn-cta"]').click();
      
      cy.get('.card:nth-child(1) .glo-btn-text').click();
  
      cy.get('button[type="submit"]').contains('No thanks').click();
  
      cy.get('.card:nth-child(1) .glo-btn-text').click();
  
      cy.get('button[type="submit"]').contains('No thanks').click();
      cy.get('#btn-save',{ timeout: 30000 }).click();
  
      cy.get('#fname').type('FN');
      cy.get('#lname').type('LN');
      cy.get('#email').type('test_' + Date.now().toString() + '@legalzoom.com');
      cy.get('input#phone').type('8182222222',{force: true});
      cy.get('#address1').type('101 N Brand Blvd., Glendale');
      cy.get('#ngb-typeahead-0-1',{ timeout: 3000 }).click();
      cy.get('#cc-number').type('4111111111111111');
      cy.get('input#billingZip').type('91203');
      cy.get('#cc-exp').type('0950');
      cy.get('#cc-csc').type('009');
      cy.get('[for="pay-single"] .description-option-single').click();
  
      // GeoLocationHandler api call gets CORS error when running the test locally or on docker that results in G-shite page being skipped by the app. 
      // So this is a workaround until the team resolves this error (OPT-383).
      cy.intercept('GET', 'Handlers/geolocationhandler', {
        statusCode: 200
      });
  
      cy.get('#btn-save',{ timeout: 3000 }).click();
      cy.get('app-desktop-lz-express-offers .title-2', { timeout: 75000 }).contains('Awesome').should('be.visible');
      cy.get('#btn-decline', { timeout: 5000 }).click();
      cy.get('#btn-decline-1', { timeout: 5000 }).click();
  
      //Set new password to create account for first time user login
      cy.get('#password').type("Test123");
      cy.get('#verifyPass').type("Test123");
      cy.get('button[data-testid="submitBtnSPC"]',{ timeout: 5000 }).click();
      
      cy.get('#btn-save', { timeout: 15000 }).click();
      cy.get('#biz-name-btn',{ timeout: 10000 }).click();
      cy.get('#business-name-designator-choice-0',{ timeout: 10000 }).click({ force: true });
      cy.get('label[for="business-name-reviewed-checkbox"]',{ timeout: 10000 }).click({ force: true });
      cy.get('#agent-name-next').click();
  
      // Progress Passed Business Address
      cy.get('#business-address-next').click();
  
      // Professional LLC
      cy.get('label[for="rd-pllc-2"]').click();
      cy.get('#business-license-next').click();
  
      // Business Owners
      cy.get('label[for="cb-owner-trust"]').click();
      cy.get('#tb-owner-trust-name-0').type('Test', { force: true });
      cy.get('#management-owner-next').click();
  
      // Business Manager
      cy.get('#tb-manager-name-0').type('Test automation', { force: true });
      cy.get('#management-manager-next').click();
  
      
      //Contact information IRS
      cy.get('#rd-trust0 label:nth-child(1)',{ timeout: 10000 }).click();
      cy.get('#tb-trust-first-name0').type('FN', { force: true });
      cy.get('#tb-trust-middle-name0').type('MN', { force: true });
      cy.get('#tb-trust-last-name0').type('LN', { force: true });
      cy.get('#tb-trust-phone-number0').type('8182222233',{force: true});
      cy.get('#tb-trust-ssn-area0').type('123', { force: true });
      cy.get('#tb-trust-ssn-group0').type('12', { force: true });
      cy.get('#tb-trust-ssn-serial0').type('1234', { force: true });
      cy.get('#management-irs-next').click();
  
      //Doing business under another name
      cy.get('#rd-dba-2').click({ force: true });
      cy.get('#irs-dba-next').click();
  
      //Do any of these options apply to your business?
      cy.get("label[class='deny-all']").click();
      cy.get('#irs-details-next').click();
  
      // Fiscal Year
      cy.get('#btn-submit',{ timeout: 10000 }).click();
      
      cy.get('#btn-decline',{ timeout: 10000 }).click();
      cy.get('div[class^="ribbon-container"]').click();
      cy.get('#order-confirmation-next').click();
      
      cy.frameLoaded('#agreement-console');
      cy.iframe('#agreement-console').find('#glo-form-check').should('be.visible').click();    
      
      cy.iframe('#agreement-console').find('button[class="btn btn-action mt-4"]').click();
      cy.get('a[class="glo-link glo-size-14"]').should('be.visible').and('contain','View order status');
    });
  });
  