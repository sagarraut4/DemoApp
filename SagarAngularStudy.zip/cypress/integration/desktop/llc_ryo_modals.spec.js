describe('LLC RYO modal functionality RT-08384', () => {

    before(() => {
        // Don't show cookie banner
        cy.hideCookieBanner();
    });

    beforeEach(() => {
        // clear session storage before each test
        cy.window().then((win) => {
            win.sessionStorage.clear()
        });

         // Fill Out Q1
        cy.fillOutQuestionnaire1WithOptions(
        {
          entityName: 'Cypress Test Automation LLC',
          industry: 'Caas',
          startBusiness: 'future',
          isFirstLLC: false,
          hireEmployees: true,
          purchaseRA: true,
          docOptions: 4,
          legalProtect: true,
          totalCompliance: false,
          packageSelection: 1,
          boaOffer: false
        }
      );

           
    it('should verify editing hire employees from yes to no', () => {   
        //edits hire employess from yes to no
        cy.get('div#order-item-0 .item-edit', { timeout: 20000 }).click();
        cy.get('label[for="rd-biz-employees-no"]').click();
        cy.get('#btn-update').click();
        //opens modal to verify input value is "no"
        cy.get('div#order-item-0 .item-edit', { timeout: 20000 }).click();
        cy.get('#rd-biz-employees-no').should('have.value', 'no')   
    });

    });

    it('should verify editing the modal for package type from economy to standard to express gold', () => {
        //edits ryo modal and selects standard package and clicks update
        cy.get('.order-item:nth-child(3) .item-edit', { timeout: 20000 }).click();
        cy.get('label[for="review_llc_package_standard"]').click();
        cy.get('#btn-update').click();
        cy.get("[ng-reflect-is-busy='true']", {timeout: 5000}).should('not.exist');
        //verifies text on ryo to confirm standard package was successfully updated
        cy.get('div.order-items.ng-star-inserted', { timeout: 20000 }).contains('Standard LLC').should('be.visible');
        
        //edits ryo modal and selects express gold package and clicks update
        cy.get('#order-item-146 a').click();
        cy.get('label[for="review_llc_package_express_gold"]').click();
        cy.get('#btn-update').click();
        cy.get("[ng-reflect-is-busy='true']", {timeout: 5000}).should('not.exist');
        //verifies text on ryo to confirm express package was successfully updated
        cy.get('#item-name-147 .item-title', { timeout: 20000 }).contains('Express Gold LLC').should('be.visible');
    });

    it('should verify modal for essential documents is editable and allows user to successfully edit ryo', () => {
        //edits essential documents modal and selects operating agreement
        cy.get('div#order-item--4 .item-edit', { timeout: 20000 }).click();
        cy.get('label[for="review_operating_agreement"]').click();
        cy.get('.no-mobile .btn-update').click();
        cy.get("[ng-reflect-is-busy='true']", {timeout: 5000}).should('not.exist');
        //verifies operating agreement displays on ryo
        cy.get('div#order-item--2 .item-title').contains('Operating agreement').should('be.visible');
        
        //edits essential documents modal and selects operating agreement and ein
        cy.get('#order-item--2  .item-edit').click();
        cy.get('label[for="review_operating_agreement_and_ein"]').click();
        cy.get('.no-mobile .btn-update').click();
        cy.get("[ng-reflect-is-busy='true']", {timeout: 5000}).should('not.exist');
        //verfies operating agreement and ein displays on ryo
        cy.get('div #item-name--2 .item-title').should('have.text', 'Operating agreement and EIN');

        //edits essential documents modal and selects operating agreement, ein and licenses
        cy.get('#order-item--2  .item-edit').click();
        cy.get('label[for="review_operating_agreement_ein_and_licenses"]').click();
        cy.get('.no-mobile .btn-update').click();
        cy.get("[ng-reflect-is-busy='true']", {timeout: 5000}).should('not.exist');
        //verifies operating agreement, ein and licenses displays on ryo
        cy.get('div #item-name--2 .item-title').should('have.text', 'Operating agreement, EIN and licenses');
    });

    it('should verify registered agent can be edited from yes to "no thanks"', () => {
        //edits registered agent modal from yes to no
        cy.get('#order-item-6286 .item-edit', { timeout: 20000 }).click();
        cy.get('label[for="rd-agent-not-lz"]').click();
        cy.get('#btn-update').click();
        //verifies no thanks displays on ryo
        cy.get('#item-amount--11',  { timeout: 20000 }).should('have.text', ' No thanks ');
    });
    
    it('should verify editing legal protect plan from yes to "no thanks"', () => {
        //edits legal protect plan modal from yes to no
        cy.get('#order-item-7328  .item-edit', { timeout: 20000 }).click();
        cy.get('label[for="review_legal_package_none"]').click();
        cy.get('#btn-update').click();
        cy.get("[ng-reflect-is-busy='true']", {timeout: 5000}).should('not.exist');
        //verfies no thanks displays on ryo
        cy.get('#item-amount--14',  { timeout: 20000 }).should('have.text', ' No thanks ');
    });
    
    it('should verify editing total compliance yes to "no thanks"', () => {
        //edits total compliance modal from yes to no
        cy.get('#order-item-7328  .item-edit', { timeout: 20000 }).click();
        cy.get('label[for="review_legal_package_none"]').click();
        cy.get('#btn-update').click();
        //verifies no thanks displays on ryo
        cy.get('#item-amount--12',  { timeout: 20000 }).should('have.text', ' No thanks ');
    });
});

