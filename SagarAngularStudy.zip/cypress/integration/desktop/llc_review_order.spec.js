describe('Order Review Pages', () => {

    before(() => {
        // Don't show cookie banner
        cy.hideCookieBanner();
    });
    
    beforeEach(() => {
        // clear session storage before each test
        cy.window().then((win) => {
            win.sessionStorage.clear()
        });  
    });
    
    it('should verify order review page details based on questionnaires selected using Wisconsin as state - RT-06566',()=>{

        cy.visit('/name/state?entity=LLC TestOrder');
        cy.intercept('POST', 'v1/questionnaire-storage').as('apiCall');
        cy.get('#tb-entity-state').type('Wisconsin');
        cy.get('#ngb-typeahead-0-0').click();
        cy.get('#btn-save').click();
        cy.wait('@apiCall').then(() => {
            cy.get('span.ng-star-inserted', { timeout: 10000 }).contains('LLC TestOrder appears to be available').should('be.visible');
            cy.get('#btn-save').click();
            cy.get('label[for="already"]').click();
            cy.get('#btn-save').click();
            cy.get('#llc-overview-next').click();
            cy.get('label[for="first-llc-yes"]').click();
            cy.get('#btn-save').click();
            cy.get('#tb-biz-industry').type('Restaurant');
            cy.get('#btn-save').click();
            cy.get('label[for="hire-employees-yes"]').click();
            cy.get('#btn-save').click();
            cy.get('#btn-save').click(); 
            cy.get('#btn-decline-1').click();
            cy.get('#btn-decline-ra',{timeout: 10000}).click();
            cy.get('#btn-decline-1').click();
            cy.get('#btn-save').click();
            cy.get('#btn-decline-1').click();
            cy.get('#btn-decline-2').click();  
            cy.get('#rd-package-3').click();
            cy.get('#btn-decline').click();
            //Verfiying Company Details   
            cy.get('#order-item--1',{timeout:20000}).contains('LLC TestOrder').should('be.visible');
            //Verfiying LLC Package and state filling fees
            cy.get('#order-item-805').contains('Wisconsin filing fee').should('be.visible');
            cy.get('#item-details-805').contains('$155').should('be.visible');
            //Verfiying Essential documents    
            cy.get('#order-item--4').contains('Essential documents').should('be.visible');
            cy.get('#order-item--4').contains('No thanks').should('be.visible');
            //Verfiying LegalZoom Registered Agent
            cy.get('#order-item--11').contains('LegalZoom Registered Agent').should('be.visible');
            cy.get('#order-item--11').contains('No thanks').should('be.visible');
            //Verfiying Total Compliance    
            cy.get('#order-item--12').contains('Total Compliance').should('be.visible');
            cy.get('#order-item--12').contains('No thanks').should('be.visible');
            //Verfiying Sales Tax    
            cy.get('#order-item--6').contains('We’ve got you covered!').should('be.visible');
            cy.get('#price--5').contains('$0').should('be.visible');
        });
    });
    
    it('When Economy pkg is selected, Professional Printing check box should be visible on Review Order Page. RT-10348', () => {
        var printDocAmt = 39;
        //Using pageToGoTo command to get to the RYO page using following arguments: Choosing Economy as package, setting Prof Printing Flag as true, and mocking balances api as 'printedWelcomePack'
        cy.goToQ1Page({pageToGoTo: 'review-your-order',pkg: 145, profprintSelect: true,apiRoute: 'printedWelcomePack'});
        //making sure welcome packet text is visible after the checkbox is selected 
        cy.get("#order-item-159", { timeout: 10000 }).contains('Printed welcome packet added')
        .should('be.visible');
        //reading total amount object from the Balances Api json file to compare it with the order's total amount on UI
        cy.readFile("cypress/fixtures/fixt_pageToGoTo/v1_carts_22622758_balances_Economy.json")
        .its('totalAmount').then((totalAmount) => {
        //making sure printing doc amount is added to the total amount
        cy.get('.total-amount').contains(totalAmount+printDocAmt).should('be.visible');
        });
    });

    it('Professional printing checkbox should not be visible on Review Order Page when Gold Pkg is selected. RT-10349', () => {
        //Using pageToGoTo command to get to the RYO page using following arguments: Choosing Gold as package and setting Prof Printing Flag as false.
        cy.goToQ1Page({pageToGoTo:'review-your-order',pkg:147, profprintSelect: false});
        //making sure print doc section is not visible
        cy.get("#order-item-159").should('not.exist');
        //Reading total amount object from the Balances Api json file to compare it with the order's total amount on UI 
        cy.readFile("cypress/fixtures/fixt_pageToGoTo/v1_carts_22622758_balances_Express.json")
        .its('totalAmount').then((totalAmount) => {
        //making sure amount is added correctly
        cy.get('.total-amount').contains(totalAmount).should('be.visible');
        });
    });

    it('Should be able to apply discount code in RYO page, correct discounted amount shows up in checkout page and that the user is able to complete Q1 and Q2. RT-08226', () => {
        // Promo code for 10% discount on LLC package amount.
        const promoCode = 'lzbiz10';
        // Expected due amount = $368(original due amount) - $7.90(10% discount) = $360.1
        const dueAfterDiscount = '$360.10';

         // Using custom command to navigate to RYO page
        cy.fillOutQuestionnaire1WithOptions({ hireEmployees: false, industry: 'Travel' });
        cy.get('.title-2.ryo-title', { timeout: 15000 }).contains('Review your order below');
        cy.get('#Group-3').click();
        cy.get('#tb-discount').type(promoCode);
        cy.get("[type='submit'] span").click();
        // Making sure spinner is gone before taking next action.
        cy.get("[ng-reflect-is-busy='true']", {timeout: 6000}).should('not.exist');
        // Verifying that correct discount amount (10% of $79 = $7.90) is applied and that the total due amount ($368 - $7.90 = $360.10) is reflected accordingly.
        cy.get('.promo-code .pb-4').contains('Discounts').should('be.visible');
        cy.get('.promo-code .pb-4 ').contains('$7.90').should('be.visible');
        cy.get('.total-amount').contains(dueAfterDiscount).should('be.visible');
        cy.get('#btn-save').click();

        // Checkout page
        cy.get('#checkout-title').should('be.visible');
        // Verifying that the discounted total due amount shows up in checkout page as well.
        cy.get('.description-option-single span').invoke('text').should('eq', dueAfterDiscount);
        // Using custom command to fill out checkout form.
        cy.fillOutCheckout();

        cy.get('.title-2.col-12', { timeout: 30000 }).should('be.visible');
        cy.get('#btn-decline').click();
        cy.get('#btn-decline-1').click();

        // Verifying that the user is able to complete Q1 successfully.
        cy.get('.hero-2.mb-2', { timeout: 20000 }).contains('Congrats!').should('be.visible');
        cy.get('.btn-action').click();

        // Q2 starts (namecheck flow)
        // Set up API intercept
        cy.intercept('GET', '/entitydb/api/v1/availability').as('getEntityAvailability');
        cy.intercept('POST', '/v1/business-name-check/processing-orders').as('availabilityTransactionLogs');

        cy.get('#business-name-next').click();

        // Await API Responses
        cy.wait('@getEntityAvailability')
            .its('response.body')
            .should('include', { 'status': 'available' });
        cy.wait('@availabilityTransactionLogs')
            .its('response.body')
            .should('include', { 'success': true });

        // Select Designator & Checkbox
        cy.get('.radio-text[for="business-name-designator-choice-0"]').click();
        cy.get('label[for="business-name-reviewed-checkbox"]').click({ force: true });

        // Submit Section
        cy.get('#agent-name-next').click();

        // Progress Passed Business Address
        cy.get('#business-address-next').click({force: true});
        cy.get("[for='rd-pllc-2']").click();
        cy.get('#business-license-next').click();

        // Ownership & management module
        cy.get('#link-entity-add').click();
        cy.get('#tb-owner-business-entity-name-0').type('Farse');
        cy.get('#management-owner-next').click();

        cy.get('#tb-manager-name-0').type('Abc Tester', { force: true });
        cy.get('#management-manager-next').click();

        cy.get('#tb-rd-entity0').click({ force: true });
        cy.get('#tb-business-entity-first-name0').type('TestFirstName');
        cy.get('#tb-business-entity-last-name0').type('TestLastName');
        cy.get('#tb-business-entity-phone-number0').type('3102223333');
        cy.get('#tb-business-entity-ssn-area0').type('111223333');
        cy.get('#management-irs-next').click();

        // Information required by IRS module
        cy.get('#rd-dba-2').click({ force: true });
        cy.get('#irs-dba-next').click();

        cy.get('.deny-all').click();
        cy.get('#irs-details-next').click();

        // Fiscal year end date module
        cy.get('#fiscal-end-next').click();
        cy.get('#btn-submit').click();

        // Mylo page
        cy.get('#btn-decline').click();

        // Q2 Confirmation page
        cy.get('.ribbon-container').click();      
        // Verifying that the user is able to complete Q2 successfully.
        cy.get('.ribbon-heading').contains('Congratulations!').should('be.visible');
    });
});