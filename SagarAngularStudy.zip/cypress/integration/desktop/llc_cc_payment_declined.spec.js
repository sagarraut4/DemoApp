describe('LLC payment declined at checkout RT-21451', () => {

    before(() => {
        // Don't show cookie banner
        cy.hideCookieBanner();
    });

    beforeEach(() => {
        // clear session storage before each test
        cy.window().then((win) => {
            win.sessionStorage.clear()
        });
    });

    it('should show decline credit card message at checkout - RT-21451', () => {
        cy.visit('/name/state?entity=TestOrder LLC');
        cy.intercept('POST', 'v1/questionnaire-storage').as('apiCall');
        cy.get('#tb-entity-state').type('Colorado');
        cy.get('#ngb-typeahead-0-0').click();
        cy.get('#btn-save').click();
        cy.wait('@apiCall').then(() => {
            cy.get('span.ng-star-inserted', { timeout: 20000 }).contains('Great news').should('be.visible');
            cy.get('#btn-save').click();
            cy.get('label[for="already"]').click();
            cy.get('#btn-save').click();
            cy.get('#llc-overview-next').click();
            cy.get('label[for="first-llc-yes"]').click();
            cy.get('#btn-save').click();
            cy.get('#tb-biz-industry').type('Restaurant');
            cy.get('#btn-save').click();
            cy.get('label[for="hire-employees-yes"]').click();
            cy.get('#btn-save').click();
            cy.get('#btn-save').click();
            cy.get('#btn-save').click();
            cy.get('label[for="rd-docs-1"]').click();
            cy.get('#btn-save').click();
            cy.get('#btn-save').click();
            cy.get('#btn-decline-2').click();
            cy.get('#rd-package-3').click();
            cy.get('#btn-decline').click();
            // Wait until on the page, otherwise test is flaky because elements can be detached from DOM
            cy.url().should('include', '/checkout/review-your-order');
            cy.get('#btn-save', { timeout: 10000 }).click();
            cy.get('#fname').type('FN');
            cy.get('#lname').type('FN');
            cy.get('#email').type('test_' + Date.now().toString() + '@legalzoom.com');
            cy.get('input#phone').type('8182222222',{force: true});
            cy.get('#address1').type('101 N Brand Blvd., Glendale');
            cy.get('#ngb-typeahead-2-0').click();
            cy.get('#cc-number').type('5112001600000006');
            cy.get('input#billingZip').type('91203');
            cy.get('#cc-exp').type('0922');
            cy.get('#cc-csc').type('009');
            cy.get('[for="pay-single"] .description-option-single').click();
            // GeoLocationHandler api call gets CORS error when running the test locally or on docker that results in G-shite page being skipped by the app. 
            // So this is a workaround until the team resolves this error (OPT-383).
            cy.intercept('GET', 'Handlers/geolocationhandler', {
                statusCode: 200
            });
            cy.get('#btn-save').click();
            cy.get('app-desktop-lz-express-offers .title-2', { timeout: 20000 }).contains('Awesome').should('be.visible');
            cy.get('#btn-decline', { timeout: 20000 }).click();
            cy.get('#btn-decline-1', { timeout: 20000 }).click();
            //processing animation screen
            cy.get('p.hero-2.mb-2', { timeout: 20000 }).contains('We tried but couldn\'t process your card');
            cy.get('.caption-1.text-danger.ng-star-inserted').contains('Payment declined');        
        });
    });
});
