describe('Example LLC Tests', () => {

    before(() => {
        // Don't show cookie banner
        cy.hideCookieBanner();
    });

    beforeEach(() => {
        // clear session storage before each test
        cy.window().then((win) => {
            win.sessionStorage.clear()
        });

        // Clear Cookies
        cy.clearCookies();
    });

    it('should show name available message when API returns true', () => {
        // Mock API response to return true
        cy.intercept('GET', '/v1/business-name-check/names/', '{"isAvailable":true}');
        cy.intercept('POST', 'v1/questionnaire-storage').as('apiCall');

        cy.visit('/name/state?entity=Bluth Bananas');
        cy.get('#tb-entity-state').type('California');
        cy.get('#ngb-typeahead-0-0').click();
        cy.get('#btn-save').click();
        cy.wait('@apiCall').then(() => {
            cy.get('span.ng-star-inserted').contains('appears to be available').should('be.visible');
        });
    });

    it('should not show name available message when API returns false', () => {
        // Mock API response to return false
        cy.intercept('GET', '/v1/business-name-check/names/', '{"isAvailable":false}');
        cy.intercept('POST', 'v1/questionnaire-storage').as('apiCall');

        cy.visit('/name/state?entity=Bluth Bananas');
        cy.get('#tb-entity-state').type('California');
        cy.get('#ngb-typeahead-0-0').click();
        cy.get('#btn-save').click();
        cy.wait('@apiCall').then(() => {
            cy.get('span.ng-star-inserted').contains('Awesome').should('be.visible');
        });
    });

    it('should capture API request body', () => {
        // Set up API intercept
        cy.intercept('POST', '/v1/carts').as('createCart');
        cy.intercept('POST', 'v1/questionnaire-storage').as('apiCall');

        cy.visit('/name/state?entity=Bluth Bananas');
        cy.get('#tb-entity-state').type('California');
        cy.get('#ngb-typeahead-0-0').click();
        cy.get('#btn-save').click();

        // Verify API request body
        cy.wait('@createCart').its('request.body').should('include', {stateId: "California"});
    })

    it('should successfuly go through Q1 questionnaire as a new user', () => {
        cy.visit('/name/state?entity=LLC Test');
        cy.intercept('POST', 'v1/questionnaire-storage').as('apiCall');
        cy.get('#tb-entity-state').type('Colorado');
        cy.get('#ngb-typeahead-0-0').click();
        cy.get('#btn-save').click();
        cy.wait('@apiCall').then(() => {
            cy.get('span.ng-star-inserted', { timeout: 10000 }).contains('appears to be available').should('be.visible');
            cy.get('#btn-save').click();
            cy.get('label[for="already"]').click();
            cy.get('#btn-save').click();
            cy.get('#llc-overview-next').click();
            cy.get('label[for="first-llc-yes"]').click();
            cy.get('#btn-save').click();
            cy.get('#tb-biz-industry').type('Restaurant');
            cy.get('#btn-save').click();
            cy.get('label[for="hire-employees-yes"]').click();
            cy.get('#btn-save').click();
            cy.get('#btn-save').click();
            cy.get('#btn-save').click();
            cy.get('label[for="rd-docs-1"]').click();
            cy.get('#btn-save').click();
            cy.get('#btn-save').click();
            cy.get('#btn-decline-2').click();
            cy.get('#rd-package-3').click();
            cy.get('#btn-decline').click();
            // Wait until on the page, otherwise test is flaky because elements can be detached from DOM
            cy.url().should('include', '/checkout/review-your-order');
            cy.get('#btn-save', { timeout: 10000 }).click();
            cy.get('#fname').type('FN');
            cy.get('#lname').type('FN');
            cy.get('#email').type('test_' + Date.now().toString() + '@legalzoom.com');
            cy.get('input#phone').type('8182222222',{force: true});
            cy.get('#address1').type('101 N Brand Blvd., Glendale');
            cy.get('#ngb-typeahead-2-0').click();
            cy.get('#cc-number').type('4111111111111111');
            cy.get('input#billingZip').type('91203');
            cy.get('#cc-exp').type('0922');
            cy.get('#cc-csc').type('009');
            cy.get('[for="pay-single"] .description-option-single').click();
            // GeoLocationHandler api call gets CORS error when running the test locally or on docker that results in G-shite page being skipped by the app. 
            // So this is a workaround until the team resolves this error (OPT-383).
            cy.intercept('GET', 'Handlers/geolocationhandler', {
                statusCode: 200
            });
            cy.get('#btn-save').click();
            cy.get('app-desktop-lz-express-offers .title-2', { timeout: 25000 }).contains('Awesome').should('be.visible');
            cy.get('#btn-decline', { timeout: 20000 }).click();
            cy.get('#btn-decline-1').click();
            cy.get('app-order-confirmation .order-confirmation .hero-2', { timeout: 20000 }).contains('Congrats!').should('be.visible');
            cy.get('button#btn-save').click();
            cy.get('app-business-details').should('be.visible');
        });
    });

    it('should show Q2', () => {
        cy.goToQ2();

        // Assert
        cy.get('app-business-details#bizSection').should('be.visible');
        cy.get('#tb-biz-name').should('be.visible');
    });
});
