describe('Skip business name tests validation', () => {

  before(() => {
    // Don't show cookie banner
    cy.hideCookieBanner();
  });

  beforeEach(() => {
    // clear session storage before each test
    cy.window().then((win) => {
      win.sessionStorage.clear()
    });
  });

  const bizName = 'ABC Company';

  it('Should display "your Business" in RYO page when business name is skipped. RT-10870', () => {
    cy.goToQ1Page({pageToGoTo: 'review-your-order', skipName: true})
    // Verifying text "your business" is visible in the heading.
    cy.get('.title-2').contains('Your business').should('be.visible');
    // Verifying business name is not visible as the line item.
    cy.get('#content-3--1').should('not.be.visible');
  });

  it('Should display the newly entered business name after business name is entered via edit Modal in RYO page . RT-10870', () => {
    cy.goToQ1Page({pageToGoTo: 'review-your-order', skipName: true})
    cy.get('#order-item-0 a').click();
    cy.get('#tb-entity-name').type(bizName);
    cy.get('.no-mobile #btn-update').click();
    // Verifying the new business name is visible in the heading.
    cy.get('.title-2').contains(bizName).should('be.visible');
    // Verifying the new business name is visible as a line item.
    cy.get('#content-3--1').should('have.text', bizName);
  });

  it('Should display the business name in RYO page when business name was entered in overview page. RT-10870', () => {
    cy.goToQ1Page({pageToGoTo: 'review-your-order', skipName: false, name: bizName});
    // Verifying the buisness name is visible in the heading.
    cy.get('.title-2').contains(bizName).should('be.visible');
    // Verifying the business name is visible as a line item.
    cy.get('#content-3--1').contains(bizName).should('be.visible');
    cy.get('#order-item--2 a').click();
    cy.get("[for='review_operating_agreement_and_ein']").click();
  });  

  it('clicking on skipping business name at LLC overview page, should navigate the page to Q1. RT-10903, RT-10869',()=> {
    //Clicking on Start now and decide later hyperlink takes it to the choose_later page 
    cy.visit('/name/state?choose_later=true');
    cy.get('#tb-entity-state').should('be.visible');
    cy.get('div.col-12.title-2.text-md-center').contains(' In what state would you like to form ').should('be.visible');
    cy.get('#tb-entity-state').type('California');
    cy.get('#ngb-typeahead-0-0').click();
    cy.get('#btn-save').click();
    //Verifying the header at name-available page
    cy.get('.title-2 > span').contains('Awesome!').should('be.visible');
  }); 

  it('Should display "your business" in place of business name in questionnaire flow (Q1) pages when business name is skipped. RT-10863', () => {
    cy.visit('/name/state?choose_later=true');
    // Verifying "your business" is displayed is state page.
    cy.get('.title-2').contains('your business').should('be.visible');
    cy.get('#tb-entity-state').type('California');
    cy.get('#ngb-typeahead-0-0').click();
    cy.get('#btn-save').click();
    cy.contains('#btn-save', 'Get my LLC', {timeout:10000}).click();
    // Verifying "your business" is displayed is timeframe page.
    cy.get('.title-2 div').contains('your business').should('be.visible');
    cy.get("[for='already']").click();
    cy.get('#btn-save').click()
    cy.get('#llc-overview-next').click()
    cy.get("[for='first-llc-yes']").click()
    cy.get('#btn-save').click();
    // Verifying "your business" is displayed is industry page.
    cy.get('.title-2').contains('your business').should('be.visible');
    cy.get('#tb-biz-industry').type('retail');
    cy.get('#btn-save').click();
    cy.get("[for='hire-employee-no']").click();
    cy.get('#btn-save').click();
    cy.get('#btn-save').click();
    // Verifying "your business" is displayed is registered-agent page.
    cy.get('.content-2').contains('your business').should('be.visible');
    cy.get('#btn-save').click();
    // Verifying "your business" is displayed is critial-doc page.
    cy.contains('.content-2', 'your business').should('be.visible');
    cy.get("[for='rd-docs-3']").click();
    cy.get('#btn-save').click();
    // Verifying "your business" is displayed is legal page.
    cy.get('.title-2').contains('your business').should('be.visible');
    cy.get('#btn-save').click();
    cy.get('#more-info-link').click();
    // Verifying "your business" is displayed is compliance page.
    cy.get('.content div p:nth-child(7)').scrollIntoView().contains('your business').should('be.visible');
  });

  it('Should display "Is this your first LLC?" in first-llc page when business name is skipped. RT-10863', () => {
    cy.goToQ1Page({pageToGoTo: 'first-llc', skipName: true});
    cy.get('.title-2').contains(' Is this your first LLC? ').should('be.visible');
  });
});



