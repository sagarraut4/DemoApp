describe('Business name validation on Questionnaire flow RT-10862', () => {

  before(() => {
    // Don't show cookie banner
    cy.hideCookieBanner();
  });

  beforeEach(() => {
    // clear session storage before each test
    cy.window().then((win) => {
      win.sessionStorage.clear()
    });
  });

  it('should show the same company name on Questionnaire flow pages what user enters on the overview page. RT-10862', () => {
    var companyName = 'Food Packers LLC';
    cy.visit('/name/state?entity=Food Packers LLC');
    cy.get('#tb-entity-state').type('California');
    cy.get('#ngb-typeahead-0-0').click();
    cy.get('#btn-save').click();
    //Verifying Business Name on 'Name Available' page 
    cy.get('span.ng-star-inserted', { timeout: 15000 }).contains(companyName).should('be.visible');
    cy.contains('#btn-save', 'Get my LLC', { timeout:10000 }).click();
    cy.get('label[for="already"]').click();
    cy.get('#btn-save').click();
    cy.get('#llc-overview-next').click();
    //Verifying Business Name on 'Is It your First LLC' page     
    cy.get('span.ng-star-inserted', { timeout: 10000 }).contains(companyName).should('be.visible');
    cy.get('label[for="first-llc-yes"]').click();
    cy.get('#btn-save').click();
    //Verifying Business Name on 'What will it do' page 
    cy.get('span.ng-star-inserted').contains(companyName).should('be.visible');
    cy.get('#tb-biz-industry').type('Food Packaging');
    cy.get('#btn-save').click();
    cy.get('label[for="hire-employees-yes"]').click();
    cy.get('#btn-save').click();
    cy.get('#btn-save').click();
    //Verifying Business Name on Registered Agent page   
    cy.get('div.registered-agent--subtitle.row.d-none.d-md-block').contains(companyName).should('be.visible');
    cy.get('#btn-save').click();
    cy.get('label[for="rd-docs-3"]').click();
    cy.get('#btn-save').click();
    //Verifying Business Name on Smart Employer page   
    cy.get('.title-2.m-0.ng-star-inserted').contains(companyName).should('be.visible');
    cy.get('#btn-save').click();
    cy.get('#btn-decline-2').click();
    cy.get('#rd-package-3').click();
    cy.get('#btn-decline').click();
    //Verifying Business Name on RYO page   
    cy.get('.title-2.mbc-12.ryo-title', { timeout: 20000 }).contains(companyName + ' is nearly a reality.').should('be.visible');
    cy.get('div.content-3').contains(companyName).should('be.visible');
  });
});
