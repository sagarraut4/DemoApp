describe('Session timeout tests', () => {

    before(() => {
        // Don't show cookie banner
        cy.hideCookieBanner();
    });

    beforeEach(() => {
      // clear session storage before each test
      cy.window().then((win) => {
        win.sessionStorage.clear()
      });
      cy.clearCookies();
      cy.clearLocalStorage();
    });

    it('Should redirect guest-user to overview page when the user tries to proceed ahead in Q1 after session idle timeout period. RT-08343', () => {
        cy.visit('/name/state?entity=ABC Company');
        cy.get('#tb-entity-state').type('California');
        cy.get('#ngb-typeahead-0-0').click();
        cy.get('#btn-save').click();
        cy.contains('#btn-save', 'Get my LLC', {timeout:12000}).click();
        cy.get("[for='already']", {timeout: 8000}).click();
        cy.get('#btn-save').click();
        // Mocking up the api response code to be 401 with specific body to mimic response of any api call after session idle timeout period.
        cy.intercept('POST', 'v1/questionnaire-storage', {
            statusCode: 401,
            body: {
                "fault": {
                "faultstring": "unauthorized session",
                "detail": {
                    "errorcode": "keymanagement.service.access_token_expired"
                    }
                }
            }
        });
        cy.get('#llc-overview-next').click();
        // Verifying that the app is trying to redirect the user to overview page.
        cy.url().should('include', 'business-formation/llc-overview.html');
    });

    it('Should redirect logged-in user to My Account page when the user tries to proceed ahead in Q1 after session idle timeout period. RT-08343', () => {
        cy.visit('/name/state?entity=ABC Company');
        cy.get('#tb-entity-state').type('California');
        cy.get('#ngb-typeahead-0-0').click();
        cy.get('#btn-save').click();
        cy.contains('#btn-save', 'Get my LLC', { timeout:12000 }).click();
        // Waiting for the below api call to respond to make sure that the app gets enough time to store the state of the current page so that it can return back to this page after login.
        cy.intercept('POST', 'v1/answers/questionnaires/27').as('apiCall');
        cy.wait('@apiCall', { timeout: 12000 }).then(() => {
            // Logging in using the command.
            cy.login();
            cy.get("[for='already']", { timeout: 15000 }).click();
            cy.get('#btn-save').click();
            // Mocking up the api response code to be 401 with specific body to mimic response of any api call after session idle timeout period.
            cy.intercept('POST', 'v1/questionnaire-storage', {
                statusCode: 401,
                body: {
                    "fault": {
                    "faultstring": "unauthorized session",
                    "detail": {
                        "errorcode": "keymanagement.service.access_token_expired"
                        }
                    }
                }
            });
            cy.get('#llc-overview-next').click()
            // Verifying that the app is trying to redirect the user to My Account page.
            cy.url().should('include', 'lzweb/myaccount/');
        });
    });
});