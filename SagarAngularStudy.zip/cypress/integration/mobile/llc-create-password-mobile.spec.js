describe('Create password page validation for new user', () => {

    before(() => {
        // Don't show cookie banner
        cy.hideCookieBanner();
    });

    beforeEach(() => {
        // clear session storage before each test
        cy.window().then((win) => {
            win.sessionStorage.clear()
        });
    });

    it('Create password page validation for new user', () => {
        var companyName = 'Food Packers LLC';
        cy.visit('/hft/state?entity=Food Packers LLC');
        cy.intercept('POST', 'v1/questionnaire-storage').as('apiCall');
        cy.get('select').select('California').should('have.value', 'California');
        cy.get('button[class="btn btn-action btn-cta"]').click();

        //Verifying Business Name on 'Name Available' page 
        cy.get('h2.title-2', { timeout: 20000 }).contains('Great news').should('be.visible');
        cy.get('button[class="btn btn-action btn-cta"]', { timeout: 20000 }).click();
        cy.get('button[class="btn btn-action btn-cta"]', { timeout: 20000 }).click();
        cy.get('button[class="btn btn-action btn-cta"]', { timeout: 20000 }).click();

        cy.get('label[for="business-start-time-already"]').click();
        cy.get('button[class="btn btn-action btn-cta"]').click();

        cy.get('label[for="first-llc-yes"]').click();
        cy.get('button[class="btn btn-action btn-cta"]').click();

        cy.get('#state_autocomplete', { timeout: 1000 }).type('Food Packaging');
        cy.get('button[class="btn btn-action btn-cta"]').click();

        cy.get('label[for="online"]', { timeout: 1000 }).click();
        cy.get('button[class="btn btn-action btn-cta"]').click();

        cy.get('label[for="no"]', { timeout: 1000 }).click();
        cy.get('button[class="btn btn-action btn-cta"]').click();

        cy.get('button[class="btn btn-action btn-cta"]').click();

        cy.get('button[class="btn btn-action btn-cta"]').click();

        cy.get('.card:nth-child(1) .glo-btn-text').click();
        cy.get('button[type="submit"]').contains('No thanks').click();

        cy.get('button[class="btn btn-action btn-cta"]').click();

        cy.get('.card:nth-child(1) .glo-btn-text').click();

        cy.get('button[type="submit"]').contains('No thanks').click();

        cy.get('.card:nth-child(1) .glo-btn-text').click();

        cy.get('button[type="submit"]').contains('No thanks').click();
        cy.get('#btn-save', { timeout: 30000 }).click();

        cy.get('#fname').type('FN');
        cy.get('#lname').type('LN');
        var email = 'test_' + Date.now().toString() + '@legalzoom.com';
        cy.get('#email').type(email);
        cy.get('input#phone').type('8182222222', { force: true });
        cy.get('#address1').type('101 N Brand Blvd., Glendale');
        cy.get('#ngb-typeahead-0-1', { timeout: 3000 }).click();
        cy.get('#cc-number').type('4111111111111111');
        cy.get('input#billingZip').type('91203');
        cy.get('#cc-exp').type('0950');
        cy.get('#cc-csc').type('009');
        cy.get('[for="pay-single"] .description-option-single').click();

        // GeoLocationHandler api call gets CORS error when running the test locally or on docker that results in G-shite page being skipped by the app. 
        // So this is a workaround until the team resolves this error (OPT-383).
        cy.intercept('GET', 'Handlers/geolocationhandler', {
            statusCode: 200
        });

        cy.get('#btn-save', { timeout: 3000 }).click();
        cy.get('app-desktop-lz-express-offers .title-2', { timeout: 85000 }).contains('Awesome').should('be.visible');
        cy.get('#btn-decline', { timeout: 5000 }).click();
        cy.get('#no-thanks-own-business a', { timeout: 5000 }).click();

        cy.get('#password').type("Test123");
        cy.get('#verifyPass').type("Test123");
        cy.get('button[data-testid="submitBtnSPC"]', { timeout: 5000 }).click();
        cy.get('#btn-save', { timeout: 15000 }).click();

        cy.reload();
        cy.get('input[name="businessName"]').type('Food Packers LLC',{ force: true });
        cy.get('#business-name-next', { timeout: 10000 }).click();

        cy.get('#business-name-designator-choice-0').shadow().find('input[name="businessNameDesignator"]').click({ force: true });
        cy.get('label[for="business-name-reviewed"]', { timeout: 10000 }).click({ force: true });
        cy.get('#business-detail-1 .text-right pl-button').shadow().find('button').click({ force: true });

        // Progress Passed Business Address
        cy.get('#business-detail-2 .text-right pl-button').shadow().find('button').click({ force: true });
        cy.get('#business-detail-2 .text-right pl-button').shadow().find('button').click({ force: true });

        // Professional LLC
        cy.get('#rd-pllc-2').shadow().find('input[name="isProfessionalLLC"]').click({ force: true });
        cy.get('#business-detail-5 .text-right pl-button').shadow().find('button').click({ force: true });

        // Business Owners
        cy.get('a#link-trust').click({ force: true });
        cy.get('#tw-trust-name-0').shadow().find('input[name="fullName"]').type('Test', { force: true });
        cy.get('#owner-detail-1 .text-right pl-button').shadow().find('button').click({ force: true });

        // Business Manager
        cy.get('pl-input[pl-name="managerName"]').shadow().find('input[name="managerName"]').type('Test automation', { force: true });
        cy.get('#owner-detail-6 .text-right pl-button').shadow().find('button').click({ force: true });


        //Contact information IRS
        cy.get('#tb-owner-0', { timeout: 10000 }).shadow().find('input').click({ force: true });
        cy.get('#tb-trust-grantor-first-name-0').shadow().find('input[placeholder="First name"]').type('FN', { force: true });
        cy.get('#tb-trust-grantor-middle-name-0').shadow().find('input[placeholder="Middle name"]').type('MN', { force: true });
        cy.get('#tb-trust-grantor-last-name-0').shadow().find('input[placeholder="Last name"]').type('LN', { force: true });
        cy.get('input#tb-trust-owner-phone-number-0').type('8182222233', { force: true });

        cy.get('input#tb-trust-owner-ssn-area-0').type('123');
        cy.get('input#tb-trust-owner-ssn-group-0').type('12');
        cy.get('input#tb-trust-owner-ssn-serial-0').type('1234');
        cy.get('#irs-detail-1 .text-right pl-button').shadow().find('button').click({ force: true });

        //Doing business under another name
        cy.get('#rd-dba-2').shadow().find('input[name="willHaveDBA"]').click({ force: true });
        cy.get('#ein-detail-1 .text-right pl-button').shadow().find('button').click({ force: true });

        //Do any of these options apply to your business?
        cy.get('pl-selection[pl-label="None of the above"]').shadow().find('input').click({ force: true });
        cy.get('#ein-detail-2 .text-right pl-button').shadow().find('button').click({ force: true });

        // Fiscal Year
        cy.get('#fiscal-year-detail .text-right pl-button').shadow().find('button').click({ force: true });

        cy.get('#btn-decline', { timeout: 10000 }).click();
        cy.get('pl-button[pl-name="submit"]').shadow().find('button').click({ force: true });

        cy.frameLoaded('#agreement-console');
        cy.wait(7000);
        cy.iframe('#agreement-console').find('#glo-form-check').should('be.visible').click();
        cy.iframe('#agreement-console').find('button[class="btn btn-action mt-4"]',{timeout:4000}).click();
        cy.get('div[class*="advisors-card-empty-state-title"]').should('be.visible').and('contain', 'Meet your business pros');
    });
});
