

describe('Address-Native Form and Autocomplete', () => {
    beforeEach(() => {
        // clear session storage before each test
        cy.window().then((win) => {
            win.sessionStorage.clear();
        });

        // Clear Cookies
        cy.clearCookies();
    });

    it('checks business address confirmation form for correct values', () => {
        cy.interceptTokensToAllowQ2Interaction();
        cy.goToQ2("California", "Cypress automated test");
        cy.contains("Check availability", { includeShadowDom: true }).click({ force: true });
        cy.businessNameConfirmQ2();

        cy.assertAddressFormValues(
            [
                ['Address Line 1', '101 N Brand Blvd'],
                ['City', 'Glendale'],
                ['State', 'CA'], ,
                ['ZIP Code', '91203'],
            ],
            'have.value')
    });

    it('checks typeahead suggestions are successfully applied to the form', () => {
        checkTypeAhead();
    });

});

function checkTypeAhead() {
    cy.interceptTokensToAllowQ2Interaction();
    cy.goToQ2("California", "Cypress automated test");
    cy.get('.pl-next-internal-step').shadow().find('button').click({ force: true })
    cy.businessNameConfirmQ2();

    cy.typeAhead("100 Congress Ave", "Address Line 1")

    const suggestion = cy.contains('100 Congress Ave Apt (39 entries) Bath, ME 04530')
    suggestion.should('be.visible')
    suggestion.click({ force: true });

    const deeperSuggestion = cy.contains(' Apt 1 Bath, ME 04530')
    deeperSuggestion.should('be.visible')
    deeperSuggestion.click({ force: true });

    cy.assertAddressFormValues(
        [
            ['Address Line 1', '100 Congress Ave'],
            ['Address Line 2', 'Apt 1'],
            ['City', 'Bath'],
            ['State', 'ME'],
            ['County', 'Sagadahoc'],
            ['ZIP Code', '04530'],
        ],
        'have.value')
}



