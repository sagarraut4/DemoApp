describe('pllc', () => {
    beforeEach(() => {
        // clear session storage before each test
        cy.window().then((win) => {
            win.sessionStorage.clear();
        });

        // Clear Cookies
        cy.clearCookies();
    });

    it('checks pllc for', () => {
        cy.interceptTokensToAllowQ2Interaction();
        cy.goToQ2("Colorado", "Cypress automated test");
        cy.contains("Check availability", { includeShadowDom: true }).click({ force: true });
        cy.businessNameConfirmQ2();

        // Need to not click multiple buttons on these
        cy.get('.business-address').shadow().find('button').click({ force: true })
        cy.get('.business-address').shadow().find('button').click({ force: true })
        cy.get('[data-cy=pllc-yes]').shadow().find('input').click({ force: true })

    });
});
