describe('Entity NameCheck [MA-91]', () => {
  beforeEach(() => {
    // clear session storage before each test
    cy.window().then((win) => {
      win.sessionStorage.clear();
    });
  });

  describe('e2e with all addons (TN) [MA-100]', () => {
    it('should go through Q1 ( with all addons ) and then lookup an entity name and finalize Q2', () => {
      const COMPANY_NAME = 'Farse';
      const ENTITY_STATE = 'Tennessee';
      const ENTITY_STATE_ABBREVIATION = 'TN';

      // Fill Out Q1
      cy.fillOutQuestionnaire1WithOptions(
        {
          mobile: true,
          entityName: COMPANY_NAME,
          entityState: ENTITY_STATE,
          industry: 'Caas'
        }
      );

      // Push through RYO
      cy.get('#btn-save', { timeout: 10000 }).click();

      // Fill Out Checkout Page
      cy.fillOutCheckout({
        state: ENTITY_STATE,
        proceed: false
      });

      // Disclaimer
      cy.get('.tn-disc-confirm > label').click();

      // Submit
      cy.get('#btn-save').click();

      // Post Checkout Options
      cy.postCheckoutOffers(true);

      // Set up API intercept
      cy.intercept('GET', '/entitydb/api/v1/availability').as('getEntityAvailability');
      cy.intercept('POST', '/v1/business-name-check/processing-orders').as('availabilityTransactionLogs');

      // Entity NameCheck
      cy.pl2Input('#tb-biz-name')
        .should('have.value', COMPANY_NAME);

      cy.pl2Button('.pl-next-internal-step')
        .click({ force: true });

      // Await API Responses
      cy.wait('@getEntityAvailability')
        .its('response.body')
        .should('include', { 'status': 'available' });
      cy.wait('@availabilityTransactionLogs')
        .its('response.body')
        .should('include', { 'success': true });

      cy.pl2Select('#business-name-designator-choice-0').click({ force: true });

      cy.get('#business-name-reviewed')
        .click({ force: true });

      cy.pl2Button('.pl-next-internal-step')
        .click({ force: true });

      // Progress Passed Business Address
      cy.get('#business-detail-2').should('have.class', 'pl-active');
      cy.pl2Button('.pl-active .pl-next-step')
        .click({ force: true })
        .click({ force: true });

      //Progress Passed Required Business Email for TN
      cy.get('#business-detail-4').should('have.class', 'pl-active');
      cy.pl2Input('pl-input#tb-biz-email')
        .click({ force: true})
        .type('cypressautomation@legalzoom.com',{ force: true });
      cy.pl2Button('.pl-active .pl-next-step')
        .click({ force: true });
  
      // Professional LLC
      cy.get('#business-detail-5').should('have.class', 'pl-active');
      cy.pl2Select('#rd-pllc-2').click({ force: true });

      cy.pl2Button('.pl-item.pl-active .pl-next-step')
        .click({ force: true });

      // Dissolve Date
      cy.get('#business-detail-8').should('have.class', 'pl-active');
      cy.pl2Select('#rd-dissolve-biz-1').click({ force: true });
      cy.pl2Input('#dp-dissolve-date')
        .type('9999-12-31', { force: true });
      cy.pl2Button('.pl-item.pl-active .pl-next-step')
        .click({ force: true });

      // Business Owners
      cy.get('#owner-detail-1').should('have.class', 'pl-active');
      cy.get('#link-trust').click();
      cy.pl2Input('#tw-trust-name-0')
        .type('Abc', { force: true });
      cy.pl2Button('.pl-item.pl-active .pl-next-step')
        .click({ force: true });

      // Business Manager
      cy.get('#owner-detail-6').should('have.class', 'pl-active');
      cy.pl2Input('.pl-item.pl-active pl-input[formcontrolname="fullName"]')
        .type('Abc', { force: true });
      cy.pl2Button('.pl-item.pl-active .pl-next-step')
        .click({ force: true });

      // IRS
      cy.get('#irs-detail-1').should('have.class', 'pl-active');
      cy.pl2Select('pl-selection#tb-owner-0').click({ force: true });
      cy.pl2Input('.pl-item.pl-active .irs-contact pl-input[formcontrolname="firstName"]')
        .type('Abc', { force: true });
      cy.pl2Input('.pl-item.pl-active .irs-contact pl-input[formcontrolname="lastName"]')
        .type('Abc', { force: true });
      cy.get('#tb-trust-owner-phone-number-0').type('1234567890');
      cy.get('#tb-trust-owner-ssn-area-0').type('123');
      cy.get('#tb-trust-owner-ssn-group-0').type('12');
      cy.get('#tb-trust-owner-ssn-serial-0').type('1234');
      cy.pl2Button('.pl-item.pl-active .pl-next-step')
        .click({ force: true });

      // DBA
      cy.get('#ein-detail-1').should('have.class', 'pl-active');
      cy.pl2Select('pl-selection#rd-dba-1').click({ force: true });
      cy.pl2Input('pl-input#tb-dba-name')
        .type('Abc', { force: true });
      cy.pl2Button('.pl-item.pl-active .pl-next-step')
        .click({ force: true });

      // Business Details
      cy.get('#ein-detail-2').should('have.class', 'pl-active');
      cy.pl2Select('#rd-vehicle-weight').click({ force: true });
      cy.pl2Select('#rd-sell-restrictions').click({ force: true });
      cy.pl2Select('#rd-excise-tax').click({ force: true });
      cy.pl2Select('#rd-wager').click({ force: true });
      cy.pl2Button('.pl-item.pl-active .pl-next-step')
        .click({ force: true });

      // Employment Hiring
      cy.get('#employee-detail-1').should('have.class', 'pl-active');
      cy.pl2Select('#rd-employees-1').click({ force: true });
      cy.pl2Counter('#tb-agri-emp-count', 'increase')
        .click();
      cy.pl2Counter('#tb-agri-emp-count', 'increase')
        .click();
      cy.pl2Counter('#tb-house-emp-count', 'increase')
        .click();
      cy.pl2Counter('#tb-other-emp-count', 'increase')
        .click();
      cy.pl2Button('.pl-item.pl-active .pl-next-step')
        .click({ force: true });

      // Paying Employees
      cy.get('#employee-detail-2').should('have.class', 'pl-active');
      cy.pl2Input('#dp-emp-pay-date')
        .type('9999-12-31', { force: true });
      cy.pl2Select('#rd-emp-pay-threshold-1').click({ force: true });
      cy.pl2Button('.pl-item.pl-active .pl-next-step')
        .click({ force: true });

      // Fiscal Year
      cy.get('#fiscal-year-detail').should('have.class', 'pl-active');
      cy.pl2Button('.pl-item.pl-active .pl-next-step')
        .click({ force: true });

      // Special Offers
      cy.get('#consultations-btn').click();

      // Q2 Complete
      cy.get('app-desktop-order-confirmation-ribbon')
        .should('be.visible');
    });
  });

  describe('e2e with all no addons (NV) [MA-101]', () => {
    it('should go through Q1 ( without addons ) and then lookup an entity name and finalize Q2', () => {
      const COMPANY_NAME = 'Farse';
      const ENTITY_STATE = 'Nevada';
      const ENTITY_STATE_ABBREVIATION = 'NV';

      // Fill Out Q1
      cy.fillOutQuestionnaire1WithOptions(
        {
          mobile: true,
          entityName: COMPANY_NAME,
          entityState: ENTITY_STATE,
          industry: 'Caas',
          startBusiness: 'future',
          isFirstLLC: false,
          hireEmployees: false,
          docOptions: 4,
          totalCompliance: false,
          packageSelection: 1,
          boaOffer: false
        }
      );

      // Push through RYO
      cy.get('#btn-save', { timeout: 10000 }).click();

      // Fill Out Checkout Page
      cy.fillOutCheckout({
        state: ENTITY_STATE
      });

      // Post Checkout Options
      cy.postCheckoutOffers(true);

      // Set up API intercept
      cy.intercept('GET', '/entitydb/api/v1/availability').as('getEntityAvailability');
      cy.intercept('POST', '/v1/business-name-check/processing-orders').as('availabilityTransactionLogs');

      // Entity NameCheck
      cy.pl2Input('#tb-biz-name')
        .should('have.value', COMPANY_NAME);

      cy.pl2Button('.pl-next-internal-step')
        .click({ force: true });

      // Await API Responses
      cy.wait('@getEntityAvailability')
        .its('response.body')
        .should('include', { 'status': 'available' });
      cy.wait('@availabilityTransactionLogs')
        .its('response.body')
        .should('include', { 'success': true });

      cy.pl2Select('#business-name-designator-choice-0').click({ force: true });

      cy.get('textarea[formcontrolname="businessNameExplanation"]')
        .type('Lorem ipsum and some soup my friend.')
        .click({ force: true });

      cy.get('#business-name-reviewed')
        .click({ force: true });

      cy.pl2Button('.pl-next-internal-step')
        .click({ force: true });

      // Progress Passed Business Address
      cy.get('#business-detail-2').should('have.class', 'pl-active');
      cy.pl2Button('.pl-active .pl-next-step')
        .click({ force: true })
        .click({ force: true });

      // Professional LLC
      cy.get('#business-detail-5').should('have.class', 'pl-active');
      cy.pl2Select('#rd-pllc-2').click({ force: true });

      cy.pl2Button('.pl-item.pl-active .pl-next-step')
        .click({ force: true });

      // Dissolve Date
      cy.get('#business-detail-8').should('have.class', 'pl-active');
      cy.pl2Select('#rd-dissolve-biz-1').click({ force: true });
      cy.pl2Input('#dp-dissolve-date')
        .type('9999-12-31', { force: true });
      cy.pl2Button('.pl-item.pl-active .pl-next-step')
        .click({ force: true });

      // Business Owners
      cy.get('#owner-detail-1').should('have.class', 'pl-active');
      cy.get('#link-trust').click();
      cy.pl2Input('#tw-trust-name-0')
        .type('Abc', { force: true });
      cy.pl2Button('.pl-item.pl-active .pl-next-step')
        .click({ force: true });

      // Business Manager
      cy.get('#owner-detail-6').should('have.class', 'pl-active');
      cy.pl2Input('.pl-item.pl-active pl-input[formcontrolname="fullName"]')
        .type('Abc', { force: true });
      cy.pl2Button('.pl-item.pl-active .pl-next-step')
        .click({ force: true });

      // Fiscal Year
      cy.get('#fiscal-year-detail').should('have.class', 'pl-active');
      cy.pl2Button('.pl-item.pl-active .pl-next-step')
        .click({ force: true });

      // Special Offers
      cy.get('#consultations-btn').click();

      // Q2 Complete
      cy.get('app-desktop-order-confirmation-ribbon')
        .should('be.visible');
    });
  });

  describe('Partial Flow - VA - Happy Path [MA-102]', () => {
    it('should verify business designator options for Q2', () => {
      const COMPANY_NAME = 'Farse';
      const ENTITY_STATE = 'Virginia';
      const ENTITY_STATE_ABBREVIATION = 'VA';

      // Intercepting API request to remove 401 requests due to old access tokens
      cy.intercept('POST', '/v1/business-name-check/processing-orders', { fixture: 'namecheck/transaction-log.json' });

      // Return "available" from namecheck API
      cy.intercept('GET', 'entitydb/api/v1/availability', { fixture: 'namecheck/available.json' });
      cy.goToQ2(ENTITY_STATE, COMPANY_NAME);

      // Advance to Progress screen
      cy.pl2Button('.pl-next-internal-step').click({ force: true });

      // Verify all three business designators are appended to business name
      cy.get('#business-name-designator-choice-0').contains(`${COMPANY_NAME} LLC`);
      cy.get('#business-name-designator-choice-1').contains(`${COMPANY_NAME} L.L.C.`);
      cy.get('#business-name-designator-choice-2').contains(`${COMPANY_NAME} Limited Liability Company`);

      // Select 1st business designator option
      cy.pl2Select('#business-name-designator-choice-0').click({ force: true });

      // Click review checkbox
      cy.get('#business-name-reviewed').click({ force: true });

      // Advance to next screen
      cy.pl2Button('.pl-next-internal-step').click({ force: true });

      // Verify on Business Address
      cy.get('#business-detail-2').should('have.class', 'pl-active'); // Element is always in the DOM so have to wait until it becomes active
    });
  });

  describe('Partial Flow - MA - 3 Failures [MA-103]', () => {
    it('should show validation failed page and can continue to business address after 3 failed namechecks with matching violation', () => {
      cy.goToQ2('Massachusetts', 'SomeMatchingName');

      // Intercepting API request to remove 401 requests due to old access tokens
      cy.intercept('POST', '/v1/business-name-check/processing-orders', { fixture: 'namecheck/transaction-log.json' });

      // Return error with matching
      cy.intercept('GET', 'entitydb/api/v1/availability', { fixture: 'namecheck/unavailable_matching.json' });

      cy.get('[pl-title="Check availability"]').click({ force: true });

      // Verify that you get the error message
      cy.get('#business-name-description-invalid').should('be.visible');
      cy.get('#business-name-check-errors').contains('Close similarities to an existing business name');

      // Try again
      cy.pl2Input('#tb-biz-name').clear().type('Some.Matching.Name', { force: true });
      cy.get('pl-button[pl-title="Check availability"]').click({ force: true });

      // Verify that you get the error message
      cy.get('#business-name-description-invalid').should('be.visible');
      cy.get('#business-name-check-errors').contains('Close similarities to an existing business name');

      // And again
      cy.pl2Input('#tb-biz-name').clear().type('somematchingname', { force: true });
      cy.get('pl-button[pl-title="Check availability"]').click({ force: true });

      // Verify that you get the validation failed page
      cy.get('#business-name-description-error')
        .should('be.visible')
        .contains('We\'ll do one more check on');

      // Proceed
      cy.pl2Button('app-business-details-namecheck-input pl-button.pl-next-step').click({ force: true });

      // Verify on Business Address
      cy.get('#business-detail-2').should('have.class', 'pl-active'); // Element is always in the DOM so have to wait until it becomes active
    });

    it('should show validation failed page and can continue to business address after 3 failed namechecks with profanity violation', () => {
      cy.goToQ2('Massachusetts', 'SomeProfaneName');

      // Intercepting API request to remove 401 requests due to old access tokens
      cy.intercept('POST', '/v1/business-name-check/processing-orders', { fixture: 'namecheck/transaction-log.json' });

      // Return error with profanity
      cy.intercept('GET', 'entitydb/api/v1/availability', { fixture: 'namecheck/unavailable_profanity.json' });

      cy.get('[pl-title="Check availability"]').click({ force: true });

      // Verify that you get the error message
      cy.get('#business-name-description-invalid').should('be.visible');
      cy.get('#business-name-check-errors').contains('Inappropriate words or language');

      // Try again
      cy.pl2Input('#tb-biz-name').clear().type('Some.Profane.Name', { force: true });
      cy.get('pl-button[pl-title="Check availability"]').click({ force: true });

      // Verify that you get the error message
      cy.get('#business-name-description-invalid').should('be.visible');
      cy.get('#business-name-check-errors').contains('Inappropriate words or language');

      // And again
      cy.pl2Input('#tb-biz-name').clear().type('someprofanename', { force: true });
      cy.get('pl-button[pl-title="Check availability"]').click({ force: true });

      // Verify that you get the validation failed page
      cy.get('#business-name-description-error')
        .should('be.visible')
        .contains('We\'ll do one more check on');

      // Proceed
      cy.pl2Button('app-business-details-namecheck-input pl-button.pl-next-step').click({ force: true });

      // Verify on Business Address
      cy.get('#business-detail-2').should('have.class', 'pl-active'); // Element is always in the DOM so have to wait until it becomes active
    });
  });

  describe('Submit same invalid name three times and continue [MA-205]', () => {
    it('should show validation failed page and can continue to business address after 3 failed namechecks with matching violation', () => {
      const businessName = 'null';
      cy.goToQ2('Massachusetts', businessName);

      // Intercepting API request to remove 401 requests due to old access tokens
      cy.intercept('POST', '/v1/business-name-check/processing-orders', { fixture: 'namecheck/transaction-log.json' });

      // Return error with matching
      cy.intercept('GET', 'entitydb/api/v1/availability', { fixture: 'namecheck/unavailable_matching.json' });

      cy.get('[pl-title="Check availability"]').click({ force: true });

      // Verify that you get the error message
      cy.get('#business-name-description-invalid').should('be.visible');
      cy.get('#business-name-check-errors').contains('Close similarities to an existing business name');

      // Try again
      cy.get('pl-button[pl-title="Check availability"]').click({ force: true });

      // Verify that you get the error message
      cy.get('#business-name-description-invalid').should('be.visible');
      cy.get('#business-name-check-errors').contains('Close similarities to an existing business name');

      // And again
      cy.get('pl-button[pl-title="Check availability"]').click({ force: true });

      // Verify that you get the validation failed page
      cy.get('#business-name-description-error')
        .should('be.visible')
        .contains('We\'ll do one more check on');

      // Proceed
      cy.pl2Button('app-business-details-namecheck-input pl-button.pl-next-step').click({ force: true });

      // Verify on Business Address
      cy.get('#business-detail-2').should('have.class', 'pl-active'); // Element is always in the DOM so have to wait until it becomes active
    });
  });

  describe('Partial Flow - TN - Try Another Name Even with Valid Response [MA-104]', () => {
    it('should verify that user can choose another name even if first name is available', () => {

      cy.goToQ2('Tennessee', 'SomeAvailableName');

      // Intercepting API request to remove 401 requests due to old access tokens
      cy.intercept('POST', '/v1/business-name-check/processing-orders', { fixture: 'namecheck/transaction-log.json' });

      // Return "available" from namecheck
      cy.intercept('GET', 'entitydb/api/v1/availability', { fixture: 'namecheck/available.json' });

      cy.get('[pl-title="Check availability"]').click({ force: true });

      // Choose different name
      cy.get('#check-different-name').should('be.visible').click({ force: true });

      // Name field should be empty tb-biz-name
      cy.pl2Input('#tb-biz-name')
        .should('be.empty');

      // Submit a 2nd name
      const bizName = 'Bluth Bananas';
      cy.pl2Input('#tb-biz-name').type(bizName, { force: true });
      cy.get('pl-button[pl-title="Check availability"]').click({ force: true });

      // Verify that name is available
      cy.get('#namecheck-results-confirmation-header').contains(bizName);
      cy.get('#namecheck-results-confirmation-header').contains('appears to be available!');

      // Choose designator and continue
      cy.pl2Select('#business-name-designator-choice-0')
        .click({ force: true });
      cy.get('#business-name-reviewed').click({ force: true });
      cy.get('app-business-details-namecheck-results pl-button[pl-title="Next Question"]').click({ force: true });

      // Verify on Business Address
      cy.get('#business-detail-2').should('have.class', 'pl-active'); // Element is always in the DOM so have to wait until it becomes active
    });
  });

  describe('Partial Flow - KS - 500 API Error [MA-105]', () => {
    it('Verify "check a different name" link does not display ', () => {
      const testBusinessName = 'Dog Taco and Grooming';

      // Return "available" from namecheck API
      cy.intercept('GET', 'entitydb/api/v1/availability', { statusCode: 500 });
      cy.goToQ2('Kansas', testBusinessName);

      // Advance to Progress screen, then to Validation Failed screen due to API error
      cy.pl2Button('.pl-next-internal-step').click({ force: true });

      // Negative assertion
      // Search body for link presence, fail if found
      cy.get('body').then($body => {
        const $checkADifferentNameLink = $body.find('#business-name-new');
        if ($checkADifferentNameLink.length > 0) {
          assert.isNotOk($checkADifferentNameLink.length > 0, '"Check a different name" link should not be displayed');
        } else {
          assert.isOk($checkADifferentNameLink.length === 0, '"Check a different name" link is not displayed');
        }
      });
    });
  });

  describe('Partial Flow - VT - API General Similarity response flow [MA-232]', () => {
    it('should take user to invalid flow', () => {
      const testBusinessName = 'bennington community theather mbe';

      // Intercepting API request to remove 401 requests due to old access tokens
      cy.intercept('POST', '/v1/business-name-check/processing-orders', { fixture: 'namecheck/transaction-log.json' });

      cy.intercept('GET', 'entitydb/api/v1/availability', { 
        statusCode: 200,
        fixture: 'namecheck/general-similarity.json'
      });
      cy.goToQ2('Vermont', testBusinessName);

      // Advance to Progress screen, then to Validation Failed screen due to API error
      cy.pl2Button('.pl-next-internal-step').click({ force: true });

      // Verify that you get the error message
      cy.get('div.error-msg span').contains('Close similarities to an existing business name');
    });
  });

  describe('Partial Flow - TX - Skip Business Name [MA-107]', () => {
    const getEntityAvailabilityStates = {
      available: 'namecheck/available.json',
      unavailable: 'namecheck/unavailable_matching.json'
    };
    let getEntityAvailabilityState = 'available';

    // Entity Name
    const testBusinessName = 'Farse';

    beforeEach(() => {
      // Reset State
      getEntityAvailabilityState = 'available';

      // Intercept availability response
      cy.intercept(
        'GET',
        'entitydb/api/v1/availability',
        (req) => {
          const fixture = getEntityAvailabilityStates[getEntityAvailabilityState];
          req.reply({ fixture });
        }
      ).as('getEntityAvailability');

      // Intercepting API request to remove 403 requests due to old access tokens
      cy.intercept('POST', '/v1/business-name-check/processing-orders', { fixture: 'namecheck/transaction-log.json' })
        .as('availabilityTransactionLogs');

      cy.goToQ2('Texas', null);
    });

    it('should be able to choose an entity name', () => {
      // Name field should be empty tb-biz-name
      cy.pl2Input('#tb-biz-name')
        .should('be.empty');

      // Advance to Progress screen
      cy.pl2Button('.pl-next-internal-step').click({ force: true });

      // Error Message
      cy.pl2InputError('#tb-biz-name')
        .should('contain', 'Business name is required');

      // Allowing Cypress to find a error
      cy.wait(500);

      // Type in Entity Name
      cy.pl2Input('#tb-biz-name')
        .type(testBusinessName, { force: true });

      // Advance to Progress screen
      cy.pl2Button('.pl-next-internal-step').click({ force: true });

      // Wait For API requests
      cy.wait('@getEntityAvailability');
      cy.wait('@availabilityTransactionLogs');

      // Verify all three business designators are appended to business name
      cy.get('#business-name-designator-choice-0').contains(`${testBusinessName} LLC`);
      cy.get('#business-name-designator-choice-1').contains(`${testBusinessName} L.L.C.`);
      cy.get('#business-name-designator-choice-2').contains(`${testBusinessName} Limited Liability Company`);

      // Select 1st business designator option
      cy.pl2Select('#business-name-designator-choice-0').click({ force: true });

      // Click review checkbox
      cy.get('#business-name-reviewed').click({ force: true });

      // Advance to next screen
      cy.pl2Button('.pl-next-internal-step').click({ force: true });

      // Verify on Business Address
      cy.get('#business-detail-2').should('have.class', 'pl-active'); // Element is always in the DOM so have to wait until it becomes active
    });

    it('should be able to fail then select a valid entity', () => {
      // Start Availability as Unavailable
      getEntityAvailabilityState = 'unavailable';

      // Name field should be empty tb-biz-name
      cy.pl2Input('#tb-biz-name')
        .should('be.empty');

      // Enter Entity Name
      cy.pl2Input('#tb-biz-name')
        .type(testBusinessName, { force: true });

      // Advance to Progress screen
      cy.pl2Button('.pl-next-internal-step').click({ force: true });

      // Wait For API requests
      cy.wait('@getEntityAvailability');
      cy.wait('@availabilityTransactionLogs').then(
        () => {
          getEntityAvailabilityState = 'available';
        }
      );

      // Verify that you get the error message
      cy.get('#business-name-description-invalid').should('be.visible');
      cy.get('#business-name-check-errors').contains('Close similarities to an existing business name');

      // Try again
      cy.pl2Input('#tb-biz-name')
        .clear()
        .type(`${testBusinessName} ${testBusinessName}`, { force: true });
      cy.pl2Button('.pl-next-internal-step').click({ force: true });

      // Wait For API requests
      cy.wait('@getEntityAvailability');
      cy.wait('@availabilityTransactionLogs');

      // Select 1st business designator option
      cy.pl2Select('#business-name-designator-choice-0').click({ force: true });

      // Click review checkbox
      cy.get('#business-name-reviewed').click({ force: true });

      // Advance to next screen
      cy.pl2Button('.pl-next-internal-step').click({ force: true });

      // Verify on Business Address
      cy.get('#business-detail-2').should('have.class', 'pl-active'); // Element is always in the DOM so have to wait until it becomes active
    });
  });
});
