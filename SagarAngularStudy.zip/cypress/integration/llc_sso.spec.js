describe('LLC SSO', () => {
  beforeEach(() => {
    Cypress.Cookies.preserveOnce(
      'LZUserIdentification',
      'LZAuthCookie',
      'ActiveSession',
      'IsGuestUser',
      'Registered'
    );
  });

  it('clears Auth0 universal login cookies', () => {
    cy.visit('https://dev-legalzoom.auth0.com/', {
      onBeforeLoad: () => {
        cy.clearLocalStorage();
      },
    });
  });

  it('should login', () => {
    cy.visit(
      '/name/state?entity=myTestEntity',
      {
        onBeforeLoad: (win) => {
          win.sessionStorage.clear();
          cy.clearCookies();
          cy.clearLocalStorage();
        },
      }
    );
    cy.wait(3000);

    cy.get('input#tb-entity-state').type('California');
    cy.get('#ngb-typeahead-0-0').click();
    cy.get('#btn-save').click();

    cy.wait(5000);

    cy.get('#lnk-save-progress').click('center');

    cy.url().should('include', '/login');

    cy.get('input[name=email]').type('newUser1@mailinator.com');
    cy.get('input[name=password]').type('Test1234');

    cy.get('button[name=submit]').click();

    cy.wait(2000);

    const ensureCookieProps = (c) => {
      expect(c).to.have.property('domain', '.legalzoom.com');
      expect(c).to.have.property('path', '/');

      return c;
    };

    // Apigee OAuth cookie
    cy.getCookie('LZUserIdentification')
      .should('exist')
      .then(ensureCookieProps)
      .then((c) => expect(c.value).to.be.a('string'));

    // session
    cy.getCookie('ActiveSession')
      .then(ensureCookieProps)
      .should('have.property', 'value', 'true');

    cy.getCookie('LZAuthCookie')
      .should('exist')
      .then(ensureCookieProps)
      .then((c) => expect(c.value).to.be.a('string'));

    cy.getCookie('IsGuestUser')
      .then(ensureCookieProps)
      .should('have.property', 'value', 'False');

    cy.getCookie('Registered')
      .then(ensureCookieProps)
      .should('have.property', 'value', '1');
  });

  it('should logout', () => {
    cy.get('#lnk-logout span').click();
    cy.wait(2000);
    expect(cy.getCookie('LZUserIdentification').value).to.be.undefined;
    expect(cy.getCookie('LZAuthCookie').value).to.be.undefined;
    expect(cy.getCookie('IsGuestUser').value).to.be.undefined;
  });

  it('should handle forgot password via legacy behavior', () => {
    cy.visit(
      '/name/state?entity=myTestEntity',
      {
        onBeforeLoad: (win) => {
          win.sessionStorage.clear();
          cy.clearCookies();
          cy.clearLocalStorage();
        },
      }
    );

    cy.wait(3000);
    cy.get('input#tb-entity-state').type('California');
    cy.get('#ngb-typeahead-0-0').click();
    cy.get('#btn-save').click();
    cy.wait(5000);
    cy.get('#lnk-save-progress').click('center');
    cy.url().should('include', '/login');
    cy.get('.auth0-lock-alternative > a.auth0-lock-alternative-link').click();
    cy.wait(2000);
    cy.url().should('include', '/Forgot-Password.aspx');
    cy.get('input[name=email]').type('newUser1@mailinator.com');
    cy.get('#SubmitBtn').click();
    cy.wait(2000);
    cy.url().should('include', '/Forgot-Password.aspx');
    cy.get('.forgot-password-section.confirmation-section > .return-text > a').click();
    cy.wait(2000);
    cy.url().should('include', '/SignIn.aspx');
  });
});
