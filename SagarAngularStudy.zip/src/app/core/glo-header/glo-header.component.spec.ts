import { PagePath } from '../../shared/models/page-model';
import { NgbModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppService } from '../../shared/state/app/app.service';
import { EventService } from '../../shared/services/event.service';
import { TrackingService } from '../../shared/services/tracking/tracking.service';
import { WindowRef } from '../../shared/services/windowRef.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { GloHeaderComponent } from './glo-header.component';
import { RouterTestingModule } from '@angular/router/testing';
import { UtilitiesService } from '@legalzoom/business-formation-sdk';
import { LocationStrategy } from '@angular/common';
import { Router } from '@angular/router';
import { Subject, of } from 'rxjs';
import { By } from '@angular/platform-browser';
import { WebSessionService } from '@legalzoom/web-session-sdk';
import { CustomerService } from '@legalzoom/customer-sdk';
import { CheckoutService as GCCheckoutService, GcPlCheckoutModule, CheckoutLibConfig, GcPlHeaderModule } from '@legalzoom/lib-checkout';
import { CookieService } from 'ngx-cookie';
import { FormatPhonePipe } from 'src/app/shared/pipes/format-phone';
import { MockComponent } from 'ng-mocks';
import { ContactInfoSliderComponent } from '../contact-info-slider/contact-info-slider.component';

declare global {
  interface Window {
    nativeWindow: any;
  }
}

describe('GloHeaderComponent', () => {
  let component: GloHeaderComponent;
  let fixture: ComponentFixture<GloHeaderComponent>;
  const mockUserService = {
    user: {}
  };
  const utag: any = {
    link() {
    }
  };
  const mockAppService = {
    currentView: '',
    loginEmail: '',
    app: {
      processingOrderId: 123
    }
  };
  const mockTrackingService = jasmine.createSpyObj(['winRef', 'ClearOAItems', 'MapToOAItems', 'sendAdConversion']);
  const mockWindowRef = jasmine.createSpyObj(['nativeWindow', 'utag']);
  mockWindowRef.nativeWindow.utag = utag;
  mockTrackingService.winRef.nativeWindow = mockWindowRef.nativeWindow;
  let mockEventService;
  let mockCustomerService;
  let mockWebSessionService;
  let mockUtilitiesService;
  let mockLocationStrategy;
  let mockGCCheckoutService;
  let mockCookieService;
  const mockRouter: any = {};
  const mockModalRef = {
    componentInstance: {},
    result: Promise.resolve({})
  };
  let mockModalService: any = {
    open() {
      return null;
    },
    close() {
      return null;
    }
  };
  beforeEach(async(() => {
    mockRouter.url = '/' + PagePath.RemainingQuestions;
    mockRouter.events = new Subject();
    mockLocationStrategy = jasmine.createSpyObj(['path']);
    mockEventService = jasmine.createSpyObj(['updateCheckoutFields']);
    mockCustomerService = jasmine.createSpyObj(['isGuestCustomer']);
    mockWebSessionService = jasmine.createSpyObj(['removeAndRevokeSession']);
    mockUtilitiesService = jasmine.createSpyObj(['clearUserSession', 'clearCookies']);
    mockGCCheckoutService = jasmine.createSpyObj(['gcHeaderLoaded']);
    mockCookieService = jasmine.createSpyObj(['get', 'post', 'put', 'delete']);
    mockLocationStrategy.path.and.returnValues(mockRouter.url);
    window.nativeWindow = window.nativeWindow || {};
    window.nativeWindow.location = { href: {} };
    mockGCCheckoutService.gcHeaderLoaded = new Subject();
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes([]),
        NgbModule,
        GcPlCheckoutModule.forRoot({
          baseUrl: '', caasUrl: 'environment.caasUrl', lzApiKeyWebSession: '', lzApiKeyAddressAutocomplete: '', applicationId: '',          
        } as CheckoutLibConfig),
        GcPlHeaderModule
      ],
      declarations: [
        GloHeaderComponent,
        FormatPhonePipe,
        MockComponent(ContactInfoSliderComponent)
      ],
      providers: [
        { provide: TrackingService, useValue: mockTrackingService },
        { provide: EventService, useValue: mockEventService },
        { provide: AppService, useValue: mockAppService },
        { provide: CustomerService, useValue: mockCustomerService },
        { provide: UtilitiesService, useValue: mockUtilitiesService },
        { provide: LocationStrategy, useValue: mockLocationStrategy },
        { provide: WebSessionService, useValue: mockWebSessionService },
        { provide: GCCheckoutService, useValue: mockGCCheckoutService },
        { provide: CookieService, useValue: mockCookieService },
        { provide: WindowRef, useValue: window },
        NgbModal
      ]
    })
      .compileComponents();
    mockModalService = TestBed.get(NgbModal);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GloHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    // Assert
    expect(component).toBeTruthy();
  });

  it('should show save progress link', async(() => {
    // Arrange
    mockCustomerService.isGuestCustomer.and.returnValues(true, true, true, true);
    fixture.detectChanges();
    const saveprogressLink = fixture.debugElement.query(By.css('#lnk-save-progress'));
    fixture.whenStable().then(() => {
      // Assert
      expect(saveprogressLink).not.toBeNull();
    });
  }));

  it('should show logout link', async(() => {
    // Arrange
    mockCustomerService.isGuestCustomer.and.returnValues(false, false, false, false);
    fixture.detectChanges();
    const saveprogressLink = fixture.debugElement.query(By.css('#lnk-logout'));
    fixture.whenStable().then(() => {
      // Assert
      expect(saveprogressLink).not.toBeNull();
    });
  }));


  it('should call webSessionService removeAndRevokeSession on click logout', async(() => {
    // Arrange
    mockWebSessionService.removeAndRevokeSession.and.returnValues(of(true));
    // Act
    component.logout();
    // Assert
    expect(mockWebSessionService.removeAndRevokeSession).toHaveBeenCalled();
    expect(mockUtilitiesService.clearUserSession).toHaveBeenCalled();
  }));

  it('should open saveYourWork model', async(() => {
    // Arrange
    mockLocationStrategy.path.and.returnValues(`/${PagePath.Checkout}/${PagePath.Checkout}`);
    mockModalRef.result = Promise.resolve({ Response: 'Success' });
    spyOn(mockModalService, 'open').and.returnValue(mockModalRef);
    // Act
    component.saveYourWork();
    // Assert
    mockModalRef.result.then((result) => {
      expect(mockEventService.updateCheckoutFields).toHaveBeenCalled();
    });
  }));

  it('should open saveYourWork model on click goHomepage', async(() => {
    // Arrange
    mockCustomerService.isGuestCustomer.and.returnValues(true);
    mockLocationStrategy.path.and.returnValues(`/${PagePath.Checkout}/${PagePath.Checkout}`);
    mockModalRef.result = Promise.resolve({ Response: 'Success' });
    spyOn(mockModalService, 'open').and.returnValue(mockModalRef);
    // Act
    component.goHomepage();
    // Assert
    mockModalRef.result.then((result) => {
      expect(result).toEqual({ Response: 'Success' });
    });
  }));

  it('should go to home page on click goHomepage if not guest user', async(() => {
    // Arrange
    mockCustomerService.isGuestCustomer.and.returnValues(false);
    // Act
    component.goHomepage();
    // Assert
    expect(window.nativeWindow.location.href).toBe('/');
    expect(mockUtilitiesService.clearUserSession).toHaveBeenCalled();
  }));
});
