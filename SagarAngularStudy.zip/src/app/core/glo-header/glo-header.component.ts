import { SessionStorageType } from '../../shared/services/tracking/session-storage';
import { AppService } from '../../shared/state/app/app.service';
import { Component, Input, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { SaveYourWorkModalComponent } from '../../shared/glo-login-modal/save-your-work-modal/save-your-work-modal.component';
import { UserDetailResponse } from '../../shared/models/login-model';
import { WindowRef } from '../../shared/services/windowRef.service';
import { LocationStrategy } from '@angular/common';
import { PagePath } from '../../shared/models/page-model';
import { TrackingService } from '../../shared/services/tracking/tracking.service';
import { HeaderDialogFormType } from '../../shared/models/dialog-model';
import { EventService } from '../../shared/services/event.service';
import { CookieName } from '../../shared/constants/product-domain';
import { UtilitiesService } from '@legalzoom/business-formation-sdk';
import { WebSessionService } from '@legalzoom/web-session-sdk';
import { CustomerService } from '@legalzoom/customer-sdk';
import { CheckoutService as GCCheckoutService } from '@legalzoom/lib-checkout';
import { ExperimentsService } from '../../shared/services/experiments/experiments.service';
import { environment } from '../../../environments/environment';
import { SsoFeatureFlagService } from '@legalzoom/site-sdk-sso';
import { CookieService } from 'ngx-cookie';
import { SsoService } from '../../shared/services/sso.service';
import { FormatPhonePipe } from '../../shared/pipes/format-phone';

@Component({
  selector: 'app-glo-header',
  templateUrl: './glo-header.component.html',
  styleUrls: ['./glo-header.component.scss'],
  providers: [FormatPhonePipe]
})
export class GloHeaderComponent implements OnInit {
  public myRouter: Router;
  @Input() mobile: boolean;
  public deskPhoneNum = '8557871221';
  public mobilePhoneNum = '8557871203';
  public isLocalHeader = true;
  public trackingType: string;
  public progressPercentage: string;
  public gcDeskPhoneNum = this.deskPhoneNum;
  public gcMobilePhoneNum = this.mobilePhoneNum;

  constructor(
    private router: Router,
    private modalService: NgbModal,
    private windowRef: WindowRef,
    private url: LocationStrategy,
    private trackingService: TrackingService,
    private eventService: EventService,
    private appService: AppService,
    private customerService: CustomerService,
    private webSessionService: WebSessionService,
    private utilitiesService: UtilitiesService,
    private gcCheckoutService: GCCheckoutService,
    private experimentService: ExperimentsService,
    private ssoService: SsoService,
    private cookieService: CookieService,
    private featureFlagService: SsoFeatureFlagService,
    private formatPhonePipe: FormatPhonePipe
  ) {
    this.myRouter = router;
  }

  ngOnInit() {
    this.updatePhoneBasedOnPosition();
    this.router.events.forEach((event) => {
      this.setProgress();

      if (event instanceof NavigationEnd) {
        this.updatePhoneBasedOnPosition();
        if (this.url.path().includes(`/${PagePath.Checkout}/${PagePath.Checkout}`)) {
          this.isLocalHeader = false;
        } else {
          this.isLocalHeader = true;
        }
      }
    });

    this.gcCheckoutService.gcHeaderLoaded.subscribe((subscriber) => {
      console.log('mobile tracking called');
      this.mobilePhoneTracking();
    });
  }

  private setProgress(): void {
    // routes and their corresponding percentages of completeness
    const routes = {
      '/name/state': 6,
      '/name/change-name': 6,
      '/name/name-available': 12,
      '/business/timeframe': 18,
      '/business/timeframe-confirm': 25,
      '/business/first-llc': 31,
      '/business/industry': 37,
      '/business/hire-employees': 43,
      '/essentials': 50,
      '/essentials/registered-agent': 56,
      '/essentials/critical-docs': 62,
      '/services': 69,
      '/services/legal': 75,
      '/services/compliance': 81,
      '/package/package-selection': 87,
      '/package/b-of-a-checking': 93,
      '/package/partners': 93
    };
    const routesB = {
      '/name/state': 6,
      '/name/change-name': 6,
      '/name/name-available': 12,
      '/business/timeframe': 18,
      '/business/timeframe-confirm': 25,
      '/business/first-llc': 31,
      '/business/industry': 37,
      '/business/hire-employees': 43,
      '/essentials': 50,
      '/essentials/registered-agent': 56,
      '/essentials/critical-docs': 62,
      '/services': 69,
      '/services/compliance': 75,
      '/services/affordable-help': 75,
      '/services/legal': 81,
      '/package/package-selection': 87,
      '/package/b-of-a-checking': 93,
      '/package/partners': 93
    };

    const [route, percentage] = Object.entries(routes)
      .sort(([key1], [key2]) => -key1.localeCompare(key2)) // order matters on this one to resolve full url matches over partials
      .find(([key]) => this.router.url.startsWith(key)) || ['', 0];

    this.progressPercentage = percentage === 0 ? 'hide' : `percentage-${percentage}`;
  }

  private updatePhoneBasedOnPosition(): void {
    if (this.url.path().includes(PagePath.RemainingQuestions) || this.url.path().includes(PagePath.PartnerOffers) || this.url.path().includes(PagePath.OrderConfirmationRibbon)) {
      // Q2 phone number
      this.deskPhoneNum = '8557871207';
      this.mobilePhoneNum = '8557871261';
    } else {
      this.deskPhoneNum = '8557730887';
      this.mobilePhoneNum = '8557871237';
    }

    this.gcDeskPhoneNum = this.formatPhonePipe.transform(this.deskPhoneNum);
    this.gcMobilePhoneNum = this.formatPhonePipe.transform(this.mobilePhoneNum);
  }

  public mobilePhoneTracking(): void {
    const win = this.trackingService.winRef.nativeWindow;
    // change tracking based on if it's q1 or q2
    const isQ2 = this.url.path().includes(PagePath.RemainingQuestions) || this.url.path().includes(PagePath.PartnerOffers) || this.url.path().includes(PagePath.OrderConfirmationRibbon);
    const cat = isQ2 ? 'biz_llc_Q2' : 'biz_llc_Q1';
    const label = isQ2 ? 'call_us_customer_care' : 'call_us_sales';
    win.utag.link({ ga_event_action: 'click', ga_event_category: cat, ga_event_label: label }, () => {
      if (win.utag_data) {
        win.utag_data.ga_event_action = '';
        win.utag_data.ga_event_category = '';
        win.utag_data.ga_event_label = '';
      }
    });
  }

  public userHasCart(): boolean {
    return typeof this.appService.app.processingOrderId !== 'undefined' && this.appService.app.processingOrderId !== undefined && this.appService.app.processingOrderId !== null;
  }

  public isGuest(): boolean {
    return this.ssoService.isGuest();
  }

  public isLoggedIn(): boolean {
    return this.ssoService.isLoggedIn();
  }

  public isGuestConvertedOnCheckout(): boolean {
    return this.appService.isGuestConvertedOnCheckout;
  };

  public goHomepage(): void {
    if (this.userHasCart() && this.isGuest()) {
      // prompt to save work
      const modalRef = this.modalService.open(SaveYourWorkModalComponent, { size: 'lg', windowClass: 'glo-modal', centered: true, scrollable: true });
      modalRef.componentInstance.currentFormType = HeaderDialogFormType.LZLogoSaveYourProgress;
      modalRef.result
        .then((res: UserDetailResponse) => {
          if (res.Response === 'Success') {
            modalRef.close();
          }
        })
        .catch((err) => {
          // do nothing
        });
    } else {
      this.utilitiesService.clearUserSession(false, SessionStorageType.APP);
      this.windowRef.nativeWindow.location.href = '/';
    }
  }

  public async saveYourWork() {
    const featureFlagName = environment.sso.configuration.launchDarkly.ssoFeatureFlag;
    const isSsoEnabled = await this.featureFlagService.isFlagEnabledAsync(featureFlagName);
    if (isSsoEnabled) {
      return this.ssoService.login({ displayContext: 'saveProgress' });
    }

    this.modalService
      .open(SaveYourWorkModalComponent, { size: 'lg', windowClass: 'glo-modal', centered: true, scrollable: true })
      .result.then((res: UserDetailResponse) => {
        if (res.Response === 'Success') {
          if (this.url.path().includes(`/${PagePath.Checkout}/${PagePath.Checkout}`)) {
            this.eventService.updateCheckoutFields();
          }
        }
      })
      .catch((err) => { });
  }

  public async logout() {
    const featureFlagName = environment.sso.configuration.launchDarkly.ssoFeatureFlag;
    const isSsoEnabled = await this.featureFlagService.isFlagEnabledAsync(featureFlagName);
    if (isSsoEnabled) {
      this.utilitiesService.clearUserSession(true, SessionStorageType.APP);
      return this.ssoService.logout(environment.sso.returnUrl);
    }

    this.webSessionService.removeAndRevokeSession().subscribe((res) => {
      this.utilitiesService.clearUserSession(true, SessionStorageType.APP);
      this.utilitiesService.clearCookies();
      this.windowRef.nativeWindow.location.href = '/';
    });
  }
}
