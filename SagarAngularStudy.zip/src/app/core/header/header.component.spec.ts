import { PagePath } from './../../shared/models/page-model';
import { NgbModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppService } from './../../shared/state/app/app.service';
import { EventService } from './../../shared/services/event.service';
import { TrackingService } from './../../shared/services/tracking/tracking.service';
import { WindowRef } from './../../shared/services/windowRef.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HeaderComponent } from './header.component';
import { RouterTestingModule } from '@angular/router/testing';
import { UtilitiesService } from '@legalzoom/business-formation-sdk';
import { LocationStrategy } from '@angular/common';
import { Router } from '@angular/router';
import { Subject, of } from 'rxjs';
import { By } from '@angular/platform-browser';
import { WebSessionService } from '@legalzoom/web-session-sdk';
import { CustomerService } from '@legalzoom/customer-sdk';
import { CheckoutService as GCCheckoutService, GcPlCheckoutModule } from '@legalzoom/lib-checkout';
import { CookieService } from 'ngx-cookie';
import { ExperimentsService } from '../../shared/services/experiments/experiments.service';

declare global {
  interface Window { nativeWindow: any; }
}

xdescribe('HeaderComponent', () => {
  let component: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;
  const mockUserService = {
    user: {}
  };
  const utag: any = {
    link() { }
  };
  const mockAppService = {
    currentView: '',
    loginEmail: '',
    app: {
      processingOrderId: 123
    }
  };
  const mockTrackingService = jasmine.createSpyObj(['winRef', 'ClearOAItems', 'MapToOAItems', 'sendAdConversion']);
  const mockWindowRef = jasmine.createSpyObj(['nativeWindow', 'utag']);
  mockWindowRef.nativeWindow.utag = utag;
  mockTrackingService.winRef.nativeWindow = mockWindowRef.nativeWindow;
  const mockExperimentsService = jasmine.createSpyObj(['getGloDesignTest']);
  let mockEventService;
  let mockCustomerService;
  let mockWebSessionService;
  let mockUtilitiesService;
  let mockLocationStrategy;
  let mockGCCheckoutService;
  let mockCookieService;
  const mockRouter: any = {};
  const mockModalRef = {
    componentInstance: {},
    result: Promise.resolve({})
  };
  let mockModalService: any = {
    open() {
      return null;
    },
    close() {
      return null;
    }
  };
  beforeEach(async(() => {
    mockRouter.url = '/' + PagePath.RemainingQuestions;
    mockRouter.events = new Subject();
    mockLocationStrategy = jasmine.createSpyObj(['path']);
    mockEventService = jasmine.createSpyObj(['updateCheckoutFields']);
    mockCustomerService = jasmine.createSpyObj(['isGuestCustomer']);
    mockWebSessionService = jasmine.createSpyObj(['removeAndRevokeSession']);
    mockUtilitiesService = jasmine.createSpyObj(['clearUserSession']);
    mockGCCheckoutService = jasmine.createSpyObj(['gcHeaderLoaded']);
    mockCookieService = jasmine.createSpyObj(['get', 'post', 'put', 'delete']);
    mockLocationStrategy.path.and.returnValues(mockRouter.url);
    window.nativeWindow = window.nativeWindow || {};
    window.nativeWindow.location = { href: {} };
    mockGCCheckoutService.gcHeaderLoaded = new Subject();
    TestBed.configureTestingModule({
      imports: [RouterTestingModule.withRoutes([]), NgbModule,
      GcPlCheckoutModule.forRoot({
        baseUrl: 'https://apidev.legalzoom.com',
        caasUrl: 'https://wwwdev.legalzoom.com',
        lzApiKeyWebSession: 'EFRxzIdlWU5DbGJIwmDtSZQYpQV3AXM0',
        lzApiKeyAddressAutocomplete: 'oKozctAjI0rNAoXeRD6SgSbRUeez1RGN',
        gcPageData: {
          desktopPhoneNumber: '(855) 787-1221',
          mobilePhoneNumber: '8557871203',
          title: 'LLC',
          phoneTooltip: `
    Mon-Fri 5am to 7pm PT
    Weekends 7am to 4pm PT
  `,
          processId: 2,
          questionnaireId: 27,

        },
        applicationId:'',
        logConfiguration: {
          applicationId: '5a9c2841-a169-471e-9af2-99590c9673ec',
          clientToken: 'pubab51a13f13d0e36243d0ec919e1db22c',
          site: 'datadoghq.com',
          sampleRate: 100,
          trackInteractions: true,
          silentMultipleInit: true
        }
      })],
      declarations: [HeaderComponent],
      providers: [
        { provide: TrackingService, useValue: mockTrackingService },
        { provide: EventService, useValue: mockEventService },
        { provide: AppService, useValue: mockAppService },
        { provide: CustomerService, useValue: mockCustomerService },
        { provide: UtilitiesService, useValue: mockUtilitiesService },
        { provide: LocationStrategy, useValue: mockLocationStrategy },
        { provide: WebSessionService, useValue: mockWebSessionService },
        { provide: GCCheckoutService, useValue: mockGCCheckoutService },
        { provide: CookieService, useValue: mockCookieService },
        { provide: WindowRef, useValue: window },
        { provide: ExperimentsService, useValue: mockExperimentsService },
        NgbModal
      ]
    })
      .compileComponents();
    mockModalService = TestBed.get(NgbModal);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    // Assert
    expect(component).toBeTruthy();
  });

  it('should show save progress link', async(() => {
    // Arrange
    mockCustomerService.isGuestCustomer.and.returnValues(true, true, true, true);
    fixture.detectChanges();
    const saveprogressLink = fixture.debugElement.query(By.css('#lnk-save-progress'));
    fixture.whenStable().then(() => {
      // Assert
      expect(saveprogressLink).not.toBeNull();
    });
  }));

  it('should show logout link', async(() => {
    // Arrange
    mockCustomerService.isGuestCustomer.and.returnValues(false, false, false, false);
    fixture.detectChanges();
    const saveprogressLink = fixture.debugElement.query(By.css('#lnk-logout'));
    fixture.whenStable().then(() => {
      // Assert
      expect(saveprogressLink).not.toBeNull();
    });
  }));


  it('should call webSessionService removeAndRevokeSession on click logout', async(() => {
    // Arrange
    mockWebSessionService.removeAndRevokeSession.and.returnValues(of(true));
    // Act
    component.logout();
    // Assert
    expect(mockWebSessionService.removeAndRevokeSession).toHaveBeenCalled();
    expect(mockUtilitiesService.clearUserSession).toHaveBeenCalled();
  }));

  it('should open saveYourWork model', async(() => {
    // Arrange
    mockLocationStrategy.path.and.returnValues(`/${PagePath.Checkout}/${PagePath.Checkout}`);
    mockModalRef.result = Promise.resolve({ Response: 'Success' });
    spyOn(mockModalService, 'open').and.returnValue(mockModalRef);
    // Act
    component.saveYourWork();
    // Assert
    mockModalRef.result.then((result) => {
      expect(mockEventService.updateCheckoutFields).toHaveBeenCalled();
    });
  }));

  it('should open saveYourWork model on click goHomepage', async(() => {
    // Arrange
    mockCustomerService.isGuestCustomer.and.returnValues(true);
    mockLocationStrategy.path.and.returnValues(`/${PagePath.Checkout}/${PagePath.Checkout}`);
    mockModalRef.result = Promise.resolve({ Response: 'Success' });
    spyOn(mockModalService, 'open').and.returnValue(mockModalRef);
    // Act
    component.goHomepage();
    // Assert
    mockModalRef.result.then((result) => {
      expect(result).toEqual({ Response: 'Success' });
    });
  }));

  it('should go to home page on click goHomepage if not guest user', async(() => {
    // Arrange
    mockCustomerService.isGuestCustomer.and.returnValues(false);
    // Act
    component.goHomepage();
    // Assert
    expect(window.nativeWindow.location.href).toBe('/');
  }));
});
