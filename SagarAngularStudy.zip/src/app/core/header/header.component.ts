import { SessionStorageType } from './../../shared/services/tracking/session-storage';
import { AppService } from './../../shared/state/app/app.service';
import { Component, Input, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { SaveYourWorkModalComponent } from '../../shared/login-modal/save-your-work-modal/save-your-work-modal.component';
import { UserDetailResponse } from '../../shared/models/login-model';
import { WindowRef } from '../../shared/services/windowRef.service';
import { LocationStrategy } from '@angular/common';
import { PagePath } from '../../shared/models/page-model';
import { TrackingService } from '../../shared/services/tracking/tracking.service';
import { HeaderDialogFormType } from '../../shared/models/dialog-model';
import { EventService } from '../../shared/services/event.service';
import { CookieName } from '../../shared/constants/product-domain';
import { UtilitiesService } from '@legalzoom/business-formation-sdk';
import { WebSessionService } from '@legalzoom/web-session-sdk';
import { CustomerService } from '@legalzoom/customer-sdk';
import { HelperService } from '@legalzoom/lib-checkout';
import { CheckoutService as GCCheckoutService } from '@legalzoom/lib-checkout';
import { environment } from '../../../environments/environment';
import { CookieService } from 'ngx-cookie';
import { SsoService } from '../../shared/services/sso.service';
import { SsoFeatureFlagService } from '@legalzoom/site-sdk-sso';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  public myRouter: Router;
  @Input() mobile: boolean;
  public deskPhoneNum = '(855) 787-1221';
  public mobilePhoneNum = '8557871203';
  public isLocalHeader = true;
  public trackingType: string;
  public hideMobile:boolean;
  constructor(
    private router: Router,
    private modalService: NgbModal,
    private windowRef: WindowRef,
    private url: LocationStrategy,
    private trackingService: TrackingService,
    private eventService: EventService,
    private appService: AppService,
    private customerService: CustomerService,
    private webSessionService: WebSessionService,
    private utilitiesService: UtilitiesService,
    private helperService: HelperService,
    private gcCheckoutService: GCCheckoutService,
    private ssoService: SsoService,
    private cookieService: CookieService,
    private featureFlagService: SsoFeatureFlagService,
  ) {
    this.myRouter = router;
  }

  ngOnInit() {
    this.updatePhoneBasedOnPosition();
    this.router.events.forEach((event) => {
      if (event instanceof NavigationEnd) {
        this.updatePhoneBasedOnPosition();
        if (this.url.path().includes(`/${PagePath.Checkout}/${PagePath.Checkout}`)) {
          this.isLocalHeader = false;
        } else {
          this.isLocalHeader = true;
        }
      }
    });
    this.appService.onHideMobile$.subscribe((res) => {
      this.hideMobile = res;
    });
    this.gcCheckoutService.gcHeaderLoaded.subscribe((subscriber) => {
      console.log('mobile tracking called');
      this.mobilePhoneTracking();
    });
  }

  private updatePhoneBasedOnPosition(): void {
    if (this.url.path().includes(PagePath.RemainingQuestions) || this.url.path().includes(PagePath.PartnerOffers) || this.url.path().includes(PagePath.OrderConfirmationRibbon)) {
      // Q2 phone number
      this.deskPhoneNum = '(855) 787-1207';
      this.mobilePhoneNum = '8557871261';
    } else {
      // Everywhere else phone number
      this.deskPhoneNum = '(855) 787-1221';
      this.mobilePhoneNum = '8557871203';
    }
  }

  public mobilePhoneTracking(): void {
    const win = this.trackingService.winRef.nativeWindow;
    // change tracking based on if it's q1 or q2
    const isQ2 = this.url.path().includes(PagePath.RemainingQuestions) || this.url.path().includes(PagePath.PartnerOffers) || this.url.path().includes(PagePath.OrderConfirmationRibbon);
    const cat = isQ2 ? 'biz_llc_Q2' : 'biz_llc_Q1';
    const label = isQ2 ? 'call_us_customer_care' : 'call_us_sales';
    win.utag.link({ ga_event_action: 'click', ga_event_category: cat, ga_event_label: label }, () => {
      if (win.utag_data) {
        win.utag_data.ga_event_action = '';
        win.utag_data.ga_event_category = '';
        win.utag_data.ga_event_label = '';
      }
    });
  }

  public userHasCart(): boolean {
    return typeof this.appService.app.processingOrderId !== 'undefined' && this.appService.app.processingOrderId !== undefined && this.appService.app.processingOrderId !== null;
  }

  public isGuest(): boolean {
    return this.ssoService.isGuest();
  }

  public isLoggedIn(): boolean {
    return this.ssoService.isLoggedIn();
  }

  public goHomepage(): void {
    if (this.userHasCart() && this.isGuest()) {
      // prompt to save work
      const modalRef = this.modalService.open(SaveYourWorkModalComponent, { size: 'lg' });
      modalRef.componentInstance.currentFormType = HeaderDialogFormType.LZLogoSaveYourProgress;
      modalRef.result
        .then((res: UserDetailResponse) => {
          if (res.Response === 'Success') {
            modalRef.close();
          }
        })
        .catch((err) => {
          // do nothing
        });
    } else {
      this.utilitiesService.clearUserSession(false, SessionStorageType.APP);
      this.windowRef.nativeWindow.location.href = '/';
    }
  }

  public async saveYourWork() {
    const featureFlagName = environment.sso.configuration.launchDarkly.ssoFeatureFlag;
    const isSsoEnabled = await this.featureFlagService.isFlagEnabledAsync(featureFlagName);
    if (isSsoEnabled) {
      return this.ssoService.login({ displayContext: 'saveProgress' });
    }

    this.modalService
      .open(SaveYourWorkModalComponent, { size: 'lg', windowClass: 'order-modal' })
      .result.then((res: UserDetailResponse) => {
        if (res.Response === 'Success') {
          if (this.url.path().includes(`/${PagePath.Checkout}/${PagePath.Checkout}`)) {
            this.eventService.updateCheckoutFields();
          }
        }
      })
      .catch((err) => { });
  }

  public async logout() {
    const featureFlagName = environment.sso.configuration.launchDarkly.ssoFeatureFlag;
    const isSsoEnabled = await this.featureFlagService.isFlagEnabledAsync(featureFlagName);
    if (isSsoEnabled) {
      this.utilitiesService.clearUserSession(true, SessionStorageType.APP);
      return this.ssoService.logout(environment.sso.returnUrl);
    }

    this.webSessionService.removeAndRevokeSession().subscribe((res) => {
      this.utilitiesService.clearUserSession(true, SessionStorageType.APP);
      this.utilitiesService.clearCookies();
      this.windowRef.nativeWindow.location.href = '/';
    });
  }
}
