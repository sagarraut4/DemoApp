// Framework
import { Component, Input, ViewEncapsulation } from '@angular/core';
import {
  fadeInOnEnterAnimation,
  fadeOutOnLeaveAnimation,
  slideInUpOnEnterAnimation,
  slideOutDownOnLeaveAnimation
} from 'angular-animations';

@Component({
  selector: 'app-contact-info-slider',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './contact-info-slider.component.html',
  styleUrls: ['./contact-info-slider.component.scss'],
  animations: [
    fadeInOnEnterAnimation({
      duration: 400
    }),
    fadeOutOnLeaveAnimation({
      duration: 400
    }),
    slideInUpOnEnterAnimation({
      duration: 400
    }),
    slideOutDownOnLeaveAnimation({
      duration: 400
    }),
  ]
})
export class ContactInfoSliderComponent {
  @Input() visible = false;
  @Input() phoneNumber: string;

  onClick_chatButton() {
    const el: HTMLLinkElement = document.querySelector('.chat-button');
    if (el) {
      el.click();
    }
    this.close();
  }

  open() {
    this.visible = true;
  }

  close() {
    this.visible = false;
  }

}
