import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';

@NgModule({
  imports: [
    CommonModule,
  ],
  declarations: [],
  exports: [],
  schemas: [],
})
export class CoreRoutingModule { }
