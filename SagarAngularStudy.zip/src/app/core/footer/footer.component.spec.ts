import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FooterComponent } from './footer.component';

describe('FooterComponent', () => {
  let component: FooterComponent;
  let fixture: ComponentFixture<FooterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FooterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  it('should create Footer Component', () => {
    expect(component).toBeTruthy();
  });
  it('should see Disclaimer text', () => {
    const footer = fixture.debugElement.nativeElement.querySelector('.cf-footer__disclaimer');
    expect(footer.innerText).toContain('Disclaimer:');
  });
});
