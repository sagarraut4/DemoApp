import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { CoreRoutingModule } from './core-routing.module';
import { GcPlHeaderModule } from '@legalzoom/lib-checkout';
import { environmentGC } from '../../../src/environments/environment';
import { GloHeaderComponent } from './glo-header/glo-header.component';
import { ContactInfoSliderComponent } from './contact-info-slider/contact-info-slider.component';
import { FormatPhonePipe } from '../shared/pipes/format-phone';
import { RouterModule } from '@angular/router';

@NgModule({
  imports: [
    CommonModule,
    CoreRoutingModule,
    RouterModule,
    GcPlHeaderModule.forRoot(environmentGC)
  ],
  declarations: [FormatPhonePipe, HeaderComponent, GloHeaderComponent, FooterComponent, ContactInfoSliderComponent],
  exports: [FormatPhonePipe, HeaderComponent, GloHeaderComponent, FooterComponent, GcPlHeaderModule, ContactInfoSliderComponent]
})
export class CoreModule { }
