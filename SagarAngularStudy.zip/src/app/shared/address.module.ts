import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddressComponent } from './components/address/address.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ReactiveFormsModule } from '@angular/forms';
import { FormatterModule } from './directives/formatter/formatter.module';
import { LzAddressComponent } from './components/lz-address/lz-address.component';

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    NgbModule,
    FormatterModule
  ],
  declarations: [AddressComponent, LzAddressComponent],
  exports: [AddressComponent, LzAddressComponent]
})
export class AddressModule { }
