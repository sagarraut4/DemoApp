import { Component, HostBinding } from '@angular/core';

@Component({
  selector : 'app-micro-copy',
  templateUrl : './micro-copy.component.html',
  styleUrls : ['./micro-copy.component.scss'],
})
export class MicroCopyComponent {
  @HostBinding('class.app-micro-copy') public defaultClass = true;

  public constructor() { }
}
