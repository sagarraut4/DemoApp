import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MicroCopyComponent } from './micro-copy.component';
import { Component } from '@angular/core';

@Component({
  selector: 'app-fake-copy',
  template: '<div>Selected</div>'
})
class FakeMicroCopyComponent {

}
describe('MicroCopyComponent', () => {
  let component: MicroCopyComponent;
  let fixture: ComponentFixture<MicroCopyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MicroCopyComponent, FakeMicroCopyComponent ]

    }).compileComponents().then(() => {
      fixture = TestBed.createComponent(MicroCopyComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });
  }));
  it('should create MicroCopyComponent', () => {
    expect(component).toBeTruthy();
  });
  it('should have defaultClass value to true', () => {
    expect(component.defaultClass).toBeTruthy();
  });

});
