import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder, ReactiveFormsModule, FormControl } from '@angular/forms';
import { SetPasswordComponent } from './set-password.component';

describe('SetPasswordComponent', () => {
  let component: SetPasswordComponent;
  let fixture: ComponentFixture<SetPasswordComponent>;
  const formBuilder: FormBuilder = new FormBuilder();


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SetPasswordComponent],
      imports: [ReactiveFormsModule],
      providers: [
        { provide: FormBuilder, useValue: formBuilder }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SetPasswordComponent);
    component = fixture.componentInstance;
    component.titleText = "Set up your online account";
    component.descriptionText = "Create a password for <strong>someone@email.com</strong>.";
    component.enterPasswordLabel = "Password";
    component.verifyPasswordLabel = "Verify Password";
    component.btnText = "Create account";
    component.form = formBuilder.group({
      password: new FormControl(component.enterPasswordLabel),
      verifyPass: new FormControl(component.verifyPasswordLabel)
    })
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display correct text in title', () => {
    const data = fixture.nativeElement;
    expect(data.querySelector("[data-testid='titleText']").textContent).toContain(component.titleText);
  });

  it('should display correct text in the description', () => {
    const data = fixture.nativeElement;
    const textDescription = data.querySelector("[data-testid='descriptionText']");
    expect(textDescription.innerHTML).toBe(component.descriptionText);
  });

  it('should display correct text in input labels', () => {
    const data = fixture.nativeElement;
    expect(data.querySelector("[data-testid='enterPasswordLabel']").textContent).toContain(component.enterPasswordLabel);
    expect(data.querySelector("[data-testid='verifyPasswordLabel']").textContent).toContain(component.verifyPasswordLabel);
  });

  it('should display correct text in submit btn', () => {
    const data = fixture.nativeElement;
    expect(data.querySelector("[data-testid='btnText']").textContent).toContain(component.btnText);
  });

  it('should display type=text/password on enterPasswordInput when eye icon is clicked', () => {
    const data = fixture.nativeElement;
    const eyeIcon = data.querySelector("[data-testid='eyeIconEnterPass']");
    const enterPasswordInput = data.querySelector("[data-testid='enterPasswordInput']");
    eyeIcon.click();
    expect(enterPasswordInput.getAttribute('type')).toBe('text');
    eyeIcon.click();
    expect(enterPasswordInput.getAttribute('type')).toBe('password');
  });

  it('should display type=text/password on verifyPasswordInput when eye icon is clicked', () => {
    const data = fixture.nativeElement;
    const eyeIcon = data.querySelector("[data-testid='eyeIconVerifyPass']");
    const verifyPasswordInput = data.querySelector("[data-testid='verifyPasswordInput']");
    eyeIcon.click();
    expect(verifyPasswordInput.getAttribute('type')).toBe('text');
    eyeIcon.click();
    expect(verifyPasswordInput.getAttribute('type')).toBe('password');
  });

  it('should display password required message for first input', () => {
    const data = fixture.nativeElement;
    const passwordElement: HTMLInputElement = data.querySelector("[data-testid='enterPasswordInput']");
    passwordElement.value = '';
    passwordElement.dispatchEvent(new Event('input'));
    passwordElement.dispatchEvent(new Event('blur'));
    fixture.detectChanges();
    const passwordValidator: HTMLSpanElement = data.querySelector("[data-testid='passRequired']");
    expect(passwordValidator.innerHTML).toEqual('Password is required.');
    expect(passwordValidator).not.toBeNull();
  });

  it('should display password required message for second input', () => {
    const data = fixture.nativeElement;
    const passwordElement: HTMLInputElement = data.querySelector("[data-testid='verifyPasswordInput']");
    passwordElement.value = '';
    passwordElement.dispatchEvent(new Event('input'));
    passwordElement.dispatchEvent(new Event('blur'));
    fixture.detectChanges();
    const passwordValidator: HTMLSpanElement = data.querySelector("[data-testid='verifyRequired']");
    expect(passwordValidator.innerHTML).toEqual('Password is required.');
    expect(passwordValidator).not.toBeNull();
  });

  it('should display password length message for first input', () => {
    const data = fixture.nativeElement;
    const passwordElement: HTMLInputElement = data.querySelector("[data-testid='enterPasswordInput']");
    passwordElement.value = 'four';
    passwordElement.dispatchEvent(new Event('input'));
    passwordElement.dispatchEvent(new Event('blur'));
    fixture.detectChanges();
    const passwordValidator: HTMLSpanElement = data.querySelector("[data-testid='passLength']");
    expect(passwordValidator.innerHTML).toEqual('Please use at least 6 characters.');
    expect(passwordValidator).not.toBeNull();
  });

  it("should display passwords don't match message for second input", () => {
    const data = fixture.nativeElement;
    const passwordElement: HTMLInputElement = data.querySelector("[data-testid='enterPasswordInput']");
    const verifyElement: HTMLInputElement = data.querySelector("[data-testid='verifyPasswordInput']");
    passwordElement.value = 'test1234';
    passwordElement.dispatchEvent(new Event('input'));
    passwordElement.dispatchEvent(new Event('blur'));
    verifyElement.value = 'test123';
    verifyElement.dispatchEvent(new Event('input'));
    verifyElement.dispatchEvent(new Event('blur'));
    fixture.detectChanges();
    const passwordValidator: HTMLSpanElement = data.querySelector("[data-testid='passMatch']");
    expect(passwordValidator.innerHTML).toEqual("Passwords don't match.");
    expect(passwordValidator).not.toBeNull();
  });

  it("submit button should have the disable attribute", () => {
    const data = fixture.nativeElement;
    const submitBtn = data.querySelector("[data-testid='submitBtnSPC']");
    expect(submitBtn.hasAttribute('disabled')).toBe(true);
  });

  it("submit button shouldn't have the disable attribute", () => {
    const data = fixture.nativeElement;
    const passwordElement: HTMLInputElement = data.querySelector("[data-testid='enterPasswordInput']");
    const verifyElement: HTMLInputElement = data.querySelector("[data-testid='verifyPasswordInput']");
    const submitBtn = data.querySelector("[data-testid='submitBtnSPC']");
    passwordElement.value = 'test1234';
    passwordElement.dispatchEvent(new Event('input'));
    passwordElement.dispatchEvent(new Event('blur'));
    verifyElement.value = 'test1234';
    verifyElement.dispatchEvent(new Event('input'));
    verifyElement.dispatchEvent(new Event('blur'));
    fixture.detectChanges();
    expect(submitBtn.hasAttribute('disabled')).toBe(false);
  });
});