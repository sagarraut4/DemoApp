import { Component, OnInit, ViewChild, ElementRef, Renderer2, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators, AbstractControl } from '@angular/forms';

@Component({
  selector: 'app-set-password',
  templateUrl: './set-password.component.html',
  styleUrls: ['./set-password.component.scss']
})

export class SetPasswordComponent implements OnInit {
  @Input() titleText: string;
  @Input() descriptionText: string;
  @Input() enterPasswordLabel: string;
  @Input() verifyPasswordLabel: string;
  @Input() btnText: string;
  @Output() onFormSubmit: EventEmitter<any> = new EventEmitter<any>();

  @ViewChild('password', { static: false }) passwordRef: ElementRef;
  @ViewChild('verifyPass', { static: false }) verifyPassRef: ElementRef;

  public form: FormGroup;
  public isPasswordVisible: boolean = false;
  public isVerifyPassVisible: boolean = false;

  constructor(
    private renderer: Renderer2,
    private fb: FormBuilder,
  ) {
  }

  ngOnInit(): void {
    this.initializeForm();
  }

  initializeForm(): void {
    this.form = this.fb.group({
      password: ['', [Validators.required, Validators.minLength(6)]],
      verifyPass: ['', [Validators.required, Validators.minLength(6)]]
    }, { validator: this.passwordConfirming });
  }

  passwordConfirming(c: AbstractControl): { invalid: boolean } {
    if (c.get('password'). value !== c.get('verifyPass').value) {
      return { invalid: true };
    }
  }

  get passwordGet() {
    return this.form.get('password');
  }

  get verifyPassGet() {
    return this.form.get('verifyPass');
  }

  onSubmit(): void {
    this.onFormSubmit.emit(this.form.value.verifyPass);
  }

  toggleVisibility(elemRef) {
    const inputType = elemRef.nativeElement.getAttribute('type') === 'password' ? 'text' : 'password';
    this.renderer.setAttribute(elemRef.nativeElement, 'type', inputType);
    if (elemRef === this.passwordRef) {
      this.isPasswordVisible = inputType === 'password' ? false : true;
    } else if (elemRef === this.verifyPassRef) {
      this.isVerifyPassVisible = inputType === 'password' ? false : true;
    }
  }
}