import {  Component, OnInit, Input, OnChanges, SimpleChanges, AfterViewInit, Renderer2, ViewChild, ElementRef} from '@angular/core';
import { FormGroup, Validators } from '@angular/forms';
import { Observable, of } from 'rxjs';
import { switchMap, debounceTime, distinctUntilChanged, catchError } from 'rxjs/operators';
import { ConstantsService } from '../../services/constants.service';
import { ValidateName } from '../../validators/form-control.validator';
import { NgbTypeahead } from '@ng-bootstrap/ng-bootstrap';
import { AddressAutocompleteService, IAutocompleteAddress, IAddressValidation } from '@legalzoom/address-autocomplete-sdk';

let nextId = 0;

@Component({
  selector: 'app-lz-address',
  templateUrl: './lz-address.component.html',
  styleUrls: ['./lz-address.component.scss']
})
export class LzAddressComponent implements OnInit, OnChanges, AfterViewInit {
  @Input() addressForm: FormGroup;
  @Input() validateForm: boolean;
  @Input() isRequired = false;
  public selectedAddressInvalid: boolean;
  public states = ConstantsService.GetAllStates();
  @ViewChild('address1', { static: false}) address1Ref: ElementRef;
  // generate unique id for element id attribute per component instance
  public id: number = nextId++;

  constructor(
    private autocomplete: AddressAutocompleteService,
    private renderer: Renderer2
  ) { }

  ngOnInit() {
    this.selectedAddressInvalid = false;
  }

  ngAfterViewInit() {
    // overwrites autocomplete=off which is set by ngbtypeahead and does not work
   this.renderer.setAttribute(this.address1Ref.nativeElement, 'autocomplete', 'no');
  }

  resultFormatter = (result: IAutocompleteAddress) => result.text;
  inputFormatter = (result: IAutocompleteAddress) => result.streetLine;

  searchAddress = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(200),
      distinctUntilChanged(),
      switchMap(term => this.autocomplete.getAddressSuggestions(term).pipe(
        catchError(() => {
          return of([]);
        }))
      ),
    )

  selectedAddress(event: any): void {
    const address: IAutocompleteAddress = event.item;
    // address line1 gets filled by input formatter
    this.addressForm.controls.city.setValue(address.city);
    this.addressForm.controls.state.setValue(address.state);
    this.addressForm.controls.zipCode.setValue('');
    this.autocomplete.getAddressValidation(address.streetLine, address.city, address.state).subscribe((res: IAddressValidation) => {
      if (res.addressInfo && res.addressInfo.length > 0) {
        this.addressForm.controls.zipCode.setValue(res.addressInfo[0].components.zipCode);
      }
      this.addressForm.controls.zipCode.markAsDirty();
      this.addressForm.controls.zipCode.markAsTouched();
      this.selectedAddressInvalid = res.isValidated ? false : true;
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (this.isRequired) {
      this.addressForm.controls.address1.setValidators([Validators.required]);
      this.addressForm.controls.address1.updateValueAndValidity();
      this.addressForm.controls.city.setValidators([Validators.required, ValidateName]);
      this.addressForm.controls.city.updateValueAndValidity();
      this.addressForm.controls.state.setValidators([Validators.required]);
      this.addressForm.controls.state.updateValueAndValidity();
      this.addressForm.controls.zipCode.setValidators([Validators.required]);
      this.addressForm.controls.zipCode.updateValueAndValidity();
    } else {
      this.addressForm.controls.address1.clearValidators();
      this.addressForm.controls.address1.updateValueAndValidity();
      this.addressForm.controls.city.clearValidators();
      this.addressForm.controls.city.updateValueAndValidity();
      this.addressForm.controls.state.clearValidators();
      this.addressForm.controls.state.updateValueAndValidity();
      this.addressForm.controls.zipCode.clearValidators();
      this.addressForm.controls.zipCode.updateValueAndValidity();
    }
  }

  public checkInteger(e: KeyboardEvent): boolean {
    const regex = /^[0-9]+$/;
    const keysAllowed = ['backspace', 'tab'];
    return (e.key.match(regex) !== null || keysAllowed.indexOf(e.key.toLowerCase()) > -1);
  }
}
