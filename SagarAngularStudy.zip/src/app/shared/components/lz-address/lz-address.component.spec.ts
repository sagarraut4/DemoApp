import { NgbTypeahead } from '@ng-bootstrap/ng-bootstrap';
import { ReactiveFormsModule, FormBuilder, FormControl } from '@angular/forms';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { LzAddressComponent } from './lz-address.component';
import { AddressAutocompleteService } from '@legalzoom/address-autocomplete-sdk';

describe('LzAddressComponent', () => {
  let component: LzAddressComponent;
  let fixture: ComponentFixture<LzAddressComponent>;
  const formBuilder: FormBuilder = new FormBuilder();
  let mockAddressAutocompleteService = jasmine.createSpyObj(['getAddressSuggestions', 'getAddressValidation']);

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [LzAddressComponent, NgbTypeahead],
      imports: [ReactiveFormsModule],
      providers: [
        { provide: AddressAutocompleteService, useValue: mockAddressAutocompleteService },
        { provide: FormBuilder, useValue: formBuilder }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LzAddressComponent);
    component = fixture.componentInstance;
    component.addressForm = formBuilder.group({
      address1: new FormControl(''),
      address2: new FormControl(''),
      city: new FormControl(''),
      state: new FormControl(''),
      zipCode: new FormControl(''),
      county: new FormControl('')
    });
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('selectedAddressInvalid should be false after component has been created', () => {
    expect(component).toBeTruthy();
    expect(component.selectedAddressInvalid).toBe(false);
  });

  it('selectedAddress method should save the values in addressForm', async () => {
    mockAddressAutocompleteService.getAddressValidation.and.returnValue(of({
      addressInfo: '',
      isValidated: false
    }));
    const event = {
      item: {
        text: 'address 1',
        streetLine: 'street 1',
        city: 'city',
        state: 'state',
        zipCode: '1134'
      }
    };
    component.selectedAddress(event);
    await fixture.whenStable();
    expect(component.addressForm.controls.city.value).toBe(event.item.city);
    expect(component.addressForm.controls.state.value).toBe(event.item.state);
    expect(component.addressForm.controls.zipCode.value).toBe('');
    expect(component.addressForm.controls.county.value).toBe('');
  });
});
