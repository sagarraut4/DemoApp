import { Component, Input, OnInit } from '@angular/core';
import { Router, NavigationEnd, UrlTree, PRIMARY_OUTLET, UrlSegment } from '@angular/router';
import { QuestionnaireService } from '../../services/questionnaire/questionnaire.service';
import { Chapter, PagePath } from '../../models/page-model';
import { QuestionnaireRoutingService } from '../../services/questionnaire-routing/questionnaire-routing.service';
import { WindowRef } from '../../services/windowRef.service';
import { QuestionnaireStorageService } from '@legalzoom/questionnaire-storage-sdk';
import { AppService } from './../../state/app/app.service';

@Component({
  selector: 'app-chapter-bar',
  templateUrl: './chapter-bar.component.html',
  styleUrls: ['./chapter-bar.component.scss']
})
export class ChapterBarComponent implements OnInit {
  @Input() mobile: boolean;
  public chapter1: string;
  public chapter2: string;
  public chapter3: string;
  public chapter4: string;
  public chapter5: string;
  public chapter6: string;

  public disableNext = true;
  public disablePrev = false;

  public hideNext = false;
  public hidePrev = false;

  public hideChapterBar = true;
  public isCheckoutPage = false;
  constructor(
    public router: Router,
    private questionnaireService: QuestionnaireService,
    private questionnaireRoutingService: QuestionnaireRoutingService,
    private windowRef: WindowRef,
    private questionnaireStorageService: QuestionnaireStorageService,
    private appService: AppService
  ) { }

  ngOnInit() {
    this.router.events.subscribe((event) => {
      if (!(event instanceof NavigationEnd)) {
        return;
      }

      if (this.questionnaireService.broswerHistory && this.questionnaireService.broswerHistory.length > 0) {
        this.disableNext = false;
      } else {
        this.disableNext = true;
      }

      if (this.router.url.startsWith('/' + Chapter.Checkout + '/' + PagePath.ReviewYourOrder) || this.router.url.startsWith('/' + Chapter.Checkout + '/' + PagePath.Checkout)) {
        this.hidePrev = true;
        this.hideNext = true;
      } else {
        this.hidePrev = false;
        this.hideNext = false;
      }

      if (this.router.url.startsWith('/' + Chapter.PostOrder + '/') || this.router.url.startsWith('/overview') || (this.questionnaireService.llc.isMobile && this.router.url.startsWith('/' + Chapter.Checkout + '/' + PagePath.Checkout))) {
        this.hideChapterBar = true;
      } else {
        this.hideChapterBar = false;
      }
      if (this.router.url.startsWith('/' + Chapter.Checkout + '/' + PagePath.Checkout)) {
        this.isCheckoutPage = true;
      } else {
        this.isCheckoutPage = false;
      }
      this.updateChapter(this.router.url);
    });
  }
  private updateChapter(currentURL) {
    if (currentURL.startsWith('/' + Chapter.Name)) {
      this.chapter1 = 'active';
      this.chapter2 = '';
      this.chapter3 = '';
      this.chapter4 = '';
      this.chapter5 = '';
      this.chapter6 = '';
    } else if (currentURL.startsWith('/' + Chapter.Business)) {
      this.chapter1 = 'complete';
      this.chapter2 = 'active';
      this.chapter3 = '';
      this.chapter4 = '';
      this.chapter5 = '';
      this.chapter6 = '';
    } else if (currentURL.startsWith('/' + Chapter.Essentials)) {
      this.chapter1 = 'complete';
      this.chapter2 = 'complete';
      this.chapter3 = 'active';
      this.chapter4 = '';
      this.chapter5 = '';
      this.chapter6 = '';
    } else if (currentURL.startsWith('/' + Chapter.Services)) {
      this.chapter1 = 'complete';
      this.chapter2 = 'complete';
      this.chapter3 = 'complete';
      this.chapter4 = 'active';
      this.chapter5 = '';
      this.chapter6 = '';
    } else if (currentURL.startsWith('/' + Chapter.Package)) {
      this.chapter1 = 'complete';
      this.chapter2 = 'complete';
      this.chapter3 = 'complete';
      this.chapter4 = 'complete';
      this.chapter5 = 'active';
      this.chapter6 = '';
    } else if (currentURL.startsWith('/' + Chapter.Checkout)) {
      this.chapter1 = 'complete';
      this.chapter2 = 'complete';
      this.chapter3 = 'complete';
      this.chapter4 = 'complete';
      this.chapter5 = 'complete';
      this.chapter6 = 'active';
    }
  }

  prevBtn(): void {
    if (typeof this.questionnaireService.broswerHistory === 'undefined') {
      this.questionnaireService.broswerHistory = [];
    }
    this.questionnaireService.broswerHistory.push(this.router.url);

    const urlTree: UrlTree = this.router.parseUrl(this.router.url);
    if (urlTree.root.hasChildren) {
      const urlSegments: UrlSegment[] = urlTree.root.children[PRIMARY_OUTLET].segments;
      const prevPage = this.questionnaireRoutingService.getPreviousPage(urlSegments[urlSegments.length - 1].path);

      if ((this.questionnaireService.llc.isChooseEntityNameLater || !this.questionnaireService.llc.isMobile) && urlSegments[urlSegments.length - 1].path === PagePath.BusinessState) {
        this.windowRef.nativeWindow.location.href = PagePath.LLCLandingPage;
        return;
      }

      this.router
        .navigate([prevPage], {
          queryParams: {
            uo: this.appService.processingOrderId,
            cartId: this.appService.cartId,
            orderId: this.appService.orderId
          },
          queryParamsHandling: 'merge'
        })
        .then(() => {
          // save last visited page
          this.questionnaireService.llc.currentView = prevPage;
          this.appService.currentView = prevPage;
          this.questionnaireStorageService.updateQuestionnaireStorage(this.appService.app.processingOrderId, this.questionnaireService.llc).subscribe();
        });
    }
  }

  shouldDisableNext() {
    return this.disableNext;
  }

  nextBtn(): void {
    this.questionnaireService.broswerHistory.pop();

    const urlTree: UrlTree = this.router.parseUrl(this.router.url);
    if (urlTree.root.hasChildren) {
      const urlSegments: UrlSegment[] = urlTree.root.children[PRIMARY_OUTLET].segments;
      const nextPage = this.questionnaireRoutingService.getNextPage(urlSegments[urlSegments.length - 1].path);

      this.router
        .navigate([nextPage], {
          queryParams: {
            uo: this.appService.processingOrderId,
            cartId: this.appService.cartId,
            orderId: this.appService.orderId
          },
          queryParamsHandling: 'merge'
        })
        .then(() => {
          // save last visited page
          this.questionnaireService.llc.currentView = nextPage;
          this.appService.currentView = nextPage;
          this.questionnaireStorageService.updateQuestionnaireStorage(this.appService.app.processingOrderId, this.questionnaireService.llc).subscribe();
        });
    }
  }
}
