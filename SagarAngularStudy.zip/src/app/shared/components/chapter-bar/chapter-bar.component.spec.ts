import { AppService } from './../../state/app/app.service';
import { QuestionnaireStorageService } from '@legalzoom/questionnaire-storage-sdk';
import { HttpClientModule } from '@angular/common/http';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ChapterBarComponent } from './chapter-bar.component';
import { Router, NavigationEnd } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { QuestionnaireService } from '../../services/questionnaire/questionnaire.service';
import { QuestionnaireRoutingService } from '../../services/questionnaire-routing/questionnaire-routing.service';
import { WindowRef } from '../../services/windowRef.service';
import { Chapter } from '../../models/page-model';
import { Subject } from 'rxjs';
import { LLC } from '../../models/questionnaire-model';

describe('ChapterBarComponent', () => {
  let component: ChapterBarComponent;
  let fixture: ComponentFixture<ChapterBarComponent>;
  const mockQuestionnaireRoutingService = jasmine.createSpyObj(['getNextPage']);
  const mockWindowRef = jasmine.createSpyObj(['nativeWindow']);
  let mockRouter: any = {};

  let mockQuestionnaireService = {
    broswerHistory: ['', ''],
    llc: new LLC()
  };
  let mockQuestionniareStorageService;
  let mockAppService;

  const llc: any = {
    isBusinessNameAvailable: true,
    isChooseNameLater: true,
    entityName: 'ABC',
    entityState: 'Alaska',
    protectAssets: true,
    orderId: 1
  };

  beforeEach(async(() => {
    mockRouter.url = '/' + Chapter.Essentials;
    mockRouter.events = new Subject();
    mockQuestionnaireService = jasmine.createSpyObj(['broswerHistory', 'llc']);
    mockQuestionnaireService.llc = llc;
    TestBed.configureTestingModule({
      declarations: [ChapterBarComponent],
      imports: [RouterTestingModule.withRoutes([]), HttpClientModule],
      providers: [
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: QuestionnaireRoutingService, useValue: mockQuestionnaireRoutingService },
        { provide: WindowRef, useValue: mockWindowRef },
        { provide: Router, useValue: mockRouter },
        { provide: QuestionnaireStorageService, useValue: mockQuestionniareStorageService },
        { provide: AppService, useValue: mockAppService },
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChapterBarComponent);
    component = fixture.componentInstance;
    component.mobile = true;
    fixture.detectChanges();
  });

  it('should create chapterbar component', () => {
    expect(component).toBeTruthy();
  });

  it('should updateChapter when router.url is /essentials', () => {
    const event = new NavigationEnd(42, '/', '/');
    TestBed.get(Router).events.next(event);

    expect(component.hideNext).toBeFalsy();
    expect(component.hidePrev).toBeFalsy();
    expect(component.chapter1).toEqual('complete');
    expect(component.chapter2).toEqual('complete');
    expect(component.chapter3).toEqual('active');
    expect(component.chapter4).toEqual('');
    expect(component.chapter5).toEqual('');
    expect(component.chapter6).toEqual('');
  });

  it('shouldDisableNext should true if browserHistory is none', () => {
    component.shouldDisableNext();
    expect(component.disableNext).toBe(true);
  });

  it('shouldDisableNext should false if browserHistory is not none', () => {
    component.shouldDisableNext();
    expect(component.disableNext).toBe(true);
  });

  it('shouldDisableNext should false if browserHistory is not none', () => {
    component.shouldDisableNext();
    expect(component.disableNext).toBe(true);
  });
});
