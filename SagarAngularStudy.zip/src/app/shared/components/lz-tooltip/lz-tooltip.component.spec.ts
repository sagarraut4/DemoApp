/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LzTooltipComponent } from './lz-tooltip.component';

describe('LzTooltipComponent', () => {
  let component: LzTooltipComponent;
  let fixture: ComponentFixture<LzTooltipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [LzTooltipComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LzTooltipComponent);
    component = fixture.componentInstance;
    component.toolTipId = '1';    
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // it('should show tooltip on click on icon', async(() => {
  //   spyOn(component, 'showTooltip');
  //   const icon = fixture.debugElement.nativeElement.querySelector('#lz-tooltip-icon-' + component.toolTipId);
  //   icon.click();
  //   fixture.whenStable().then(() => {
  //     fixture.detectChanges();
  //     expect(component.showTooltip).toHaveBeenCalled();
  //   });
  //   // click again to close the toolip
  //   icon.click();
  //   fixture.whenStable().then(() => {
  //     fixture.detectChanges();
  //     expect(component.showTooltip).toHaveBeenCalled();
  //   });
  // }));

  // it('should not close modal on click on modal body', () => {
  //   spyOn(component, 'showTooltip');
  //   spyOn(component, 'bodyClick');
  //   const icon = fixture.debugElement.nativeElement.querySelector('#lz-tooltip-icon-' + component.toolTipId);
  //   icon.click();
  //   const modalBody = fixture.debugElement.nativeElement.querySelector('#lz-tooltip-body-' + component.toolTipId);
  //   modalBody.click();
  //   fixture.whenStable().then(() => {
  //     fixture.detectChanges();
  //     expect(component.showTooltip).toHaveBeenCalled();
  //     expect(component.bodyClick).toHaveBeenCalled();
  //   });
  // });

});
