import { Component, OnInit, Input, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-lz-tooltip',
  templateUrl: './lz-tooltip.component.html',
  styleUrls: ['./lz-tooltip.component.scss']
})
export class LzTooltipComponent implements OnInit, OnDestroy {
  public showToolTip;
  @Input() showContentHeader = false;
  @Input() toolTipId: string;
  constructor() { this.showToolTip = false; }

  private el: HTMLElement;

  ngOnInit() {
    window.addEventListener('click', (event) => {
      this.showToolTip = false;
    });
  }

  showTooltip(ev) {
    if (this.showToolTip) {
      this.showToolTip = false;
    } else {
      this.showToolTip = true;
      const icon = document.getElementById('lz-tooltip-icon-' + this.toolTipId);
      const iconPosition = icon.getBoundingClientRect();
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      const iconFinalPosition = iconPosition.top + scrollTop + 20;
      const tooltipBody = (document.querySelector('#lz-tooltip-body-' + this.toolTipId)) as HTMLElement;
      tooltipBody.style.top = iconFinalPosition.toString() + 'px';
      document.querySelector('body').insertAdjacentElement('beforeend', document.querySelector('#lz-tooltip-body-' + this.toolTipId));
    }
    ev.stopImmediatePropagation();
  }

  bodyClick(ev) {
    ev.stopImmediatePropagation();
  }
  ngOnDestroy() {
    if (document.querySelector('body').lastElementChild === document.querySelector('#lz-tooltip-body-' + this.toolTipId)) {
      document.querySelector('body').removeChild(document.querySelector('#lz-tooltip-body-' + this.toolTipId));
    }
  }
}

// Usage
// -- must provide toolTipId to avoid any conflicts when there are more than one tooltip on page
// -- must provide showContentHeader as true/false value to show/hide header text. If not provided considered as false by-default
