import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ReactiveFormsModule, FormsModule, FormBuilder } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TextMaskModule } from 'angular2-text-mask';
import { WindowRef } from 'src/app/shared/services/windowRef.service';
import { QuestionnaireRoutingService } from 'src/app/shared/services/questionnaire-routing/questionnaire-routing.service';
import { HttpClient } from '@angular/common/http';
import { CookieService } from 'ngx-cookie';
import { QuestionnaireService } from 'src/app/shared/services/questionnaire/questionnaire.service';
import { ExperimentsService } from 'src/app/shared/services/experiments/experiments.service';
import { EventService } from 'src/app/shared/services/event.service';
import { PageScrollService } from 'ngx-page-scroll';
import { ProductDefinitionService } from 'src/app/shared/services/product-definition/product-definition.service';
import { OrderConfirmationComponent } from './order-confirmation.component';
import { TrackingService } from '../../services/tracking/tracking.service';
import { Router } from '@angular/router';

describe('OrderConfirmationComponent', () => {
  let component: OrderConfirmationComponent;
  let fixture: ComponentFixture<OrderConfirmationComponent>;
  let mockQuestionnaireService, mockQuestionnaireRoutingService, mockTrackingService, mockProductDefService, mockEventService ,  mockCookieService;
  const llc: any = {
    isBusinessNameAvailable: true,
    isChooseNameLater: true,
    entityName: 'ABC',
    entityState: 'Alaska',
    protectAssets: true,
    orderId: 1,
    checkoutEmail: 'dshivbhakta@lz.com',
    LWTExpressOrderResponse: {
      ExpressOrderId: 1,
      PaymentStatus: 1
    },
    TMSExpressOrderResponse: {
      ExpressOrderId: 1,
      PaymentStatus: 1
    },
    GSuiteOrderResponse:  {
      ExpressOrderId: 1,
      PaymentStatus: 1
    },
    gsuitePackageType: 'Express',
    gsuiteNumSeats: 1,
    packageSelected: 147
  };
  beforeEach(async(() => {
    mockCookieService = jasmine.createSpyObj(['put', 'get']);
    mockQuestionnaireService = jasmine.createSpyObj(['llc']);
    mockEventService = jasmine.createSpyObj(['saveAndContinue']);
    mockProductDefService = jasmine.createSpyObj(['getLLCPackageName']);
    mockTrackingService = jasmine.createSpyObj(['SetGA_Arrays']);
    mockQuestionnaireRoutingService = jasmine.createSpyObj(['getNextPage']);
    mockQuestionnaireService.llc = llc;
    TestBed.configureTestingModule({
      declarations: [OrderConfirmationComponent],
      imports: [RouterTestingModule,
        ReactiveFormsModule,
        HttpClientTestingModule,
        NgbModule,
        TextMaskModule, FormsModule],
      providers: [
        FormBuilder,
        WindowRef,
        QuestionnaireRoutingService,
        HttpClient,
        ExperimentsService,
        PageScrollService,
        { provide: ProductDefinitionService, useValue: mockProductDefService},
        { provide: CookieService, useValue: mockCookieService },
        { provide: EventService, useValue: mockEventService },
        { provide: TrackingService, useValue: mockTrackingService},
        { provide: QuestionnaireRoutingService, useValue: mockQuestionnaireRoutingService},
        { provide: QuestionnaireService, useValue: mockQuestionnaireService }
      ]
    }).compileComponents().then(() => {
      fixture = TestBed.createComponent(OrderConfirmationComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });
  }));

  it('it should create OrderConfirmationComponent', () => {
    expect(component).toBeTruthy();
  });
  it('getNextPage should have been called', () => {
    const router: Router = TestBed.get(Router);
    spyOn(router, 'navigate').and.stub();
    mockQuestionnaireRoutingService.getNextPage.and.returnValue('/');
    component.save();
    expect(mockQuestionnaireRoutingService.getNextPage).toHaveBeenCalled();
  });
  it('orderId should be as expected', () => {
    component.ngOnInit();
    expect(component.orderId).toEqual(1);
  });
  it('checkoutEmail should be as exppected', () => {
    component.ngOnInit();
    expect(component.checkoutEmail).toEqual('dshivbhakta@lz.com');
  });
  it('gsuiteNumSeats should be as exppected', () => {
    component.ngOnInit();
    expect(component.gsuiteNumSeats).toEqual(1);
  });
  it('isPaymentError should be false', () => {
    component.ngOnInit();
    expect(component.isPaymentError).toBeFalsy();
    expect(mockTrackingService.SetGA_Arrays).toHaveBeenCalled();
  });
  it('isPaymentError should be true', () => {
    const questionnarieService = TestBed.get(QuestionnaireService);
    questionnarieService.llc.LWTExpressOrderResponse.PaymentStatus = 0;
    component.ngOnInit();
    expect(component.isPaymentError).toBeTruthy();
    expect(mockTrackingService.SetGA_Arrays).toHaveBeenCalled();
  });
 });
