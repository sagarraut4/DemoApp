import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { QuestionnaireRoutingService } from '../../services/questionnaire-routing/questionnaire-routing.service';
import { PagePath } from '../../models/page-model';
import { QuestionnaireService } from '../../services/questionnaire/questionnaire.service';
import { TrackingService } from '../../services/tracking/tracking.service';
import { ExpressOrderResponse } from '../../models/express-order-model';
import { ProductDefinitionService } from '../../services/product-definition/product-definition.service';

@Component({
  selector: 'app-desktop-order-confirmation',
  templateUrl: './order-confirmation.component.html',
  styleUrls: ['./order-confirmation.component.scss']
})
export class OrderConfirmationComponent implements OnInit {

  public orderId: number;
  public lwtOrder: ExpressOrderResponse;
  public tmsOrder: ExpressOrderResponse;
  public gsuiteOrder: ExpressOrderResponse;
  public gsuitePackageType: string;
  public gsuiteNumSeats: number;
  public checkoutEmail: string;
  public isPaymentError: boolean;

  constructor(
    private router: Router,
    private questionnaireRoutingService: QuestionnaireRoutingService,
    public questionnaireService: QuestionnaireService,
    private trackingService: TrackingService,
    private productDefinitionService: ProductDefinitionService
  ) { }

  ngOnInit() {
    this.orderId = this.questionnaireService.llc.orderId;
    this.checkoutEmail = this.questionnaireService.llc.checkoutEmail;
    this.lwtOrder = this.questionnaireService.llc.LWTExpressOrderResponse;
    this.tmsOrder = this.questionnaireService.llc.TMSExpressOrderResponse;
    this.gsuiteOrder = this.questionnaireService.llc.GSuiteOrderResponse;
    this.gsuitePackageType = this.questionnaireService.llc.gsuitePackageType;
    this.gsuiteNumSeats = this.questionnaireService.llc.gsuiteNumSeats;

    if ((this.lwtOrder && this.lwtOrder.PaymentStatus === 0 )
      || (this.tmsOrder && this.tmsOrder.PaymentStatus === 0)
      || (this.gsuiteOrder && this.gsuiteOrder.PaymentStatus === 0)) {
      this.isPaymentError = true;
    }

    this.trackingService.SetGA_Arrays(PagePath.OrderConfirmation);
  }

  getLLCPackage(): string {
    return this.productDefinitionService.getLLCPackageName(this.questionnaireService.llc.packageSelected);
  }

  save(): void {
    const nextPage = this.questionnaireRoutingService.getNextPage(PagePath.OrderConfirmation);
    this.router.navigate(['./' + nextPage]);
  }
}
