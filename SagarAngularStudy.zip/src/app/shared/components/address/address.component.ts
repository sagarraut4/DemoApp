import { of, Observable } from 'rxjs';
import { catchError, debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { Component, OnInit, Input, OnChanges, SimpleChanges, ViewChild, ElementRef, AfterViewInit, Renderer2 } from '@angular/core';
import { FormGroup, Validators } from '@angular/forms';
import { AddressAutocompleteService, IAutocompleteAddress, IAddressValidation } from '@legalzoom/address-autocomplete-sdk';
let nextId = 0;

@Component({
  selector: 'app-address',
  templateUrl: './address.component.html',
  styleUrls: ['./address.component.scss']
})
export class AddressComponent implements OnInit, OnChanges, AfterViewInit {
  @Input() addressForm: FormGroup;
  @Input() validateForm: boolean;
  @Input() showCounty: boolean;
  // generate unique id for element id attribute per component instance
  public id: number = nextId++;
  public selectedAddressInvalid: boolean;
  @ViewChild('address1', { static: false }) address1Ref: ElementRef;

  constructor(
    private autocomplete: AddressAutocompleteService,
    private renderer: Renderer2
  ) { }

  ngOnInit() {
    this.selectedAddressInvalid = false;
  }

  ngAfterViewInit() {
    // overwrites autocomplete=off which is set by ngbtypeahead and does not work
    this.renderer.setAttribute(this.address1Ref.nativeElement, 'autocomplete', 'no');
  }

  resultFormatter = (result: IAutocompleteAddress) => result.text;
  inputFormatter = (result: IAutocompleteAddress) => result.streetLine;

  searchAddress = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(200),
      distinctUntilChanged(),
      switchMap(term => this.autocomplete.getAddressSuggestions(term).pipe(
        catchError(() => {
          return of([]);
        }))
      ),
    )

  selectedAddress(event: any): void {
    const address: IAutocompleteAddress = event.item;
    // address line1 gets filled by input formatter
    this.addressForm.controls.city.setValue(address.city);
    this.addressForm.controls.state.setValue(address.state);

    this.addressForm.controls.zipCode.setValue('');
    this.addressForm.controls.county.setValue('');

    this.autocomplete.getAddressValidation(address.streetLine, address.city, address.state).subscribe((res: IAddressValidation) => {

      if (res.addressInfo && res.addressInfo.length > 0) {
        this.addressForm.controls.zipCode.setValue(res.addressInfo[0].components.zipCode);

        if (this.showCounty) {
          this.addressForm.controls.county.setValue(res.addressInfo[0].metadata.countyName);
        }
      }

      this.selectedAddressInvalid = res.isValidated ? false : true;
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.validateForm.currentValue) {
      this.addressForm.controls.address1.setValidators([Validators.required]);
      this.addressForm.controls.address1.updateValueAndValidity();
      this.addressForm.controls.city.setValidators([Validators.required]);
      this.addressForm.controls.city.updateValueAndValidity();
      this.addressForm.controls.state.setValidators([Validators.required]);
      this.addressForm.controls.state.updateValueAndValidity();
      this.addressForm.controls.zipCode.setValidators([Validators.required]);
      this.addressForm.controls.zipCode.updateValueAndValidity();
    } else {
      this.addressForm.controls.address1.clearValidators();
      this.addressForm.controls.address1.updateValueAndValidity();
      this.addressForm.controls.city.clearValidators();
      this.addressForm.controls.city.updateValueAndValidity();
      this.addressForm.controls.state.clearValidators();
      this.addressForm.controls.state.updateValueAndValidity();
      this.addressForm.controls.zipCode.clearValidators();
      this.addressForm.controls.zipCode.updateValueAndValidity();
    }
  }
}
