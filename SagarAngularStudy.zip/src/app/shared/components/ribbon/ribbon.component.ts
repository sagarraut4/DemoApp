import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-ribbon',
  templateUrl: './ribbon.component.html',
  styleUrls: ['./ribbon.component.scss']
})
export class RibbonComponent implements OnInit {
  @Input() active = false;
  constructor() { }

  ngOnInit() {
  }


  cutRibbon() {
    this.active = true;
  }
}
