import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RibbonComponent } from './ribbon.component';

describe('RibbonComponent', () => {
  let component: RibbonComponent;
  let fixture: ComponentFixture<RibbonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RibbonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RibbonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create ribbon component', () => {
    expect(component).toBeTruthy();
  });

  it('should click on .ribbon-container', async(() => {
    spyOn(component, 'cutRibbon');

    const button = fixture.debugElement.nativeElement.querySelector('.ribbon-container');
    button.click();

    fixture.whenStable().then(() => {
      expect(component.cutRibbon).toHaveBeenCalled();
    });
  }));
});
