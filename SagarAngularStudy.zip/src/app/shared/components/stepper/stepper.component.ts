import { Component, Input, Output, OnInit, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-desktop-stepper',
  templateUrl: './stepper.component.html',
  styleUrls: ['./stepper.component.scss']
})
export class StepperComponent implements OnInit {
  // tslint:disable-next-line: no-output-native
  @Output() change: EventEmitter<number> = new EventEmitter();
  private maxSeats = 200;
  private minSeats = 1;
  // tslint:disable-next-line: variable-name
  private _count = 1;


  get isMin(): boolean { return this._count === this.minSeats; }
  get isMax(): boolean { return this._count === this.maxSeats; }

  @Input()
  set count(value: number) {
    this._count = value;
    this.change.emit(this.count);
  }

  get count( ): number {
    return this._count;
  }

  constructor() { }

  ngOnInit() {
  }

  decreaseCount() {
    this.count = Math.max(this.minSeats, this.count - 1);
  }

  increaseCount() {
    this.count = Math.min(this.maxSeats, this.count + 1);
  }
}
