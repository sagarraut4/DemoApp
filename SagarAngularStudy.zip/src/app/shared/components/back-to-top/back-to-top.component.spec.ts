import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BackToTopComponent } from './back-to-top.component';
import { PageScrollService } from 'ngx-page-scroll';

describe('BackToTopComponent', () => {
  let component: BackToTopComponent;
  let fixture: ComponentFixture<BackToTopComponent>;
  let mockPageScrollService: PageScrollService;

  beforeEach(async(() => {
    mockPageScrollService = jasmine.createSpyObj(['start']);
    TestBed.configureTestingModule({
      declarations: [ BackToTopComponent ],
      providers: [
        { provide: PageScrollService, useValue: mockPageScrollService }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BackToTopComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create back to top component', () => {
    expect(component).toBeTruthy();
  });

  it('should click on .scroll-to-top', async(() => {
    spyOn(component, 'scroll');

    const button = fixture.debugElement.nativeElement.querySelector('.scroll-to-top');
    button.click();

    fixture.whenStable().then(() => {
      expect(component.scroll).toHaveBeenCalled();
    });
  }));

  it('should call pagescroll start function', () => {
    component.scroll();
    expect(mockPageScrollService.start).toHaveBeenCalled();
  });
});
