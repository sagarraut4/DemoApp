import { Component, OnInit, Inject } from '@angular/core';
import { PageScrollService, PageScrollInstance } from 'ngx-page-scroll';
import { DOCUMENT } from '@angular/common';

@Component({
  selector: 'app-back-to-top',
  templateUrl: './back-to-top.component.html',
  styleUrls: ['./back-to-top.component.scss']
})
export class BackToTopComponent {

  constructor(
    private pageScrollService: PageScrollService,
    @Inject(DOCUMENT) private document: any
  ) { }

  scroll(): void {
    const target = 'body';
    const scroll: PageScrollInstance = PageScrollInstance.newInstance({ document: this.document, scrollTarget: target, pageScrollDuration: 300 });
    this.pageScrollService.start(scroll);
  }
}
