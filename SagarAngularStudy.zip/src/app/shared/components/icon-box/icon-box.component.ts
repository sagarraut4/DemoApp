import { Component, Input, OnInit, ContentChildren } from '@angular/core';

@Component({
  selector: 'app-icon-box',
  templateUrl: './icon-box.component.html',
  styleUrls: ['./icon-box.component.scss']
})
export class IconBoxComponent implements OnInit {
  @Input() icon: string;
  @Input() title: string = null;
  @Input() desktop = false;

  constructor() { }

  ngOnInit() {
  }

}
