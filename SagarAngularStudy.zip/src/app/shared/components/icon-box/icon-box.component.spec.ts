import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IconBoxComponent } from './icon-box.component';

describe('IconBoxComponent', () => {
  let component: IconBoxComponent;
  let fixture: ComponentFixture<IconBoxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IconBoxComponent ]
    }).compileComponents().then(() => {
      fixture = TestBed.createComponent(IconBoxComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });
  }));
  it('should create IconBoxComponent', () => {
    expect(component).toBeTruthy();
  });
  it('should not have href of iconurl not provided', () => {
    expect(fixture.debugElement.nativeElement.querySelector('.icon-box-icon>use').getAttribute('xlink:href'))
      .toEqual('');
  });
  it('should have href  if icon provided', () => {
    component.icon = 'ABC';
    fixture.detectChanges();
    const iconhrefVal = fixture.debugElement.nativeElement.querySelector('.icon-box-icon>use').getAttribute('xlink:href');
    expect(iconhrefVal)
      .toEqual('ABC');
  });
  it('should have icon-box-discretion inner div null if title not provided', () => {
    const iconhrefVal = fixture.debugElement.nativeElement.querySelector('.icon-box-description').innerText;
    expect(iconhrefVal)
      .toEqual('');
  });
  it('should have icon-box-discretion inner div null if title not provided', () => {
    const iconhrefVal = fixture.debugElement.nativeElement.querySelector('.icon-box-description').innerText;
    expect(iconhrefVal)
      .toEqual('');
  });
  it('should have icon-box-discretion inner div if title is provided', () => {
    component.title = 'Title';
    fixture.detectChanges();
    const iconhrefVal = fixture.debugElement.nativeElement.querySelector('.icon-box-description').innerText;
    expect(iconhrefVal)
      .toEqual('Title');
  });
});
