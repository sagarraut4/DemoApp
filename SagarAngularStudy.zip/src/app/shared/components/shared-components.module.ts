import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ChapterBarComponent } from './chapter-bar/chapter-bar.component';
import { UsefulInfoComponent } from './useful-info/useful-info.component';
import { BackToTopComponent } from './back-to-top/back-to-top.component';
import { SpinnerComponent } from './spinner/spinner.component';
import { IconBoxComponent } from './icon-box/icon-box.component';
import { RibbonComponent } from './ribbon/ribbon.component';
import { ServerErrorComponent } from '../modals/server-error/server-error.component';
import { FormatterModule } from '../directives/formatter/formatter.module';
import { NameformatterDirective } from '../directives/nameformatter.directive';
import { FocusNextInputDirective } from '../directives/focus-next-input.directive';
import { TrimDirective } from '../directives/trim.directive';
import { TrackingDirective } from '../directives/tracking.directive';
import { StepperComponent } from './stepper/stepper.component';
import { LzTooltipComponent } from './lz-tooltip/lz-tooltip.component';
import {OrderConfirmationComponent} from './order-confirmation/order-confirmation.component';
import { MicroCopyComponent } from './micro-copy/micro-copy.component';
import { PaymentErrorComponent } from './payment-error/payment-error.component';
import {FeatureFlagModule} from '../directives/feature-flag/feature-flag.module';
import { SetPasswordComponent } from './set-password/set-password.component';
import { ReactiveFormsModule } from '@angular/forms';
import { SetPasswordErrorComponent } from '../modals/set-password-error/set-password-error.component'

@NgModule({
  imports : [
    CommonModule,
    RouterModule,
    FormatterModule,
    FeatureFlagModule,
    ReactiveFormsModule,
  ],
  declarations : [
    ChapterBarComponent,
    UsefulInfoComponent,
    BackToTopComponent,
    SpinnerComponent,
    IconBoxComponent,
    RibbonComponent,
    ServerErrorComponent,
    StepperComponent,
    LzTooltipComponent,
    OrderConfirmationComponent,
    MicroCopyComponent,
    PaymentErrorComponent,
    SetPasswordComponent,
    TrackingDirective,
    SetPasswordErrorComponent
  ],
  entryComponents : [
    ServerErrorComponent,
    SetPasswordErrorComponent
  ],
  exports : [
    CommonModule,
    RouterModule,
    FeatureFlagModule,
    ChapterBarComponent,
    UsefulInfoComponent,
    BackToTopComponent,
    SpinnerComponent,
    IconBoxComponent,
    RibbonComponent,
    ServerErrorComponent,
    StepperComponent,
    MicroCopyComponent,
    NameformatterDirective,
    TrimDirective,
    FocusNextInputDirective,
    TrackingDirective,
    LzTooltipComponent,
    OrderConfirmationComponent,
    PaymentErrorComponent,
    SetPasswordComponent,
    SetPasswordErrorComponent
  ],
  schemas : [
  ],
})
export class SharedComponentsModule {
}
