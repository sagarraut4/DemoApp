import { Component, OnInit, Input, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { PageScrollService, PageScrollInstance } from 'ngx-page-scroll';

@Component({
  selector: 'app-useful-info',
  templateUrl: './useful-info.component.html',
  styleUrls: ['./useful-info.component.scss']
})
export class UsefulInfoComponent {
  @Input() text = 'More Info';

  constructor(
    private pageScrollService: PageScrollService,
    @Inject(DOCUMENT) private document: any
  ) { }

  scroll(): void {
    const target = '#useful-info';
    const scroll: PageScrollInstance = PageScrollInstance.newInstance({ document: this.document, scrollTarget: target, pageScrollDuration: 300 });
    this.pageScrollService.start(scroll);
  }
}
