import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { UsefulInfoComponent } from './useful-info.component';
import { PageScrollService } from 'ngx-page-scroll';

describe('UsefulInfoComponent', () => {
  let component: UsefulInfoComponent;
  let fixture: ComponentFixture<UsefulInfoComponent>;
  let mockPageScrollService: PageScrollService;

  beforeEach(async(() => {
    mockPageScrollService = jasmine.createSpyObj(['start']);
    TestBed.configureTestingModule({
      declarations: [ UsefulInfoComponent ],
      providers: [
        { provide: PageScrollService, useValue: mockPageScrollService }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UsefulInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create useful info component', () => {
    expect(component).toBeTruthy();
  });

  it('should click on .scroller__more', async(() => {
    spyOn(component, 'scroll');

    const button = fixture.debugElement.nativeElement.querySelector('.scroller__more');
    button.click();

    fixture.whenStable().then(() => {
      expect(component.scroll).toHaveBeenCalled();
    });
  }));

  it('should call pagescroll start function', () => {
    component.scroll();
    expect(mockPageScrollService.start).toHaveBeenCalled();
  });
});
