import { HttpClientModule } from '@angular/common/http';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SetPasswordErrorComponent } from './set-password-error.component';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { By } from '@angular/platform-browser';

describe('SetPasswordErrorComponent', () => {
  let component: SetPasswordErrorComponent;
  let fixture: ComponentFixture<SetPasswordErrorComponent>;
  const mockNgbActiveModal = jasmine.createSpyObj(['close', 'dismiss']);
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SetPasswordErrorComponent],
      imports: [HttpClientModule],
      providers: [{ provide: NgbActiveModal, useValue: mockNgbActiveModal }]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SetPasswordErrorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create server error component', () => {
    expect(component).toBeTruthy();
  });

  it('cross button should close the active modal', () => {
    const crossBtn = fixture.debugElement.query(By.css('.close-button')).nativeElement;
    crossBtn.click();
    expect(mockNgbActiveModal.dismiss).toHaveBeenCalled();
  });

  it('close button should click and call close method', () => {
    spyOn(component, 'cta');
    const close = fixture.debugElement.query(By.css('.btn-action')).nativeElement;
    close.click();
    expect(component.cta).toHaveBeenCalled();

  });

  it('close button should close the active modal', () => {
    const close = fixture.debugElement.query(By.css('.btn-action')).nativeElement;
    close.click();
    expect(mockNgbActiveModal.close).toHaveBeenCalled();
  });
});
