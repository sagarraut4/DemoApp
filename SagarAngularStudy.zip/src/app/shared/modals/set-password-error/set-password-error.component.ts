import { Component, ChangeDetectionStrategy } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-desktop-server-error',
  templateUrl: './set-password-error.component.html',
  styleUrls: ['./set-password-error.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SetPasswordErrorComponent {

  constructor(public activeModal: NgbActiveModal) { }

  cta() {
    this.activeModal.close();
  }
}