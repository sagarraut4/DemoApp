import { Component, ChangeDetectionStrategy, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-desktop-server-error',
  templateUrl: './server-error.component.html',
  styleUrls: ['./server-error.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ServerErrorComponent {

  constructor(public activeModal: NgbActiveModal) { }

  @Input() errorTitle = 'Oops!';
  @Input() errorMessage = 'Something went wrong. Let\'s try again.';
  @Input() errorCta = 'Try again';

  cta() {
    this.activeModal.close();
  }

}
