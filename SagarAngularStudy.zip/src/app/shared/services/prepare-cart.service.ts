import { CookieService } from 'ngx-cookie';
import { TrackSEMDataService } from './tracking/track-sem-data.service';
import { PackageService } from './package.service';
import { UserCartService } from '../../../app/pl-features/glo-design/shared/services/user-cart.service';
import { AppService } from './../state/app/app.service';
import { Injectable } from '@angular/core';
import { IQueueEntry, QueueService, TrackJsErrorLogService, UtilitiesService } from '@legalzoom/business-formation-sdk';
import { CartItemSource, UpdateCartByQuestionnaireRequest, ChangePackageRequest, CartResponse, AddCartItemRequest, CancelCartItemRequest, AddCartDiscountByCartIdRequest, CancelCartDiscountRequest, CartService } from '@legalzoom/cart-sdk';
import { of, Subject } from 'rxjs';
import { HttpErrorResponse } from '@angular/common/http';
import { ProductName, CookieName } from '../constants/product-domain';
import { Router } from '@angular/router';
import { QuestionnaireService } from './questionnaire/questionnaire.service';
import { Chapter, PagePath } from '../models/page-model';
import { ConstantsService } from './constants.service';
import { QuestionnaireMappingService } from './questionnaire/questionnaire-mapping.service';
import { CartCreationStatus, EventService } from './event.service';
import { TrackingService } from './tracking/tracking.service';
import { ProductConfigurationIds } from '../models/cart-model';
import { QuestionnaireStorageService } from '@legalzoom/questionnaire-storage-sdk';
import { WebSessionService, CreateGuestCustomerAndSessionResponse } from '@legalzoom/web-session-sdk';
import { IUserAnswerRequest, IUserAnswerResponse, IProductFilingRequest, QuestionnaireAnswerService } from '@legalzoom/questionnaire-answer-sdk';
import { ProductService } from '@legalzoom/product-sdk';
import { CustomerService } from '@legalzoom/customer-sdk';
@Injectable({
  providedIn: 'root'
})
export class PrepareCartService {
  public parentComponentName = '';
  promoCodeApplyErrorEvent: Subject<any> = new Subject<any>();
  private shouldRemovePromocode = false;
  constructor(
    private queueService: QueueService,
    private webSessionService: WebSessionService,
    private appService: AppService,
    private trackJS: TrackJsErrorLogService,
    private utilitiesService: UtilitiesService,
    private router: Router,
    private questionnaireService: QuestionnaireService,
    private cartService: CartService,
    private userCartService: UserCartService,
    private questionnaireMappingService: QuestionnaireMappingService,
    private productService: ProductService,
    private packageService: PackageService,
    private questionnaireStorageService: QuestionnaireStorageService,
    private questionnaireAnswerService: QuestionnaireAnswerService,
    private eventService: EventService,
    private trackingService: TrackingService,
    private trackSemDataService: TrackSEMDataService,
    private cookieService: CookieService,
    private customerService: CustomerService
  ) {}

  prepareQueueEntries(): IQueueEntry {
    const activeSession = this.cookieService.get(CookieName.ACTIVESESSION) ?
      this.cookieService.get(CookieName.ACTIVESESSION).toLowerCase() === 'true' : false;
    return {
      name: 'prepareQueueEntries ' + this.constructor.name,
      pre: () => {
        return of(null);
      },
      post: () => {
        if (!activeSession) {
          this.queueService.add(this.prepareGuestCustomerAndSession());
          this.queueService.add(this.utilitiesService.prepareSaveCookies(this.appService));
        }
        if (!this.appService.cartId) {
          this.queueService.add(this.userCartService.prepareCreateNewCart());
          this.queueService.add(this.utilitiesService.prepareSaveCookies(this.appService));
          this.queueService.add(this.questionnaireService.prepareUpdateQuestionnaireStorage({
            currentView: this.questionnaireService.llc.currentView,
          }));
          this.queueService.add(this.prepareTrackSemDataService());
        } else {
          this.eventService.updateCartCreationStatus(CartCreationStatus.Created);
        }

        this.queueService.add(this.prepareKenshooTrack());
        this.queueService.add(this.prepareRestoreLLCData());
        this.queueService.process().subscribe();
      },
      error: (error: any) => {
        console.log(error);
        this.trackJS.track(ProductName.LLC, this.constructor.name, error);
        return of(null);
      }
    };
  }
  public prepareQueueForQuestStorageFillingFee() {
    this.queueService.add(this.questionnaireService.prepareUpdateQuestionnaireStorage({
      currentView: this.questionnaireService.llc.currentView,
    }));
    this.queueService.add(this.prepareSaveAndGetMappedUserAnswers());
    this.queueService.add(this.prepareGetAvailablePackagesWithFilingFees());
    this.queueService.process().subscribe();
  }

  prepareGuestCustomerAndSession(): IQueueEntry {
    return {
      name: 'prepareGuestCustomerAndSession ' + this.constructor.name,
      pre: () => {
        return this.webSessionService.createGuestCustomerAndSession();
      },
      post: (response: CreateGuestCustomerAndSessionResponse) => {
        if (response) {
          this.appService.customerId = response.customer.customerId;
          this.appService.loginEmail = response.customer.emailId;
          this.appService.sessionId = response.session.sessionId;
          this.appService.accessToken = response.session.accessToken;
          const isGuest = this.customerService.isGuestCustomer(this.appService.loginEmail);

          this.utilitiesService.saveCookies(this.appService.app.sessionId, this.appService.app.accessToken, this.appService.app.customerId, isGuest);
        }
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, `${this.constructor.name} called from ${this.parentComponentName}`, error);
        return of(null);
      }
    };
  }

  prepareRestoreLLCData(): IQueueEntry {
    const that = this;
    const currentUrl = this.router.url.split('/');
    return {
      name: 'prepareRestoreIncData ' + this.constructor.name,
      pre: () => {
        return of(null);
      },
      post: (response) => {
        that.questionnaireService.llc.currentView =
          that.questionnaireService.llc.currentView && that.questionnaireService.llc.currentView !== '' ? that.questionnaireService.llc.currentView : Chapter.Name + '/' + currentUrl[currentUrl.length - 1];
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        return of(null);
      }
    };
  }

  prepareSaveAndGetMappedUserAnswers(): IQueueEntry {
    const that = this;
    return {
      name: 'prepareSaveAndGetMappedUserAnswers ' + this.constructor.name,
      pre: () => {
        const mappedUserAnswer = that.questionnaireMappingService.doMapping(this.questionnaireService.llc, this.appService.processingOrderId);
        const userAnswerRequest: IUserAnswerRequest = {
          questionnaireFieldGroupAnswers: {
            userOrderId: mappedUserAnswer.userOrderId,
            //
            questionnaireId: that.appService.app.questionnaireId,
            fieldAnswers: mappedUserAnswer.fieldAnswers,
            groupAnswers: []
          }
        };
        return that.questionnaireAnswerService.saveAndGetMappedUserAnswers(userAnswerRequest, that.appService.app.questionnaireId);
      },
      post: (response: IUserAnswerResponse) => {
        that.questionnaireMappingService.questionnaireMappingResponse = response;
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, `${this.constructor.name} called from ${this.parentComponentName}`, error);
        return of(null);
      }
    };
  }

  prepareGetAvailablePackagesWithFilingFees(): IQueueEntry {
    return {
      name: 'prepareGetAvailablePackagesWithFilingFees ' + this.constructor.name,
      pre: () => {
        const customerStateAbbr = ConstantsService.getStateByName(this.questionnaireService.llc.entityState).abbr;

        const productFilingRequest: IProductFilingRequest = {
          state: customerStateAbbr,
          // to-do un-comment code when mappingservice is ready with mappingResponse variable
          fieldAnswers: this.questionnaireMappingService.questionnaireMappingResponse.questionnaireFieldGroupAnswers.fieldAnswers,
          groupAnswers: this.questionnaireMappingService.questionnaireMappingResponse.questionnaireFieldGroupAnswers.groupAnswers
        };
        return this.productService.getAvailablePackagesWithFilingFees(this.appService.processId, productFilingRequest);
      },
      post: (response) => {
        this.packageService.mapPackageConfigurations(response).subscribe((result) => {
          this.packageService.packageConfigurations = result;
        });
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, `${this.constructor.name} called from ${this.parentComponentName}`, error);
        return of(null);
      }
    };
  }

  prepareKenshooTrack(): IQueueEntry {
    const that = this;
    return {
      name: 'prepareKenshooTrack ' + this.constructor.name,
      clearQueueOnError: false,
      pre: () => {
        return of(null);
      },
      post: (response) => {
        this.trackingService.sendAdConversion(PagePath.BusinessState);
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, `${this.constructor.name} called from ${this.parentComponentName}`, error);
        return of(null);
      }
    };
  }

  prepareTrackSemDataService(): IQueueEntry {
    const that = this;
    return {
      name: 'prepareTrackSemDataService ' + this.constructor.name,
      clearQueueOnError: false,
      pre: () => {
        this.trackingService.UpdateTrackingModel();
        that.trackingService.setUserOrderID(this.appService.processingOrderId);
        const kidSet = that.cookieService.get('sem_kid');
        if (kidSet) {
          return that.trackSemDataService.track();
        } else {
          return of(null);
        }
      },
      post: (response) => {},
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, `${this.constructor.name} called from ${this.parentComponentName}`, error);
        return of(null);
      }
    };
  }

  public prepareUpdateLoadingStatus(): IQueueEntry {
    return {
      name: 'closeModalOnQueueComplete ' + this.constructor.name,
      pre: () => {
        this.eventService.updateLoadingStatus(false);
        return of(null);
      },
      post: () => {},
      error: (error: HttpErrorResponse) => {
        this.trackJS.track(ProductName.LLC, 'user-cart.service', error);
        return of(null);
      }
    };
  }

  prepareChangePackage(configId: number): IQueueEntry {
    const that = this;
    return {
      name: 'prepareChangePackage ' + this.constructor.name,
      pre: () => {
        const changePackageRequest: ChangePackageRequest = {
          newProductConfigurationId: configId,
          catItemSource: CartItemSource.userAction,
          updatedBy: that.appService.app.customerId.toString(),
          fieldAnswers: that.questionnaireMappingService.questionnaireMappingResponse.questionnaireFieldGroupAnswers.fieldAnswers,
          groupAnswers: that.questionnaireMappingService.questionnaireMappingResponse.questionnaireFieldGroupAnswers.groupAnswers
        };

        return this.cartService.changePackage(that.appService.app.cartId, changePackageRequest);
      },
      post: (response: CartResponse) => {
        that.userCartService.updateCartResponse = response;
        if (response) {
          const appState = that.appService.app;
          appState.cartId = response.cart.cartId;
          that.appService.app = appState;
        }
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'user-cart.service', error);
        return of(null);
      }
    };
  }

  prepareGetCartModelFromApiData(): IQueueEntry {
    const that = this;
    return {
      name: 'prepareGetCartModelFromApiData ' + this.constructor.name,
      pre: () => {
        return of(null);
      },
      post: () => {
        that.userCartService.userCart = that.userCartService.getCartModelFromApiData(that.userCartService.updateCartResponse, that.appService.getCartBalanceByCartIdResponse);
        that.userCartService.userCartChange.next(that.userCartService.userCart);
      },
      error: (error: HttpErrorResponse) => {
        that.trackJS.track(ProductName.LLC, 'user-cart.service', error);
        return of(null);
      }
    };
  }

  prepareUpdateCartByQuestionnaire(): IQueueEntry {
    const that = this;
    return {
      name: 'prepareUpdateCartByQuestionnaire ' + this.constructor.name,
      pre: () => {
        const updateCartRequest: UpdateCartByQuestionnaireRequest = {
          cartItemSource: CartItemSource.userAction,
          changedBy: that.appService.app.customerId.toString(),
          fieldAnswers: that.userCartService.answerResponse !== undefined && that.userCartService.answerResponse.fieldAnswers !== undefined ? that.userCartService.answerResponse.fieldAnswers : null,
          groupAnswers: that.userCartService.answerResponse !== undefined && that.userCartService.answerResponse.groupAnswers !== undefined ? that.userCartService.answerResponse.groupAnswers : null
        };
        return that.cartService.updateCartByQuestionnaire(that.appService.app.cartId, updateCartRequest);
      },
      post: (response) => {
        that.userCartService.updateCartResponse = response;
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'user-cart.service', error);
        return of(null);
      }
    };
  }

  prepareGetCartBalanceByCartId(paymentMode = '', displayErrorModal = false): IQueueEntry {
    const that = this;
    return {
      name: 'prepareGetCartBalanceByCartId ' + this.constructor.name,
      clearQueueOnError: displayErrorModal,
      pre: () => {
        return that.cartService.getCartBalanceByCartId(that.appService.app.cartId);
      },
      post: (response) => {
        this.appService.getCartBalanceByCartIdResponse = response;
        this.appService.amount = paymentMode === '3pay' ? this.appService.getCartBalanceByCartIdResponse.cartInstallments.firstInstallment.installmentAmount : this.appService.getCartBalanceByCartIdResponse.cartBalance;
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        // if (displayErrorModal) {
        //   this.errorResponseService.displayErrorModal();
        // }
        this.trackJS.track(ProductName.LLC, 'user-cart.service', error);
        return of(null);
      }
    };
  }

  private prepareAddCartDiscountByCartId(promoCode: string): IQueueEntry {
    const that = this;
    return {
      name: 'prepareAddCartDiscountByCartId ' + this.constructor.name,
      clearQueueOnError: false,
      pre: () => {
        const request: AddCartDiscountByCartIdRequest = {
          promoCode,
          changedBy: that.appService.app.customerId.toString()
        };
        return this.cartService.addCartDiscountByCartId(that.userCartService.userCart.cartId, request);
      },
      post: (response) => {
        that.promoCodeApplyErrorEvent.next(false);
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        // this.eventService.updateLoadingStatus(false);
        if (error.status === 400) {
          that.promoCodeApplyErrorEvent.next(true);
          if (this.userCartService.userCart.promoCode && this.userCartService.userCart.promoCode.length > 0) {
            that.shouldRemovePromocode = true;
          }
        }
        that.trackJS.track(ProductName.LLC, 'user-cart.service', error);
        return of(null);
      }
    };
  }

  private prepareCancelCartDiscount(): IQueueEntry {
    const that = this;
    return {
      name: 'prepareCancelCartDiscount ' + this.constructor.name,
      pre: () => {
        if (that.shouldRemovePromocode) {
          const request: CancelCartDiscountRequest = {
            changedBy: that.appService.app.customerId.toString()
          };
          return that.cartService.cancelCartDiscount(that.userCartService.userCart.cartId, request);
        } else {
          return of(null);
        }
      },
      post: (response) => {
        that.shouldRemovePromocode = false;
      },
      error: (error: HttpErrorResponse) => {
        this.eventService.updateLoadingStatus(false);
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'user-cart.service', error);
        return of(null);
      }
    };
  }

  public getCartWithUpdatedPackage() {
    this.queueService.add(this.prepareUpdateCartByQuestionnaire());
    this.queueService.add(this.prepareGetCartBalanceByCartId('', false));
    this.queueService.add(this.prepareGetCartModelFromApiData());
    return this.queueService.process();
  }

  public savePackageAndGetCart(packageConfigId): void {
    this.queueService.add([
      this.questionnaireService.prepareUpdateQuestionnaireStorage({
        currentView: this.questionnaireService.llc.currentView,
      }),
      this.prepareSaveAndGetMappedUserAnswers()
    ]);
    this.queueService.add(this.prepareChangePackage(packageConfigId));
    this.queueService.add(this.prepareGetCartBalanceByCartId('', false));
    this.queueService.add(this.prepareGetCartModelFromApiData());
    this.queueService.add(this.prepareUpdateLoadingStatus());
    this.queueService.process().subscribe();
  }

  public saveAndRefreshCart(): void {
    this.queueService.add([
      this.questionnaireService.prepareUpdateQuestionnaireStorage({
        currentView: this.questionnaireService.llc.currentView,
      }),
      this.prepareSaveAndGetMappedUserAnswers()
    ]);
    this.queueService.add(this.prepareUpdateCartByQuestionnaire());
    this.queueService.add(this.prepareGetCartBalanceByCartId('', false));
    this.queueService.add(this.prepareGetCartModelFromApiData());
    this.queueService.process().subscribe();
  }

  public AddProfessionalPrint(): void {
    this.queueService.add(this.prepareAddBpptoCart());
    this.saveAndRefreshCart();
  }

  public RemoveProfessionalPrint(): void {
    this.queueService.add(this.prepareRemoveBppfromCart());
    this.saveAndRefreshCart();
  }

  prepareAddBpptoCart(): IQueueEntry {
    const that = this;
    return {
      pre: () => {
        const createAddCartItemRequest: AddCartItemRequest = {
          productConfigurationId: ProductConfigurationIds.economyLLCShipping,
          cartItemSource: CartItemSource.userAction,
          addedBy: this.appService.app.customerId.toString()
        };

        return this.cartService.addCartItem(this.appService.app.cartId, createAddCartItemRequest);
      },
      post: (response) => {
        that.userCartService.updateCartResponse = response;
      },
      error: (error: HttpErrorResponse) => {
        this.eventService.updateLoadingStatus(false);
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'user-cart.service', error);
        return of(null);
      }
    };
  }

  prepareRemoveBppfromCart(): IQueueEntry {
    const that = this;
    return {
      pre: () => {
        const createCancelCartItemRequest: CancelCartItemRequest = {
          updatedBy: this.appService.app.customerId.toString(),
          cancelPrintingItem: true,
          cancelSimilarProducts: false
        };
        const CartToGetBppCartItemId: CartResponse = that.userCartService.updateCartResponse;
        return that.cartService.cancelCartItem(
          that.appService.app.cartId,
          CartToGetBppCartItemId.cart.cartItems.find((x) => x.productConfigurationId === ProductConfigurationIds.economyLLCShipping).cartItemId,
          createCancelCartItemRequest
        );
      },
      post: (response) => {
        that.userCartService.updateCartResponse = response;
      },
      error: (error: HttpErrorResponse) => {
        this.eventService.updateLoadingStatus(false);
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'user-cart.service', error);
        return of(null);
      }
    };
  }

  public applyPromoCode(promoCode: string): void {
    this.queueService.add(this.prepareAddCartDiscountByCartId(promoCode));
    this.queueService.add(this.prepareCancelCartDiscount());
    this.queueService.add(this.prepareUpdateCartByQuestionnaire());
    this.queueService.add(this.prepareGetCartBalanceByCartId('', false));
    this.queueService.add(this.prepareGetCartModelFromApiData());
    this.queueService.process().subscribe();
  }

  public removePromoCode(): void {
    this.shouldRemovePromocode = true;
    this.queueService.add(this.prepareCancelCartDiscount());
    this.queueService.add(this.prepareUpdateCartByQuestionnaire());
    this.queueService.add(this.prepareGetCartBalanceByCartId('', false));
    this.queueService.add(this.prepareGetCartModelFromApiData());
    this.queueService.process().subscribe();
  }
}
