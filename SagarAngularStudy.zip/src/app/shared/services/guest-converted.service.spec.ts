import { TestBed } from '@angular/core/testing';
import { HTTP_INTERCEPTORS, HttpClient } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { GuestConvertedService } from './guest-converted.service';
import { AppService } from '../state/app';
import { EnvironmentService } from './environment.service';

describe('GuestConvertedService', () => {
  let service: GuestConvertedService;
  let httpMock: HttpTestingController;
  let mockAppService = { customerId: 12345678 };
  let mockEnvironmentService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        GuestConvertedService,
        { provide: HTTP_INTERCEPTORS, useClass: GuestConvertedService, multi: true },
        { provide: AppService, useValue: mockAppService },
        { provide: EnvironmentService, useValue: mockEnvironmentService },
        HttpClient
      ]
    });
    service = TestBed.get(GuestConvertedService);
    httpMock = TestBed.get(HttpTestingController);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});