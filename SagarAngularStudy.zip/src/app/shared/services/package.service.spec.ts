import { IPackageConfiguration, FilingFees, IPackageConfigurations, QuestionnaireAnswerModule, QuestionnaireAnswerService } from '@legalzoom/questionnaire-answer-sdk';
/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { PackageService } from './package.service';
import { QuestionnaireMappingService } from './questionnaire/questionnaire-mapping.service';
import { QuestionnaireService } from './questionnaire/questionnaire.service';
import { AppService } from '../state/app';
import { ProductService, ProductModule } from '@legalzoom/product-sdk';
import { ProductConfigurationIds } from '../models/cart-model';
import { LLC } from '../models/questionnaire-model';
import { of } from 'rxjs';

describe('PackageService', () => {
  let service: PackageService;
  let mockQuestionnaireMappingService;
  let mockQuestionnaireService;
  let mockProductService;
  let mockQuestionAnswerService;
  const mockAppService = {
    currentView: '',
    loginEmail: '',
    processingOrderId: 123,
    app: {
      processingOrderId: 123
    }
  };
  const configuration: IPackageConfiguration = {
    name: 'test',
    parentProductId: 123,
    productComponentId: 123,
    productConfigurationId: ProductConfigurationIds.economyLLCPackage,
    displayNameOnBill: 'test',
    displayNameOnWeb: 'test',
    packageProductConfigurationId: 'test',
    extendedPrice: 123,
    filingfees: new FilingFees(),
    productTypeId: 'test',
    shouldDisplayOnBill: true,
    productComponent: null,
    isDefaultPackage: true,
    childProducts: []
  };
  const configurations: IPackageConfigurations = {
    packageConfiguration: [configuration]
  };
  const productFillingFeesResponse = {
    packages: [{
      productConfigurationId: 123,
      productBasePriceId: 123,
      productPricePointId: 123,
      productPriceAdjustmentId: 123,
      basePrice: 123,
      lawyerAmount: 123,
      adjustedPrice: 123,
      stateId: 123,
      countyId: 123,
      productName: 'test',
      billingDisplayName: 'test',
      purchaseLockDisplayName: 'test',
      filingFee: {
        productConfigurationId: 123,
        productBasePriceId: 123,
        productPricePointId: 123,
        productPriceAdjustmentId: 123,
        basePrice: 123,
        lawyerAmount: 123,
        adjustedPrice: 123,
        stateId: 123,
        countyId: 123,
        productName: 'test',
        billingDisplayName: 'test',
        purchaseLockDisplayName: 'test',
      }
    }]
  };

  beforeEach(() => {
    mockQuestionnaireMappingService = jasmine.createSpyObj(['doMapping']);
    mockProductService = jasmine.createSpyObj(['getAvailablePackagesWithFilingFees']);
    mockQuestionAnswerService = jasmine.createSpyObj(['saveAndGetMappedUserAnswers']);
    mockQuestionnaireService = {
      llc: new LLC()
    };
    mockQuestionnaireService.llc.entityState = 'California';
    TestBed.configureTestingModule({
      imports: [ProductModule, QuestionnaireAnswerModule],
      providers: [PackageService,
        { provide: QuestionnaireMappingService, useValue: mockQuestionnaireMappingService },
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: AppService, useValue: mockAppService },
        { provide: ProductService, useValue: mockProductService },
        { provide: QuestionnaireAnswerService, useValue: mockQuestionAnswerService },
      ]
    });
    service = TestBed.get(PackageService);
  });

  it('should create', inject([PackageService], (serviceref: PackageService) => {
    expect(serviceref).toBeTruthy();
  }));
  it('should return getPackageDisplayName Economy', () => {
    configuration.productConfigurationId = ProductConfigurationIds.economyLLCPackage;
    const result = service.getPackageDisplayName(configuration);
    expect(result).toBe('Economy');
  });
  it('should return getPackageDisplayName Standard', () => {
    configuration.productConfigurationId = ProductConfigurationIds.standarLLCPackage;
    const result = service.getPackageDisplayName(configuration);
    expect(result).toBe('Standard');
  });
  it('should return getPackageDisplayName Express Gold', () => {
    configuration.productConfigurationId = ProductConfigurationIds.expressGoldLLCPackage;
    const result = service.getPackageDisplayName(configuration);
    expect(result).toBe('Express Gold');
  });
  it('should return getPackageDisplayName Get Me Started', () => {
    configuration.productConfigurationId = ProductConfigurationIds.tier1LLCPackage;
    const result = service.getPackageDisplayName(configuration);
    expect(result).toBe('Get Me Started');
  });
  it('should return getPackageDisplayName Support Me', () => {
    configuration.productConfigurationId = ProductConfigurationIds.tier2LLCPackage;
    const result = service.getPackageDisplayName(configuration);
    expect(result).toBe('Support Me');
  });
  it('should return getPackageDisplayName Help Me Grow', () => {
    configuration.productConfigurationId = ProductConfigurationIds.tier3LLCPackage;
    const result = service.getPackageDisplayName(configuration);
    expect(result).toBe('Help Me Grow');
  });
  it('should return blank object of type IPackageConfiguration', () => {
    const result = service.createNewPackageConfiguration();
    expect(typeof (result)).toBe('object');
  });
  it('should return 1 package configuration', async(() => {
    const result = service.mapPackageConfigurations(productFillingFeesResponse);
    result.subscribe(data => {
      expect(data.packageConfiguration.length).toBe(1);
    });
  }));
  it('should not call loadPackages if service.packageConfigurations has value', () => {
    spyOn(service, 'loadPackages');
    service.packageConfigurations = configurations;
    service.getPackages();
    expect(service.loadPackages).not.toHaveBeenCalled();
  });
  it('should call loadPackages if service.packageConfigurations doesnot have value', () => {
    spyOn(service, 'loadPackages');
    service.packageConfigurations = null;
    service.getPackages();
    expect(service.loadPackages).toHaveBeenCalled();
  });
  it('should call loadPackages if service.packageConfigurations doesnot have value', async(() => {
    mockQuestionnaireMappingService.doMapping.and.returnValue({});
    mockQuestionAnswerService.saveAndGetMappedUserAnswers.and.returnValue(of({}));
    mockProductService.getAvailablePackagesWithFilingFees.and.returnValue(of({}));
    spyOn(service, 'mapPackageConfigurations');
    service.loadPackages();
    expect(mockQuestionAnswerService.saveAndGetMappedUserAnswers).toHaveBeenCalled();
  }));
});
