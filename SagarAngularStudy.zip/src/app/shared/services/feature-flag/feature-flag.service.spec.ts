import {TestBed} from '@angular/core/testing';
import {FeatureFlagService} from "./feature-flag.service";
import {EnvironmentService} from "../environment.service";
import {QuestionnaireService} from "../questionnaire/questionnaire.service";
import {AppService} from "../../state/app";
import * as LDClient from "launchdarkly-js-client-sdk";

const MOCK_FEATURE_ON_KEY = 'test-key-on';
const MOCK_FEATURE_OFF_KEY = 'test-key-off';
const MOCK_FEATURE_DATA = {
  'mock-key-on': true,
  'mock-key-off': false
};

describe('FeatureFlagService', () => {
  let service: FeatureFlagService;
  const mockEnvironmentService = jasmine.createSpyObj(['getLaunchDarklyClientId']);
  const mockAppService = {customerId: 123, loginEmail: 'test@legalzoom.com'};
  const mockQuestionnaireService = {llc: {entityState: 'California', isMobile: false}};
  const mockLDClient = {
    variation: (key, defaultValue) => {
      return (key in MOCK_FEATURE_DATA) ? MOCK_FEATURE_DATA[key] : defaultValue;
    },
  };

  beforeEach(() => {
      TestBed.configureTestingModule({
          providers: [
            {
              provide: EnvironmentService,
              useValue: mockEnvironmentService
            },
            {
              provide: AppService,
              useValue: mockAppService
            },
            {
              provide: QuestionnaireService,
              useValue: mockQuestionnaireService
            },
            FeatureFlagService,
          ],
        },
      );
      service = TestBed.get(FeatureFlagService);

      mockEnvironmentService.getLaunchDarklyClientId.and.returnValue('602c5aecf44d360b390e063c');

    },
  );

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('[Feature Is Off]',
    () => {

      it('isFeatureOn - should return falsy', (done) => {
        service.isFeatureOn(MOCK_FEATURE_OFF_KEY).subscribe(isFeatureOn => {
            expect(isFeatureOn).toBeFalsy(`'isFeatureOn' is not falsy`);
            done();
          },
        );
      });

      it('isFeatureOff - should return truthy', (done) => {
        service.isFeatureOff(MOCK_FEATURE_OFF_KEY).subscribe(isFeatureOff => {
            expect(isFeatureOff).toBeTruthy(`'isFeatureOff' is not truthy`);
            done();
          },
        );
      });
    },
  );

  describe('[Feature Is On]',
    () => {
      it('isFeatureOn - should return truthy', (done) => {
        service.isFeatureOn(MOCK_FEATURE_ON_KEY).subscribe(isFeatureOn => {
            expect(isFeatureOn).toBeTruthy(`'isFeatureOn' is not truthy`);
            done();
          },
        );
      });

      it('isFeatureOff - should return falsy', (done) => {
        service.isFeatureOff(MOCK_FEATURE_ON_KEY).subscribe(isFeatureOff => {
            expect(isFeatureOff).toBeFalsy(`'isFeatureOff' is not falsy`);
            done();
          },
        );
      });
    },
  );
});
