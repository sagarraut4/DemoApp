import { Injectable } from '@angular/core';
import { BehaviorSubject, ReplaySubject } from 'rxjs';
import { map } from 'rxjs/operators';
import { AppService } from '../../state/app';
import { EnvironmentService } from '../environment.service';
import { QuestionnaireService } from '../questionnaire/questionnaire.service';
import { ConstantsService } from '../constants.service';
import * as LDClient from 'launchdarkly-js-client-sdk';

export const FEATURE_FLAG_NAMECHECK_LOGGING = 'lz-entity-name-check';
export const FEATURE_FLAG_NAMECHECK_FLOW = 'lz-entity-name-check-flow';
export const FEATURE_FLAG_CONTINUE_WITH_THIS_NAME_ANYWAY_FLOW = 'continue-with-this-name-anyway-flow';
export const FEATURE_FLAG_Q2_PROF_REQ_DESKTOP_ENHANCED_INPUT = 'lz-q2_prof-req_desktop_enhcd-input';
export const FEATURE_FLAG_Q2_PROF_REQ_MOBILE_ENHANCED_INPUT = 'lz-q2_prof-req_mobile_enhcd-input';
export const FEATURE_FLAG_Q2_Advance_Namecheck_State ='lz-advance-name-check-state';
export const FEATURE_FLAG_Q2_SHOW_IN_IQ_FLOW='lz-show-q2-llc-in-iq-flow';
export const FEATURE_FLAG_LZ_PARTNER_OFFER_NEXT='lz-partner-offer-next';
export interface FeatureFlagUser {
  key?: string;
  email?: string;
  custom?: any;
  anonymous?: boolean
}

@Injectable({
  providedIn: 'root'
})
export class FeatureFlagService {
  // We're using two types of flags, boolean for feature on/off, and number to specify a numeric setting that we can dynamically update without code change.
  // It's simplest to cache the flag values in separate collections since they have different types
  private flagChanges: { [key: string]: ReplaySubject<boolean> } = {};
  private numberChanges: { [key: string]: ReplaySubject<number> } = {};
  private ldClient: LDClient.LDClient;
  private user: FeatureFlagUser;
  public bofaSquareEnabled: boolean = true;
  public nameCheckFailureMax = 3;
  public isSetPasswordEnabled: boolean = true;
  public businessNameHelpModalTime=120000;
  public advanceNameCheckState=false
  public advancenameCheckFailureMax = 2;
  private advanceNameCheckStatefeature = new BehaviorSubject<boolean>(false);
  public showQ2InIqFlow = false;
  public readonly advanceNameCheckStatefeature$ = this.advanceNameCheckStatefeature.asObservable();
  public showPartnerOfferNext: boolean = true;
  public constructor(private environment: EnvironmentService, private appService: AppService, private questionnaireService: QuestionnaireService) {
    const user = this.getUser();
    this.ldClient = LDClient.initialize(this.environment.getLaunchDarklyClientId(), user);
    this.ldClient.on('initialized', () => {
      // cache all flag values at once, since all were fetched during initialization
      this.setLocalCache(this.ldClient.allFlags(), user);
    });

    this.isFeatureOn('lz-square-partner-offer').subscribe(bofaSquareEnabled =>{
      this.bofaSquareEnabled = bofaSquareEnabled;
    });

    this.getNumberSetting('lz-entity-name-check-help-timer').subscribe(businessNameHelpModalTime =>{
      this.businessNameHelpModalTime = businessNameHelpModalTime*1000;
    });

    this.getNumberSetting('lz-entity-name-check-failure-max').subscribe(val =>{
      if (val > 0) {
        this.nameCheckFailureMax = val;
      }
    });
    
    this.getNumberSetting('lz-advance-name-check-failure-max').subscribe(val => {
      if (val > 0) {
        this.advancenameCheckFailureMax = val;
      }
    });

    this.isFeatureOn(FEATURE_FLAG_Q2_SHOW_IN_IQ_FLOW).subscribe(showQ2InIqFlow => {
      this.showQ2InIqFlow = showQ2InIqFlow;
    })

    this.isFeatureOn(FEATURE_FLAG_LZ_PARTNER_OFFER_NEXT).subscribe(showPartnerOfferNext =>{
      this.showPartnerOfferNext = showPartnerOfferNext;
    });
  }

  /**
   * checks if any user properties have changed, and re-evaluates flags if so
   */
  public reinitializeFlagsIfUserChanged(): void {
    const currentUser = this.getUser();
    if (!this.deepCompare(currentUser, this.user)) {
      this.ldClient.identify(currentUser).then(flags => {
        this.setLocalCache(flags, currentUser);

        // Check if name check subject needs to be updated.
        for (const [key, value] of Object.entries(flags)) {
          if(key==FEATURE_FLAG_Q2_Advance_Namecheck_State)
          {
            this.advanceNameCheckStatefeature.next(value);
          }
        }
      });
    }
  }

  /**
   * Is Feature On
   */
  public isFeatureOn(featureKey: string): ReplaySubject<boolean> {
    if (typeof this.flagChanges[featureKey] === 'undefined') {
      this.flagChanges[featureKey] = new ReplaySubject<boolean>(1);
    }
    return this.flagChanges[featureKey];
  }

  /**
   * Faux: Is Feature Off
   */
  public isFeatureOff(featureKey: string): ReplaySubject<boolean> {
    // Using is Feature On - but FLIP the response
    // @ts-ignore
    return this.isFeatureOn(featureKey).pipe(map((isFeatureOn) => !isFeatureOn));
  }

  /**
   * Get value of multivariate flag of Number type
   */
  public getNumberSetting(featureKey: string): ReplaySubject<number> {
    if (typeof this.numberChanges[featureKey] === 'undefined') {
      this.numberChanges[featureKey] = new ReplaySubject<number>(1);
    }
    return this.numberChanges[featureKey];
  }

  private getUser() : FeatureFlagUser {
    const { entityState, isMobile } = this.questionnaireService.llc;
    if (this.appService.customerId) {
      return { key: this.appService.customerId.toString(),
        email: this.appService.loginEmail,
      custom: {
        llcState: ConstantsService.getStateAbbr(entityState),
        platform: isMobile ? 'mobile' : 'web'
      }
      };
    }
    return { anonymous: true };
  }

  private setLocalCache(flags: LDClient.LDFlagSet, user: FeatureFlagUser): void {
    for (const [key, value] of Object.entries(flags)) {
      if (typeof value === 'number') {
        const numberChange = this.getNumberSetting(key);
        numberChange.next(value);
      } else {
        const flagChange = this.isFeatureOn(key);
        flagChange.next(value);
      }
    }
    this.user = user;
  }

  private deepCompare(thing1, thing2): boolean {
    if (thing1 === thing2) {
      return true;
    }

    if (thing1 === null || thing2 === null || typeof thing1 !== "object" || typeof thing2 !== "object") {
      return false;
    }

    const keys1 = Object.keys(thing1);
    const keys2 = Object.keys(thing2);
    if (keys1.length != keys2.length) {
      return false;
    }
    for (const key of keys1) {
      if (!(key in keys2) || !this.deepCompare(thing1[key], thing2[key])) {
        return false;
      }
    }

    return true;
  }
}
