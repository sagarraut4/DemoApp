import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormControl, FormGroup } from '@angular/forms';
import { COMMON_LIB_CONFIG, CommonLibConfig } from '@legalzoom/common-sdk';
import { EntityDbLoggingErrorStates, EntityDbLoggingService } from './entity-db-logging.service';
import { FeatureFlagService } from './feature-flag/feature-flag.service';
import { AppService } from '../state/app';
import { QuestionnaireService } from './questionnaire/questionnaire.service';
import { of } from 'rxjs';
import { EntitydbService } from '@legalzoom/entitydb-sdk';

describe('EntityDbLoggingService', () => {
  const MOCK_STATE_CALIFORNIA = 'California';
  const MOCK_RESPONSE = true;

  let service: EntityDbLoggingService;

  // Create Mock Objects
  const formGroup: FormGroup = new FormGroup(
    {
      businessDetails: new FormGroup(
        {
          businessName: new FormControl(),
          businessNameDesignator: new FormControl(),
        },
      ),
    },
  );
  const mockAppService = {
    app: {
      processingOrderId: 1,
      questionnaireId: 1,
    },
    questionnaireId: 1,
  };

  const mockQuestionnaireService = {
    llc: {
      currentView: '',
      packageSelected: '',
      entityState: MOCK_STATE_CALIFORNIA,
      legalAdvice: false,
    },
  };
  let mockFeatureFlagResponse = false;

  // Create SpyObj
  const mockFeatureFlagService = jasmine.createSpyObj(['isFeatureOn']);
  const mockEntitydbService = jasmine.createSpyObj(['getEntityAvailability', 'saveEntityAvailabilityLog']);

  beforeEach(() => {
      TestBed.configureTestingModule({
          imports: [
            HttpClientTestingModule,
          ],
          providers: [
            EntityDbLoggingService,
            {provide: AppService, useValue: mockAppService},
            {provide: QuestionnaireService, useValue: mockQuestionnaireService},
            {provide: FeatureFlagService, useValue: mockFeatureFlagService},
            {provide: EntitydbService, useValue: mockEntitydbService},
            {provide: COMMON_LIB_CONFIG, useValue: new CommonLibConfig('', '', '', '', '')},
          ],
        },
      );

      service = TestBed.get(EntityDbLoggingService);
    },
  );

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('IsFeature Stream',
    () => {
      it(`[Feature Off] - Observable stream should stop with error: '${EntityDbLoggingErrorStates.FeatureFlagOff}'`, async (done) => {
          // Arrange
          mockFeatureFlagResponse = false;
          mockFeatureFlagService.isFeatureOn.and.returnValue(
            of(mockFeatureFlagResponse),
          );

          // Act
          service.checkNameAndLog(formGroup).subscribe(
            // No Success Response
            successResponse => {
              expect(true).toBeFalsy(`This should not happen! ${successResponse}`);
              done();
            },

            // Should have an ERROR response
            errorResponse => {

              // Assert
              // Error should have been thrown
              expect(errorResponse).toBe(EntityDbLoggingErrorStates.FeatureFlagOff);

              // Terminate Test
              done();
            },
          );
        },
      );

      it(`[Feature On & Valid State] Observable stream should complete`, async (done) => {
          // Arrange
          mockFeatureFlagResponse = true;
          mockFeatureFlagService.isFeatureOn.and.returnValue(
            of(mockFeatureFlagResponse),
          );
          mockQuestionnaireService.llc.entityState = MOCK_STATE_CALIFORNIA;
          mockEntitydbService.getEntityAvailability.and.returnValue(
            of(MOCK_RESPONSE),
          );
          mockEntitydbService.saveEntityAvailabilityLog.and.returnValue(
            of(MOCK_RESPONSE),
          );

          // Act
          service.checkNameAndLog(formGroup).subscribe(
            // Success Response
            successResponse => {
              // Assert a response should FIRE
              expect(successResponse).toBe(MOCK_RESPONSE);

              // Terminate Test
              done();
            },

            // No Error Response
            errorResponse => {
              expect(true).toBeFalsy(`This should not happen! ${errorResponse}`);
              done();
            },
          );
        },
      );
    },
  );

  describe('EntityAvailable Stream',
    () => {
      beforeEach(() => {
        // Arrange
        mockFeatureFlagResponse = true;
        mockFeatureFlagService.isFeatureOn.and.returnValue(
          of(mockFeatureFlagResponse),
        );

        mockQuestionnaireService.llc.entityState = MOCK_STATE_CALIFORNIA;
        mockEntitydbService.getEntityAvailability.and.returnValue(
          of(MOCK_RESPONSE),
        );
        mockEntitydbService.saveEntityAvailabilityLog.and.returnValue(
          of(MOCK_RESPONSE),
        );
      });

      it(`[Non Cached Response] Observable stream should complete`, async (done) => {
          // Act
          service.checkNameAndLog(formGroup).subscribe(
            // Success Response
            successResponse => {
              // Assert a response should FIRE
              expect(successResponse).toBeDefined(); // TODO: Better test response

              // Terminate Test
              done();
            },
          );
        },
      );
    },
  );
});
