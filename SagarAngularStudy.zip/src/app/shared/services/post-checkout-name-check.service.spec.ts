import { TestBed } from '@angular/core/testing';

import {
  PostCheckoutNameCheckService,
  PostCheckoutNameCheckState,
} from './post-checkout-name-check.service';
import { COMMON_LIB_CONFIG, CommonLibConfig } from '@legalzoom/common-sdk';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { EntitydbService, EntityNameStatus, IEntityDbResponse, NameCheckReasonCode } from '@legalzoom/entitydb-sdk';
import { of, throwError } from 'rxjs';
import { FormControl, FormGroup } from '@angular/forms';
import { QuestionnaireService } from './questionnaire/questionnaire.service';
import { ConstantsService } from './constants.service';
import { FeatureFlagService } from './feature-flag/feature-flag.service';

describe('PostCheckoutNamecheckService', () => {
  let service: PostCheckoutNameCheckService = null;

  const mockEntityDbService = jasmine.createSpyObj('EntitydbService', ['getEntityAvailability']);
  const customerId = 12345;
  const entityName = 'Test Entity Name';
  const entityStateName = 'CA';
  const mockQuestionnaireService = {
    llc: {
      currentView: '',
      packageSelected: '',
      entityState: 'California',
      legalAdvice: false,
    },
  }
  const mockFeatureFlagService = {
    nameCheckFailureMax: 5
  }

  const availableResponse: IEntityDbResponse = {
    status: EntityNameStatus.Available,
  };

  const conditionalResponse: IEntityDbResponse = {
    status: EntityNameStatus.Conditional,
  };

  const unavailableResponse: IEntityDbResponse = {
    status: EntityNameStatus.Unavailable,
  };

  const generalSimlarityResponse: IEntityDbResponse = {
    status: EntityNameStatus.GeneralSimilarity,
  };

  const randomResponse: IEntityDbResponse = {
    status: <any>'does not exist',
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        PostCheckoutNameCheckService,
        {provide: QuestionnaireService, useValue: mockQuestionnaireService},
        {provide: EntitydbService, useValue: mockEntityDbService},
        { provide: FeatureFlagService, useValue: mockFeatureFlagService },
        {provide: COMMON_LIB_CONFIG, useValue: new CommonLibConfig('', '', '', '', '')},
      ],
    });

    service = TestBed.get(PostCheckoutNameCheckService);
  });

  describe('initialization', () => {

    it('should be created', () => {
      expect(service).toBeTruthy();
    });

    it('should have an initial failure count of 0', () => {
      expect(service.nameCheckFailureCount).toBe(0);
    });

    it('should set current state as Default', () => {
      expect(service.currentState).toBe(PostCheckoutNameCheckState.Default);
    });

    it('should retrieve previous state as undefined', () => {
      expect(service.previousState).toBe(undefined);
    });

    it('should be able to lookup entity', () => {
      console.log(service);
      expect(service.canLookUpEntity).toBe(true);
    });

  });


  describe('public methods/properties', () => {

    describe('pauseProgress()', () => {

      it('should emit false', (done) => {
        service.pauseProgress();
        service.canProgress$.subscribe((res) => {
          expect(res).toBe(false);
          done();
        });
      });

    });

    describe('resumeProgress()', () => {

      it('should emit canProgress is false', (done) => {
        service.resumeProgress();
        service.canProgress$.subscribe((res) => {
          expect(res).toBe(true);
          done();
        });
      });

    });

  });

  describe('reset()', () => {
    it('should set failure count to 0', () => {
      service.reset();
      expect(service.nameCheckFailureCount).toBe(0);
    });
  });

  describe('resetBusinessName()', () => {
    it('should reset the form control', () => {
      // Arrange
      const formControl: FormControl = new FormControl('mock_values');
      const formGroup: FormGroup = new FormGroup({
          businessName: formControl,
          businessNameDesignator: formControl,
          isBusinessName: formControl,
          businessNameExplanation: formControl,
        },
      );

      // Act
      service.resetBusinessName(formGroup);

      // Assert
      expect(service.currentState).toBe(PostCheckoutNameCheckState.Default);
      expect(formControl.value).toBe('');
    });
  });

  describe('canLookUpEntity()', () => {
    it('should return true when in default state', () => {
      expect(service.currentState).toBe(PostCheckoutNameCheckState.Default);
      expect(service.canLookUpEntity).toBe(true);
    });

    it('should return true when in Invalid state', () => {
      mockEntityDbService.getEntityAvailability.and.returnValue(of(unavailableResponse));
      service.getEntityNameAvailability(customerId, entityName, entityStateName).subscribe();

      expect(service.canLookUpEntity).toBe(true);
    });
  });

  describe('getEntityNameAvailability()', () => {

    it('should set state to Pending before request completes', () => {
      mockEntityDbService.getEntityAvailability.and.returnValue(of(availableResponse));

      service.getEntityNameAvailability(customerId, entityName, entityStateName);

      expect(service.currentState).toBe(PostCheckoutNameCheckState.Pending);
    });

    it('should set state to Valid when entity name status is available', (done) => {
      mockEntityDbService.getEntityAvailability.and.returnValue(of(availableResponse));

      service.getEntityNameAvailability(customerId, entityName, entityStateName)
        .subscribe((res) => {
          expect(service.currentState).toBe(PostCheckoutNameCheckState.Valid);
          done();
        });
    });

    it('should set state to Conditional when entity name status is conditional', (done) => {
      mockEntityDbService.getEntityAvailability.and.returnValue(of(conditionalResponse));

      service.getEntityNameAvailability(customerId, entityName, entityStateName)
        .subscribe((res) => {
          expect(service.currentState).toBe(PostCheckoutNameCheckState.Conditional);
          done();
        });
    });

    it('should set state to Valid when entity name is unavailable', (done) => {
      mockEntityDbService.getEntityAvailability.and.returnValue(of(unavailableResponse));

      service.getEntityNameAvailability(customerId, entityName, entityStateName)
        .subscribe((res) => {
          expect(service.currentState).toBe(PostCheckoutNameCheckState.Invalid);
          done();
        });
    });

    it('should set state to Invalid when entity name returns status of general similarity', (done) => {
      mockEntityDbService.getEntityAvailability.and.returnValue(of(generalSimlarityResponse));

      service.getEntityNameAvailability(customerId, entityName, entityStateName)
        .subscribe((res) => {
          expect(service.currentState).toBe(PostCheckoutNameCheckState.Invalid);
          done();
        });
    });

    it('should set state to Error when entity name returns an unknown status (new api response)', (done) => {
      mockEntityDbService.getEntityAvailability.and.returnValue(of(randomResponse));

      service.getEntityNameAvailability(customerId, entityName, entityStateName)
        .subscribe((res) => {
          expect(service.currentState).toBe(PostCheckoutNameCheckState.Error);
          done();
        });
    });

    it('should handle an error response', (done) => {
      mockEntityDbService.getEntityAvailability.and.returnValue(throwError('TEST ERROR'));

      service.getEntityNameAvailability(customerId, entityName, entityStateName)
        .subscribe((res) => {
          // Should not get here
          // expect(service.currentState).toBe(PostCheckoutNameCheckState.Error);
          done();
        }, (err) => {
          expect(service.currentState).toBe(PostCheckoutNameCheckState.Error);
          done();
        });
    });

    it(`should emit state InvalidMaxRetries when entity name is unavailable more than ${mockFeatureFlagService.nameCheckFailureMax} times`, (done) => {
      mockEntityDbService.getEntityAvailability.and.returnValue(of(unavailableResponse));

      service.stateChange$.subscribe((res) => {
        if (service.nameCheckFailureCount >= mockFeatureFlagService.nameCheckFailureMax) {
          expect(res).toBe(PostCheckoutNameCheckState.InvalidMaxRetries);
          done();
        }
      });

      for (let i = 0; i < mockFeatureFlagService.nameCheckFailureMax; i += 1) {
        service.getEntityNameAvailability(customerId, entityName, entityStateName)
          .subscribe((res) => {
          });
      }
    });

    it('show allow one extra failure', () => {
      mockEntityDbService.getEntityAvailability.and.returnValue(of(unavailableResponse));

      for (let i = 0; i < mockFeatureFlagService.nameCheckFailureMax; i += 1) {
        service.getEntityNameAvailability(customerId, entityName, entityStateName)
          .subscribe((res) => {
          });
      }

      const previousErrorCount: number = service.nameCheckFailureCount;

      service.allowOneExtraFailure();

      expect(service.nameCheckFailureCount).toBeLessThan(previousErrorCount);
    });

    it('show not allow one extra failure', () => {
      const previousErrorCount: number = service.nameCheckFailureCount;

      service.allowOneExtraFailure();

      expect(service.nameCheckFailureCount).toBe(previousErrorCount);
    });

    it('could reset form group', () => {
      const formGroup: FormGroup = new FormGroup(
        {
          businessNameDesignator: new FormControl(''),
          isBusinessName: new FormControl(false),
          businessNameExplanation: new FormControl(''),
        },
      );

      const questionnaireServiceInstance = TestBed.get(QuestionnaireService);

      service.allowIncompleteBusinessNameToProgress(formGroup);

      const {businessNameDesignator, isBusinessName, businessNameExplanation} = formGroup.controls;

      expect(businessNameDesignator.value).toBe('LLC');
      expect(isBusinessName.value).toBeTruthy();
      expect(businessNameExplanation.value).toBe('');

      questionnaireServiceInstance.llc.entityState = ConstantsService.STATES_SHOW_NAME_EXPLANATION[0];

      service.allowIncompleteBusinessNameToProgress(formGroup);

      expect(businessNameExplanation.value).toBe('Not provided');
    });
  });


  describe('getErrorsFromReasons()', () => {
    it('profanity response', () => {
      // Arrange
      const mockWords = 'mockWords';
      const response: Partial<IEntityDbResponse> = {
        reasons: [
          {
            code: NameCheckReasonCode.Profanity,
            text: '',
            words: mockWords,
          },
        ],
      };

      const [reason] = service.getErrorsFromReasons(response as IEntityDbResponse);

      // Act

      // Assert
      expect(reason).toContain('Delete inappropriate words or language');
      expect(reason).toContain(mockWords);
    });

    it('restricted response', () => {
      // Arrange
      const mockWords = 'mockWords';
      const response: Partial<IEntityDbResponse> = {
        reasons: [
          {
            code: NameCheckReasonCode.RestrictedWord,
            text: '',
            words: mockWords,
          },
        ],
      };

      const [reason] = service.getErrorsFromReasons(response as IEntityDbResponse);

      // Act

      // Assert
      expect(reason).toContain('Delete prohibited words');
      expect(reason).toContain(mockWords);
    });

    it('matching records found response', () => {
      // Arrange
      const response: Partial<IEntityDbResponse> = {
        reasons: [
          {
            code: NameCheckReasonCode.MatchingRecordsFound,
            text: '',
          },
        ],
      };

      const [reason] = service.getErrorsFromReasons(response as IEntityDbResponse);

      // Act

      // Assert
      expect(reason).toContain('Add or change some words so your name isn\'t so similar to an existing business name.');
    });

    it('general similarity response', () => {
      // Arrange
      const response: Partial<IEntityDbResponse> = {
        reasons: [
          {
            code: NameCheckReasonCode.General,
            text: 'General Similarity Rule',
          },
        ],
      };

      // Act
      const [reason] = service.getErrorsFromReasons(response as IEntityDbResponse);

      // Assert
      expect(reason).toContain('Add or change some words so your name isn\'t so similar to an existing business name.');
    });

    it('invalid character response', () => {
      // Arrange
      const mockWords = 'mockWords';
      const response: Partial<IEntityDbResponse> = {
        reasons: [
          {
            code: NameCheckReasonCode.InvalidCharacter,
            text: '',
            words: mockWords,
          },
        ],
      };

      // Act
      const [reason] = service.getErrorsFromReasons(response as IEntityDbResponse);

      // Assert
      expect(reason).toContain('Delete special characters');
      expect(reason).toContain(mockWords);
    });

    it('default response', () => {
      // Arrange
      const response: Partial<IEntityDbResponse> = {
        reasons: [
          {
            code: NameCheckReasonCode.InvalidDesignator,
            text: '',
            words: 'A',
          },
          {
            code: null,
            text: '',
            words: 'A',
          },
        ],

      };

      // Act
      const [reason1, reason2] = service.getErrorsFromReasons(response as IEntityDbResponse);

      // Assert
      expect(reason1).toContain('Delete incorrect designator (like Co., Corp., or Inc.)');
      expect(reason2).toContain('A technical issue on our end, please try again');
    });
  });
});
