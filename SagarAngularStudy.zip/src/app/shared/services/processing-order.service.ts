import { Injectable } from '@angular/core';
import {
  IQueueEntry,
  TrackJsErrorLogService
} from '@legalzoom/business-formation-sdk';
import { HttpErrorResponse } from '@angular/common/http';
import { ProductName } from '../constants/product-domain';
import { of } from 'rxjs';
import { ProcessingOrderService as SdkProcessingOrderService } from '@legalzoom/processing-order-sdk';
@Injectable({
  providedIn: 'root'
})
export class ProcessingOrderService {

  constructor(private sdkProcessingOrderService: SdkProcessingOrderService, private trackJsErrorLogService: TrackJsErrorLogService) { }
  prepareGetProcessingOrderById(context: any, appService: any, processingOrderId, authToken: string, customerId: number, productName: ProductName): IQueueEntry {
    const that = this;
    return {
      name: 'prepareGetProcessingOrderById processing-order.service' + context.constructor.name,
      pre: () => {
        return that.sdkProcessingOrderService.getProcessingOrdersById(processingOrderId);
      },
      post: (response) => {
        const appState = appService.app;
        if (response && response.processingOrder) {
          appState.processingOrderId = response.processingOrder.processingOrderId;
          appState.isQuestionnaireComplete = response.processingOrder.isQuestionnaireCompleted;
        } else {
          appState.processingOrderId = 0;
        }
        appService.app = appState;
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJsErrorLogService.track(productName, 'processing-order.service' + context.constructor.name, error);
        return of(null);
      }
    };
  }
}
