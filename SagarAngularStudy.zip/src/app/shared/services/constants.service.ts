import { Injectable } from '@angular/core';

@Injectable()
export class ConstantsService {
  constructor() { }
  public static get TAG_NAME(): string {
    return 'llc_optimization';
  }

  public static get MANAGER_TITLES(): string[] {
    return ['Chairman', 'Chairperson', 'Chairwoman', 'Chief Executive Officer', 'Chief Financial Officer',
      'General Manager', 'Manager', 'Managing Member', 'Member', 'President', 'Secretary', 'Treasurer',
      'Vice President'];
  }

  public static get OWNER_TITLES(): string[] {
    return ['Chairman', 'Chairperson', 'Chairwoman', 'Chief Executive Officer', 'Chief Financial Officer',
      'General Manager', 'Manager', 'Managing Member', 'Member', 'President', 'Secretary', 'Treasurer',
      'Vice President'];
  }

  public static get STATES_ALLOW_DISSOLVE(): string[] {
    return ['Alabama', 'Arizona', 'Hawaii', 'Louisiana', 'Illinois', 'Indiana', 'Iowa', 'Massachusetts',
      'Mississippi', 'Michigan', 'Minnesota', 'Missouri', 'Montana', 'Nevada', 'New Hampshire', 'New Jersey',
      'New Mexico', 'New York', 'North Carolina', 'North Dakota', 'Ohio', 'Oklahoma', 'Oregon', 'South Carolina',
      'South Dakota', 'Tennessee', 'Utah', 'Vermont', 'Washington', 'West Virginia'];
  }

  public static get STATES_REQUIRING_BIZ_PURPOSE_DESC(): string[] {
    return ['Delaware', 'Massachusetts', 'Maryland', 'Missouri', 'New Mexico', 'New Jersey', 'Oregon', 'Utah', 'Pennsylvania', 'New Hampshire'];
  }

  public static get STATES_REQUIRING_NAICS_CODE(): string[] {
    return ['Alaska', 'Louisiana', 'Mississippi', 'Connecticut'];
  }

  public static get STATES_REQUIRING_BIZ_COUNTY(): string[] {
    return ['New York', 'Pennsylvania'];
  }

  public static get STATES_REQUIRING_BIZ_EMAIL(): string[] {
    return ['Connecticut', 'Mississippi', 'Oklahoma', 'Vermont', 'Georgia', 'Washington', 'South Dakota', 'Louisiana', 'Tennessee', 'Wyoming','Oregon'];
  }

  public static get STATES_REQUIRING_BIZ_PHONE(): string[] {
    return ['Wyoming', 'Arkansas', 'North Carolina'];
  }

  public static get STATES_REQUIRING_FORMATION_DATE(): string[] {
    return ['Idaho', 'Montana', 'New Mexico', 'Mississippi', 'Vermont'];
  }

  public static get STATES_REQUIRING_SOS_RETRY(): string[] {
    return ['Idaho', 'Montana', 'New Mexico', 'Mississippi', 'Vermont'];
  }

  public static get STATES_REQUIRING_ATTORNEY(): string[] {
    return ['New York'];
  }

  public static get STATES_REQUIRING_LIMITED_SCOPE_AGREEMENT(): string[] {
    return ['Tennessee'];
  }

  public static get STATES_REQUIRING_OWNERS_MARRIED(): string[] {
    return ['Arizona', 'California', 'Idaho', 'Louisiana', 'Nevada', 'New Mexico', 'Texas', 'Washington', 'Wisconsin'];
  }

  public static get STATES_NOT_ALLOW_OUT_OF_STATE(): string[] {
    return ['Alaska', 'Arizona', 'California', 'Idaho', 'Louisiana', 'Maryland', 'Massachusetts', 'Nebraska',
      'New Hampshire', 'New Jersey', 'Oregon', 'Pennsylvania', 'South Carolina', 'Tennessee', 'West Virginia'];
  }

  public static get STATES_NOT_ALLOW_PO_BOX(): string[] {
    return ['Alaska', 'Arizona', 'California', 'Colorado', 'Connecticut', 'Dist. of Columbia', 'District of Columbia',
      'Florida', 'Georgia', 'Idaho', 'Illinois', 'Iowa', 'Louisiana', 'Maryland', 'Massachusetts', 'Montana',
      'Nebraska', 'New Hampshire', 'New Mexico', 'North Carolina', 'North Dakota', 'Oklahoma', 'Pennsylvania',
      'Rhode Island', 'South Carolina', 'South Dakota', 'Tennessee', 'Utah', 'Virginia', 'West Virginia'];
  }

  public static get STATES_NOT_ALLOW_PROLLC(): string[] {
    return ['Alabama', 'Alaska', 'California', 'Delaware', 'Georgia', 'Hawaii', 'Indiana', 'Louisiana', 'Maryland',
      'Missouri', 'New Jersey', 'New Mexico', 'Ohio', 'Oregon', 'Rhode Island', 'South Carolina', 'South Dakota',
      'Wisconsin', 'Wyoming', 'New York'];
  }

  public static get STATES_REQUIRING_FISCAL_DATE_WITHOUT_EIN(): string[] {
    return ['Kansas', 'New Jersey', 'Tennessee', 'Vermont'];
  }

  public static get STATES_REQUIRING_RA(): string[] {
    return ['New York', 'Minnesota', 'Pennsylvania'];
  }

  public static get STATES_REQUIRING_RA_EMAIL(): string[] {
    return ['Dist. of Columbia', 'District of Columbia', 'Georgia', 'Indiana', 'Ohio', 'South Dakota', 'Mississippi', 'Arizona', 'Louisiana', 'Washington'];
  }

  public static get STATES_REQUIRING_CRA_INDICATOR(): string[] {
    return ['South Dakota'];
  }

  public static get STATES_REQUIRING_NAICS_NEW_URL(): string[] {
    return ['Alaska'];
  }
  
  public static get STATES_REQUIRING_LABOR_JUDGMENT(): string[] {
    return ['California'];
  }

  public static get STATES_SHOW_NAME_EXPLANATION(): string[] {
    return ['Delaware', 'Dist. of Columbia', 'District of Columbia', 'New York', 'Nevada', 'Wyoming'];
  }
  // Hari made changes on 07/06/2021 for ORCO - 75, 76, 77 and 78 stories.
  public static get STATES_MISSING_REGISTERED_ENTITY_NAMES(): string[] {
    return ['Delaware', 'Hawaii', 'Michigan', 'New Jersey', 'Utah', 'Illinois', 'Louisiana', 'Mississippi', 'South Carolina', 'Ohio'];
  }
  public static get STATES_REQUIRING_OWNERSHIP_PHONE_NUMBER(): string[] {
    return ['Louisiana'];
  }
  public static get STATES_REQUIRING_OWNERSHIP_ADDRESS(): string[] {
    return ['Louisiana'];
  }

  public static get STATES_REQUIRING_OWNERSHIP_EIN(): string[] {
    return ['Louisiana'];
  }

  public static get STATES_REQUIRING_OWNERSHIP_SSN(): string[] {
    return ['Louisiana'];
  }
  
  public static get STATES_NOT_REQUIRING_TRUST(): string[] {
    return ['Louisiana'];
  }
  public static get STATES_REQUIRING_TAXATION(): string[] {
    return ['Louisiana'];
  }
  
  /** [ OPT-241 ]
   *  PLLC Designator conditions and how list below has been derived:
   *   1. Per comment-reply from Wendy Wong in https://contently.com/stories/281299#comments
   *   2. Kansas, Maine, Massachusetts, Nebraska and West Virginia do not see the subsection
   */
  public static get STATES_REQUIRING_PLLC_DESIGNATOR(): string[] {
    return ['Arizona', 'Arkansas', 'Colorado', 'Connecticut', 'District of Columbia', 'Florida', 'Idaho', 'Iowa',
      /*'Kansas',*/ 'Kentucky', /*'Maine', 'Massachusetts',*/ 'Michigan', 'Minnesota', 'Mississippi', 'Montana',
      /*'Nebraska',*/ 'Nevada', 'New Hampshire', 'North Carolina', 'North Dakota', 'Oklahoma', 'Pennsylvania',
      'Tennessee', 'Texas', 'Utah', 'Vermont', 'Virginia', 'Washington'/*, 'West Virginia*/];
  }

  public static get STATE_EXCLUSIONS_FOR_EMAIL_LICENSE_TEXT(): string[] {
    return ['Arkansas', 'Kansas', 'Nebraska', 'Oklahoma', 'North Dakota'];
  }

  public static get STATES_REQUIRING_LICENSED_INDUSTRY_OR_PROFESSION(): string[] {
    return ['Colorado', 'Minnesota', 'Pennsylvania', 'Texas'];
  }

  public static get STATE_INDUSTRIES_AND_PROFESSIONS(): { [key:string]: string[] } {
    return {
      Colorado: [
        'Architect',
        'Certified public accountant',
        'Chiropractor',
        'Dentist',
        'Engineer',
        'Land surveyor',
        'Lawyer',
        'Optometrist',
        'Physical therapist',
        'Physician and surgeon',
        'Podiatrist',
        'Professional counselor',
        'Veterinarian',
      ],
      Minnesota: [
        'Accountancy',
        'Architecture',
        'Certified interior design',
        'Chiropractic',
        'Dentistry and dental hygiene',
        'Engineering',
        'Geoscience',
        'Landscape architecture',
        'Law',
        'Marriage and family therapy',
        'Medicine and surgery',
        'Optometry',
        'Pharmacy',
        'Physician assistant',
        'Podiatric medicine',
        'Professional counseling',
        'Psychology',
        'Registered nursing',
        'Social work',
        'Surveying',
        'Veterinary medicine',
      ],
      Pennsylvania: [
        'Chiropractic',
        'Dentistry',
        'Law',
        'Medicine and surgery',
        'Optometry',
        'Osteopathic medicine and surgery',
        'Podiatric medicine',
        'Public accounting',
        'Psychology',
        'Veterinary medicine',
      ],
      Texas: [
        'Accountant/CPA',
        'Acupuncturist',
        'Anesthesiologist (MD)',
        'Architect',
        'Athletic trainer',
        'Attorney',
        'Audiologist',
        'Chemical dependency counselor (licensed)',
        'Chiropractor',
        'Dental hygienist',
        'Dentist',
        'Electronic access control',
        'Embalmer',
        'EMS personnel (EMT, attendant, paramedic)',
        'EMS provider',
        'Engineer',
        'Equine dentistry',
        'Funeral director',
        'Geoscientist (licensed)',
        'Hearing aid dispenser',
        'Inspector (real estate or home)',
        'Insurance agent/broker',
        'Investment advisor (registered)',
        'Locksmith',
        'Marriage/family therapist (licensed)',
        'Massage therapist',
        'Massage school/massage therapy instructor',
        'Medical physicist (licensed)',
        'Medicine, Doctor of',
        'Mental health or professional counselor (licensed)',
        'Mental health professional (licensed)',
        'Midwife',
        'Mold assessment',
        'Mold remediation',
        'Mortgage broker',
        'Nurse',
        'Nurse anesthetist',
        'Nurse, psychiatric',
        'Occupational therapist',
        'Optometrist',
        'Orthopedics',
        'Orthotist',
        'Osteopathy, Doctor of',
        'Perfusionist',
        'Pharmacist',
        'Physical therapist',
        'Physician',
        'Physician assistant',
        'Podiatrist',
        'Polygraph examiner',
        'Priviate investigator',
        'Private security',
        'Prosthetist',
        'Psychiatrist',
        'Psychologist',
        'Psychotherapist',
        'Radiologist',
        'Radiology technician, medical',
        'Real estate agent',
        'Real estate appraiser*',
        'Real estate broker',
        'Respiratory care therapist',
        'Sanitarian (professional)',
        'Securities broker/dealer',
        'Social worker (licensed clinical, baccalaureate, or master)',
        'Speech/language pathologist',
        'Sports medicine',
        'Surveyor (public or regular)',
        'Therapeutic optometrist',
        'Therapist (licensed mental health)',
        'Veterinarian',
      ],
    }
  }

  public static GetAllStates(): { name: string, abbr: string }[] {
    return this.STATES;
  }

  public static get STATES_REQUIRING_RA_PHONE(): string[] {
    return ['Louisiana'];
  }

  public static get STATES_SHOW_RA_LAWFIRM(): string[] {
    return ['Louisiana'];
  }

  public static get STATES_SHOW_PAPER_WORK_DEADLINE(): string[] {
    return ['Louisiana'];
  }
  public static get BAD_WORD_LIST(): string[] {
  return  ["4r5e", "5h1t", "5hit", "a55", "anal", "anus", "ar5e", "arrse", "arse", "ass", "ass-fucker", "asses", "assfucker", "assfukka", "asshole", "assholes", "asswhole", "a_s_s", "b!tch", "b00bs", "b17ch", "b1tch", "ballbag", "balls", "ballsack", "bastard", "beastial", "beastiality", "bellend", "bestial", "bestiality", "bi+ch", "biatch", "bitch", "bitcher", "bitchers", "bitches", "bitchin", "bitching", "bloody", "blow job", "blowjob", "blowjobs", "boiolas", "bollock", "bollok", "boner", "boob", "boobs", "booobs", "boooobs", "booooobs", "booooooobs", "breasts", "buceta", "bugger", "bum", "bunny fucker", "butt", "butthole", "buttmuch", "buttplug", "c0ck", "c0cksucker", "carpet muncher", "cawk", "chink", "cipa", "cl1t", "clit", "clitoris", "clits", "cnut", "cock", "cock-sucker", "cockface", "cockhead", "cockmunch", "cockmuncher", "cocks", "cocksuck", "cocksucked", "cocksucker", "cocksucking", "cocksucks", "cocksuka", "cocksukka", "cok", "cokmuncher", "coksucka", "coon", "cox", "crap", "cum", "cummer", "cumming", "cums", "cumshot", "cunilingus", "cunillingus", "cunnilingus", "cunt", "cuntlick", "cuntlicker", "cuntlicking", "cunts", "cyalis", "cyberfuc", "cyberfuck", "cyberfucked", "cyberfucker", "cyberfuckers", "cyberfucking", "d1ck", "damn", "dick", "dickhead", 
  "dildo", "dildos", "dink", "dinks", "dirsa", "dlck", "dog-fucker", 
  "doggin", "dogging", "donkeyribber", "doosh", "duche", "dyke", "ejaculate", 
  "ejaculated", "ejaculates", "ejaculating", "ejaculatings", "ejaculation", 
  "ejakulate", "fuck", "fucker", "f4nny", "fag", "fagging", 
  "faggitt", "faggot", "faggs", "fagot", "fagots", "fags", 
  "fanny", "fannyflaps", "fannyfucker", "fanyy", "fatass", 
  "fcuk", "fcuker", "fcuking", "feck", "fecker", "felching", 
  "fellate", "fellatio", "fingerfuck", "fingerfucked", 
  "fingerfucker", "fingerfuckers", "fingerfucking", "fingerfucks", 
  "fistfuck", "fistfucked", "fistfucker", "fistfuckers", "fistfucking", 
  "fistfuckings", "fistfucks", "flange", "fook", "fooker", "fuck", "fucka", 
  "fucked", "fucker", "fuckers", "fuckhead", "fuckheads", "fuckin", "fucking", 
  "fuckings", "fuckingshitmotherfucker", "fuckme", "fucks", "fuckwhit", "fuckwit", 
  "fudge packer", "fudgepacker", "fuk", "fuker", "fukker", "fukkin", "fuks",
   "fukwhit", "fukwit", "fux", "fux0r", "f_u_c_k", "gangbang", "gangbanged", 
   "gangbangs", "gaylord", "gaysex", "goatse", "God", "god-dam", "god-damned", 
   "goddamn", "goddamned", "hardcoresex", "hell", "heshe", "hoar", "hoare", "hoer", 
   "homo", "hore", "horniest", "horny", "hotsex", "jack-off", "jackoff", "jap", 
   "jerk-off", "jism", "jiz", "jizm", "jizz", "kawk", "knob", "knobead", "knobed", 
   "knobend", "knobhead", "knobjocky", "knobjokey", "kock", "kondum", "kondums", 
   "kum", "kummer", "kumming", "kums", "kunilingus", "l3i+ch", "l3itch", "labia", 
   "lust", "lusting", "m0f0", "m0fo", "m45terbate", "ma5terb8", "ma5terbate", 
   "masochist", "master-bate", "masterb8", "masterbat*", "masterbat3", "masterbate", 
   "masterbation", "masterbations", "masturbate", "mo-fo", "mof0", "mofo", 
   "mothafuck", "mothafucka", "mothafuckas", "mothafuckaz", "mothafucked", 
   "mothafucker", "mothafuckers", "mothafuckin", "mothafucking", "mothafuckings", 
   "mothafucks", "mother fucker", "motherfuck", "motherfucked", "motherfucker", 
   "motherfuckers", "motherfuckin", "motherfucking", "motherfuckings", 
   "motherfuckka", "motherfucks", "muff", "mutha", "muthafecker", "muthafuckker", 
   "muther", "mutherfucker", "n1gga", "n1gger", "nazi", "nigg3r", "nigg4h", "nigga", 
   "niggah", "niggas", "niggaz", "nigger", "niggers", "nob", "nob jokey", "nobhead", 
   "nobjocky", "nobjokey", "numbnuts", "nutsack", "orgasim", "orgasims", "orgasm", 
   "orgasms", "p0rn", "pawn", "pecker", "penis", "penisfucker", "phonesex", "phuck", 
   "phuk", "phuked", "phuking", "phukked", "phukking", "phuks", "phuq", "pigfucker", 
   "pimpis", "piss", "pissed", "pisser", "pissers", "pisses", "pissflaps", "pissin", 
   "pissing", "pissoff", "poop", "porn", "porno", "pornography", "pornos", "prick", 
   "pricks", "pron", "pube", "pusse", "pussi", "pussies", "pussy", "pussys", 
   "rectum", "retard", "rimjaw", "rimming", "s hit", "s.o.b.", "sadist", "schlong", 
   "screwing", "scroat", "scrote", "scrotum", "semen", "sex", "sh!+", "sh!t", "sh1t", 
   "shag", "shagger", "shaggin", "shagging", "shemale", "shi+", "shit", "shitdick", 
   "shite", "shited", "shitey", "shitfuck", "shitfull", "shithead", "shiting", 
   "shitings", "shits", "shitted", "shitter", "shitters", "shitting", "shittings", 
   "shitty", "skank", "slut", "sluts", "smegma", "smut", "snatch", "son-of-a-bitch", 
   "spac", "spunk", "s_h_i_t", "t1tt1e5", "t1tties", "teets", "teez", "testical", 
   "testicle", "tit", "titfuck", "tits", "titt", "tittie5", "tittiefucker", "titties",
    "tittyfuck", "tittywank", "titwank", "tosser", "turd", 
   "tw4t", "twat", "twathead", "twatty", "twunt", "twunter", "v14gra", "v1gra", "vagina", "viagra", "vulva", "w00se", "wang", "wank", "wanker", "wanky", "whoar", "whore", "willies", "willy", "xrated", "xxx"]
  }

  public static GetAllMonths(): { name: string, days: number }[] {
    return [
      { name: 'January', days: 31 },
      { name: 'February', days: 28 },
      { name: 'March', days: 31 },
      { name: 'April', days: 30 },
      { name: 'May', days: 31 },
      { name: 'June', days: 30 },
      { name: 'July', days: 31 },
      { name: 'August', days: 31 },
      { name: 'September', days: 30 },
      { name: 'October', days: 31 },
      { name: 'November', days: 30 },
      { name: 'December', days: 31 }
    ];
  }

  public static getStateAbbr(state) {
    const abbr = this.STATES.find(e => typeof state === 'string' && e.name.toLowerCase() === state.trim().toLowerCase());
    return abbr ? abbr.abbr : '';
  }

  public static getStateByAbbr(abbr) {
    const state = this.STATES.find(e => typeof abbr === 'string' && e.abbr === abbr.trim().toUpperCase());
    return (state && state.name) ? state.name : abbr.trim().toUpperCase();
  }

  public static getStateByName(name) {
    return this.STATES.find(e => typeof name === 'string' && e.name.toLowerCase() === name.trim().toLowerCase());
  }

  public static getStateExpedite(state) {
    const province = this.EXPEDITEPERSTATE.find(e => typeof state === 'string' && e.name.toLowerCase() === state.trim().toLowerCase());
    return province ? province.expediteTAT : '';
  }

  public static getState(input) {
    let s;
    if (!input) {
      input = {};
      input.name = '';
    }

    // tslint:disable-next-line: prefer-for-of
    for (let x = 0; x < this.STATES.length; x++) {
      if (this.STATES[x].name.toLowerCase() === input.name.trim().toLowerCase()) {
        s = this.STATES[x];
      }
    }
    return s;
  }

  private static get STATES(): { name: string, abbr: string }[] {
    return [
      { name: 'Alabama', abbr: 'AL' },
      { name: 'Alaska', abbr: 'AK' },
      { name: 'Arizona', abbr: 'AZ' },
      { name: 'Arkansas', abbr: 'AR' },
      { name: 'California', abbr: 'CA' },
      { name: 'Colorado', abbr: 'CO' },
      { name: 'Connecticut', abbr: 'CT' },
      { name: 'Delaware', abbr: 'DE' },
      { name: 'Dist. of Columbia', abbr: 'DC' },
      { name: 'Florida', abbr: 'FL' },
      { name: 'Georgia', abbr: 'GA' },
      { name: 'Hawaii', abbr: 'HI' },
      { name: 'Idaho', abbr: 'ID' },
      { name: 'Illinois', abbr: 'IL' },
      { name: 'Indiana', abbr: 'IN' },
      { name: 'Iowa', abbr: 'IA' },
      { name: 'Kansas', abbr: 'KS' },
      { name: 'Kentucky', abbr: 'KY' },
      { name: 'Louisiana', abbr: 'LA' },
      { name: 'Maine', abbr: 'ME' },
      { name: 'Maryland', abbr: 'MD' },
      { name: 'Massachusetts', abbr: 'MA' },
      { name: 'Michigan', abbr: 'MI' },
      { name: 'Minnesota', abbr: 'MN' },
      { name: 'Mississippi', abbr: 'MS' },
      { name: 'Missouri', abbr: 'MO' },
      { name: 'Montana', abbr: 'MT' },
      { name: 'Nebraska', abbr: 'NE' },
      { name: 'Nevada', abbr: 'NV' },
      { name: 'New Hampshire', abbr: 'NH' },
      { name: 'New Jersey', abbr: 'NJ' },
      { name: 'New Mexico', abbr: 'NM' },
      { name: 'New York', abbr: 'NY' },
      { name: 'North Carolina', abbr: 'NC' },
      { name: 'North Dakota', abbr: 'ND' },
      { name: 'Ohio', abbr: 'OH' },
      { name: 'Oklahoma', abbr: 'OK' },
      { name: 'Oregon', abbr: 'OR' },
      { name: 'Pennsylvania', abbr: 'PA' },
      { name: 'Rhode Island', abbr: 'RI' },
      { name: 'South Carolina', abbr: 'SC' },
      { name: 'South Dakota', abbr: 'SD' },
      { name: 'Tennessee', abbr: 'TN' },
      { name: 'Texas', abbr: 'TX' },
      { name: 'Utah', abbr: 'UT' },
      { name: 'Vermont', abbr: 'VT' },
      { name: 'Virginia', abbr: 'VA' },
      { name: 'Washington', abbr: 'WA' },
      { name: 'West Virginia', abbr: 'WV' },
      { name: 'Wisconsin', abbr: 'WI' },
      { name: 'Wyoming', abbr: 'WY' }];
  }

  private static get EXPEDITEPERSTATE(): { name: string, expediteTAT: string }[] {
    return [
      { name: 'Alabama', expediteTAT: '11-13' },
      { name: 'Alaska', expediteTAT: '8-10' },
      { name: 'Arizona', expediteTAT: '17-19' },
      { name: 'Arkansas', expediteTAT: '7-9' },
      { name: 'California', expediteTAT: '10-12' },
      { name: 'Colorado', expediteTAT: '7-9' },
      { name: 'Connecticut', expediteTAT: '8-10' },
      { name: 'Delaware', expediteTAT: '10-12' },
      { name: 'Dist. of Columbia', expediteTAT: '13-15' },
      { name: 'Florida', expediteTAT: '12-14' },
      { name: 'Georgia', expediteTAT: '9-11' },
      { name: 'Hawaii', expediteTAT: '9-11' },
      { name: 'Idaho', expediteTAT: '13-15' },
      { name: 'Illinois', expediteTAT: '7-9' },
      { name: 'Indiana', expediteTAT: '12-14' },
      { name: 'Iowa', expediteTAT: '9-11' },
      { name: 'Kansas', expediteTAT: '9-11' },
      { name: 'Kentucky', expediteTAT: '8-10' },
      { name: 'Louisiana', expediteTAT: '11-13' },
      { name: 'Maine', expediteTAT: '14-16' },
      { name: 'Maryland', expediteTAT: '12-14' },
      { name: 'Massachusetts', expediteTAT: '12-14' },
      { name: 'Michigan', expediteTAT: '7-9' },
      { name: 'Minnesota', expediteTAT: '8-10' },
      { name: 'Mississippi', expediteTAT: '6-8' },
      { name: 'Missouri', expediteTAT: '9-11' },
      { name: 'Montana', expediteTAT: '7-9' },
      { name: 'Nebraska', expediteTAT: '9-11' },
      { name: 'Nevada', expediteTAT: '7-9' },
      { name: 'New Hampshire', expediteTAT: '13-15' },
      { name: 'New Jersey', expediteTAT: '8-10' },
      { name: 'New Mexico', expediteTAT: '15-17' },
      { name: 'New York', expediteTAT: '7-9' },
      { name: 'North Carolina', expediteTAT: '7-9' },
      { name: 'North Dakota', expediteTAT: '17-19' },
      { name: 'Ohio', expediteTAT: '11-13' },
      { name: 'Oklahoma', expediteTAT: '8-10' },
      { name: 'Oregon', expediteTAT: '7-9' },
      { name: 'Pennsylvania', expediteTAT: '11-13' },
      { name: 'Rhode Island', expediteTAT: '14-16' },
      { name: 'South Carolina', expediteTAT: '7-9' },
      { name: 'South Dakota', expediteTAT: '7-9' },
      { name: 'Tennessee', expediteTAT: '12-14' },
      { name: 'Texas', expediteTAT: '8-10' },
      { name: 'Utah', expediteTAT: '9-11' },
      { name: 'Vermont', expediteTAT: '13-15' },
      { name: 'Virginia', expediteTAT: '8-10' },
      { name: 'Washington', expediteTAT: '13-15' },
      { name: 'West Virginia', expediteTAT: '8-10' },
      { name: 'Wisconsin', expediteTAT: '7-9' },
      { name: 'Wyoming', expediteTAT: '9-11' }];
  }
  public static get STATES_INCLUDED_IN_STID_SP(): string[] {
    return ['Arizona', 'California', 'Colorado', 'Florida', 'Illinois', 'Minnesota', 'New Jersey', 'Ohio'
    , 'Pennsylvania', 'South Carolina', 'Texas', 'Virginia', 'Washington', 'Wisconsin'];
  }

  public static get BUSINESS_NAME_DESIGNATORS(): string[] {
    return [
      'LLC',
      'L.L.C.',
      'Limited Liability Company'
    ];
  }
  public static get RESTRICTED_BUSINESS_NAME_DESIGNATORS(): string[] {
    return [
      'LLC',
      'L.L.C.',
      'Limited Liability Company',
      'LimitedLiabilityCompany',
      'INC.',
      'CorPoration',
      'Incorporated'
    ];
  }
  public static get RESTRICTED_DESIGNATORS_MESSAGE(): string[] {
    return [
      'INC.',
      'CorPoration',
      'Incorporated'
    ];
  }
}

export enum SEAD {
  RA_LZ = 'RA_LZ',
  RA_NOT_LZ = 'RA_NOT_LZ',
  BAP_YES = 'BAP_YES',
  BAP_NO = 'BAP_NO',
  BLP_OA = 'BLP_OA',
  BLP_OA_EIN = 'BLP_OA_EIN',
  BLP_OA_EIN_LIC = 'BLP_OA_EIN_LIC',
  BLP_NO = 'BLP_NO',
  BOFA_YES = 'BOFA_YES',
  BOFA_NO = 'BOFA_NO',
  COMPLIANCE_YES = 'COMPLIANCE_YES',
  COMPLIANCE_NO = 'COMPLIANCE_NO',
  FNAME = 'FNAME',
  LNAME = 'LNAME',
  PHONE_NUMBER = 'PHONE_NUMBER',
  PACKAGE_NAME = 'PACKAGE_NAME',
  ORDER_TOTAL = 'ORDER_TOTAL'
}

export enum ProcessId {
  LLC = 2,
  LastWillAndTestament = 6,
  TrademarkSearch = 13,
  Gsuite = 161,
  LZTax = 167
}

export enum QuestionnaireId {
  LastWillAndTestament = 49,
  TrademarkSearch = 77,
  Gsuite = 680,
  LZTax = 687
}

export enum StatusType {
  Unsuccess = 0,
  Success = 1
}

export enum TEALIUM_TAGS {
  AttributionJS_DEV = 705,
  AttributionJS_QA = 765,
  AttributionJS_PROD = 720,
  GA_PROD = 533,
  GA_QA = 450,
  AudienceStream = 396,
  Amplitude_PROD = 946,
  HEAP_POC = 947,
  Kenshoo_AllNonZeroDollarConversion = 757,
  BingAds_OrderConfirmEvent = 502,
  Facebook_Start_Events = 758,
  Facebook_Order_Complete_Events = 773,
  Facebook_Order_Complete_Events_2 = 678,
  Conversion_trackTransaction = 812,
  Confirm_Image_Pixels = 411,
  PepperJam_TealiumPixel = 798,
  Zeta_Conversion_Tracking = 905,
  Zeta_Page_Tracking = 906,
  LLC_Inc_Checkout_Tracking = 912,
  Adwords_Conversion_Retargeting = 827,
  Proactive_Chat = 786,
  Criteo_View_Cart = 814,
}

export enum CookieName {
  LLC_Formation_State = 'llc_formation_state'
}

export enum PartnerOfferTagNames {
  LLC_Partner_Offer_BofA = 'LLC_Partner_Offer_BofA',
  LLC_Partner_Offer_Brex = 'LLC_Partner_Offer_Brex',
  LLC_Partner_Offer_Square = 'LLC_Partner_Offer_Square',
  LLC_Partner_Offer_Toast = 'LLC_Partner_Offer_Toast'
}  

export enum TaxOfferTagNames {
  Tax_Price_Test_VAR_A = 'Tax_Price_Test_VAR_A_99/159',
  Tax_Price_Test_Var_B = 'Tax_Price_Test_Var_B_99/169',
  Tax_Price_Test_Ctrl = 'Tax_Price_Test_Ctrl_79/139',
}
