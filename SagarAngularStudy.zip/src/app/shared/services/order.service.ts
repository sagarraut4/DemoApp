import { Injectable } from '@angular/core';
import {
  IQueueEntry,
  TrackJsErrorLogService
} from '@legalzoom/business-formation-sdk';
import { HttpErrorResponse } from '@angular/common/http';
import { of } from 'rxjs';
import { ProductName } from '../constants/product-domain';
import { OrderService as SdkOrderService } from '@legalzoom/order-sdk';
import { CrossSellOrder } from '../models/crossSell-order-model';
@Injectable({
  providedIn: 'root'
})
export class OrderService {

  constructor(private sdkOrderService: SdkOrderService, private trackJsErrorLogService: TrackJsErrorLogService) { }
  prepareGetOrderById(context: any, appService: any, orderId: number, customerId: number, authToken: string, productName: ProductName): IQueueEntry {
    const that = this;
    return {
      name: 'prepareGetOrderById order.service' + context.constructor.name,
      pre: () => {
        return that.sdkOrderService.getOrdersById(orderId);
      },
      post: (response) => {
        const appState = appService.app;
        if (!!response) {
          appState.orderId = response.order.orderId;
          context.order = response.order;
        } else {
          appState.orderId = 0;
        }
        appService.app = appState;
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJsErrorLogService.track(productName, 'order.service' + context.constructor.name, error);
        return of(null);
      }
    };

  }
  prepareGetCrossSellOrderById(context: any, appService: any, orderId: number, customerId: number, productName: ProductName): IQueueEntry {
    const that = this;
    return {
      name: 'prepareGetCrossSellOrderById order.service' + context.constructor.name,
      pre: () => {
        return that.sdkOrderService.getCrossSellOrdersById(orderId);
      },
      post: (response) => {
        const appState = appService.app;
        if (!!response) {
          appState.crossSellOrderResponse = new CrossSellOrder();
          appState.crossSellOrderResponse.orderId = response.orderId;
          appState.crossSellOrderResponse.orderItemId = response.orderItems[0].orderItemId;
          appState.crossSellOrderResponse.processingOrderId = response.orderItems[0].processingOrder.processingOrderId;
          appState.crossSellOrderResponse.productName = response.orderItems[0].productName;
          appState.crossSellOrderResponse.productConfigurationId = response.orderItems[0].productConfiguration.productConfigurationId;
          appState.crossSellOrderResponse.amount = null;
          appState.crossSellOrderResponse.shippingOrderContactId = null;
          appState.crossSellOrderResponse.billingOrderContactId = null;
          appState.crossSellOrderResponse.primaryOrderContactId = null;
          appState.crossSellOrderResponse.paymentResponseStatus = null;
        }
        appService.app = appState;
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJsErrorLogService.track(productName, 'order.service' + context.constructor.name, error);
        return of(null);
      }
    };
  }
  prepareGetOrderContactOrderById(context: any, appService: any, orderId: number, customerId: number): IQueueEntry {
    const that = this;
    return {
      name: 'prepareGetOrderContactOrderById order.service' + context.constructor.name,
      pre: () => {
        return that.sdkOrderService.getOrderContact(orderId);
      },
      post: (response) => {
        const crossSellOrder = appService.app.crossSellOrderResponse;
        const appState = appService.app;
        if (!!response && response.contacts) {
          appState.crossSellOrderResponse = new CrossSellOrder();
          appState.crossSellOrderResponse.orderId = crossSellOrder.orderId;
          appState.crossSellOrderResponse.orderItemId = crossSellOrder.orderItemId;
          appState.crossSellOrderResponse.processingOrderId = crossSellOrder.processingOrderId;
          appState.crossSellOrderResponse.productName = crossSellOrder.productName;
          appState.crossSellOrderResponse.productConfigurationId = crossSellOrder.productConfigurationId;
          appState.crossSellOrderResponse.shippingOrderContactId = response.contacts.find(element => element.contactType = "Shipping").orderContactId;
          appState.crossSellOrderResponse.billingOrderContactId = response.contacts.find(element => element.contactType = "Billing").orderContactId;
          appState.crossSellOrderResponse.primaryOrderContactId = response.contacts.find(element => element.contactType = "Primary").orderContactId;
          appState.crossSellOrderResponse.amount = null;
          appState.crossSellOrderResponse.paymentResponseStatus = null;
        }
        appService.app = appState;
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJsErrorLogService.track('LLC', 'order.service' + context.constructor.name, error);
        return of(null);
      }
    };
  }
}
