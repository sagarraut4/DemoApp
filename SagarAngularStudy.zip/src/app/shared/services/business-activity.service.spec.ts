import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { BusinessActivityService } from './business-activity.service';
import { EnvironmentService } from './environment.service';
import { QuestionnaireService } from './questionnaire/questionnaire.service';

describe('BusinessActivityService', () => {
  let service: BusinessActivityService;
  const mockEnvironmentService = jasmine.createSpyObj(['getBusinessActivitiesUrl', 'getBusinessActivityUrl']);
  const mockQuestionnaireService = {
    llc: { businessPurposeObject: { uuid: 'test' } }
  };
  let httpMock: HttpTestingController;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [BusinessActivityService,
        { provide: EnvironmentService, useValue: mockEnvironmentService },
        { provide: QuestionnaireService, useValue: mockQuestionnaireService }
      ]
    });
    service = TestBed.get(BusinessActivityService);
    httpMock = TestBed.get(HttpTestingController);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
    expect(service.bizActivities.length).toBe(0);
  });
  it('should call http get method with test url', () => {
    mockEnvironmentService.getBusinessActivityUrl.and.returnValues('http://.../test?uuid={0}');
    service.getBizActivity().subscribe(data => {
      expect(data.BusinessActivities).toBe('');
    });

    const req = httpMock.expectOne('http://.../test?uuid=test');
    expect(req.request.method).toEqual('GET');

    req.flush({ BusinessActivities: ''});
    httpMock.verify();
  });
  it('should setBizActivities', () => {
    mockEnvironmentService.getBusinessActivitiesUrl.and.returnValues('http://.../test');
    service.setBizActivities();
    const req = httpMock.expectOne('http://.../test');
    expect(req.request.method).toEqual('GET');
    req.flush([{ BusinessActivities: ''}]);
    httpMock.verify();
    expect(service.bizActivities.length).toBeGreaterThan(0);
  });
});
