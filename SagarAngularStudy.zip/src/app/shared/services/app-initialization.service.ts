import { UserCartService } from '../../../app/pl-features/glo-design/shared/services/user-cart.service';
import { QuestionnaireService as LLCQuestionnaireService } from './questionnaire/questionnaire.service';
import { Injectable } from '@angular/core';
import { AppService, createAppState } from '../state/app';
import { CookieService } from 'ngx-cookie';
import { QueueService, IQueueEntry, TrackJsErrorLogService } from '@legalzoom/business-formation-sdk';
import { Observable, of, throwError } from 'rxjs';
import { NavigationExtras, Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { AuthService } from './auth.service';
import { UtilityService } from './utility.service';
import { TrackSEMDataService } from '../services/tracking/track-sem-data.service';
import { Chapter, PagePath } from '../models/page-model';
import { LLC } from '../models/questionnaire-model';
import { ProductName, CookieName } from '../constants/product-domain';
import { OrderService } from './order.service';
import { ProcessingOrderService } from './processing-order.service';
import { QuestionnaireAnswerService } from './questionnaire-answer.service';
import { ExperimentsService } from './experiments/experiments.service';
import { FeatureFlagService, FEATURE_FLAG_Q2_SHOW_IN_IQ_FLOW } from './feature-flag/feature-flag.service';
import { ErrorEventService } from '@legalzoom/site-sdk-sso';
import { CustomerService } from '@legalzoom/customer-sdk';
import { QuestionnaireStorageMappingService } from './questionnaire-storage/questionnaire-storage-mapping.service';
import { PrepareCartService } from './prepare-cart.service';
import { WindowRef } from './windowRef.service';
import { CrossSellService } from './cross-sell.service';
import { TrackingService } from '../../shared/services/tracking/tracking.service';
import { IOrder } from '@legalzoom/order-sdk';
import { CartResponse, Cart } from '@legalzoom/cart-sdk';
import { GuestConvertedService } from './guest-converted.service';

@Injectable({
  providedIn: 'root'
})
export class AppInitializationService {
  private currentRoutePath: string;
  private isReloaded = false;
  private isCustomerChanged = false; // to check if customer get changed from previous login/order
  private cart: Cart;
  private order: IOrder;

  constructor(
    private appService: AppService,
    private cookieService: CookieService,
    private authService: AuthService,
    private processingOrderService: ProcessingOrderService,
    private userCartService: UserCartService,
    private orderService: OrderService,
    private router: Router,
    private llcQuestionnaireService: LLCQuestionnaireService,
    private questionnaireAnswerService: QuestionnaireAnswerService,
    private queueService: QueueService,
    private utilityService: UtilityService,
    private trackSemDataService: TrackSEMDataService,
    private trackjsErrorLogService: TrackJsErrorLogService,
    private featureFlagService: FeatureFlagService,
    private experimentsService: ExperimentsService,
    private errorEventService: ErrorEventService,
    private customerService: CustomerService,
    private questionnaireStorageMappingService: QuestionnaireStorageMappingService,
    private prepareCartService: PrepareCartService,
    private windowRef: WindowRef,
    private crossSellService: CrossSellService,
    private trackingService: TrackingService,
    private guestConvertedService: GuestConvertedService,
  ) { }

  initializeApp(currentRoutePath: string): Observable<boolean> {
    this.subscribeTo401ErrorEvents();
    this.subscribeToErrorEvents();

    this.currentRoutePath = `.${currentRoutePath}`;

    // session info
    const activeSession = this.cookieService.get(CookieName.ACTIVESESSION) ?
      this.cookieService.get(CookieName.ACTIVESESSION).toLowerCase() === 'true' : false;

    const authToken = this.utilityService.getAuthTokenConsultationCookie();
    const customerId = this.utilityService.getCustomerIdConsultationCookie();

    if (this.isReloaded) {
      return of(true);
    }

    this.isReloaded = true;

    let tempProcessingOrderId = this.utilityService.getIntParamFromQueryString('uo');
    let tempCartId = this.utilityService.getIntParamFromQueryString('cartId');
    const IQCheckoutComplete = this.utilityService.getStringParamFromQueryString('iqCheckoutComplete');
    const answers = this.utilityService.getStringParamFromQueryString('answers');
    const hasAnswersPassedIn = answers && answers.length > 0;

    if (hasAnswersPassedIn && this.appService.customerId && this.appService.customerId !== customerId) {
      this.isCustomerChanged = true;
    }

    if (this.appService.customerId !== customerId) {
      this.utilityService.clearAppState(false);
    }

    if (tempProcessingOrderId && this.appService.processingOrderId != tempProcessingOrderId) {
      this.utilityService.clearAppState(false);
    }

    // in Query string uo=0 come only when user is logout and and click on LLC button on affinity banner
    if (this.utilityService.getParamValueQueryString('uo') == '0') {
      this.windowRef.nativeWindow.location.href = PagePath.MyAccount;
      return of(false);
    }

    this.appService.accessToken = authToken;
    this.appService.customerId = customerId;

    tempProcessingOrderId = this.utilityService.getIntParamFromQueryString('uo') || this.appService.processingOrderId;
    tempCartId = this.utilityService.getIntParamFromQueryString('cartId') || this.appService.cartId;
    const tempOrderId = this.utilityService.getIntParamFromQueryString('orderId') || this.appService.orderId;
    const siblingOrder = this.utilityService.getIntParamFromQueryString('siblingOrders');
    const kenshooID = this.utilityService.getStringParamFromQueryString('kid');
    if (kenshooID) {
      this.trackSemDataService.setSEMCookies();
    }

    if (!activeSession) {
      console.log('App Initialization - no active session found');

      this.utilityService.clearAppState(true);
      this.windowRef.nativeWindow.sessionStorage.removeItem('sessionStore');
      const pathSuffix = this.extractIQPath();
      this.windowRef.nativeWindow.location.href = `${PagePath.IQFlow}${pathSuffix}`;
    }

    this.queueService.add(this.authService.prepareGetCustomerAndSession(authToken, customerId));

    const queueEntries: IQueueEntry[] = [];
    if (tempCartId && !this.isCustomerChanged) {
      queueEntries.push(this.userCartService.prepareGetCartById(this, this.appService, tempCartId, customerId, ProductName.LLC));
    } else {
      this.queueService.add(this.userCartService.prepareCreateNewCart());
    }

    if (tempProcessingOrderId) {
      if (!this.isCustomerChanged) {
        queueEntries.push(this.processingOrderService.prepareGetProcessingOrderById(this, this.appService, tempProcessingOrderId, authToken, customerId, ProductName.LLC));
      }
      if (hasAnswersPassedIn) {
        const isMobile = this.llcQuestionnaireService.llc.isMobile;
        this.llcQuestionnaireService.llc = new LLC();
        this.questionnaireStorageMappingService.setLLCObject(JSON.parse(answers));
        this.llcQuestionnaireService.llc.isMobile = isMobile;
        this.llcQuestionnaireService.llc.bFunnelTest = this.experimentsService.GetBFunnelTestValue();
        this.llcQuestionnaireService.llc.bShowPriceTest1 = this.experimentsService.GetTsaTestValue();
        this.llcQuestionnaireService.llc.currentView = Chapter.Checkout + '/' + PagePath.ReviewYourOrder;
        queueEntries.push(this.llcQuestionnaireService.prepareUpdateQuestionnaireStorage(this.llcQuestionnaireService.llc,
          this.isCustomerChanged ? this.appService.app.processingOrderId : tempProcessingOrderId));
      }
      else {
        queueEntries.push(
          this.llcQuestionnaireService.prepareGetQuestionnaireStorage(this, customerId, tempProcessingOrderId, authToken, ProductName.LLC, (data) => {
            this.setllcInSession(data);
          })
        );
      }
      queueEntries.push(this.questionnaireAnswerService.prepareGetUserAnswers(this, customerId, tempProcessingOrderId, ProductName.LLC, this.isCustomerChanged));

    }

    if (tempOrderId) {
      queueEntries.push(this.orderService.prepareGetOrderById(this, this.appService, tempOrderId, customerId, authToken, ProductName.LLC));
    }

    if (queueEntries && queueEntries.length > 0) {
      this.queueService.add(queueEntries);
    }

    this.queueService.add(
      this.questionnaireAnswerService.prepareDeleteQuestionnaireAnswers(this, customerId, ProductName.LLC, (data) => {
        if (!hasAnswersPassedIn) {
          this.successDeleteQuestionnaireAnswers(data);
        }
      })
    );

    if (hasAnswersPassedIn) {
      this.queueService.add(this.prepareCartService.prepareSaveAndGetMappedUserAnswers());
      this.queueService.add(this.prepareCartService.prepareChangePackage(this.llcQuestionnaireService.llc.packageSelected));
      this.queueService.add(this.prepareRedirectToRYO());
    }

    if (IQCheckoutComplete) {
      this.queueService.add(this.crossSellService.prepareGetPaymentProfileByCustomerId(customerId));
      this.queueService.add(this.prepareCartService.prepareGetCartBalanceByCartId());
      this.queueService.add(this.addIQOrderTracking());
      this.queueService.add(this.crossSellService.prepareGetPaymentByOrderId(this.appService, tempOrderId, customerId));
      this.llcQuestionnaireService.llc.orderId = tempOrderId;
    }

    if (siblingOrder) {
      this.queueService.add(this.orderService.prepareGetCrossSellOrderById(this, this.appService, siblingOrder, customerId, ProductName.LLC));
      this.queueService.add(this.orderService.prepareGetOrderContactOrderById(this, this.appService, siblingOrder, customerId));
      this.queueService.add(this.crossSellService.prepareGetPaymentByOrderId(this.appService, siblingOrder, customerId, true));
    }

    this.queueService.add(this.crossSellService.prepareGetCustomerContactByCustomerId(this.appService, customerId));
    this.queueService.add(this.prepareNavigateToCustomerStartPoint(this));

    return this.queueService.process();
  }

  private prepareRedirectToRYO(): IQueueEntry {
    const that = this;
    return {
      name: 'prepareRedirectToRYO ' + this.constructor.name,
      pre: () => {
        return of(true);
      },
      post: () => {
        const { cartId, processingOrderId } = that.appService;
        that.router.navigate(
          [`./${Chapter.Checkout}/${PagePath.ReviewYourOrder}`],
          {
            queryParams: { cartId, uo: processingOrderId },
            replaceUrl: true
          });
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        that.trackjsErrorLogService.track(ProductName.LLC, 'app-initialization.service', error);
        return of(null);
      }
    };
  }

  private addIQOrderTracking(): IQueueEntry {
    const context = this;
    return {
      name: 'app-initialization.service attachIQOrders',
      pre: () => {
        return of(true);
      },
      post: () => {
        if (!context.cart || !context.cart.cartItems) throwError('Empty cart not added to tracking');
        //hackiness to match the structure required by the get cart model method
        const cartResponse: CartResponse = { cart: context.cart };
        const cartModel = context.userCartService.getCartModelFromApiData(cartResponse, context.appService.getCartBalanceByCartIdResponse);
        context.trackingService.ClearOAItems();
        context.trackingService.MapToOAItems(cartModel);
        if (context.order && context.order.orderId) context.trackingService.setUserOrderID(context.order.orderId);
        return of(true);
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        context.trackjsErrorLogService.track(ProductName.LLC, 'app-initialization.service', error);
        return of(null);
      }
    };
  }

  private navigateToCustomerStartPoint(context, url, extras?: NavigationExtras): Observable<boolean> {
    let returnValue = true;
    if (url) {
      this.navigateToURL(url, extras);
    } else if (this.llcQuestionnaireService.llc.currentView === `${Chapter.Checkout}/${PagePath.ReviewYourOrder}`
      || this.llcQuestionnaireService.llc.currentView === `${Chapter.Checkout}/${PagePath.Checkout}`) {

      const navigationURL = './' + Chapter.Checkout + '/' + PagePath.ReviewYourOrder;
      this.navigateToURL(navigationURL);
    }
    else {
      if (window.location.href.indexOf('localhost') < 0 && window.location.href.indexOf('wwwlocal') < 0) {
        if (this.appService.app.cartId && this.appService.app.processingOrderId) {
          this.setSessionStore();
          const pathSuffix = this.extractIQPath();
          window.location.href = `${PagePath.IQFlow}${pathSuffix}`;
          returnValue = false;
        }
        else {
          window.location.href = PagePath.LLCLandingPage;
          returnValue = true;
        }
      } else {
        this.setSessionStore();
        const pathSuffix = this.extractIQPath();
        window.location.href = `${PagePath.IQFlow}${pathSuffix}`;
      }
    }
    return of(returnValue);
  }

  private setSessionStore() {
    this.windowRef.nativeWindow.sessionStorage.setItem('sessionStore', JSON.stringify({
      processingOrderId: this.appService.app.processingOrderId,
      cartId: this.appService.app.cartId,
    }));
  }

  private extractIQPath() {
    if (this.cart && this.cart.cartItems && this.cart.cartItems.length) {
      const cartItem = this.cart.cartItems.find((item) => item.productTypeId === 2);
      const packageID = cartItem && cartItem.productConfigurationId ? cartItem.productConfigurationId : 0;
      const paths = {
        7820: '/name?packageId=7820',
        7846: '/name?packageId=7846',
        7847: '/name?packageId=7847',
        7848: '/attorney-assist-interstitial?packageId=7848',
      };

      if(this.experimentsService.isFreePre()){
        const isFreePaths = {
          7820: '/name?packageId=7820',
          7846: '/name?packageId=7846',
          7847: '/name?packageId=7847',
          7848: '/attorney-assist-interstitial?packageId=7848',
        };
        return isFreePaths[packageID]
      }
      
      if (this.experimentsService.isLeadWithFree()) {
        return '/state?packageId=7820';
      }
      return paths[packageID] || '/name';
    }
    return '/name';
  }

  private navigateToURL(url: string, extras?: NavigationExtras) {
    const currentUrl = this.currentRoutePath.indexOf('?') > 0 ? this.currentRoutePath.substring(0, this.currentRoutePath.indexOf('?')) : this.currentRoutePath;

    if (currentUrl !== url) {
      this.router.navigate([url], extras);
    }
  }

  private setllcInSession(data: any) {
    const jsonObj: any = JSON.parse(data.answers);
    const llcObj: LLC = jsonObj as LLC;
    this.llcQuestionnaireService.setLLC(llcObj);
    this.featureFlagService.reinitializeFlagsIfUserChanged();
  }

  successDeleteQuestionnaireAnswers(response) {
    if (response) {
      this.llcQuestionnaireService.llc = new LLC();
    }
  }

  private prepareNavigateToCustomerStartPoint(context: any): IQueueEntry {
    const that = this;
    return {
      name: 'app-initialization.service prepareValidateSession',
      pre: () => {
        return of(true);
      },
      post: (response) => {
        const readOnlyAppState = this.appService.app;

        if (readOnlyAppState && readOnlyAppState.processingOrderId && readOnlyAppState.orderId) {
          if (!readOnlyAppState.isQuestionnaireComplete) {
            // allow the user to continue with the express offers cross-sell if they arrived from IQ Flow Checkout
            const IQCheckoutComplete = this.utilityService.getStringParamFromQueryString('iqCheckoutComplete');
            if (IQCheckoutComplete) {
              //fix to show correct IsGuestConvertedOnCheckout from IQ Flow Checkout
              this.guestConvertedService.updateIsGuestConvertedOnCheckout();
            }

            if (!IQCheckoutComplete) {
              // Check feature flag to see if User should complete Q2 in IQFlow or Remaining Questions
              const url = `${PagePath.IQFlow}/q2intro?orderId=${readOnlyAppState.orderId}&cartId=${readOnlyAppState.cartId}&graphType=q2`
              if (this.cookieService.get('show_q2_llc_in_iq_flow') === 'true') {
                this.queueService.add(this.gotoOutsideOfLLC(url))
              }
              else if (this.featureFlagService.showQ2InIqFlow) {
                this.queueService.add(this.gotoOutsideOfLLC(url))
              } else {
                return context.navigateToCustomerStartPoint(context, `./${Chapter.PostOrder}/${PagePath.RemainingQuestions}`)
              }
            } else {
              return true;
            }
          } else {
            this.queueService.add(this.gotoOutsideOfLLC(PagePath.MyAccount));
          }
        } else if (readOnlyAppState && readOnlyAppState.cartId && readOnlyAppState.processingOrderId) {
          let getUrl = `./${this.llcQuestionnaireService.llc.currentView}`;
          const isLoginCallback = this.utilityService.getParamValueQueryString('isLoginCallback') === 'true' || false;

          if (!isLoginCallback && this.llcQuestionnaireService.llc.currentView === `${Chapter.Checkout}/${PagePath.Checkout}`) {
            getUrl = `./${Chapter.Checkout}/${PagePath.ReviewYourOrder}`;
          }

          if (this.llcQuestionnaireService.llc.currentView === `${Chapter.Checkout}/${PagePath.ReviewYourOrder}`
            || this.llcQuestionnaireService.llc.currentView === `${Chapter.Checkout}/${PagePath.Checkout}`) {
            const pathSuffix = this.extractIQPath();
            //if a path suffix exists, we can safely assume that it is free/pre
            if (pathSuffix !== '/name') {
              const url = PagePath.IQFlowCheckout + readOnlyAppState.cartId;
              this.queueService.add(this.gotoOutsideOfLLC(url));
            }
            return context.navigateToCustomerStartPoint(context, getUrl, {
              replaceUrl: true
            });
          }
          else {
            this.setSessionStore();
            const pathSuffix = this.extractIQPath();
            this.queueService.add(this.gotoOutsideOfLLC(`${PagePath.IQFlow}${pathSuffix}`));
          }
        } else {
          this.queueService.add(this.gotoOutsideOfLLC(PagePath.MyAccount));
        }
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackjsErrorLogService.track(ProductName.LLC, 'app-initialization.service', error);
        return of(null);
      }
    };
  }

  private subscribeTo401ErrorEvents(): void {
    this.errorEventService.onUnauthorizedSession.subscribe((error: HttpErrorResponse) => {
      this.trackjsErrorLogService.track('LLC', `API-401 Unauthorized Error: ${error.url}`, error);

      this.errorEventService.onUnauthorizedSession.unsubscribe();

      const redirectUrl = this.get401RedirectUrl();
      this.utilityService.clearAppState(true);
      window.location.href = redirectUrl;
    });
  }

  private subscribeToErrorEvents(): void {
    this.errorEventService.onError.subscribe((error) => {
      this.trackjsErrorLogService.track('LLC', `API-${error.status} Error: ${error.url}`, error);
    });
  }

  private get401RedirectUrl() {
    if (this.customerService.isGuestCustomer(this.appService.loginEmail) && !this.router.url.startsWith('/' + Chapter.PostOrder + '/')) {
      return PagePath.LLCLandingPage;
    }
    return PagePath.MyAccount;
  }

  private gotoOutsideOfLLC(pagepath: any): IQueueEntry {
    return {
      name: 'app-initialization.service gotoOutsideOfLLC',
      pre: () => {
        return of(false);
      },
      post: (response) => {
        setTimeout(() => {
          window.location.href = pagepath;
        }, 100);

      },
      error: (error: HttpErrorResponse) => {
        return of(false);
      }
    };
  }
}
