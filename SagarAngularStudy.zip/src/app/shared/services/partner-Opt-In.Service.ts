import { Injectable } from '@angular/core';
import { HttpClient,HttpErrorResponse,HttpHeaders } from '@angular/common/http';
import { IQueueEntry, TrackJsErrorLogService } from '@legalzoom/business-formation-sdk';
import { of } from 'rxjs';
import { EnvironmentService } from './environment.service';
import { ProductName } from '../constants/product-domain';
import { AppService } from '../state/app';
import {PartnerOptInRequest} from '../models/partner-opt-in-model'
@Injectable({
  providedIn: 'root'
})
export class PartnerOptInService {
  constructor(
    private http: HttpClient, 
    private appService: AppService,
    private environmentService: EnvironmentService,
    private trackJS:TrackJsErrorLogService
    ) {} 

    private optionsWithSessionCookie = {
      headers: new HttpHeaders()
        .set('x-lz-api-key', this.environmentService.getLzApiKey()),
      withCredentials : true
  }
    
  public createPartnerOptIn(partnerOptInRequest:PartnerOptInRequest): IQueueEntry {
    return {
      name: 'partnerOptIn ' + this.constructor.name,
      pre: () => {
        return this.http.post<any>(this.environmentService.getPartnerOptInUrl(), partnerOptInRequest,this.optionsWithSessionCookie)
      },
      post: (response) => { },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'partner-offer.component', error);
        return of(null);
      }
    }; 
  }
}
