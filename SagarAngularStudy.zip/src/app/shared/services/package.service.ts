import { ProductConfigurationIds } from './../models/cart-model';
import { AppService } from './../state/app/app.service';
import { QuestionnaireMappingService } from './../services/questionnaire/questionnaire-mapping.service';
import { Injectable } from '@angular/core';
import { of, Observable } from 'rxjs';
import { IProductFilingResponse, IPackageConfigurations, IPackageConfiguration, IUserAnswerRequest, QuestionnaireAnswerService, IProductFilingRequest } from '@legalzoom/questionnaire-answer-sdk';
import { QuestionnaireService } from './questionnaire/questionnaire.service';
import { ConstantsService } from './constants.service';
import { mergeMap } from 'rxjs/operators';
import { ProductService } from '@legalzoom/product-sdk';

@Injectable({
  providedIn: 'root'
})
export class PackageService {
  public packageConfigurations: IPackageConfigurations;
  constructor(
    private questionnaireMappingService: QuestionnaireMappingService,
    private questionnaireService: QuestionnaireService,
    private appService: AppService,
    private productService: ProductService,
    private questionAnswerService: QuestionnaireAnswerService
  ) { }


  public getPackages(): Observable<IPackageConfigurations> {
    if (!this.packageConfigurations) {
      return this.loadPackages();
    } else {
      return of(this.packageConfigurations);
    }
  }

  public loadPackages(): Observable<IPackageConfigurations> {
    const mappedUserAnswer = this.questionnaireMappingService.doMapping(this.questionnaireService.llc, this.appService.processingOrderId);
    const userAnswerRequest: IUserAnswerRequest = {
      questionnaireFieldGroupAnswers: {
        userOrderId: mappedUserAnswer.userOrderId,
        questionnaireId: this.appService.questionnaireId,
        fieldAnswers: mappedUserAnswer.fieldAnswers,
        groupAnswers: []
      }
    };
    const customerStateAbbr = ConstantsService.getStateByName(this.questionnaireService.llc.entityState).abbr;
    return this.questionAnswerService.saveAndGetMappedUserAnswers(
      userAnswerRequest,
      this.appService.app.questionnaireId).pipe(mergeMap((saveUserAnswerResponse) => {
        const productFilingRequest: IProductFilingRequest = {
          fieldAnswers: saveUserAnswerResponse.questionnaireFieldGroupAnswers.fieldAnswers,
          groupAnswers: saveUserAnswerResponse.questionnaireFieldGroupAnswers.groupAnswers,
          state: customerStateAbbr,
        };
        return this.productService.getAvailablePackagesWithFilingFees(
          this.appService.app.processId,
          productFilingRequest).pipe(mergeMap(productFilingResponse => {
            return this.mapPackageConfigurations(productFilingResponse);
          }));
      }));
  }
  public mapPackageConfigurations(productFilingFees: IProductFilingResponse): Observable<IPackageConfigurations> {
    const packageConfigurations: IPackageConfigurations = {
      packageConfiguration: []
    };

    for (const productFilingFee of productFilingFees.packages) {
      const packageConfiguration: IPackageConfiguration = {
        name: productFilingFee.productName,
        parentProductId: null,
        productComponentId: null,
        productConfigurationId: productFilingFee.productConfigurationId,
        displayNameOnBill: productFilingFee.billingDisplayName,
        displayNameOnWeb: productFilingFee.purchaseLockDisplayName,
        packageProductConfigurationId: null,
        productTypeId: '',
        shouldDisplayOnBill: false,
        productComponent: null,
        isDefaultPackage: false,
        childProducts: null,
        extendedPrice: productFilingFee.adjustedPrice,

        filingfees: {
          productBasePriceId: productFilingFee.filingFee ? productFilingFee.filingFee.productBasePriceId : null,
          productPricePointId: productFilingFee.filingFee ? productFilingFee.filingFee.productPricePointId : null,
          productPriceAdjustmentId: productFilingFee.filingFee ? productFilingFee.filingFee.productPriceAdjustmentId : null,
          basePrice: productFilingFee.filingFee ? productFilingFee.filingFee.basePrice : null,
          lawyerAmount: productFilingFee.filingFee ? productFilingFee.filingFee.lawyerAmount : null,
          adjustedPrice: productFilingFee.filingFee ? productFilingFee.filingFee.adjustedPrice : null,
          stateId: productFilingFee.filingFee ? productFilingFee.filingFee.stateId : null,
          countyId: productFilingFee.filingFee ? productFilingFee.filingFee.countyId : null,
          productName: productFilingFee.filingFee ? productFilingFee.filingFee.productName : null,
          billingDisplayName: productFilingFee.filingFee ? productFilingFee.filingFee.billingDisplayName : null,
          purchaseLockDisplayName: productFilingFee.filingFee ? productFilingFee.filingFee.purchaseLockDisplayName : null
        }
      };
      packageConfigurations.packageConfiguration.push(packageConfiguration);
    }
    return of(packageConfigurations);
  }
  public createNewPackageConfiguration(): IPackageConfiguration {
    return {
      name: '',
      parentProductId: 0,
      productComponentId: 0,
      productConfigurationId: 0,
      displayNameOnBill: '',
      displayNameOnWeb: '',
      packageProductConfigurationId: '',
      extendedPrice: 0,
      filingfees: null,
      productTypeId: '',
      shouldDisplayOnBill: false,
      productComponent: null,
      isDefaultPackage: false,
      childProducts: null
    };
  }
  public getPackageDisplayName(pkg: IPackageConfiguration): string {
    switch (pkg.productConfigurationId) {
      case ProductConfigurationIds.economyLLCPackage:
        return 'Economy';
      case ProductConfigurationIds.standarLLCPackage:
        return 'Standard';
      case ProductConfigurationIds.expressGoldLLCPackage:
        return 'Express Gold';
      case ProductConfigurationIds.tier1LLCPackage:
        return 'Get Me Started';
      case ProductConfigurationIds.tier2LLCPackage:
        return 'Support Me';
      case ProductConfigurationIds.tier3LLCPackage:
        return 'Help Me Grow';
      default:
        return pkg.displayNameOnBill;
    }
  }
}
