import { Injectable } from '@angular/core';
import { Subject, BehaviorSubject, Observable } from 'rxjs';

export enum CartCreationStatus {
  Pending,
  Created,
  Error,
  None
}

export enum CartLoadingStatus {
  Undefined,
  Loading,
  Loaded,
  Error
}

@Injectable()
export class EventService {
  public saveAndContinueEvent = new Subject();
  public updateLoadingStatusEvent = new Subject();
  public resetConfigEvent = new Subject();
  private cartCreationEvent = new BehaviorSubject<CartCreationStatus>(CartCreationStatus.None);
  public readonly cartCreation$ = this.cartCreationEvent.asObservable();
  private cartLoadingEvent = new BehaviorSubject<CartLoadingStatus>(CartLoadingStatus.Undefined);
  public readonly cartLoading$ = this.cartLoadingEvent.asObservable();
  public showMoreInfoEvent = new Subject<boolean>();
  public updateCheckoutFieldsEvent = new Subject();
  private openAlertBoxEvent = new Subject<any>();
  public readonly openAlertBox$: Observable<any> = this.openAlertBoxEvent.asObservable();

  constructor() { }

  saveAndContinue(currentPage: string): void {
    this.saveAndContinueEvent.next(currentPage);
  }

  updateCartCreationStatus(status: CartCreationStatus): void {
    this.cartCreationEvent.next(status);
  }

  updateCartLoadingStatus(status: CartLoadingStatus): void {
    this.cartLoadingEvent.next(status);
  }

  showMoreInfo(): void {
    this.showMoreInfoEvent.next(true);
  }

  openAlertBox(data: any): void {
    this.openAlertBoxEvent.next(data);
  }

  updateCheckoutFields(): void {
    this.updateCheckoutFieldsEvent.next();
  }

  updateLoadingStatus(isLoading: boolean): void {
    this.updateLoadingStatusEvent.next(isLoading);
  }

  updateResetConfigEvent(): void {
    this.resetConfigEvent.next();
  }
}
