import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { EnvironmentService } from './environment.service';
import { QuestionnaireService } from './questionnaire/questionnaire.service';

@Injectable()
export class BusinessActivityService {
  public bizActivities;

  constructor(
    private http: HttpClient,
    private environmentService: EnvironmentService,
    private questionnaireService: QuestionnaireService
  ) {
    this.bizActivities = [];
  }

  setBizActivities(): void {
    const url = this.environmentService.getBusinessActivitiesUrl();

    this.http.get(url).subscribe(r => {
      this.bizActivities = r;
    });
  }

  getBizActivity(): Observable<any> {
    let url = this.environmentService.getBusinessActivityUrl();
    url = url.replace('{0}', this.questionnaireService.llc.businessPurposeObject.uuid);
    return this.http.get(url);
  }
}
