import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders,HttpErrorResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { IQueueEntry, TrackJsErrorLogService } from '@legalzoom/business-formation-sdk';
import { catchError, map } from 'rxjs/operators';
import { EnvironmentService } from './environment.service';
import { AppService } from '../state/app';
import { ProductName } from '../constants/product-domain';
import { TrackingService } from './tracking/tracking.service';
import { DatePipe } from '@angular/common';
import { CookieService } from 'ngx-cookie';
import {Agreements,AgreementStatus,LegalAgreementInfo,AgreementRequest,Agreement} from '../models/agreement-model'
@Injectable({
  providedIn: 'root'
})
export class AgreementService {
  constructor(
    private http: HttpClient, 
    private appService: AppService, 
    private environmentService: EnvironmentService, 
    private trackingService: TrackingService, 
    private datePipe: DatePipe,
    private trackJS:TrackJsErrorLogService,
    private cookieService:CookieService
    ) {}

  private optionsWithSessionCookie = {
      headers: new HttpHeaders()
        .set('x-lz-api-key', this.environmentService.getLzApiKey()),
      withCredentials : true
  }

  public getAgreement(): Observable<Agreements> {
    return this.http.get<Agreements>(this.environmentService.getAgreementsUrl(), this.optionsWithSessionCookie).pipe(
      map((response) => {
        return response;
      }),
      catchError((error) => {
        console.log(error);
        this.trackingService.triggerClickTrack(ProductName.LLC, 'agreement.service', error);
        return of(null);
      })
    );
  }

  public createAgreement(nextConfigId:number): IQueueEntry {
    return {
      name: 'Create Next Agreement' + this.constructor.name,
      pre: () => {
        let request:LegalAgreementInfo = {
          entityProcessingOrderId: this.appService.processingOrderId,
          entityOrderId: this.appService.orderId,
          orderId: this.appService.orderId,
          processingOrderId: 0,
          givenYear: new Date().getFullYear(),
          productId: nextConfigId
        };
        return this.http.post<any>(this.environmentService.getAgreementsUrl(), request,this.optionsWithSessionCookie)
      },
      post: (response) => {
        if (this.cookieService.get('LOGGEDIN_AS_AGENT') !== '1') {
          if (response != null && response.agreements != null  && response.agreements.length>0) {
            this.updateAgreement(response.agreements[0].agreementId);
          }
        }
       },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'partner-offer.component', error);
        return of(null);
      }
    };  
  }

  public updateAgreement(agreementId: number): Observable<string> {
    const ipAddress = sessionStorage.getItem('ipAddress');
    const today = new Date();
    let agreementRequest:AgreementRequest = {
        acceptStatus: AgreementStatus.Accepted,
        ipAddress: ipAddress !== null ? ipAddress : '',
        firstName: this.appService.firstName,
        middleInitial: '',
        lastName: this.appService.lastName,
        acceptedDate: this.datePipe.transform(today, 'yyyy-MM-dd'),
        contentVersion: 1
      };
    return this.http.put<string>(this.environmentService.getAgreementsUrl() + '/' + agreementId, agreementRequest, this.optionsWithSessionCookie).pipe(
      map((response) => {
        return response;
      }),
      catchError((error) => {
        console.log(error);
        this.trackingService.triggerClickTrack(ProductName.LLC, 'agreement.service', error);
        return of(null);
      })
    );
  }
}
