import { Injectable } from '@angular/core';
import { WindowRef } from './windowRef.service';

@Injectable({
  providedIn: 'root',
})
export class ErrorLoggingService {
  private window: any;

  constructor(
    private windowService: WindowRef
  ) {
    this.window = this.windowService.nativeWindow;
  }

  /**
   * Reports an error to trackJs
   * @param message error name
   */
  trackError(message: string): void {
    if (this.window.trackJs) {
      this.window.trackJs.track(message);
    }
  }

  /**
   * Adds or updates metadata sent with errors to trackJs
   * @param key metadata name
   * @param value metadata value
   */
  setMetadata(key: string, value: string): void {
    if (this.window.trackJs && key) {
      this.window.trackJs.addMetadata(key, value);
    }
  }

  /**
   * Removes metadata sent with errors to trackJs
   * @param key metadata name
   */
  removeMetadata(key: string): void {
    if (this.window.trackJs && key) {
      this.window.trackJs.removeMetadata(key);
    }
  }
}
