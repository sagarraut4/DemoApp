import { UserCartService } from '../../pl-features/glo-design/shared/services/user-cart.service';
import { Router } from '@angular/router';
import { IQueueEntry, QueueService, TrackJsErrorLogService, UtilitiesService } from '@legalzoom/business-formation-sdk';
import { CookieService } from 'ngx-cookie';
import { TestBed, inject } from '@angular/core/testing';
import { PrepareCartService } from './prepare-cart.service';
import { CartService, CartModule } from '@legalzoom/cart-sdk';
import { QuestionnaireStorageModule, QuestionnaireStorageService } from '@legalzoom/questionnaire-storage-sdk';
import { WebSessionModule, WebSessionService } from '@legalzoom/web-session-sdk';
import { QuestionnaireMappingService } from './questionnaire/questionnaire-mapping.service';
import { AppService } from '../state/app';
import { QuestionnaireService } from './questionnaire/questionnaire.service';
import { PackageService } from './package.service';
import { EventService } from './event.service';
import { TrackingService } from './tracking/tracking.service';
import { TrackSEMDataService } from './tracking/track-sem-data.service';
import { of, Subject } from 'rxjs';
import { LLCMapped } from '../models/llcmapped-model';
import { ProductConfigurationIds } from '../models/cart-model';
import { QuestionnaireAnswerService } from '@legalzoom/questionnaire-answer-sdk';
import { ProductService, ProductModule } from '@legalzoom/product-sdk';
import { COMMON_LIB_CONFIG, CommonLibConfig } from '@legalzoom/common-sdk';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('PrepareCartService', () => {
  const mockWebSessionService = jasmine.createSpyObj(['createGuestCustomerAndSession']);
  const mockAppService = {
    sessionId: null, accessToken: null, customerId: null, cartId: null, processingOrderId: 1,
    app: { sessionId: null, accessToken: null, customerId: 456, cartId: null, processingOrderId: null, questionnaireId: 12 },
    getCartBalanceByCartIdResponse: { cartBalance: {}, cartInstallments: { firstInstallment: { installmentAmount: '' } } }
  };
  // tslint:disable-next-line:prefer-const
  let mockTrackJsError;
  const mockUtilitiesService = jasmine.createSpyObj(['prepareSaveCookies', 'saveCookies']);
  const mockRouter = { url: '' };
  const mockQuestionnaireService = { llc: { entityState: 'California', currentView: 'name/business-state' } };
  const mockCartService = jasmine.createSpyObj(['addCartItem', 'cancelCartItem', 'updateCartByQuestionnaire',
    'getCartBalanceByCartId', 'getCartModelFromApiData', 'addCartDiscountByCartId', 'cancelCartDiscount', 'changePackage']);
  const mockQuestionnaireStorageService = jasmine.createSpyObj(['updateQuestionnaireStorage']);
  const mockUserCartService = jasmine.createSpyObj(['prepareCreateNewCart', 'getCartModelFromApiData', 'userCartChange']);
  mockUserCartService.userCartChange = new Subject();
  mockUserCartService.answerRespone = { fieldAnswers: [], groupAnswers: [] };
  mockUserCartService.userCart = { cartId: 123 };
  const mockQuestionnaireMappingService = jasmine.createSpyObj(['doMapping']);
  const mockProductService = jasmine.createSpyObj(['getAvailablePackagesWithFilingFees']);
  const mockPackageService = jasmine.createSpyObj(['mapPackageConfigurations']);
  const mockQuestionnaireAnswerService = jasmine.createSpyObj(['saveAndGetMappedUserAnswers']);
  const mockEventService = jasmine.createSpyObj(['updateLoadingStatus']);
  // tslint:disable-next-line:prefer-const
  let mockTrackingService = jasmine.createSpyObj(['UpdateTrackingModel', 'setUserOrderID', 'sendAdConversion']);
  const mockCookieService = jasmine.createSpyObj(['get', 'post', 'put', 'delete']);
  // tslint:disable-next-line:prefer-const
  let mockTrackSEMDataService;
  const mockmethod: IQueueEntry = {
    name: 'methodname',
    pre: () => {
      return of(null);
    },
    post: (response) => {
    },
    error: (error) => {
      return of(null);
    }
  };
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, WebSessionModule, CartModule, QuestionnaireStorageModule, ProductModule],
      providers: [PrepareCartService,
        { provide: WebSessionService, useValue: mockWebSessionService },
        { provide: AppService, useValue: mockAppService },
        { provide: CookieService, useValue: mockCookieService },
        { provide: TrackJsErrorLogService, useValue: mockTrackJsError },
        { provide: UtilitiesService, useValue: mockUtilitiesService },
        { provide: Router, useValue: mockRouter },
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: CartService, useValue: mockCartService },
        { provide: UserCartService, useValue: mockUserCartService },
        { provide: QuestionnaireStorageService, useValue: mockQuestionnaireStorageService },
        { provide: QuestionnaireMappingService, useValue: mockQuestionnaireMappingService },
        { provide: ProductService, useValue: mockProductService },
        { provide: PackageService, useValue: mockPackageService },
        { provide: QuestionnaireAnswerService, useValue: mockQuestionnaireAnswerService },
        { provide: EventService, useValue: mockEventService },
        { provide: TrackingService, useValue: mockTrackingService },
        { provide: TrackSEMDataService, useValue: mockTrackSEMDataService },
        { provide: COMMON_LIB_CONFIG, useValue: new CommonLibConfig('', '', '', '', '') }
      ]
    });
    mockQuestionnaireStorageService.updateQuestionnaireStorage.and.returnValue(of(true));
    mockQuestionnaireAnswerService.saveAndGetMappedUserAnswers.and.returnValue(of({
      questionnaireFieldGroupAnswers:
        { userOrderId: 123, createdBy: 'test', isMajorRevision: false, fieldAnswers: [], groupAnswers: [] }
    }));
    mockCartService.updateCartByQuestionnaire.and.returnValue(of(true));
    mockCartService.getCartBalanceByCartId.and.returnValue(of(true));
    mockUserCartService.getCartModelFromApiData.and.returnValue(of(true));
    const mockMapping = new LLCMapped();
    mockMapping.fieldAnswers = [];
    mockMapping.groupAnswerCollections = [];
    mockMapping.userOrderId = 132456;
    mockQuestionnaireMappingService.doMapping.and.returnValue(mockMapping);
    mockUserCartService.userCartChange.next('');
    mockUserCartService.updateCartResponse = { cart: { cartItems: [{ productConfigurationId: ProductConfigurationIds.economyLLCShipping, cartItemId: 1 }] } };
    mockQuestionnaireMappingService.questionnaireMappingResponse = { questionnaireFieldGroupAnswers: { fieldAnswers: [], groupAnswers: [] } };
    mockProductService.getAvailablePackagesWithFilingFees.and.returnValue(of(true));
    mockPackageService.mapPackageConfigurations.and.returnValue(of(true));
  });

  it('PrepareCartService should ...', inject([PrepareCartService], (service: PrepareCartService) => {
    expect(service).toBeTruthy();
  }));

  it('prepareGetQuestionnaireStorage method should prepare the questionnaire', () => {
    const service: PrepareCartService = TestBed.get(PrepareCartService);
    const mockQueueService = TestBed.get(QueueService);
    mockWebSessionService.createGuestCustomerAndSession.and.returnValue(of({ customer: { customerId: 123, emailId: 'test@legalzoom.com' }, session: { sessionId: 789, accessToken: 'accessToken' } }));
    mockUtilitiesService.prepareSaveCookies.and.returnValue(mockmethod);
    mockUserCartService.prepareCreateNewCart.and.returnValue(mockmethod);
    mockQueueService.add(service.prepareQueueEntries());
    mockQueueService.process().subscribe();
    expect(mockWebSessionService.createGuestCustomerAndSession).toHaveBeenCalled();
  });

  it('AddProfessionalPrint method should add professional print', () => {
    const service: PrepareCartService = TestBed.get(PrepareCartService);
    mockCartService.addCartItem.and.returnValue(of(true));
    service.AddProfessionalPrint();
    expect(mockCartService.addCartItem).toHaveBeenCalled();
    expect(mockQuestionnaireStorageService.updateQuestionnaireStorage).toHaveBeenCalled();
    expect(mockQuestionnaireAnswerService.saveAndGetMappedUserAnswers).toHaveBeenCalled();
    expect(mockCartService.updateCartByQuestionnaire).toHaveBeenCalled();
    expect(mockCartService.getCartBalanceByCartId).toHaveBeenCalled();
    expect(mockUserCartService.getCartModelFromApiData).toHaveBeenCalled();
    expect(mockQuestionnaireMappingService.doMapping).toHaveBeenCalled();
  });

  it('prepareRemoveBppfromCart method should add professional print', () => {
    const service: PrepareCartService = TestBed.get(PrepareCartService);
    mockCartService.cancelCartItem.and.returnValue(of(true));
    service.RemoveProfessionalPrint();
    expect(mockCartService.cancelCartItem).toHaveBeenCalled();
    expect(mockQuestionnaireStorageService.updateQuestionnaireStorage).toHaveBeenCalled();
    expect(mockQuestionnaireAnswerService.saveAndGetMappedUserAnswers).toHaveBeenCalled();
    expect(mockCartService.updateCartByQuestionnaire).toHaveBeenCalled();
    expect(mockCartService.getCartBalanceByCartId).toHaveBeenCalled();
    expect(mockUserCartService.getCartModelFromApiData).toHaveBeenCalled();
    expect(mockQuestionnaireMappingService.doMapping).toHaveBeenCalled();
  });

  it('applyPromoCode method should apply the promo code', () => {
    const service: PrepareCartService = TestBed.get(PrepareCartService);
    mockCartService.addCartDiscountByCartId.and.returnValue(of(true));
    mockCartService.cancelCartDiscount.and.returnValue(of(true));
    service.applyPromoCode('testPromo');
    expect(mockCartService.addCartDiscountByCartId).toHaveBeenCalled();
    expect(mockCartService.updateCartByQuestionnaire).toHaveBeenCalled();
    expect(mockCartService.getCartBalanceByCartId).toHaveBeenCalled();
    expect(mockUserCartService.getCartModelFromApiData).toHaveBeenCalled();
  });

  it('getCartWithUpdatedPackage method should get the updated package', () => {
    const service: PrepareCartService = TestBed.get(PrepareCartService);
    service.getCartWithUpdatedPackage();
    expect(mockCartService.updateCartByQuestionnaire).toHaveBeenCalled();
    expect(mockCartService.getCartBalanceByCartId).toHaveBeenCalled();
    expect(mockUserCartService.getCartModelFromApiData).toHaveBeenCalled();
  });

  it('prepareRestoreLLCData method should restore the llc data', () => {
    const service: PrepareCartService = TestBed.get(PrepareCartService);
    const mockQueueService = TestBed.get(QueueService);
    mockQueueService.add(service.prepareRestoreLLCData());
    mockQueueService.process().subscribe();
    expect(mockQuestionnaireService.llc.currentView).toBe('name/business-state');
  });

  it('savePackageAndGetCart method should restore the llc data', () => {
    const service: PrepareCartService = TestBed.get(PrepareCartService);
    mockCartService.changePackage.and.returnValue(of({ cart: { cartId: 123 } }));
    service.savePackageAndGetCart(ProductConfigurationIds.tier1LLCPackage);
    expect(mockQuestionnaireStorageService.updateQuestionnaireStorage).toHaveBeenCalled();
    expect(mockQuestionnaireAnswerService.saveAndGetMappedUserAnswers).toHaveBeenCalled();
    expect(mockCartService.changePackage).toHaveBeenCalled();
    expect(mockCartService.getCartBalanceByCartId).toHaveBeenCalled();
    expect(mockUserCartService.getCartModelFromApiData).toHaveBeenCalled();
    expect(mockEventService.updateLoadingStatus).toHaveBeenCalled();
  });

  it('prepareQueueForQuestStorageFillingFee method should prepare queue for storage filing fee', () => {
    const service: PrepareCartService = TestBed.get(PrepareCartService);
    const mockQueueService = TestBed.get(QueueService);
    mockQueueService.add(service.prepareQueueForQuestStorageFillingFee());
    mockQueueService.process().subscribe();
    expect(mockQuestionnaireStorageService.updateQuestionnaireStorage).toHaveBeenCalled();
    expect(mockQuestionnaireMappingService.doMapping).toHaveBeenCalled();
    expect(mockQuestionnaireAnswerService.saveAndGetMappedUserAnswers).toHaveBeenCalled();
    expect(mockProductService.getAvailablePackagesWithFilingFees).toHaveBeenCalled();
    expect(mockPackageService.mapPackageConfigurations).toHaveBeenCalled();
  });
});
