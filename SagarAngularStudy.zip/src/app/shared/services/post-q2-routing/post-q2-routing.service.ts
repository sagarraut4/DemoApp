import { Injectable } from '@angular/core';
import { UtilitiesService } from '@legalzoom/business-formation-sdk';
import { WindowRef } from '../windowRef.service';
import { PagePath } from '../../models/page-model';
import { SessionStorageType } from '../tracking/session-storage';
import { FeatureFlagService } from '../feature-flag/feature-flag.service';
import { AppService } from '../../state/app';
import { WebSessionService } from '@legalzoom/web-session-sdk';
import { SsoFeatureFlagService } from '@legalzoom/site-sdk-sso';
import { SsoService } from '../sso.service';
import { environment } from '../../../../environments/environment';

@Injectable({
  providedIn: 'root'
})

export class PostQ2RoutingService {

  constructor(
    private utilitiesService: UtilitiesService,
    private windowRef: WindowRef,
    private featureFlagService: FeatureFlagService,
    private appService: AppService,
    private webSessionService: WebSessionService,
    private ssoFeatureFlagService: SsoFeatureFlagService,
    private ssoService: SsoService
  ) {
    this.featureFlagService.reinitializeFlagsIfUserChanged();
  }

  public goToMyAccount() {
    this.utilitiesService.clearUserSession(false, SessionStorageType.APP);
    this.windowRef.nativeWindow.location.href = PagePath.MyAccount;
  }

  public async goToNextPage() {
    if (this.featureFlagService.isSetPasswordEnabled) {
      this.goToMyAccount();
    } else {
      if (this.appService.isGuestConvertedOnCheckout) {
        const featureFlagName = environment.sso.configuration.launchDarkly.ssoFeatureFlag;
        const isSsoEnabled = await this.ssoFeatureFlagService.isFlagEnabledAsync(featureFlagName);
        if (isSsoEnabled) {
          this.utilitiesService.clearUserSession(this.appService.isGuestConvertedOnCheckout, SessionStorageType.APP);
          return this.ssoService.logout(environment.sso.returnUrl + PagePath.MyAccount);
        }
  
        this.webSessionService.removeAndRevokeSession().subscribe((res) => {
          this.utilitiesService.clearUserSession(this.appService.isGuestConvertedOnCheckout, SessionStorageType.APP);
          this.windowRef.nativeWindow.location.href = PagePath.MyAccount;
        });
      }
      else {
        this.utilitiesService.clearUserSession(this.appService.isGuestConvertedOnCheckout, SessionStorageType.APP);
        this.windowRef.nativeWindow.location.href = PagePath.MyAccount;
      }
    }
  }
}