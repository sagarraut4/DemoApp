import { async, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { UtilitiesService } from '@legalzoom/business-formation-sdk';
import { WindowRef } from '../windowRef.service';
import { FeatureFlagService } from '../feature-flag/feature-flag.service';
import { AppService } from '../../state/app';
import { WebSessionService } from '@legalzoom/web-session-sdk';
import { SsoFeatureFlagService } from '@legalzoom/site-sdk-sso';
import { SsoService } from '../sso.service';
import { PostQ2RoutingService } from './post-q2-routing.service';
import { LLC } from '../../../../app/shared/models/questionnaire-model';
import { HttpClientModule } from '@angular/common/http';
import { COMMON_LIB_CONFIG, CommonLibConfig } from '@legalzoom/common-sdk';
import { QuestionnaireService } from '../../../../app/shared/services/questionnaire/questionnaire.service';
import { EnvironmentService } from '../../../../app/shared/services/environment.service';

declare global {
  interface Window { nativeWindow: any; }
}

describe('PostQ2RoutingService with isSetPasswordEnabled = true', () => {
  let service: PostQ2RoutingService;
  let mockUtilitiesService = jasmine.createSpyObj(['clearUserSession']);
  let mockAppService;
  let mockWebSessionService;
  let mockFeatureFlagService = jasmine.createSpyObj(['reinitializeFlagsIfUserChanged']);
  let mockSsoFeatureFlagService;
  let mockSsoService;
  mockFeatureFlagService.isSetPasswordEnabled = true;
  window.nativeWindow = window.nativeWindow || {};
  window.nativeWindow.location = { href: {} };

  const mockQuestionnaireService = {
    llc: new LLC()
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule],
      providers: [PostQ2RoutingService, WindowRef,
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: UtilitiesService, useValue: mockUtilitiesService },
        { provide:  COMMON_LIB_CONFIG, useValue: new CommonLibConfig('','','','','')},
        EnvironmentService, 
        { provide: WindowRef, useValue: window },
        { provide: AppService, useValue: mockAppService },
        { provide: WebSessionService, useValue: mockWebSessionService },
        { provide: FeatureFlagService, useValue: mockFeatureFlagService },
        { provide: SsoFeatureFlagService, useValue: mockSsoFeatureFlagService },
        { provide: SsoService, useValue: mockSsoService }
      ]
    });
    service = TestBed.get(PostQ2RoutingService);
  }));

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should call goToMyAccount', async(() => {
    spyOn(service, 'goToMyAccount');
    service.goToNextPage();
    expect(service.goToMyAccount).toHaveBeenCalled();
  }));

  it('should call clearUserSession', fakeAsync(() => {
    service.goToMyAccount();
    tick();
    expect(mockUtilitiesService.clearUserSession).toHaveBeenCalled();
  }));
});

describe('PostQ2RoutingService with isSetPasswordEnabled = false and isGuestConvertedOnCheckout = false', () => {
  let service: PostQ2RoutingService;
  let mockUtilitiesService = jasmine.createSpyObj(['clearUserSession']);
  let mockAppService = { isGuestConvertedOnCheckout: false };
  let mockWebSessionService;
  let mockFeatureFlagService = jasmine.createSpyObj(['reinitializeFlagsIfUserChanged']);
  let mockSsoFeatureFlagService;
  let mockSsoService;
  mockFeatureFlagService.isSetPasswordEnabled = false;
  window.nativeWindow = window.nativeWindow || {};
  window.nativeWindow.location = { href: {} };

  const mockQuestionnaireService = {
    llc: new LLC()
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule],
      providers: [PostQ2RoutingService, WindowRef,
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: UtilitiesService, useValue: mockUtilitiesService },
        { provide:  COMMON_LIB_CONFIG, useValue: new CommonLibConfig('','','','','')},
        EnvironmentService, 
        { provide: WindowRef, useValue: window },
        { provide: AppService, useValue: mockAppService },
        { provide: WebSessionService, useValue: mockWebSessionService },
        { provide: FeatureFlagService, useValue: mockFeatureFlagService },
        { provide: SsoFeatureFlagService, useValue: mockSsoFeatureFlagService },
        { provide: SsoService, useValue: mockSsoService }
      ]
    });
    service = TestBed.get(PostQ2RoutingService);
  }));

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it("shouldn't call goToMyAccount", async(() => {
    spyOn(service, 'goToMyAccount');
    service.goToNextPage();
    expect(service.goToMyAccount).not.toHaveBeenCalled();
  }));

  it('should call clearUserSession', fakeAsync(() => {
    service.goToMyAccount();
    tick();
    expect(mockUtilitiesService.clearUserSession).toHaveBeenCalled();
  }));
});