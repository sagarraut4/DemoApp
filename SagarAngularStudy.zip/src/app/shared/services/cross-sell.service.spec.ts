import { WindowRef } from './windowRef.service';
import { TrackingService } from './tracking/tracking.service';
import { TestBed } from '@angular/core/testing';
import { CrossSellService } from './cross-sell.service';
import {
  QueueService,
  IQueueEntry, TrackJsErrorLogService
} from '@legalzoom/business-formation-sdk';
import { AppService } from '../state/app';
import { QuestionnaireService } from './questionnaire/questionnaire.service';
import { EventService } from './event.service';
import { of, throwError } from 'rxjs';
import { CrossSellPackages } from '../constants/cross-sell-packages';
import { LLC } from '../models/questionnaire-model';
import { CheckoutReturnType } from '../constants/checkout-return-type';
import { TaggingService, ITagOrderByIdResponse } from '@legalzoom/tagging-sdk';
import { ICreateCrossSellOrderResponse, IGetOrderContactResponse, ICreateOrderContactResponse, OrderService } from '@legalzoom/order-sdk';
import { IEmailHandlerResponse, EmailNotificationService } from '@legalzoom/notification-sdk';
import { ProcessingOrderService } from '@legalzoom/processing-order-sdk';
import { QuestionnaireAnswerService } from '@legalzoom/questionnaire-answer-sdk';
import { PaymentService, ICreatePaymentResponse } from '@legalzoom/payment-sdk';
declare global {
  interface Window {
    nativeWindow: any;
  }
}
describe('Service: CrossSell', () => {
  let service: CrossSellService;
  const mockAppService = {
    currentView: '',
    loginEmail: '',
    orderId: 123,
    customerId: 123,
    accessToken: 'testingtoken',
    app: {
      processingOrderId: 123,
      lwtCrossSellOrderResponse: { orderId: 32778305 },
      tmsCrossSellOrderResponse: { orderId: 32778305 }
    }
  };
  let mockOrderService;
  let mockPaymentService;
  let mockEmailNotificationService;
  let mockTaggingService;
  const mockQuestionnaireService = {
    llc: new LLC()
  };
  mockQuestionnaireService.llc.businessAddress.state = 'California';
  let mockProcessingOrderService;
  let mockTrackingService;
  let mockEventService;
  let mockQuestionnaireAnswerService;
  const mockTrackJsErrorLogService = jasmine.createSpyObj(['track']);
  const createCrossSellOrderResponse: ICreateCrossSellOrderResponse = {
    orderId: 32778305,
    orderItem: {
      orderId: 32778305,
      orderItemId: 54409585,
      parentOrderItemId: 54409547,
      stateId: 0,
      basePrice: 69,
      extendedPrice: 49,
      quantity: 1,
      productConfiguration: {
        productConfigurationId: 6399,
        productTypeId: '9',
        shouldDisplayOnBill: true,
        productComponent: {
          productComponentId: 1413,
          productComponentFlags: {
            allowCustomerToAdd: false,
            allowCustomizablePrice: false,
            allowExpediteOnPackage: false,
            allowStoreCredit: true,
            allowElectronicChecks: true,
            canSubscribe: false,
            canEditQuantity: false,
            autoRenewByDefault: false,
            mustAutoRenewToSubscribe: false,
            isService: false
          },
          name: 'Last Will and Testament Basic',
          displayNameOnBill: 'Basic Last Will and Testament',
          displayNameOnWeb: 'Last Will and Testament Basic',
          description: null,
          longDescription: null,
          internalDescription: null,
          isActive: true
        },
        isDefaultPackage: false,
        childProducts: [{}]
      },
      isCancelled: false,
      childOrderItems: [{}],
      processingOrder: {
        processId: 6,
        processingOrderId: 508064052,
        questionnaireId: 49,
        processingStatusId: 0,
        processingStatusCategoryId: 0,
        complete: false
      },
      productName: 'Last Will and Testament',
      isShipped: false,
      shipMethodId: null,
      lineNumber: 1,
      dateCreated: '2019-02-20T16:58:53.323Z',
      createdBy: '12329191',
      dateLastModified: '2019-02-20T16:58:53.323Z',
      lastModifiedBy: '12329191'
    }
  };

  const getOrderContactResponse: IGetOrderContactResponse = {
    contacts: [
      {
        orderContactId: 42693842,
        contactType: 'Primary',
        firstName: 'Test',
        lastName: 'Test',
        addressLine1: '101 N Brand Blvd',
        addressLine2: null,
        city: 'Glendale',
        state: 'California',
        county: null,
        zipCode: '91203',
        emailAddresses: [
          {
            emailAddress: 'lm2202019_7@lz.com'
          }
        ],
        homePhone: '(333) 333-3333',
        workPhone: '',
        mobilePhone: '',
        faxPhone: null,
        country: null,
        stateId: 5,
        dateCreated: new Date('2019-02-20T16:55:29.567Z'),
        createdBy: 'AWSStepFunction',
        dateLastModified: new Date('2019-02-20T16:55:29.567Z'),
        lastModifiedBy: null
      },
      {
        orderContactId: 42693843,
        contactType: 'Shipping',
        firstName: 'Test',
        lastName: 'Test',
        addressLine1: '101 N Brand Blvd',
        addressLine2: null,
        city: 'Glendale',
        state: 'California',
        county: null,
        zipCode: '91203',
        emailAddresses: [
          {
            emailAddress: 'lm2202019_7@lz.com'
          }
        ],
        homePhone: '(333) 333-3333',
        workPhone: '',
        mobilePhone: '',
        faxPhone: null,
        country: null,
        stateId: 5,
        dateCreated: new Date('2019-02-20T16:55:29.567Z'),
        createdBy: 'AWSStepFunction',
        dateLastModified: new Date('2019-02-20T16:55:29.567Z'),
        lastModifiedBy: null
      },
      {
        orderContactId: 42693844,
        contactType: 'Billing',
        firstName: 'Test',
        lastName: 'Test',
        addressLine1: '101 N Brand Blvd',
        addressLine2: null,
        city: 'Glendale',
        state: 'California',
        county: null,
        zipCode: '91203',
        emailAddresses: [
          {
            emailAddress: 'lm2202019_7@lz.com'
          }
        ],
        homePhone: '(333) 333-3333',
        workPhone: '',
        mobilePhone: '',
        faxPhone: null,
        country: null,
        stateId: 5,
        dateCreated: new Date('2019-02-20T16:55:29.567Z'),
        createdBy: 'AWSStepFunction',
        dateLastModified: new Date('2019-02-20T16:55:29.567Z'),
        lastModifiedBy: null
      }
    ]
  };

  const createPaymentResponse: ICreatePaymentResponse = {
    paymentTransactionId: 34719743,
    orderId: 32778303,
    transactionType: '1',
    paymentType: '1',
    amount: 49,
    currencyCode: 'USD',
    creationDate: '2019-02-21T00:56:40.6159002Z',
    createdBy: '12329191',
    transactionStatus: '3',
    statusDate: '2019-02-21T00:56:40.6159002Z',
    parentId: 0,
    customerId: '12329191',
    comments: 'Express Order',
    reasonId: '1',
    reasonText: 'Payment From Website',
    paymentProfileId: 27957350,
    gateway: '8',
    canceled: false,
    cancelationDate: '0001-01-01T00:00:00Z',
    source: '100',
    manualCheckId: null,
    notificationEmail: 'lm2202019_7@lz.com'
  };

  const tagOrderResponse: ITagOrderByIdResponse = {
    orderTag: {
      tagId: 33337,
      tagType: '1',
      tag: 'inc_crosssell_tms_federal_99',
      dateCreated: '2019-02-19T14:19:26.613Z',
      createdBy: '12321213',
      dateUpdated: '2019-02-21T00:56:50.9288196Z',
      updatedBy: '12321213'
    }
  };

  const createOrderContactRespose: ICreateOrderContactResponse = {
    orderContact: [{
      orderContactId: 42693847,
      contactType: 'Primary',
      firstName: 'Test',
      lastName: 'Test',
      addressLine1: '101 N Brand Blvd',
      addressLine2: null,
      city: 'Glendale',
      state: 'California',
      county: null,
      zipCode: '91203',
      emailAddresses: [
        {
          emailAddress: 'lm2202019_7@lz.com'
        }
      ],
      homePhone: '(333) 333-3333',
      workPhone: '',
      mobilePhone: '',
      faxPhone: 'null',
      country: 'null',
      stateId: 5,
      dateCreated: new Date('2019-02-21T00:56:51.3507114Z'),
      createdBy: 'AWSStepFunction',
      dateLastModified: new Date('2019-02-21T00:56:51.3507114Z'),
      lastModifiedBy: 'AWSStepFunction'
    }]
  };

  const emailHandlerResponse: IEmailHandlerResponse = {
    Message: 'Success',
    StatusCode: '200'
  };
  const mockmethod: IQueueEntry = {
    name: 'methodname',
    pre: () => {
      return of({});
    },
    post: (response) => {
    },
    error: (error) => {
      return of(null);
    }
  };
  window.nativeWindow = window.nativeWindow || {
    trackJs: {
      track() { },
      addMetadata() { },
      removeMetadata() { }
    }
  };
  let mockWindowRef = jasmine.createSpyObj(['nativeWindow']);
  beforeEach(() => {
    mockOrderService = jasmine.createSpyObj(['createCrossSellOrder', 'createOrderContact']);
    mockPaymentService = jasmine.createSpyObj(['createPayment']);
    mockEmailNotificationService = jasmine.createSpyObj(['sendEmailNotification',]);
    mockProcessingOrderService = jasmine.createSpyObj(['createProcessingOrderQueue', 'updateProcessingOrder']);
    mockTrackingService = jasmine.createSpyObj(['ClearOAItems', 'winRef']);
    mockEventService = jasmine.createSpyObj(['saveAndContinue']);
    mockQuestionnaireAnswerService = jasmine.createSpyObj(['saveAndGetMappedUserAnswers']);
    mockWindowRef = jasmine.createSpyObj(['nativeWindow']);
    mockTaggingService = jasmine.createSpyObj(['tagOrderById']);
    mockTrackingService.winRef.nativeWindow = mockWindowRef.nativeWindow;
    TestBed.configureTestingModule({
      providers: [
        CrossSellService,
        { provide: AppService, useValue: mockAppService },
        { provide: WindowRef, useValue: window },
        QueueService,
        { provide: OrderService, useValue: mockOrderService },
        { provide: TrackJsErrorLogService, useValue: mockTrackJsErrorLogService },
        { provide: PaymentService, useValue: mockPaymentService },
        { provide: EmailNotificationService, useValue: mockEmailNotificationService },
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: ProcessingOrderService, useValue: mockProcessingOrderService },
        { provide: TrackingService, useValue: mockTrackingService },
        { provide: EventService, useValue: mockEventService },
        { provide: TaggingService, useValue: mockTaggingService },
        { provide: QuestionnaireAnswerService, useValue: mockQuestionnaireAnswerService }
      ]
    });
    service = TestBed.get(CrossSellService);
  });

  it('should create', () => {
    expect(service).toBeTruthy();
  });

  it('should complete all steps for TMS', () => {
    mockOrderService.createCrossSellOrder.and.returnValue(of(createCrossSellOrderResponse));
    mockProcessingOrderService.createProcessingOrderQueue.and.returnValue(of(null));
    mockQuestionnaireAnswerService.saveAndGetMappedUserAnswers.and.returnValue(of(null));
    mockProcessingOrderService.updateProcessingOrder.and.returnValue(of(null));
    mockPaymentService.createPayment.and.returnValue(of(createPaymentResponse));
    mockTaggingService.tagOrderById.and.returnValue(of(tagOrderResponse));
    mockOrderService.createOrderContact.and.returnValue(of(createOrderContactRespose));
    mockEmailNotificationService.sendEmailNotification.and.returnValue(of(emailHandlerResponse));
    mockEventService.saveAndContinue.and.returnValue(of(''));
    service.savePackage(CrossSellPackages.tms);
    expect(mockOrderService.createCrossSellOrder).toHaveBeenCalled();
    expect(mockPaymentService.createPayment).toHaveBeenCalled();
    expect(mockProcessingOrderService.createProcessingOrderQueue).toHaveBeenCalled();
    expect(mockQuestionnaireAnswerService.saveAndGetMappedUserAnswers).toHaveBeenCalled();
    expect(mockProcessingOrderService.updateProcessingOrder).toHaveBeenCalled();
    expect(mockTaggingService.tagOrderById).toHaveBeenCalled();
    expect(mockOrderService.createOrderContact).toHaveBeenCalled();
    expect(mockEmailNotificationService.sendEmailNotification).toHaveBeenCalled();
    expect(mockEventService.saveAndContinue).toHaveBeenCalled();
  });

  it('should complete all steps for both', () => {
    mockOrderService.createCrossSellOrder.and.returnValue(of(createCrossSellOrderResponse));
    mockProcessingOrderService.createProcessingOrderQueue.and.returnValue(of(null));
    mockQuestionnaireAnswerService.saveAndGetMappedUserAnswers.and.returnValue(of(null));
    mockProcessingOrderService.updateProcessingOrder.and.returnValue(of(null));
    mockPaymentService.createPayment.and.returnValue(of(createPaymentResponse));
    mockTaggingService.tagOrderById.and.returnValue(of(tagOrderResponse));
    mockOrderService.createOrderContact.and.returnValue(of(createOrderContactRespose));
    mockEmailNotificationService.sendEmailNotification.and.returnValue(of(emailHandlerResponse));
    mockEventService.saveAndContinue.and.returnValue(of(''));
    service.savePackage(CrossSellPackages.both);
    expect(mockOrderService.createCrossSellOrder).toHaveBeenCalled();
    expect(mockPaymentService.createPayment).toHaveBeenCalled();
    expect(mockProcessingOrderService.createProcessingOrderQueue).toHaveBeenCalled();
    expect(mockQuestionnaireAnswerService.saveAndGetMappedUserAnswers).toHaveBeenCalled();
    expect(mockProcessingOrderService.updateProcessingOrder).toHaveBeenCalled();
    expect(mockTaggingService.tagOrderById).toHaveBeenCalled();
    expect(mockOrderService.createOrderContact).toHaveBeenCalled();
    expect(mockEmailNotificationService.sendEmailNotification).toHaveBeenCalled();
    expect(mockEventService.saveAndContinue).toHaveBeenCalled();
  });

  it('should complete all steps for LWT', () => {  
    mockOrderService.createCrossSellOrder.and.returnValue(of(createCrossSellOrderResponse));
    mockQuestionnaireAnswerService.saveAndGetMappedUserAnswers.and.returnValue(of(null));
    mockPaymentService.createPayment.and.returnValue(of(createPaymentResponse));
    mockTaggingService.tagOrderById.and.returnValue(of(tagOrderResponse));
    mockOrderService.createOrderContact.and.returnValue(of(createOrderContactRespose));
    mockEmailNotificationService.sendEmailNotification.and.returnValue(of(emailHandlerResponse));
    mockEventService.saveAndContinue.and.returnValue(of(''));
    service.savePackage(CrossSellPackages.lwt);
    expect(mockOrderService.createCrossSellOrder).toHaveBeenCalled();
    expect(mockPaymentService.createPayment).toHaveBeenCalled();
    expect(mockProcessingOrderService.createProcessingOrderQueue).not.toHaveBeenCalled();
    expect(mockQuestionnaireAnswerService.saveAndGetMappedUserAnswers).toHaveBeenCalled();
    expect(mockProcessingOrderService.updateProcessingOrder).not.toHaveBeenCalled();
    expect(mockTaggingService.tagOrderById).toHaveBeenCalled();
    expect(mockOrderService.createOrderContact).toHaveBeenCalled();
    expect(mockEmailNotificationService.sendEmailNotification).toHaveBeenCalled();
    expect(mockEventService.saveAndContinue).toHaveBeenCalled();
  });
  it('should return "createCrossSellOrder" if createCrossSellsOrder_CrossSell function fails', () => {
    mockOrderService.createCrossSellOrder.and.returnValue(throwError({ message: 'error' }));
    const appService = TestBed.get(AppService);
    service.savePackage(CrossSellPackages.lwt);
    expect(mockOrderService.createCrossSellOrder).toHaveBeenCalled();
    expect(mockPaymentService.createPayment).not.toHaveBeenCalled();
    expect(appService.expressOrderProcessType).toBe(CheckoutReturnType.createCrossSellOrder);
  });
  it('should stop calling methods after "createBillOrder_crossSell" if createBillOrder_CrossSell function fails', () => {
    mockOrderService.createCrossSellOrder.and.returnValue(of(createCrossSellOrderResponse));
    mockPaymentService.createPayment.and.returnValue(throwError({ message: 'error' }));
    mockProcessingOrderService.createProcessingOrderQueue.and.returnValue(of(null));
    service.savePackage(CrossSellPackages.tms);
    expect(mockOrderService.createCrossSellOrder).toHaveBeenCalled();
    expect(mockPaymentService.createPayment).toHaveBeenCalled();
    expect(mockQuestionnaireAnswerService.saveAndGetMappedUserAnswers).not.toHaveBeenCalled();
  });
});
