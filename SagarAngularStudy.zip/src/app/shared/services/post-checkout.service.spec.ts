import { HttpClientTestingModule } from '@angular/common/http/testing';
import { environmentCommon } from './../../../environments/environment';
import { TestBed, inject, async } from '@angular/core/testing';
import { PostCheckoutService } from './post-checkout.service';
import { QuestionnaireMappingService } from './questionnaire/questionnaire-mapping.service';
import { QuestionnaireService } from './questionnaire/questionnaire.service';
import { AppService } from '../state/app';
import { TrackJsErrorLogService, QueueService } from '@legalzoom/business-formation-sdk';
import { QuestionnaireRoutingService } from './questionnaire-routing/questionnaire-routing.service';
import { ReplaySubject, of } from 'rxjs';
import { RouterEvent, Router } from '@angular/router';
import { LLC } from '../models/questionnaire-model';
import { OrderModule, OrderService } from '@legalzoom/order-sdk';
import { ProcessingOrderService } from '@legalzoom/processing-order-sdk';
import { QuestionnaireAnswerService, QuestionnaireAnswerModule } from '@legalzoom/questionnaire-answer-sdk';

describe('PostCheckoutService', () => {
  let service: PostCheckoutService;
  let mockQuestionnaireMappingService;
  let mockQuestionnaireAnswerService;
  let mockProcessingOrderService;
  let mockQuestionnaireRoutingService;
  let mockTrackJsErrorLogService;
  let mockOrderService;
  const mockAppService = {
    processingOrderId: 123,
    app: {
      processingOrderId: 123,
      questionnaireId: 12345,
      orderId: 123,
      customerId: 123,
      accessToken: 'test'
    }
  };
  const eventSubject = new ReplaySubject<RouterEvent>(1);
  const mockRouter: any = {
    navigate: jasmine.createSpy('navigate'),
    events: eventSubject.asObservable(),
    url: '/name/state'
  };
  beforeEach(() => {
    mockQuestionnaireRoutingService = jasmine.createSpyObj(['getNextPage']);
    mockQuestionnaireMappingService = jasmine.createSpyObj(['doMapping']);
    mockQuestionnaireAnswerService = jasmine.createSpyObj(['saveAndGetMappedUserAnswers']);
    mockProcessingOrderService = jasmine.createSpyObj(['updateProcessingOrder']);
    mockTrackJsErrorLogService = jasmine.createSpyObj(['track']);
    mockOrderService = jasmine.createSpyObj(['postFinalizeOrder', 'addAddOnToOrder']);
    const mockQuestionnaireService = {
      llc: new LLC()
    };

    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        OrderModule.forRoot(environmentCommon),
        QuestionnaireAnswerModule.forRoot(environmentCommon)
      ],
      providers: [PostCheckoutService,
        { provide: QuestionnaireMappingService, useValue: mockQuestionnaireMappingService },
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: QuestionnaireAnswerService, useValue: mockQuestionnaireAnswerService },
        { provide: TrackJsErrorLogService, useValue: mockTrackJsErrorLogService },
        { provide: QuestionnaireRoutingService, useValue: mockQuestionnaireRoutingService },
        { provide: ProcessingOrderService, useValue: mockProcessingOrderService },
        { provide: OrderService, useValue: mockOrderService },
        { provide: AppService, useValue: mockAppService },
        { provide: Router, useValue: mockRouter },
        QueueService
      ]
    });
    service = TestBed.get(PostCheckoutService);
  });

  it('should be created', inject([PostCheckoutService], (serviceRef: PostCheckoutService) => {
    expect(serviceRef).toBeTruthy();
  }));
  it('should be called saveAndGetMappedUserAnswers', async(() => {
    mockQuestionnaireMappingService.doMapping.and.returnValue({});
    mockQuestionnaireAnswerService.saveAndGetMappedUserAnswers.and.returnValue(of(null));
    const queueService = TestBed.get(QueueService);
    queueService.add(service.prepareSaveAndGetMappedUserAnswers(service));
    queueService.process().subscribe();
    expect(mockQuestionnaireAnswerService.saveAndGetMappedUserAnswers).toHaveBeenCalled();
  }));
  it('should be called prepareUpdateProcessingOrder', async(() => {
    mockProcessingOrderService.updateProcessingOrder.and.returnValues(of(null));
    const queueService = TestBed.get(QueueService);    
    const mockService:any = service;
    mockService.entityState = 'California';
    queueService.add(service.prepareUpdateProcessingOrder(mockService));
    queueService.process().subscribe();
    expect(mockProcessingOrderService.updateProcessingOrder).toHaveBeenCalled();
  }));
  it('should be called preparePostFinalizeOrder', async(() => {
    service.mappedLLC = {
      userOrderId: 1234
    };
    service.updateProcessingOrderResponse = {
      processingOrder: {
        processingOrderId: 1234
      }
    };
    mockQuestionnaireRoutingService.getNextPage.and.returnValue('test');
    mockOrderService.postFinalizeOrder.and.returnValues(of(true));
    const queueService = TestBed.get(QueueService);
    queueService.add(service.preparePostFinalizeOrder(service));
    queueService.process().subscribe();
    expect(mockOrderService.postFinalizeOrder).toHaveBeenCalled();
    expect(mockRouter.navigate).toHaveBeenCalled();
  }));
  it('should be called prepareAddAddOnToOrder', async(() => {
    mockOrderService.addAddOnToOrder.and.returnValues(of(null));
    const queueService = TestBed.get(QueueService);
    queueService.add(service.prepareAddAddOnToOrder({}));
    queueService.process().subscribe();
    expect(mockOrderService.addAddOnToOrder).toHaveBeenCalled();
  }));
});
