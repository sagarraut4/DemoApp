import { TestBed } from '@angular/core/testing';
import { BackButtonService } from './back-button.service';
import { Router, RouterEvent, NavigationEnd, NavigationStart, NavigationError, NavigationCancel } from '@angular/router';
import { Chapter } from '../models/page-model';
import { ReplaySubject } from 'rxjs';
import { Location } from '@angular/common';

describe('BackButtonService', () => {
  let service: BackButtonService;
  let eventSubject;
  let mockRouter;
  let mockLocation;
  beforeEach(() => {
    mockLocation = jasmine.createSpyObj(['replaceState', 'forward']);
    eventSubject = new ReplaySubject<RouterEvent>(1);
    mockRouter = {
      navigate: jasmine.createSpy('navigate'),
      events: eventSubject.asObservable(),
      url: '/' + Chapter.PostOrder
    };
    TestBed.configureTestingModule({
      providers: [
        BackButtonService,
        { provide: Location, useValue: mockLocation },
        { provide: Router, useValue: mockRouter },
      ]
    });
    service = TestBed.get(BackButtonService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  it('should be init', () => {
    service.init();
    eventSubject.next(new NavigationEnd(1, 'regular', 'redirectUrl'));
    eventSubject.next(new NavigationStart(1, 'regular'));
    eventSubject.next(new NavigationError(1, 'regular', 'redirectUrl'));
    mockLocation = TestBed.get(Location);
    expect(mockLocation.replaceState).not.toHaveBeenCalled();
    expect(mockLocation.forward).not.toHaveBeenCalled();
  });
  it('should check if back button clicked and maintain recor in routesHistory', () => {
    service.init();
    eventSubject.next(new NavigationStart(1, 'regular'));
    expect(service.backButtonClicked).toBe(false);
    eventSubject.next(new NavigationStart(1, 'regular1'));
    eventSubject.next(new NavigationStart(1, 'regular'));
    expect(service.backButtonClicked).toBe(true);
  });
  it('should call replaceState', () => {
    mockLocation.replaceState.and.returnValues();
    mockLocation.forward.and.returnValues();
    service.init();
    eventSubject.next(new NavigationCancel(1, 'regular', 'reloadpage'));
    expect(mockLocation.replaceState).toHaveBeenCalled();
    expect(mockLocation.forward).toHaveBeenCalled();
  });
  it('should false if path contains order', () => {
    service.backButtonClicked = true;
    const result = service.verifyRoute(`/${Chapter.PostOrder}/`);
    expect(result).toBe(false);
  });
  it('should true if path doesnot contains order', () => {
    service.backButtonClicked = true;
    const result = service.verifyRoute(`/${Chapter.Name}/`);
    expect(result).toBe(true);
  });
});
