import { AppService } from './../state/app/app.service';
import { ExperimentsService } from './experiments/experiments.service';
import { Injectable } from '@angular/core';
import { CheckoutService as GCCheckoutService, CrossSellConfig, CrossSellService as GCCrossSellService, GCPageInput } from '@legalzoom/lib-checkout';
import { TrackingService } from './tracking/tracking.service';
import { Cart, CartItem, CartItemType, ProductComponentId, ProductConfigurationIds } from './../../../app/shared/models/cart-model';
import { ITagOrderByIdRequest, TagType, TaggingService } from '@legalzoom/tagging-sdk';
import { QuestionnaireService } from './questionnaire/questionnaire.service';
import { PagePath } from '../models/page-model';
import { EventService } from './event.service';
import { PrepareCartService } from './../../shared/services/prepare-cart.service';
import { UtilitiesService } from '@legalzoom/business-formation-sdk';
import { Payment } from '@legalzoom/sdk-checkout';
import { CustomerService } from '@legalzoom/customer-sdk';
import { PartnerOfferTagNames, ProcessId, QuestionnaireId, TaxOfferTagNames } from './constants.service';
import { SessionStorageType } from './tracking/session-storage';
import { TaxPackages } from '../models/tax-packages-model';
import { FeatureFlagService } from './feature-flag/feature-flag.service';

@Injectable({
  providedIn: 'root'
})
export class CheckoutService {
  public cart: Cart;
  constructor(
    private gcCheckoutService: GCCheckoutService,
    private trackingService: TrackingService,
    private experimentsService: ExperimentsService,
    private appService: AppService,
    private questionnaireService: QuestionnaireService,
    private experimentService: ExperimentsService,
    private eventService: EventService,
    private taggingService: TaggingService,
    private prepareCartService: PrepareCartService,
    private customerService: CustomerService,
    private utilitiesService: UtilitiesService,
    private gcCrossSellService: GCCrossSellService,
    private featureFlagService: FeatureFlagService
  ) { }

  subscribeToCheckoutEvents() {
    this.gcCheckoutService.gcAgreeAndPayNow.subscribe((subscriber) => {
      console.log('gcAgreeAndPayNow event');
      this.trackingService.triggerClickTrack('global_checkout', 'checkout_agree_and_pay_now', 'click');
    });

    this.gcCheckoutService.gcLoaded.subscribe((subscriber) => {
      console.log('trigger tracking called');
      this.cart = {
        cartItems: this.mapCartItems(subscriber.cart.cartItems),
        discount: subscriber.cartBalance.totalDiscount,
        dueNow: subscriber.cartBalance.cartBalance,
        packageTitle: '',
        installmentAmount: this.getCartInstallment(subscriber.cartBalance.cartInstallments),
        storeCredit: subscriber.cartBalance.storeCreditAvailable
      };
      const packageCartItem: CartItem = this.cart.cartItems.find((cartItem) => cartItem.type === CartItemType.RootPackage);
      const fillingFeeList: number[] = this.cart.cartItems.filter((cartItem) => cartItem.type === CartItemType.FilingFee).map((cartItem) => cartItem.amount);
      const shippingFeeList: number[] = this.cart.cartItems.filter((cartItem) => cartItem.type === CartItemType.ShippingItems).map((cartItem) => cartItem.amount);
      if (fillingFeeList.length === 0) {
        fillingFeeList.push(0);
      }
      if (shippingFeeList.length === 0) {
        shippingFeeList.push(0);
      }
      const revenue: number = this.cart.dueNow - fillingFeeList.reduce((accumulator, currentValue) => accumulator + currentValue) - shippingFeeList.reduce((accumulator, currentValue) => accumulator + currentValue);

      this.trackingService.triggerCheckoutPixels(packageCartItem.title, revenue);
    });

    this.gcCheckoutService.gcProcessCheckoutInit.subscribe((subscriber) => {
      console.log('initCheckout event');
      if (subscriber.isThreePay) {
        this.trackingService.triggerClickTrack('global_checkout', 'checkout_installment_plan', '3_pay');
      } else {
        this.trackingService.triggerClickTrack('global_checkout', 'checkout_single_payment', '3_pay');
      }
    });

    this.gcCheckoutService.gcProcessCheckoutOrderCharged.subscribe((subscriber) => {
      this.performTracking(subscriber);
      this.setAppStateAfterCheckout(subscriber);
      this.setSession(this.appService.loginEmail, this.appService.sessionId, this.appService.accessToken, this.appService.customerId);
      this.setQuestionnaire(subscriber);
      this.clearIqFlowSession();
      if (this.questionnaireService.llc.brexPartnerOfferShown) {
        this.orderTagByIdForApiHandlerExp(PartnerOfferTagNames.LLC_Partner_Offer_Brex).subscribe();
      }

      if (this.questionnaireService.llc.bofaShown) {
        this.orderTagByIdForApiHandlerExp(PartnerOfferTagNames.LLC_Partner_Offer_BofA).subscribe();
      }

      if (this.questionnaireService.llc.toastPartnerOfferShown) {
        this.orderTagByIdForApiHandlerExp(PartnerOfferTagNames.LLC_Partner_Offer_Toast).subscribe();
      }

      if (this.questionnaireService.llc.squarePartnerOfferShown) {
        this.orderTagByIdForApiHandlerExp(PartnerOfferTagNames.LLC_Partner_Offer_Square).subscribe();
      }

      if (this.experimentService.isLLCTaxPilotTest_CTRL()
        || this.experimentService.isLLCTaxPilotTest_EXPA()
        || this.experimentService.isLLCTaxPilotTest_EXPB()) {
        this.orderTagByIdForApiHandlerExp(this.experimentsService.getExperimentName1()).subscribe();
      }

      if (this.experimentService.isLLCHolisticFlowV3()) {
        this.orderTagByIdForApiHandlerExp('RYO_Checkout_Test_Ctrl').subscribe();
      }

    });

    this.gcCheckoutService.gcUserSessionUpdated.subscribe((res) => {
      console.log('user session updated');
      this.updateAppState(res);
    });

    this.gcCheckoutService.paymentResponse.subscribe((r: any) => {
      if (r) {
        this.updatePaymentState(r.paymentByProfile);
      }
    });

    this.gcCrossSellService.gcProcessCrossSellOrderCharged.subscribe((subscriber) => {
      this.appService.crossSellOrderResponse = subscriber.crossSellOrder;
      this.eventService.saveAndContinue(PagePath.Checkout);
    });
  }

  private updatePaymentState(payment: Payment) {
    const appState = this.appService.app;
    appState.payment = payment;
    this.appService.app = appState;
  }

  private setSession(loginEmail, sessionId, accessToken, customerId) {
    const isGuest = this.customerService.isGuestCustomer(loginEmail);

    this.utilitiesService.saveCookies(sessionId, accessToken, customerId, isGuest);
  }

  private updateAppState(response): void {
    const appState = this.appService.app;
    appState.customerId = response.userId;
    appState.loginEmail = response.loginEmail;
    appState.sessionId = response.sessionId;
    appState.accessToken = response.accessToken;
    appState.processingOrderId = response.processingOrderId;

    this.setSession(appState.loginEmail, appState.sessionId, appState.accessToken, appState.customerId);

    if (response.cart) {
      appState.cartId = response.cart.cartId;
    }
    this.appService.app = appState;
    if (response.isSignInFromCheckout) {
      // If user is on checkout page and login with user who has store credit and press back button then RYO page should be refreshed with correct data from glo userCartService
      this.prepareCartService.saveAndRefreshCart();
    }
  }

  public performTracking(response) {
    const customerInfo = {
      isThreePay: response.isMultiPay,
      primaryContactInfo: {
        StateName: response.shippingContact.state,
        Zip: response.shippingContact.zip,
        Email1: response.shippingContact.email,
        FirstName: response.shippingContact.firstName,
        LastName: response.shippingContact.lastName
      }
    };
    const orderInfo = {
      OrderId: response.orderId
    };
    this.trackingService.SetECommerceTracking(customerInfo, orderInfo);
  }

  public setAppStateAfterCheckout(response: any) {
    this.appService.orderId = response.orderId;
    // In case of store credit, it displays incorrect total on Order Confirmation Page.
    // It Should rather display the actual cart total without deducting store credit.
    this.appService.amount = response.cartBalance.storeCreditAvailable > 0 ?
      (response.cartBalance.totalAmount + response.cartBalance.totalTax - response.cartBalance.totalDiscount)
      : response.isThreePay
        ? response.cartBalance.cartInstallments.firstInstallment.installmentAmount
        : response.cartBalance.cartBalance;
    this.appService.getCartBalanceByCartIdResponse = response.cartBalance;
    this.appService.paymentGateway = response.paymentProfile.gateway;
    this.appService.customerId = response.userId;
    this.appService.loginEmail = response.loginEmail;
    this.appService.sessionId = response.sessionId;
    this.appService.accessToken = response.accessToken;
    this.appService.paymentProfileId = response.paymentProfile.profileId;
    this.appService.isGuestConvertedOnCheckout = response.isGuestConvertedOnCheckout;
    this.appService.firstName = response.shippingContact.firstName;
    this.appService.lastName = response.shippingContact.lastName;
    this.appService.cart = response.cart;
  }

  private setQuestionnaire(response: any) {
    this.questionnaireService.llc.orderId = response.orderId;
    this.questionnaireService.llc.checkoutEmail = response.loginEmail;
    this.questionnaireService.llc.is3Pay = response.isThreePay;

    this.questionnaireService.llc.businessAddress.address1 = response.shippingContact.addressLine1;
    this.questionnaireService.llc.businessAddress.address2 = response.shippingContact.addressLine2;
    this.questionnaireService.llc.businessAddress.city = response.shippingContact.city;
    this.questionnaireService.llc.businessAddress.state = response.shippingContact.state;
    this.questionnaireService.llc.businessAddress.zipCode = response.shippingContact.zipcode;
    this.questionnaireService.llc.businessAddress.county = response.shippingContact.county;
    this.questionnaireService.llc.contactPhone = response.shippingContact.homePhone;
  }

  public getCartInstallment(cartInstallments: any): number {
    const installmentFee = 2;

    if (cartInstallments) {
      const prices = [cartInstallments.firstInstallment.installmentAmount, cartInstallments.secondInstallment.installmentAmount, cartInstallments.thirdInstallment.installmentAmount];
      return Math.max(...prices) + installmentFee;
    }

    return 0;
  }

  public mapCartItems(cartItems: any) {
    const items: CartItem[] = [];
    cartItems.forEach((c) => {
      const item: CartItem = {
        amount: c.extendedPrice,
        description: c.productName,
        details: c.productName,
        productConfigurationId: c.productConfigurationId,
        title: c.productName,
        type: c.productTypeId,
        hideAmount: c.basePrice
      };
      items.push(item);
    });
    return items;
  }

  public orderTagByIdForApiHandlerExp(experimentName: string) {
    const tagOrderByIdRequest: ITagOrderByIdRequest = {
      tagType: TagType.system,
      tag: experimentName,
      createdBy: this.appService.customerId.toString()
    };
    return this.taggingService.tagOrderById(this.appService.orderId, tagOrderByIdRequest);
  }

  public getTaxConfig(): any {
    let taxConfig;
    if (this.questionnaireService.llc.taxPackageSelected) {
      const selectedTaxPackage = TaxPackages.find(x => x.productConfigurationId === this.questionnaireService.llc.taxPackageSelected);
      if (!selectedTaxPackage) {
        return;
      }
      taxConfig = {
        productConfigurationId: selectedTaxPackage.productConfigurationId,
        fieldAnswers: [
          {
            fieldName: 'sState',
            fieldValue: this.questionnaireService.llc.entityState
          }
        ],
        processId: ProcessId.LZTax,
        questionnaireId: QuestionnaireId.LZTax,
        productName: selectedTaxPackage.title,
        amount: selectedTaxPackage.amount,
        terms: selectedTaxPackage.terms,
        confirmationDisclaimer: selectedTaxPackage.confirmationDisclaimer
      };
    }
    return taxConfig;
  }

  public clearIqFlowSession() {
    const IQFlowSessionKey = 'sessionStore';
    // If session storage finds value for IQ_Flow_Session_Key than remove.
    if (sessionStorage.getItem(IQFlowSessionKey)){
      sessionStorage.removeItem(IQFlowSessionKey);
    };    
  }

  public setGlobalCheckoutObject() {
    const llcAppState = JSON.parse(sessionStorage.getItem(SessionStorageType.APP) ? sessionStorage.getItem(SessionStorageType.APP) : '{}');
    const taxConfig = this.getTaxConfig();
    const globalCheckoutObject: GCPageInput = {
      userId: (llcAppState.customerId) ? llcAppState.customerId : 0,
      loginEmail: (llcAppState.loginEmail) ? llcAppState.loginEmail : '',
      cartId: (llcAppState.cartId) ? llcAppState.cartId : 0,
      processingOrderId: (llcAppState.processingOrderId) ? llcAppState.processingOrderId : 0,
      accessToken: (llcAppState.accessToken) ? llcAppState.accessToken : '',
      primaryContact: {
        email: this.questionnaireService.llc.customerEmail ? this.questionnaireService.llc.customerEmail : '',
        phone: this.questionnaireService.llc.customerPhoneNumber ? this.questionnaireService.llc.customerPhoneNumber : '',
      },
      professionalPrintComponents: [ProductComponentId.economyLLCPackage],
      desktopPhoneNumber: '8557730887',
      mobilePhoneNumber: '8557871237',
      partnerOfferConfigId: [ProductConfigurationIds.smallBusinessBankingConsultation, 
      ProductConfigurationIds.brexPartnerOffer],
      isSetPasswordEnabled: true
    };

    if (taxConfig) {
      globalCheckoutObject.crossSellConfig = taxConfig;
    }
    return globalCheckoutObject;
  }
}
