import { TestBed, inject } from '@angular/core/testing';

import { ErrorLoggingService } from './error-logging.service';
import { WindowRef } from './windowRef.service';
declare global {
  interface Window {
    nativeWindow: any;
  }
}

// TODO: fix tests
xdescribe('ErrorLoggingService', () => {
  let service: ErrorLoggingService;
  beforeEach(() => {
    window.nativeWindow = window.nativeWindow || {
      trackJs: {
        track() { },
        addMetadata() {},
        removeMetadata() {}
      }
    };
    TestBed.configureTestingModule({
      providers: [ErrorLoggingService,
        { provide: WindowRef, useValue: window }
      ],
    });
    service = TestBed.get(ErrorLoggingService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  it('trackError should be defined ', () => {
    expect(service.trackError).toBeDefined();
  });
  it('setMetadata should be defined ', () => {
    expect(service.setMetadata).toBeDefined();
  });
  it('removeMetadata should be defined ', () => {
    expect(service.removeMetadata).toBeDefined();
  });
  it('should call window.trackJs.track ', () => {
    const mockwindow = TestBed.get(WindowRef);
    spyOn(mockwindow.nativeWindow.trackJs, 'track');
    service.trackError('test');
    expect(mockwindow.nativeWindow.trackJs.track).toHaveBeenCalled();
  });
  it('should call window.trackJs.addMetadata ', () => {
    const mockwindow = TestBed.get(WindowRef);
    spyOn(mockwindow.nativeWindow.trackJs, 'addMetadata');
    service.setMetadata('test', 'test');
    expect(mockwindow.nativeWindow.trackJs.addMetadata).toHaveBeenCalled();
  });
  it('should call window.trackJs.removeMetadata ', () => {
    const mockwindow = TestBed.get(WindowRef);
    spyOn(mockwindow.nativeWindow.trackJs, 'removeMetadata');
    service.removeMetadata('test');
    expect(mockwindow.nativeWindow.trackJs.removeMetadata).toHaveBeenCalled();
  });
});
