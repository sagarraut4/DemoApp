import { Injectable } from '@angular/core';
import { Router, NavigationStart, NavigationCancel } from '@angular/router';
import { Location } from '@angular/common';
import { Chapter } from '../models/page-model';

@Injectable()
export class BackButtonService {
  public backButtonClicked = false;
  private routesHistory: Array<string> = [];

  constructor(
    private location: Location,
    private router: Router,
  ) { }

  public verifyRoute(path: string): boolean {
    if (this.backButtonClicked && path.substring(0, Chapter.PostOrder.length + 2) === `/${Chapter.PostOrder}/`) {
      return false;
    } else {
      return true;
    }
  }

  public init() {
    this.router.events.subscribe(events => {
      if (events instanceof NavigationStart) {
        const lastPage = this.routesHistory[this.routesHistory.length - 2];

        if (events.url === lastPage) {
          this.backButtonClicked = true;
        } else {
          this.backButtonClicked = false;
          this.routesHistory.push(events.url);
        }
      }

      if (events instanceof NavigationCancel) {
        // due to an angular bug, we have to fix the browser's history
        this.location.replaceState(events.url);
        this.location.forward();
      }
    });
  }
}
