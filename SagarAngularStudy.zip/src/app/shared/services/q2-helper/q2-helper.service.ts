import { Injectable } from '@angular/core';
import { AbstractControl, FormControl, FormGroup, ValidationErrors, ValidatorFn } from '@angular/forms';
import { WindowRef } from '../windowRef.service';
import * as moment from 'moment-timezone';
import { ConstantsService } from '../constants.service';
/** TODO: TO be removed with Q2 Rewrite
 * This exists to limit the code duplication without ultimately disrupting the pre existing logic
 */
@Injectable({
  providedIn: 'root'
})
export class Q2HelperService {

  // Match all LLC abbreviation combinations and full spelling
  // RegExps are case-insensitive, match at end of string
  public static businessDesignatorsRegExps: RegExp[] = [
    /L\.?L\.?C\.?$/i,
    /Limited\sLiability\sCompany$/i,
    / \.?I\.?N\.?C\.?$/i
  ];
  public constructor(private windowRef: WindowRef) {
  }

  /**
   * Form Control Validators
   */
  public static mustNotEqual(sourceValue: string): ValidatorFn {
    return (control: AbstractControl): ValidationErrors => {
      if (control.value === sourceValue) {
        return {
          mustNotEqual: `Must not match ${sourceValue}`
        };
      }

      return null;
    };
  }

  public static mustNotEndWithDesignator(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors => {
      if (control.value && this.hasBusinessDesignatorAtEndOfBusinessName(control.value.trim())) {
        return {
          mustNotEndWithDesignator: `Must not have business designator`
        };
      }

      return null;
    };
  }

  public static hasBusinessDesignatorAtEndOfBusinessName(businessName: string): boolean {
    return this.businessDesignatorsRegExps.some((businessDesignatorRegExp) => {
      return businessDesignatorRegExp.test(businessName.trim());
    });
  }

  /**
   * Form Group/Control Helpers
   */
  public static removeBusinessDesignator(control: FormControl): void {
    if (control.value) {
      // Prepare by removing all leading/trailing spaces
      let newValue = control.value.trim();

      for (const businessDesignatorExp of this.businessDesignatorsRegExps) {
        if (businessDesignatorExp.test(newValue)) {
          newValue = newValue.replace(businessDesignatorExp, '');
          break;
        }
      }
      newValue = newValue.trim();
      control.setValue(newValue);
    }
  }

  public static removeLLCBusinessDesignator(control: FormControl): void {
    if (control.value) {
      // Prepare by removing all leading/trailing spaces
      let newValue = control.value.trim();

      let isContainMessageDesignator=ConstantsService.RESTRICTED_BUSINESS_NAME_DESIGNATORS.filter(designator=>newValue.toLowerCase().includes(designator.toLowerCase()));
      if(isContainMessageDesignator !=null && isContainMessageDesignator.length>0){ 
        const newRegex = new RegExp(isContainMessageDesignator[0], "i");
        newValue=newValue.replace(newRegex,'');
      }
      newValue = newValue.trim();
      control.setValue(newValue);
    }
  }

  public isFieldInvalid = (formGroup: FormGroup, field: string): boolean => {
    const formControl: FormControl = formGroup.get(field) as FormControl;

    return (typeof (formControl) !== 'undefined') && (formControl !== null) &&
      formControl.invalid;
  };

  public isFieldNotEmpty = (formGroup: FormGroup, field: string): boolean => {
    const formControl: FormControl = formGroup.get(field) as FormControl;

    return (typeof (formControl) !== 'undefined') && (formControl !== null) &&
      (typeof (formControl.value) !== 'undefined') && (formControl.value !== null) &&
      formControl.value.toString().trim().length > 0;
  };

  /**
   * Helper Functions
   */
  public scrollWindowTo(self) {
    const top = (this.windowRef.nativeWindow.pageYOffset + self.getBoundingClientRect().top);

    if (!!this.windowRef.nativeWindow.MSInputMethodContext) { // is Edge / IE11
      this.windowRef.nativeWindow.scrollTo(0, top);
    } else if (self.scrollIntoView) {
      self.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } else {
      this.windowRef.nativeWindow.scrollTo({ top, behavior: 'smooth' });
    }
  };

  public getBusinessHour():boolean{
    const format='hh:mm a';
    const currentTime = moment(moment().tz('America/Los_Angeles').format(format), format);
    const startTime = moment('06:00 AM', format);
    const endTime = moment('06:00 PM', format);
    const currentDay=moment(moment().tz('America/Los_Angeles')).format('dddd');
    if(currentDay!=null && currentDay.toLowerCase()!='saturday' && currentDay.toLowerCase()!='sunday')
    return currentTime.isBetween(startTime, endTime);
    else
    return false;
  }
}
