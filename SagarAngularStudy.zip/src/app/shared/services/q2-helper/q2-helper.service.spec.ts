import { TestBed } from '@angular/core/testing';

import { Q2HelperService } from './q2-helper.service';
import { FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { WindowRef } from '../windowRef.service';

describe('Q2HelperService', () => {
  let service: Q2HelperService;
  let emptyFormGroup: FormGroup;
  let formGroup: FormGroup;
  let formControl: FormControl;
  const mockFormControlKey = 'mockKey';
  const mockFormControlValue = 'mockValue';
  const businessNameWithDesignators = [
    'Test Company LLC',
    'Test Company llc',
    'Test Company LL.C.',
    'Test Company ll.c.',
    'Test Company LLC.',
    'Test Company llc.',
    'Test Company LL.C.',
    'Test Company ll.c.',
    'Test Company LL.C.',
    'Test Company ll.c.',
    'Test Company L.LC',
    'Test Company l.lc',
    'Test Company L.L.C',
    'Test Company l.l.c',
    'Test Company Limited Liability Company',
    'Test Company limited liability company',
    'Test Company LLC '
  ];

  const businessNamesWithoutDesignators = [
    '',
    'Test Company',
    'Test Company liLAc',
    'Test Company Limited Liability Co.',
    'Test LLC Company'
  ];


  beforeEach(
    () => TestBed.configureTestingModule({
      providers: [
        WindowRef
      ]
    })
  );

  beforeEach(() => {
    service = TestBed.get(Q2HelperService);
    formGroup = new FormGroup(
      {
        mockKey: new FormControl(null, [Validators.required])
      }
    );
    emptyFormGroup = new FormGroup({});

    formControl = formGroup.get(mockFormControlKey) as FormControl;
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('Form Control Validators', () => {

    describe('[mustNotEqual] ', () => {
      const mockEndValue = 'endValue';
      const mockSourceValue = 'startValue';


      it('when not equal - should be valid', () => {
        // Arrange
        const validator: ValidatorFn = Q2HelperService.mustNotEqual(mockSourceValue);

        // Act
        formControl.setValidators(validator);
        formControl.setValue(mockEndValue);
        formControl.updateValueAndValidity();

        // Assert
        expect(formControl.valid).toBeTruthy();
      });

      it('when equal - it should not be valid', () => {
        // Arrange
        const validator: ValidatorFn = Q2HelperService.mustNotEqual(mockEndValue);

        // Act
        formControl.setValidators(validator);
        formControl.setValue(mockEndValue);
        formControl.updateValueAndValidity();

        // Assert
        expect(formControl.invalid).toBeTruthy();
        expect(formControl.errors.mustNotEqual).toContain('Must not match');
      });
    });

    describe('[mustNotEndWithDesignator]', () => {

      it('should return an error if form control value has business designator', () => {
        const validatorFn = Q2HelperService.mustNotEndWithDesignator();
        const testFormControl = new FormControl('Test Company LLC');
        const result = validatorFn(testFormControl);
        expect(result).toEqual({ mustNotEndWithDesignator: 'Must not have business designator' });
      });

      it('should return an error if form control value has business designator with space at end', () => {
        const validatorFn = Q2HelperService.mustNotEndWithDesignator();
        const testFormControl = new FormControl('Test Company LLC ');
        const result = validatorFn(testFormControl);
        expect(result).toEqual({ mustNotEndWithDesignator: 'Must not have business designator' });
      });

      it('should return null if form control value does not have business designator', () => {
        const validatorFn = Q2HelperService.mustNotEndWithDesignator();
        const testFormControl = new FormControl('Test Company');
        const result = validatorFn(testFormControl);
        expect(result).toEqual(null);
      });

    });

    describe('[hasBusinessDesignatorAtEndOfBusinessName] ', () => {

      businessNameWithDesignators.forEach((testBusinessName) => {
        it(`should detect business designator in business name: ${testBusinessName}`, () => {
          // Arrange

          // Act
          const result = Q2HelperService.hasBusinessDesignatorAtEndOfBusinessName(testBusinessName);
          // Assert
          expect(result).toBe(true);
        });
      });

      businessNamesWithoutDesignators.forEach((testBusinessName) => {
        it(`should not detect business designator in business name: ${testBusinessName}`, () => {
          // Arrange

          // Act
          const result = Q2HelperService.hasBusinessDesignatorAtEndOfBusinessName(testBusinessName);
          // Assert
          expect(result).toBe(false);
        });
      });

    });

  });

  describe('Form Group/Control Helpers', () => {

    describe('[removeBusinessDesignator] ', () => {

      businessNameWithDesignators.forEach((testBusinessName) => {
        it(`should remove business designator in business name: ${testBusinessName}`, () => {
          // Arrange
          const testFormControl = new FormControl(testBusinessName);

          // Act
          const result = Q2HelperService.removeBusinessDesignator(testFormControl);
          // Assert
          expect(testFormControl.value).toBe('Test Company');
        });
      });

      businessNamesWithoutDesignators.forEach((testBusinessName) => {
        it(`should not remove business designator in business name: ${testBusinessName}`, () => {
          // Arrange
          const testFormControl = new FormControl(testBusinessName);

          // Act
          Q2HelperService.removeBusinessDesignator(testFormControl);
          // Assert
          expect(testFormControl.value).toBe(testBusinessName);
        });
      });

    });

    describe('[isFieldInvalid] ', () => {
      it('should be falsy with an empty form group', () => {
        // Arrange

        // Act

        // Assert
        expect(service.isFieldInvalid(emptyFormGroup, mockFormControlKey)).toBeFalsy();
      });

      it('should be truthy if invalid', () => {
        // Arrange

        // Act

        // Assert
        expect(service.isFieldInvalid(formGroup, mockFormControlKey)).toBeTruthy();
      });

      it('should be falsy if valid', () => {
        // Arrange
        formControl.setValue(mockFormControlValue);

        // Act
        formControl.updateValueAndValidity();

        // Assert
        expect(service.isFieldInvalid(formGroup, mockFormControlKey)).toBeFalsy();
      });
    });

    describe('[isFieldNotEmpty] ', () => {
      it('should be falsy with an empty form group', () => {
        // Arrange

        // Act

        // Assert
        expect(service.isFieldNotEmpty(emptyFormGroup, mockFormControlKey)).toBeFalsy();
      });

      it('should be null if invalid', () => {
        // Arrange

        // Act

        // Assert
        expect(service.isFieldNotEmpty(formGroup, mockFormControlKey)).toBeFalsy();
      });

      it('should be falsy if the string is empty', () => {
        // Arrange
        formControl.setValue('');

        // Act

        // Assert
        expect(service.isFieldNotEmpty(formGroup, mockFormControlKey)).toBeFalsy();
      });

      it('should be truthy if not empty', () => {
        // Arrange
        formControl.setValue(mockFormControlValue);

        // Act

        // Assert
        expect(service.isFieldNotEmpty(formGroup, mockFormControlKey)).toBeTruthy();
      });
    });
  });

  describe('Helper functions', () => {

    describe('[scrollWindowTo] ', () => {
      it('should use native element.scrollIntoView', () => {
        // Arrange
        const el = document.body;
        spyOn(el, 'scrollIntoView');

        // Act
        service.scrollWindowTo(el);

        // Assert
        expect(el.scrollIntoView).toHaveBeenCalled();
      });
    });

  });
});
