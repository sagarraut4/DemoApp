import { WebSessionService } from '@legalzoom/web-session-sdk';
import { Injectable } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { TrackJsErrorLogService, IQueueEntry, UtilitiesService } from '@legalzoom/business-formation-sdk';
import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';
import { CookieService, CookieOptions } from 'ngx-cookie';
import { AppService } from '../state/app';
import { CookieName, ProductName } from '../constants/product-domain';
import { HelperService } from '@legalzoom/lib-checkout';
import { CustomerService } from '@legalzoom/customer-sdk';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  public currentToken: string;
  constructor(
    private webSessionService: WebSessionService,
    private appService: AppService,
    private cookieService: CookieService,
    private trackJS: TrackJsErrorLogService,
    private helperService: HelperService,
    private utilitiesService: UtilitiesService,
    private customerService: CustomerService
  ) { }

  getAuthToken() {
    return this.currentToken;
  }

  refreshToken(): Observable<string> {
    const app = this.appService.app;
    return this.webSessionService.createGuestCustomerAndSession().pipe(
      map((response) => {
        app.accessToken = response.session.accessToken;
        this.appService.app = app;

        this.refreshCheckoutToken(response.session.accessToken);

        return (this.currentToken = response.session.accessToken);
      })
    );
  }

  refreshCheckoutToken(token: string): void {
    this.helperService.updateToken(token);
  }

  prepareGetCustomerAndSession(authToken, customerId): IQueueEntry {
    return {
      name: 'prepareGetCustomerAndSession auth.service',
      // clearQueueOnError: false,
      pre: () => {
        return this.webSessionService.getCustomerAndSession('');
      },
      post: (response) => {
        const appState = this.appService.app;
        appState.customerId = response.customerId;
        appState.accessToken = response.session.find((s) => s.key === 'accessToken').value;
        appState.sessionId = response.session.find((s) => s.key === 'TIMESTRING').value;
        appState.loginEmail = response.session.find((s) => s.key === 'UserName').value;
        appState.jwtToken= response.session.find((s) => s.key === 'jwt') ? response.session.find((s) => s.key === 'jwt').value : '';
        const isGuest = this.customerService.isGuestCustomer(appState.loginEmail);

        this.utilitiesService.saveCookies(appState.sessionId, appState.accessToken, appState.customerId, isGuest);

        this.appService.app = appState;
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'auth.service', error);
        return of(null);
      }
    };
  }
}
