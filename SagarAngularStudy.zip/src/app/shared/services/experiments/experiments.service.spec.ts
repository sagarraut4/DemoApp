import { TestBed, inject } from '@angular/core/testing';
import { ExperimentsService } from './experiments.service';
import { CookieService } from 'ngx-cookie';
import { QuestionnaireService } from '../questionnaire/questionnaire.service';
import { LLC } from '../../models/questionnaire-model';
import { EnvironmentService } from '../environment.service';

describe('ExperimentsService', () => {
  let service: ExperimentsService;
  const mockCookieService = jasmine.createSpyObj(['get']);
  const mockEnvironmentService = jasmine.createSpyObj(['useGloTheme']);
  const mockQuestionnaireService = {
    llc: new LLC()
  };
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        ExperimentsService,
        { provide: CookieService, useValue: mockCookieService },
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: EnvironmentService, useValue: mockEnvironmentService }
      ]
    });
    service = TestBed.get(ExperimentsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should not return null GetBFunnelTestValue', () => {
    const result = service.GetBFunnelTestValue();
    expect(result).not.toBeNull();
  });

  it('should not return null GetBShowPriceTestValue', () => {
    const result = service.GetBShowPriceTestValue();
    expect(result).not.toBeNull();
  });

  it('should not return null GetBShowPriceTest1Value', () => {
    const result = service.GetBShowPriceTest1Value();
    expect(result).not.toBeNull();
  });

  it('should not return null GetBShowPriceTest1ValueForQ2Crosssells', () => {
    const result = service.GetBShowPriceTest1ValueForQ2Crosssells();
    expect(result).not.toBeNull();
  });
});
