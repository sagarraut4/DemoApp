import { Injectable } from '@angular/core';
import { CookieService } from 'ngx-cookie';
import { TaxPackages } from '../../models/tax-packages-model';
import { EnvironmentService } from '../environment.service';
import { QuestionnaireService } from '../questionnaire/questionnaire.service';

@Injectable()
export class ExperimentsService {
  private Experiments() {
    return {
      defaultValue: 'Null',
      LLC_ATTY_GUIDED_TEST_V2: {
        cookie_name: 'LLC_ATTY_GUIDED_TEST_V2',
        ctrl: 'LLC_ATTY_GUIDED_TEST_V2_CTRL',
        expa: 'LLC_ATTY_GUIDED_TEST_V2_EXPA',
        notintest: 'LLC_ATTY_GUIDED_TEST_V2_NOT_IN_TEST'
      },
      LLC_TAX_PILOT_TEST: {
        cookie_name: 'LLC_TSA_THROTTLE_TEST',
        ctrl: 'LLC_TSA_THROTTLE_CONTROL',
        expa: 'LLC_TSA_THROTTLE_EXPERIMENT',
        expb: 'LLC_TSA_THROTTLE_NO_TSA',
        notintest: 'LLC_TSA_THROTTLE_TEST_NOT_IN_TEST'
      },      
      LZ_LLC_HOLISTIC_FLOW_V3: {
        cookie_name: 'LZ_LLC_HOLISTIC_FLOW_V3',
        ctrl: 'LZ_LLC_HOLISTIC_FLOW_V3_CTRL'
      },
      llcSimpleSub: {
        cookie_name: 'test_segment_SimpleSub'
      },
      llcLeadWithFree: {
        cookie_name: 'test_segment_LeadWithFree'
      },
      llcFreePre: {
        cookie_name: 'test_segment_llc_freemium_premium'
      },
    };
  }

  constructor(private environmentService: EnvironmentService, private cookieService: CookieService, private questionnaireService: QuestionnaireService) { }

  // Commenting this out first before removing it completely
  public GetBFunnelTestValue() {
    return this.Experiments().defaultValue;
  }

  public GetBShowPriceTest1Value() {
    // Tax Pilot Test - B-58124
    if (
      this.questionnaireService.llc.bShowPriceTest1 &&
      (this.questionnaireService.llc.bShowPriceTest1 === this.Experiments().LLC_TAX_PILOT_TEST.ctrl
        || this.questionnaireService.llc.bShowPriceTest1 === this.Experiments().LLC_TAX_PILOT_TEST.expa
        || this.questionnaireService.llc.bShowPriceTest1 === this.Experiments().LLC_TAX_PILOT_TEST.expb)
    ) {
      return this.questionnaireService.llc.bShowPriceTest1;
    }
    return this.cookieService.get(this.Experiments().LLC_TAX_PILOT_TEST.cookie_name) ? this.cookieService.get(this.Experiments().LLC_TAX_PILOT_TEST.cookie_name) : 'Null';
  }

  public GetTsaTestValue() {
    this.questionnaireService.llc.bShowPriceTest1 = this.GetBShowPriceTest1Value();
    const taxPackage = TaxPackages.find(tp => tp.productConfigurationId === this.questionnaireService.llc.taxPackageSelected);
    this.questionnaireService.llc.bShowPriceTest1 = taxPackage ? 'LLC_TSA_THROTTLE_NO_TSA' : 'LLC_TSA_THROTTLE_EXPERIMENT';
    return this.questionnaireService.llc.bShowPriceTest1;
  }

  public GetBShowPriceTest1ValueForQ2Crosssells() {
    if (
      this.questionnaireService.llc.bShowPriceTest1 &&
      (this.questionnaireService.llc.bShowPriceTest1 === this.Experiments().LLC_TAX_PILOT_TEST.ctrl
        || this.questionnaireService.llc.bShowPriceTest1 === this.Experiments().LLC_TAX_PILOT_TEST.expa
        || this.questionnaireService.llc.bShowPriceTest1 === this.Experiments().LLC_TAX_PILOT_TEST.expb)
    ) {
      return this.questionnaireService.llc.bShowPriceTest1;
    }
    return this.Experiments().defaultValue;
  }

  /**
   * Functions used for checking which experiment is currently active
   */
  
  public isE2EZeroPriceTest_ExpA(): boolean {
    return false;
  }

  public isLLCTaxPilotTest_CTRL(): boolean {
    return CookieService.prototype.get('LLC_TSA_THROTTLE_TEST') === this.Experiments().LLC_TAX_PILOT_TEST.ctrl;
  }

  public isLLCTaxPilotTest_EXPA(): boolean {
    return CookieService.prototype.get('LLC_TSA_THROTTLE_TEST') === this.Experiments().LLC_TAX_PILOT_TEST.expa;
  }

  public isLLCTaxPilotTest_EXPB(): boolean {
    return CookieService.prototype.get('LLC_TSA_THROTTLE_TEST') === this.Experiments().LLC_TAX_PILOT_TEST.expb;
  }

  public isLLCHolisticFlowV3(): boolean {
    return this.cookieService.get(this.Experiments().LZ_LLC_HOLISTIC_FLOW_V3.cookie_name) === this.Experiments().LZ_LLC_HOLISTIC_FLOW_V3.ctrl;
  }

  public isSimpleSub() {
    return this.cookieService.get(this.Experiments().llcSimpleSub.cookie_name) !== undefined;
  }

  public isLeadWithFree() {
    return this.cookieService.get(this.Experiments().llcLeadWithFree.cookie_name) !== undefined;
  }

  public isFreePre() {
    return this.cookieService.get(this.Experiments().llcFreePre.cookie_name) !== undefined;
  }

  public getExperimentName1(): string {
    if (
      this.questionnaireService.llc.bShowPriceTest1 &&
      (this.questionnaireService.llc.bShowPriceTest1 === this.Experiments().LLC_TAX_PILOT_TEST.ctrl
        || this.questionnaireService.llc.bShowPriceTest1 === this.Experiments().LLC_TAX_PILOT_TEST.expa
        || this.questionnaireService.llc.bShowPriceTest1 === this.Experiments().LLC_TAX_PILOT_TEST.expb)
    ) {
      return this.questionnaireService.llc.bShowPriceTest1;
    } else {
      return this.Experiments().LLC_TAX_PILOT_TEST.notintest;
    }
  }
  /** End Region */
}
