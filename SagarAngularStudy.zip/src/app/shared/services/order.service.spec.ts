import { environmentCommon } from './../../../environments/environment';
import { TestBed, async } from '@angular/core/testing';
import {
  TrackJsErrorLogService,
  QueueService
} from '@legalzoom/business-formation-sdk';
import { OrderService as SdkOrderService, OrderModule } from '@legalzoom/order-sdk';
import { OrderService } from './order.service';
import { ProductName } from '../constants/product-domain';
import { of, throwError } from 'rxjs';

describe('OrderService', () => {
  let service: OrderService;
  let mockSdkOrderService;
  let mockTrackJsErrorLogService;
  const mockAppService = {
    app: {
      orderId: 123
    }
  };
  beforeEach(() => {
    mockSdkOrderService = jasmine.createSpyObj(['getOrdersById']);
    mockTrackJsErrorLogService = jasmine.createSpyObj(['track']);
    TestBed.configureTestingModule({
      imports: [
        OrderModule.forRoot(environmentCommon)
      ],
      providers: [
        OrderService,
        { provide: SdkOrderService, useValue: mockSdkOrderService },
        { provide: TrackJsErrorLogService, useValue: mockTrackJsErrorLogService },
        QueueService
      ]
    });
    service = TestBed.get(OrderService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('getOrdersById should be called', async(() => {
    mockSdkOrderService.getOrdersById.and.returnValue(of({
      order: {
        orderId: 123
      }
    }));
    const mockQueueService = TestBed.get(QueueService);
    mockQueueService.add(service.prepareGetOrderById(service, mockAppService, 123, 123, 'test', ProductName.LLC));
    mockQueueService.process().subscribe();
    expect(mockSdkOrderService.getOrdersById).toHaveBeenCalled();
  }));
  it('should trackJs.track if "getOrdersById" function fails', () => {
    mockSdkOrderService.getOrdersById.and.returnValue(throwError({ message: 'error' }));
    const mockQueueService = TestBed.get(QueueService);
    mockQueueService.add(service.prepareGetOrderById(service, mockAppService, 123, 123, 'test', ProductName.LLC));
    mockQueueService.process().subscribe();
    expect(mockTrackJsErrorLogService.track).toHaveBeenCalled();
  });
});
