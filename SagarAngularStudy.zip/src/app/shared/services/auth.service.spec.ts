import { TestBed } from '@angular/core/testing';

import { AuthService } from './auth.service';
import { HttpClient } from '@angular/common/http';
import { AppService } from '../state/app';
import { CookieService } from 'ngx-cookie';
import { EnvironmentService } from './environment.service';
import { WebSessionService } from '@legalzoom/web-session-sdk';
import { CustomerService } from '@legalzoom/customer-sdk';
import { UtilitiesService } from '@legalzoom/business-formation-sdk';

describe('AuthService', () => {
  const mockWebSessionService = jasmine.createSpyObj(['createGuestCustomerAndSession', 'getCustomerAndSession']);
  const mockAppService = jasmine.createSpyObj(['app']);
  const mockCookieService = jasmine.createSpyObj(['get', 'check', 'getAll', 'set', 'delete']);
  const mockEnvironmentService = jasmine.createSpyObj(['getTealiumConfig']);
  const mockHttpClient = jasmine.createSpyObj(['get', 'post', 'put', 'delete']);
  const mockCustomerService = jasmine.createSpyObj(['getOptionsWithCustomerAndToken', 'isGuestCustomer', 'getCustomerInfo', 'forgetPassword']);
  const mockUtilitiesService = jasmine.createSpyObj(['saveCookies']);

  beforeEach(() => TestBed.configureTestingModule({
    providers: [
      { provide: HttpClient, useValue: mockHttpClient },
      { provide: WebSessionService, useValue: mockWebSessionService },
      { provide: AppService, useValue: mockAppService },
      { provide: CookieService, useValue: mockCookieService },
      { provide: EnvironmentService, useValue: mockEnvironmentService },
      { provide: EnvironmentService, useValue: mockEnvironmentService },
      { provide: CustomerService, useValue: mockCustomerService },
      { provide: UtilitiesService, useValue: mockUtilitiesService }
    ]
  }));

  it('should be created', () => {
    const service: AuthService = TestBed.get(AuthService);
    expect(service).toBeTruthy();
  });
});
