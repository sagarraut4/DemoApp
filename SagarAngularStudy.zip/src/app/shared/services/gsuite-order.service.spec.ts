import { ProcessingOrderService } from '@legalzoom/processing-order-sdk';
import { LLC } from 'src/app/shared/models/questionnaire-model';
import { AppService } from './../state/app/app.service';
import {
  QueueService, TrackJsErrorLogService
} from '@legalzoom/business-formation-sdk';
import { TaggingService, ITagOrderByIdResponse } from '@legalzoom/tagging-sdk';
import { EmailNotificationService, IEmailHandlerResponse } from '@legalzoom/notification-sdk';
import { of, throwError } from 'rxjs';
import { ProductDefinitionService } from './product-definition/product-definition.service';
import { QuestionnaireService } from './questionnaire/questionnaire.service';
import { ResellerService } from '@legalzoom/reseller-sdk';
import { OrderService, ICreateCrossSellOrderResponse, IGetOrderContactResponse, ICreateOrderContactResponse, IProcessingOrderQueueResponse } from '@legalzoom/order-sdk';
import { GsuiteOrderService } from './gsuite-order.service';
import { TestBed, async } from '@angular/core/testing';
import { WindowRef } from './windowRef.service';
import { PaymentService, ICreatePaymentResponse } from '@legalzoom/payment-sdk';

describe('GsuiteOrderService', () => {
  let service: GsuiteOrderService;
  let mockOrderService;
  let mockPaymentService;
  let mockEmailNotificationService;
  let mockProductDefinitionService;
  let mockResellerService;
  let mockTaggingService;
  let mockProcessingOrderService;
  const mockQuestionnaireService = {
    llc: new LLC()
  };
  const mockAppService = {
    currentView: '',
    loginEmail: '',
    orderId: 123,
    customerId: 123,
    accessToken: 'testingtoken',
    paymentProfileId: 123,
    paymentGateway: 5,
    app: {
      processingOrderId: 123,
      gSuiteCrossSellOrderResponse: { orderItem: { processingOrder: { processingOrderId: 123 } } },
    }
  };
  const mockTrackJsErrorLogService = jasmine.createSpyObj(['track']);
  const createCrossSellOrderResponse: ICreateCrossSellOrderResponse = {
    orderId: 32778305,
    orderItem: {
      orderId: 32778305,
      orderItemId: 54409585,
      parentOrderItemId: 54409547,
      stateId: 0,
      basePrice: 69,
      extendedPrice: 49,
      quantity: 1,
      productConfiguration: {
        productConfigurationId: 6399,
        productTypeId: '9',
        shouldDisplayOnBill: true,
        productComponent: {
          productComponentId: 1413,
          productComponentFlags: {
            allowCustomerToAdd: false,
            allowCustomizablePrice: false,
            allowExpediteOnPackage: false,
            allowStoreCredit: true,
            allowElectronicChecks: true,
            canSubscribe: false,
            canEditQuantity: false,
            autoRenewByDefault: false,
            mustAutoRenewToSubscribe: false,
            isService: false
          },
          name: 'Last Will and Testament Basic',
          displayNameOnBill: 'Basic Last Will and Testament',
          displayNameOnWeb: 'Last Will and Testament Basic',
          description: null,
          longDescription: null,
          internalDescription: null,
          isActive: true
        },
        isDefaultPackage: false,
        childProducts: [{}]
      },
      isCancelled: false,
      childOrderItems: [{}],
      processingOrder: {
        processId: 6,
        processingOrderId: 508064052,
        questionnaireId: 49,
        processingStatusId: 0,
        processingStatusCategoryId: 0,
        complete: false
      },
      productName: 'Last Will and Testament',
      isShipped: false,
      shipMethodId: null,
      lineNumber: 1,
      dateCreated: '2019-02-20T16:58:53.323Z',
      createdBy: '12329191',
      dateLastModified: '2019-02-20T16:58:53.323Z',
      lastModifiedBy: '12329191'
    }
  };

  const getOrderContactResponse: IGetOrderContactResponse = {
    contacts: [
      {
        orderContactId: 42693842,
        contactType: 'Primary',
        firstName: 'Test',
        lastName: 'Test',
        addressLine1: '101 N Brand Blvd',
        addressLine2: null,
        city: 'Glendale',
        state: 'California',
        county: null,
        zipCode: '91203',
        emailAddresses: [
          {
            emailAddress: 'lm2202019_7@lz.com'
          }
        ],
        homePhone: '(333) 333-3333',
        workPhone: '',
        mobilePhone: '',
        faxPhone: null,
        country: null,
        stateId: 5,
        dateCreated: new Date('2019-02-20T16:55:29.567Z'),
        createdBy: 'AWSStepFunction',
        dateLastModified: new Date('2019-02-20T16:55:29.567Z'),
        lastModifiedBy: null
      },
      {
        orderContactId: 42693843,
        contactType: 'Shipping',
        firstName: 'Test',
        lastName: 'Test',
        addressLine1: '101 N Brand Blvd',
        addressLine2: null,
        city: 'Glendale',
        state: 'California',
        county: null,
        zipCode: '91203',
        emailAddresses: [
          {
            emailAddress: 'lm2202019_7@lz.com'
          }
        ],
        homePhone: '(333) 333-3333',
        workPhone: '',
        mobilePhone: '',
        faxPhone: null,
        country: null,
        stateId: 5,
        dateCreated: new Date('2019-02-20T16:55:29.567Z'),
        createdBy: 'AWSStepFunction',
        dateLastModified: new Date('2019-02-20T16:55:29.567Z'),
        lastModifiedBy: null
      },
      {
        orderContactId: 42693844,
        contactType: 'Billing',
        firstName: 'Test',
        lastName: 'Test',
        addressLine1: '101 N Brand Blvd',
        addressLine2: null,
        city: 'Glendale',
        state: 'California',
        county: null,
        zipCode: '91203',
        emailAddresses: [
          {
            emailAddress: 'lm2202019_7@lz.com'
          }
        ],
        homePhone: '(333) 333-3333',
        workPhone: '',
        mobilePhone: '',
        faxPhone: null,
        country: null,
        stateId: 5,
        dateCreated: new Date('2019-02-20T16:55:29.567Z'),
        createdBy: 'AWSStepFunction',
        dateLastModified: new Date('2019-02-20T16:55:29.567Z'),
        lastModifiedBy: null
      }
    ]
  };

  const createPaymentResponse: ICreatePaymentResponse = {
    paymentTransactionId: 34719743,
    orderId: 32778303,
    transactionType: '1',
    paymentType: '1',
    amount: 49,
    currencyCode: 'USD',
    creationDate: '2019-02-21T00:56:40.6159002Z',
    createdBy: '12329191',
    transactionStatus: '3',
    statusDate: '2019-02-21T00:56:40.6159002Z',
    parentId: 0,
    customerId: '12329191',
    comments: 'Express Order',
    reasonId: '1',
    reasonText: 'Payment From Website',
    paymentProfileId: 27957350,
    gateway: '8',
    canceled: false,
    cancelationDate: '0001-01-01T00:00:00Z',
    source: '100',
    manualCheckId: null,
    notificationEmail: 'lm2202019_7@lz.com'
  };

  const tagOrderResponse: ITagOrderByIdResponse = {
    orderTag: {
      tagId: 33337,
      tagType: '1',
      tag: 'inc_crosssell_tms_federal_99',
      dateCreated: '2019-02-19T14:19:26.613Z',
      createdBy: '12321213',
      dateUpdated: '2019-02-21T00:56:50.9288196Z',
      updatedBy: '12321213'
    }
  };

  const createOrderContactRespose: ICreateOrderContactResponse = {
    orderContact: [{
      orderContactId: 42693847,
      contactType: 'Primary',
      firstName: 'Test',
      lastName: 'Test',
      addressLine1: '101 N Brand Blvd',
      addressLine2: null,
      city: 'Glendale',
      state: 'California',
      county: null,
      zipCode: '91203',
      emailAddresses: [
        {
          emailAddress: 'lm2202019_7@lz.com'
        }
      ],
      homePhone: '(333) 333-3333',
      workPhone: '',
      mobilePhone: '',
      faxPhone: 'null',
      country: 'null',
      stateId: 5,
      dateCreated: new Date('2019-02-21T00:56:51.3507114Z'),
      createdBy: 'AWSStepFunction',
      dateLastModified: new Date('2019-02-21T00:56:51.3507114Z'),
      lastModifiedBy: 'AWSStepFunction'
    }]
  };

  const emailHandlerResponse: IEmailHandlerResponse = {
    Message: 'Success',
    StatusCode: '200'
  };

  const processingOrderResponse: IProcessingOrderQueueResponse = {
    processingOrderQueue: {
      processingOrderQueueId: 1,
      processingOrderId: 123,
      isRevision: false,
      orderItemId: 131,
      dateCreated: '25/09/2020'
    }
  }

  beforeEach(() => {
    mockOrderService = jasmine.createSpyObj(['createCrossSellOrder', 'getOrderContact', 'createOrderContact']);
    mockPaymentService = jasmine.createSpyObj(['createPayment']);
    mockEmailNotificationService = jasmine.createSpyObj(['sendEmailNotification']);
    mockProductDefinitionService = jasmine.createSpyObj(['getGSuitePackages']);
    mockResellerService = jasmine.createSpyObj(['createProratedPayment']);
    mockTaggingService = jasmine.createSpyObj(['tagOrderById']);
    mockProcessingOrderService = jasmine.createSpyObj(['updateProcessingOrder', 'updateProcessingStatus']);
    TestBed.configureTestingModule({
      providers: [
        GsuiteOrderService,
        { provide: AppService, useValue: mockAppService },
        { provide: WindowRef, useValue: window },
        QueueService,
        { provide: OrderService, useValue: mockOrderService },
        { provide: TrackJsErrorLogService, useValue: mockTrackJsErrorLogService },
        { provide: PaymentService, useValue: mockPaymentService },
        { provide: EmailNotificationService, useValue: mockEmailNotificationService },
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: TaggingService, useValue: mockTaggingService },
        { provide: ResellerService, useValue: mockResellerService },
        { provide: ProductDefinitionService, useValue: mockProductDefinitionService },
        { provide: ProcessingOrderService, useValue: mockProcessingOrderService }
      ]
    });
    service = TestBed.get(GsuiteOrderService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should complete all steps for create GSuit order', async(() => {
    mockOrderService.createCrossSellOrder.and.returnValue(of(createCrossSellOrderResponse));
    mockOrderService.getOrderContact.and.returnValue(of(getOrderContactResponse));
    mockOrderService.createOrderContact.and.returnValue(of(createOrderContactRespose));
    mockResellerService.createProratedPayment.and.returnValue(of(null));
    mockPaymentService.createPayment.and.returnValue(of(createPaymentResponse));
    mockTaggingService.tagOrderById.and.returnValue(of(tagOrderResponse));
    mockEmailNotificationService.sendEmailNotification.and.returnValue(of(emailHandlerResponse));
    mockProcessingOrderService.updateProcessingOrder.and.returnValue(of(processingOrderResponse));
    mockProcessingOrderService.updateProcessingStatus.and.returnValue(of(processingOrderResponse));
    service.loadQueueForCrossSellOrder('', 2, 12);
    const queueService = TestBed.get(QueueService);
    queueService.process().subscribe();
    expect(mockOrderService.createCrossSellOrder).toHaveBeenCalled();
    expect(mockOrderService.getOrderContact).toHaveBeenCalled();
    expect(mockOrderService.createOrderContact).toHaveBeenCalled();
    expect(mockTaggingService.tagOrderById).toHaveBeenCalled();
    expect(mockResellerService.createProratedPayment).toHaveBeenCalled();
    expect(mockPaymentService.createPayment).toHaveBeenCalled();
    expect(mockEmailNotificationService.sendEmailNotification).toHaveBeenCalled();
    expect(mockProcessingOrderService.updateProcessingOrder).toHaveBeenCalled();
    expect(mockProcessingOrderService.updateProcessingStatus).toHaveBeenCalled();
  }));

  it('should return "createCrossSellOrder" if createCrossSellsOrder_CrossSell function fails', async(() => {
    mockOrderService.createCrossSellOrder.and.returnValue(throwError({ message: 'error' }));
    mockOrderService.getOrderContact.and.returnValue(throwError({ message: 'error' }));
    const appService = TestBed.get(AppService);
    service.loadQueueForCrossSellOrder('', 2, 12);
    const queueService = TestBed.get(QueueService);
    queueService.process().subscribe();
    expect(mockOrderService.createCrossSellOrder).toHaveBeenCalled();
    expect(mockOrderService.getOrderContact).toHaveBeenCalled();
    expect(mockPaymentService.createPayment).not.toHaveBeenCalled();
  }));

  it('should stop calling methods after "createProratedPayment" if createProratedPayment function fails', async(() => {
    mockOrderService.createCrossSellOrder.and.returnValue(of(createCrossSellOrderResponse));
    mockOrderService.getOrderContact.and.returnValue(of(getOrderContactResponse));
    mockOrderService.createOrderContact.and.returnValue(of(createOrderContactRespose));
    mockResellerService.createProratedPayment.and.returnValue(throwError({ message: 'error' }));
    mockPaymentService.createPayment.and.returnValue(of(null));
    service.loadQueueForCrossSellOrder('', 2, 12);
    const queueService = TestBed.get(QueueService);
    queueService.process().subscribe();
    expect(mockOrderService.createCrossSellOrder).toHaveBeenCalled();
    expect(mockOrderService.getOrderContact).toHaveBeenCalled();
    expect(mockOrderService.createOrderContact).toHaveBeenCalled();
    expect(mockResellerService.createProratedPayment).toHaveBeenCalled();
    expect(mockPaymentService.createPayment).not.toHaveBeenCalled();
  }));

  it('should stop calling methods after "createBillOrder_crossSell" if createBillOrder_CrossSell function fails', async(() => {
    mockOrderService.createCrossSellOrder.and.returnValue(of(createCrossSellOrderResponse));
    mockOrderService.getOrderContact.and.returnValue(of(getOrderContactResponse));
    mockOrderService.createOrderContact.and.returnValue(of(createOrderContactRespose));
    mockResellerService.createProratedPayment.and.returnValue(of(null));
    mockPaymentService.createPayment.and.returnValue(throwError({ message: 'error' }));
    service.loadQueueForCrossSellOrder('', 2, 12);
    const queueService = TestBed.get(QueueService);
    queueService.process().subscribe();
    expect(mockOrderService.createCrossSellOrder).toHaveBeenCalled();
    expect(mockOrderService.getOrderContact).toHaveBeenCalled();
    expect(mockOrderService.createOrderContact).toHaveBeenCalled();
    expect(mockResellerService.createProratedPayment).toHaveBeenCalled();
    expect(mockPaymentService.createPayment).toHaveBeenCalled();
    expect(mockTaggingService.tagOrderById).not.toHaveBeenCalled();
  }));
});
