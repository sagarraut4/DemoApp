import { TestBed } from '@angular/core/testing';
import { QuestionnaireService as LLCQuestionnaireService } from './questionnaire/questionnaire.service';
import { AppInitializationService } from './app-initialization.service';
import { AppService } from '../state/app';
import { EnvironmentService } from './environment.service';
import { TrackJsErrorLogService, QueueService } from '@legalzoom/business-formation-sdk';
import { AuthService } from './auth.service';
import { UserCartService } from '../../pl-features/glo-design/shared/services/user-cart.service';
import { Router, RouterEvent } from '@angular/router';
import { UtilityService } from './utility.service';
import { TrackSEMDataService } from './tracking/track-sem-data.service';
import { CookieService } from 'ngx-cookie';
import { ReplaySubject } from 'rxjs';
import { ProcessingOrderService } from './processing-order.service';
import { QuestionnaireAnswerService } from './questionnaire-answer.service';
import { OrderService } from './order.service';
import { ExperimentsService } from './experiments/experiments.service';
import { FeatureFlagService } from './feature-flag/feature-flag.service';
import { CookieName } from '../constants/product-domain';

describe('AppInitializationService', () => {
  let service: AppInitializationService;
  const app = {
    customerId: undefined,
    accessToken: undefined,
    processingOrderId: undefined,
    cartId: undefined
  };
  let mockAppService = {
    customerId: undefined,
    app: {}
  };
  const mockAuthService = jasmine.createSpyObj(['refreshToken', 'prepareGetCustomerAndSession']);
  const mockProcessingOrderService = jasmine.createSpyObj(['createProcessingOrderQueue',
    'updateProcessingOrder', 'prepareGetProcessingOrderById']);
  const mockOrderService = jasmine.createSpyObj(['prepareGetOrderById']);
  const mockCookieService = jasmine.createSpyObj(['get']);
  const mockQuestionnaireAnswerService = jasmine.createSpyObj(['saveAndGetMappedUserAnswers', 'prepareGetUserAnswers', 'prepareDeleteQuestionnaireAnswers']);
  const mockEnvironmentService = jasmine.createSpyObj(['getTimestringCookie']);
  const mockLLCQuestionnaireService = jasmine.createSpyObj(['prepareGetQuestionnaireStorage']);
  const mockQueueService = jasmine.createSpyObj(['add', 'process']);
  const mockUserCartService = jasmine.createSpyObj(['prepareGetCartById']);
  const mockUtilityService = jasmine.createSpyObj(['getAuthTokenConsultationCookie', 'getCustomerIdConsultationCookie',
    'getIntParamFromQueryString', 'getStringParamFromQueryString', 'clearAppState']);
  const mockExperimentsService = jasmine.createSpyObj(['getGloDesignTest']);
  const mockTrackSEMDataService = jasmine.createSpyObj(['setSEMCookies']);
  const mockTrackJsErrorLogService = jasmine.createSpyObj(['track']);
  const eventSubject = new ReplaySubject<RouterEvent>(1);
  let mockRouter;
  const mockFeatureFlagService = { bofaSquareEnabled: true }
  beforeEach(() => {
    mockRouter = {
      navigate: jasmine.createSpy('navigate'),
      events: eventSubject.asObservable(),
      url: '/name/state'
    };
    mockAppService.app = app;
    TestBed.configureTestingModule({
      providers: [
        AppInitializationService,
        { provide: AppService, useValue: mockAppService },
        { provide: EnvironmentService, useValue: mockEnvironmentService },
        { provide: TrackJsErrorLogService, useValue: mockTrackJsErrorLogService },
        { provide: AuthService, useValue: mockAuthService },
        { provide: ProcessingOrderService, useValue: mockProcessingOrderService },
        { provide: UserCartService, useValue: mockUserCartService },
        { provide: OrderService, useValue: mockOrderService },
        { provide: Router, useValue: mockRouter },
        { provide: LLCQuestionnaireService, useValue: mockLLCQuestionnaireService },
        { provide: QuestionnaireAnswerService, useValue: mockQuestionnaireAnswerService },
        { provide: UtilityService, useValue: mockUtilityService },
        { provide: TrackSEMDataService, useValue: mockTrackSEMDataService },
        { provide: CookieService, useValue: mockCookieService },
        { provide: ExperimentsService, useValue: mockExperimentsService },
        { provide: QueueService, useValue: mockQueueService },
        { provide: FeatureFlagService, useValue: mockFeatureFlagService }
      ]
    });
    service = TestBed.get(AppInitializationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should go in else condition to load name/state page but current path is same so should not call router.navigate', () => {
    mockCookieService.get.withArgs(CookieName.ACTIVESESSION).and.returnValue('true');
    mockUtilityService.getStringParamFromQueryString
      .withArgs('kid').and.returnValue(undefined)
      .withArgs('entity').and.returnValue('test');
    mockEnvironmentService.getTimestringCookie.and.returnValues('abcdTest');
    service.initializeApp('/name/state');
    expect(mockRouter.navigate).not.toHaveBeenCalled();
  });

  it('should go in else condition to load name/name-available page', () => {
    mockCookieService.get.withArgs(CookieName.ACTIVESESSION).and.returnValue('false');
    mockUtilityService.getStringParamFromQueryString
      .withArgs('kid').and.returnValue(undefined)
      .withArgs('state').and.returnValue('Ca')
      .withArgs('entity').and.returnValue(undefined)
      .withArgs('choose_later').and.returnValue(undefined);
    mockEnvironmentService.getTimestringCookie.and.returnValues('abcdTest');
    service.initializeApp('/name/business');
    expect(mockRouter.navigate).toHaveBeenCalled();
  });

  it('should call trackSemDataService setSEMCookies if querystring contains kid', () => {
    mockCookieService.get.withArgs(CookieName.ACTIVESESSION).and.returnValue('true');
    mockUtilityService.getStringParamFromQueryString
      .withArgs('kid').and.returnValue('test')
      .withArgs('state').and.returnValue('Ca')
      .withArgs('entity').and.returnValue(undefined)
      .withArgs('choose_later').and.returnValue(undefined);
    mockUtilityService.getAuthTokenConsultationCookie.and.returnValue(null);
    mockUtilityService.getCustomerIdConsultationCookie.and.returnValue(null);
    mockEnvironmentService.getTimestringCookie.and.returnValues('abcdTest');
    service.initializeApp('/name/business');    
    expect(mockTrackSEMDataService.setSEMCookies).toHaveBeenCalled();
  });

  it('should call processingOrderService.prepareGetProcessingOrderById', () => {
    mockProcessingOrderService.prepareGetProcessingOrderById.and.returnValue(null);
    mockLLCQuestionnaireService.prepareGetQuestionnaireStorage.and.returnValue(null);
    mockQuestionnaireAnswerService.prepareGetUserAnswers.and.returnValue(null);
    mockQuestionnaireAnswerService.prepareDeleteQuestionnaireAnswers.and.returnValue(null);
    mockCookieService.get.withArgs(CookieName.ACTIVESESSION).and.returnValue('true');

    mockUtilityService.getAuthTokenConsultationCookie.and.returnValue('2468');
    mockUtilityService.getCustomerIdConsultationCookie.and.returnValue('123');

    mockUtilityService.getIntParamFromQueryString
      .withArgs('uo').and.returnValue('9999')
      .withArgs('cartId').and.returnValue('123')
      .withArgs('orderId').and.returnValue('123')
    mockUtilityService.getStringParamFromQueryString
      .withArgs('kid').and.returnValue('test')
      .withArgs('state').and.returnValue('Ca')
      .withArgs('entity').and.returnValue(undefined)
      .withArgs('choose_later').and.returnValue(undefined)
     
    mockAppService = TestBed.get(AppService);
    const mockapp = {
      customerId: 123,
      accessToken: 'testtest',
      processingOrderId: 9999,
      cartId: 123
    };
    mockAppService.customerId = mockapp.customerId;
    mockAppService.app = mockapp;
    
    mockEnvironmentService.getTimestringCookie.and.returnValues('abcdTest');
    service.initializeApp('/name/business');
    expect(mockProcessingOrderService.prepareGetProcessingOrderById).toHaveBeenCalled();
    expect(mockLLCQuestionnaireService.prepareGetQuestionnaireStorage).toHaveBeenCalled();
    expect(mockQuestionnaireAnswerService.prepareGetUserAnswers).toHaveBeenCalled();
    expect(mockQuestionnaireAnswerService.prepareDeleteQuestionnaireAnswers).toHaveBeenCalled();
  });

  it('should call userCartService.prepareGetCartById', () => {
    mockCookieService.get.withArgs(CookieName.ACTIVESESSION).and.returnValue('true');
    mockProcessingOrderService.prepareGetProcessingOrderById.and.returnValue(null);
    mockLLCQuestionnaireService.prepareGetQuestionnaireStorage.and.returnValue(null);
    mockQuestionnaireAnswerService.prepareGetUserAnswers.and.returnValue(null);
    mockQuestionnaireAnswerService.prepareDeleteQuestionnaireAnswers.and.returnValue(null);
    mockUtilityService.getIntParamFromQueryString
      .withArgs('uo').and.returnValue('9999')
      .withArgs('cartId').and.returnValue('123')
      .withArgs('orderId').and.returnValue('123')
    mockUtilityService.getStringParamFromQueryString
      .withArgs('kid').and.returnValue('test')
      .withArgs('state').and.returnValue('Ca')
      .withArgs('entity').and.returnValue(undefined)
      .withArgs('choose_later').and.returnValue(undefined)
    mockUtilityService.getAuthTokenConsultationCookie.and.returnValue('9876');
    mockUtilityService.getCustomerIdConsultationCookie.and.returnValue('123');

    mockAppService = TestBed.get(AppService);
    const mockapp = {
      customerId: 123,
      accessToken: 'testtest',
      processingOrderId: 1234,
      cartId: 1234
    };
    mockAppService.app = mockapp;
    mockEnvironmentService.getTimestringCookie.and.returnValues('abcdTest');
    service.initializeApp('/name/business');
    expect(mockProcessingOrderService.prepareGetProcessingOrderById).toHaveBeenCalled();
    expect(mockLLCQuestionnaireService.prepareGetQuestionnaireStorage).toHaveBeenCalled();
    expect(mockQuestionnaireAnswerService.prepareGetUserAnswers).toHaveBeenCalled();
    expect(mockQuestionnaireAnswerService.prepareDeleteQuestionnaireAnswers).toHaveBeenCalled();
    expect(mockUserCartService.prepareGetCartById).toHaveBeenCalled();
  });
});
