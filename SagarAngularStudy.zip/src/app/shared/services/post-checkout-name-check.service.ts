import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { AbstractControl, FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { EntitydbService, EntityNameStatus, EntityType, IEntityDbResponse, NameCheckReasonCode } from '@legalzoom/entitydb-sdk';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { filter, map, tap } from 'rxjs/operators';
import { ConstantsService } from './constants.service';
import { QuestionnaireService } from './questionnaire/questionnaire.service';
import { 
  FeatureFlagService,
  FEATURE_FLAG_Q2_Advance_Namecheck_State,
  FEATURE_FLAG_Q2_SHOW_IN_IQ_FLOW
} from './feature-flag/feature-flag.service';
import { BusinessNameRule, IEntityErrorReasons } from '../models/business-name-rule';
import { AppService } from '../../../app/shared/state/app/app.service';
import { WindowRef } from './windowRef.service';
import { UtilityService } from '../../../app/shared/services/utility.service';
import { PagePath } from '../../../app/shared/models/page-model';
import { CookieService } from 'ngx-cookie';
export enum PostCheckoutNameCheckState {
  Default,
  DefaultNoEntity,
  Pending,
  Valid,
  Invalid,
  Conditional,
  InvalidMaxRetries,
  Error,
  ConsentConditional,
  MatchEntity
}

@Injectable({
  providedIn: 'root'
})
export class PostCheckoutNameCheckService {
  // tslint:disable-next-line:variable-name
  private _previousState: PostCheckoutNameCheckState;
  public get previousState(): PostCheckoutNameCheckState {
    return this._previousState;
  }

  // tslint:disable-next-line:variable-name
  private _currentState: PostCheckoutNameCheckState = PostCheckoutNameCheckState.Default;
  public get currentState(): PostCheckoutNameCheckState {
    return this._currentState;
  }

  private stateChangeEvent = new BehaviorSubject<PostCheckoutNameCheckState>(this.currentState);
  public readonly stateChange$ = this.stateChangeEvent.asObservable();
  private consentConditionalEvent = new BehaviorSubject<boolean>(false);
  public readonly consentConditional$ = this.consentConditionalEvent.asObservable();
  private matchEntityEvent = new BehaviorSubject<boolean>(false);
  public readonly matchEntity$ = this.matchEntityEvent.asObservable();
  public helpModalOpenOnce = new BehaviorSubject<boolean>(false);
  public isStateRequireAdvanceNameCheck =this.featureFlagService.advanceNameCheckState;
  public businessEntityName=new BehaviorSubject<string>('');
  public get canLookUpEntity(): boolean {
    return (
      this.currentState === PostCheckoutNameCheckState.Default ||
      this.currentState === PostCheckoutNameCheckState.Invalid ||
      this.currentState === PostCheckoutNameCheckState.Conditional ||
      this.currentState === PostCheckoutNameCheckState.ConsentConditional ||
      this.currentState === PostCheckoutNameCheckState.MatchEntity||
      this.currentState === PostCheckoutNameCheckState.InvalidMaxRetries
    );
  }

  private invalidReasonsEvent = new BehaviorSubject<any>([]);
  public readonly invalidReasons$ = this.invalidReasonsEvent.asObservable();

  // tslint:disable-next-line:variable-name
  private _nameCheckFailureCount = 0;
  public get nameCheckFailureCount(): number {
    return this._nameCheckFailureCount;
  }

  private _modalCount = 0;
  public incrementModalCounter() {
    this._modalCount++;
    return this._modalCount;
  }

  private canProgressEvent = new BehaviorSubject<boolean>(true);
  public readonly canProgress$ = this.canProgressEvent.asObservable();

  public constructor(
    private entitydbService: EntitydbService, 
    private questionnaireService: QuestionnaireService, 
    private featureFlagService: FeatureFlagService, 
    private httpClient: HttpClient,
    private utilityService: UtilityService,
    private windowRef: WindowRef,
    private appService: AppService,
    private cookieService:CookieService) {
    this.featureFlagService.reinitializeFlagsIfUserChanged();
    this.featureFlagService.advanceNameCheckStatefeature$.subscribe(advanceNameCheckState =>{
      this.isStateRequireAdvanceNameCheck = advanceNameCheckState;
      this.featureFlagService.advanceNameCheckState=advanceNameCheckState;
    });
    if (this.cookieService.get('show_q2_llc_in_iq_flow') === 'true') {
         this.gotoIQFlow(); 
    }
    else
    {
      this.featureFlagService.isFeatureOn(FEATURE_FLAG_Q2_SHOW_IN_IQ_FLOW).subscribe((isFeatureOn: boolean) => {
        if (isFeatureOn) {
          // Redirect to new Q2 in IQ workflow
          this.gotoIQFlow();
        }
      });
    }
   
  }

  public pauseProgress(): void {
    this.canProgressEvent.next(false);
  }

  public resumeProgress(): void {
    this.canProgressEvent.next(true);
  }

  public allowOneExtraFailure(): void {
    // Lower Max Failure Count
    if (this.nameCheckFailureCount >= this.featureFlagService.nameCheckFailureMax) {
      this._nameCheckFailureCount = this.featureFlagService.nameCheckFailureMax - 1;
    }
  }

  public reset(): void {
    // Reset State
    this.updateState(PostCheckoutNameCheckState.Default);

    // Reset Failure Count
    this._nameCheckFailureCount = 0;
  }

  public allowIncompleteBusinessNameToProgress(formGroup: FormGroup): void {
    // Get FormControls
    const { businessNameDesignator, isBusinessName, businessNameExplanation } = formGroup.controls;
    const requiresBusinessNameExplanation: boolean = ConstantsService.STATES_SHOW_NAME_EXPLANATION.includes(this.questionnaireService.llc.entityState);

    // Update Values
    businessNameDesignator.setValue('LLC');
    isBusinessName.setValue(true);

    // Reset Value And Validity
    businessNameDesignator.updateValueAndValidity();
    isBusinessName.updateValueAndValidity();

    // Requires Business Name Explanation
    if (requiresBusinessNameExplanation) {
      businessNameExplanation.setValue('Not provided');
      businessNameExplanation.updateValueAndValidity();
    }
  }

  public resetBusinessName(formGroup: FormGroup): void {
    // Clear Form Control
    const { businessName, businessNameDesignator, isBusinessName, businessNameExplanation } = formGroup.controls;

    // Reset Value
    businessName.setValue('');
    businessNameDesignator.setValue('');
    isBusinessName.setValue(false);
    businessNameExplanation.setValue('');

    // Cleanup and Update Markings
    this.resetFormControl(businessName, Validators.required);
    this.resetFormControl(businessNameDesignator, Validators.required);
    this.resetFormControl(isBusinessName, Validators.requiredTrue);
    this.resetFormControl(businessNameExplanation);

    // Reset Failure
    this.allowOneExtraFailure();

    // Change State to Default
    this.updateState(PostCheckoutNameCheckState.Default);
  }

  private resetFormControl(formControl: AbstractControl, ...validators: ValidatorFn[]): void {
    formControl.clearValidators();
    formControl.markAsPristine();
    formControl.markAsUntouched();
    formControl.setValidators(validators);
    formControl.updateValueAndValidity();
  }

  public getEntityNameAvailability(entityName: string, entityStateName: string): Observable<IEntityDbResponse> {
    this.updateState(PostCheckoutNameCheckState.Pending);
    entityName = entityName.indexOf('&') > 0 ? encodeURIComponent(entityName) : entityName;
    return this.entitydbService.getEntityAvailability(entityName, EntityType.LLC, ConstantsService.getStateAbbr(entityStateName)).pipe(
      tap(
        (response: IEntityDbResponse) => {
          // Update State
          switch (response.status) {
            case EntityNameStatus.Available:
              this.updateState(PostCheckoutNameCheckState.Valid);
              break;

            case EntityNameStatus.Conditional:
              const code = this.getConsentCodeFromReasons(response);
              if (code.length == 1) {
                this.updateState(PostCheckoutNameCheckState.ConsentConditional);
              } else {
                this.updateState(PostCheckoutNameCheckState.Conditional);
              }
              break;
            case EntityNameStatus.Unavailable:
            case EntityNameStatus.GeneralSimilarity:
            case EntityNameStatus.PhoneticSimilarity:
              this.setMatchEntityState(response);
              break;
            default:
              this.updateState(PostCheckoutNameCheckState.Error);
              break;
          }
        },
        (error) => {
          this.updateState(PostCheckoutNameCheckState.Error);

          // Throw Error
          throwError(error);
        }
      )
    );
  }

  public updateState(state: PostCheckoutNameCheckState): void {
    // Test for Failure - to augment the response based on the results
    if (state !== PostCheckoutNameCheckState.Default && state !== PostCheckoutNameCheckState.DefaultNoEntity && state !== PostCheckoutNameCheckState.Pending) {
      this._nameCheckFailureCount++;

      // User has Encountered the name check error more than the allowed times
      if (this.isStateRequireAdvanceNameCheck && this._nameCheckFailureCount > this.featureFlagService.advancenameCheckFailureMax && state !=PostCheckoutNameCheckState.Error && state !=PostCheckoutNameCheckState.Valid) {
        // Change State to Max Retries
        state = PostCheckoutNameCheckState.InvalidMaxRetries;
      }
      else if(this._nameCheckFailureCount >= this.featureFlagService.nameCheckFailureMax && state !=PostCheckoutNameCheckState.Error && state !=PostCheckoutNameCheckState.Valid)
      {
        state = PostCheckoutNameCheckState.Error;
      }
    }

    // Update States
    this._previousState = this._currentState;
    this._currentState = state;

    // Send State Change
    this.stateChangeEvent.next(state);
  }

  public getConsentCodeFromReasons({ reasons = [] }: IEntityDbResponse): string[] {
    return reasons
      .filter((reason) => reason.code != undefined && reason.text.indexOf('consent') > 0)
      .map(({ code }) => {
        return code;
      });
  }
  public setMatchEntityState(response: IEntityDbResponse) {
    const matchCode = this.getMatchCodeFromReasons(response);
    if (matchCode.length >= 1) {
      this.updateState(PostCheckoutNameCheckState.MatchEntity);
    } else {
      this.updateState(PostCheckoutNameCheckState.Invalid);
    }
  }
  public getMatchCodeFromReasons({ reasons = [] }: IEntityDbResponse): any {
    return reasons
      .filter((reason) => reason.code == NameCheckReasonCode.MatchingRecordsFound && reason.entity != undefined && reason.entity.length > 0)
      .map(({ entity }) => {
        return entity;
      });
  }

  public getErrorsFromReasons({ status, reasons = [] }: IEntityDbResponse): IEntityErrorReasons[] {
    this.consentConditionalEvent.next(false);
    this.matchEntityEvent.next(false);
    let issueDetailWord='';
    return reasons.map(({ code, words = '', text, entity = null }) => {
      if (words !== '') {
        const uniqueWords = words
          .trim()
          .split(',')
          .map((item) => item.trim())
          .filter(function (item, i, allItems) {
            return i == allItems.indexOf(item);
          })
          .join(', ');
        words = `<strong>${uniqueWords}</strong>`;
        issueDetailWord=uniqueWords;
      }

      switch (code) {
        case NameCheckReasonCode.Profanity:
          return <IEntityErrorReasons>{
            errorsFromReasons:this.isStateRequireAdvanceNameCheck?`Name contains one or more words of an inappropriate or profane nature.`:`Delete inappropriate words or language: ${words}`,
            errorType:"Inappropriate words:",
            issueDetails:`${issueDetailWord}`
          }
        case NameCheckReasonCode.RestrictedWord:
          if (text.indexOf('consent') > 0) {
            this.consentConditionalEvent.next(true);
            return <IEntityErrorReasons>{
              errorsFromReasons:this.isStateRequireAdvanceNameCheck?`Cannot contain ${words} without prior consent  ${text.split('consent')[1].trim()}`:`Delete ${words}—or to keep, get permission ${text.split('consent')[1].trim()}`,
              errorType:"Restricted words:",
              issueDetails:`${issueDetailWord}`
            }
          } else {
            return <IEntityErrorReasons>{
              errorsFromReasons:(this.isStateRequireAdvanceNameCheck && text.split(':')[1] !=undefined)?`Following ${words} name must contain either ${text.split(':')[1].trim()}`:`Delete prohibited words: ${words}`,
              errorType:"Restricted words:",
              issueDetails:`${issueDetailWord}`
            }
          }
        case NameCheckReasonCode.InvalidDesignator:
          return <IEntityErrorReasons>{
              errorsFromReasons:this.isStateRequireAdvanceNameCheck?`Name contains one or more business entity identifiers, such as "Incorporated," "Corporation," "Inc.," "Limited Liability Company," or "LLC."`:`Delete incorrect designator (like Co., Corp., or Inc.)`,
              errorType:"Designators:",
              issueDetails:`${issueDetailWord}`
            }
        case NameCheckReasonCode.MatchingRecordsFound:
          if (entity != null && entity != undefined && entity.length >= 1 && status != EntityNameStatus.PhoneticSimilarity && status != EntityNameStatus.GeneralSimilarity) {
            this.matchEntityEvent.next(true);
            return <IEntityErrorReasons>{
              errorsFromReasons:this.isStateRequireAdvanceNameCheck ? `
                Name matches the name of a business entity that's already registered with the state of ${this.questionnaireService.llc.entityState}. Try a different name to make it more unique.
                <br/>
                <br/>
                <span>Currently registered entities include: <span><strong>` +
              entity
                .slice(0, 5)
                .map(({ name, entityName }) =>(entityName === undefined ? name : entityName))
                .join(', ')+`</strong>`
              :
              `Add or change some words so your name isn't so similar to [this/these] existing business [name/names]:` +
              '<ul>' +
              entity
                .slice(0, 5)
                .map(({ name, entityName }) => '<li>' + (entityName === undefined ? name : entityName) + '</li>')
                .join('') +
              '</ul>',
              errorType:"Matching name:",
              issueDetails:`${this.businessEntityName.getValue()}`
            }
          } else {
            if (status == EntityNameStatus.PhoneticSimilarity || status == EntityNameStatus.GeneralSimilarity) {
              return <IEntityErrorReasons>{
                errorsFromReasons:this.isStateRequireAdvanceNameCheck?`
                Name is similar to the name of a business entity that's already registered with the state of ${this.questionnaireService.llc.entityState}. Try a different name to make it more unique.
                <br/>
                <br/>
                <span>Currently registered entities include: <span><strong>`+
                entity
                  .slice(0, 5)
                  .map(({ name, entityName }) => (entityName === undefined ? name : entityName))
                  .join(', ')+`</strong>`
                :
                `Add or change some words so your name isn't so similar to an existing business name.`,
                errorType:"Similar name:",
                issueDetails:`${this.businessEntityName.getValue()}`
              }
            } else {
              return <IEntityErrorReasons>{
                errorsFromReasons:`Close similarities to an existing business name`,
                errorType:"Similar name:",
                issueDetails:`${this.businessEntityName.getValue()}`
              }
            }
          }
        case NameCheckReasonCode.General:
          return <IEntityErrorReasons>{
            errorsFromReasons:`Add or change some words so your name isn't so similar to an existing business name.`,
            errorType:"Similar name:",
            issueDetails:`${this.businessEntityName.getValue()}`
          }

        case NameCheckReasonCode.InvalidCharacter:
          return <IEntityErrorReasons>{
            errorsFromReasons:this.isStateRequireAdvanceNameCheck ? `Name must only contain alphanumeric characters (A-Z, a-z, 0-9), ampersand (&), and hyphen (-).`:`Delete special characters: ${words}`,
            errorType:"Contains ineligible characters:",
            issueDetails:`${issueDetailWord}`
          }


        default:
          if (code == undefined && text.indexOf('It is likely this name is') == 0) {
            return <IEntityErrorReasons>{
              errorsFromReasons:'',
              errorType:"",
              issueDetails:``
            }
          } else if (text) {
            return <IEntityErrorReasons>{
              errorsFromReasons:text,
              errorType:"Contains ineligible characters:",
              issueDetails:`${issueDetailWord}`
            }
          }
          return <IEntityErrorReasons>{
            errorsFromReasons:`A technical issue on our end, please try again`,
            errorType:"Contains ineligible characters:",
            issueDetails:`${issueDetailWord}`
          }
      }
    });
  }

  /**
   * Used to determine if entityDB API has support for checking registered names in a particular state
   */
  public canFullyValidateName(): boolean {
    return !ConstantsService.STATES_MISSING_REGISTERED_ENTITY_NAMES.includes(this.questionnaireService.llc.entityState);
  }

  public getEntityNameRule(stateCode:string): any {
    return this.httpClient
      .get<BusinessNameRule[]>('assets/businessNameRuleData/rule.json')
      .pipe(
        map((response) => {
          return response.filter((data) => data['stateCode'] === stateCode);
        })
      )
  }

  public gotoIQFlow()
  {
    const orderId = this.utilityService.getIntParamFromQueryString('orderId') || this.appService.orderId;
    const cartId = this.utilityService.getIntParamFromQueryString('cartId') || this.appService.cartId;
    if (orderId && cartId) {
      this.windowRef.nativeWindow.location.href = `${PagePath.IQFlow}/q2intro?orderId=${orderId}&cartId=${cartId}&graphType=q2`;
    }     
  }
}
