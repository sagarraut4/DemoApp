import { AppService } from './../state/app/app.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { of } from 'rxjs';
import {
  IQueueEntry, TrackJsErrorLogService, ProductResponse, ProductPriceResponse
} from '@legalzoom/business-formation-sdk';
import {
  IUserAnswerRequest,
  QuestionnaireAnswerService
} from '@legalzoom/questionnaire-answer-sdk';
import { ProductName } from '../constants/product-domain';
import { PagePath } from '../models/page-model';
import { QuestionnaireRoutingService } from './questionnaire-routing/questionnaire-routing.service';
import { Router } from '@angular/router';
import { QuestionnaireMappingService } from './questionnaire/questionnaire-mapping.service';
import { QuestionnaireService } from './questionnaire/questionnaire.service';
import { ProcessingOrderService, IUpdateProcessingOrderRequest } from '@legalzoom/processing-order-sdk';
import { OrderService, IPostFinalizeOrderRequest } from '@legalzoom/order-sdk';

@Injectable()
export class PostCheckoutService {
  public updateProcessingOrderResponse: any;
  public mappedLLC: any;
  public profLLC: ProductResponse;
  public profLLCprice: ProductPriceResponse;
  public PROFESSIONAL_LLC_CONFIG_ID = 153;
  constructor(
    private appService: AppService,
    private questionnaireMappingService: QuestionnaireMappingService,
    private questionnaireAnswerService: QuestionnaireAnswerService,
    private questionnaireService: QuestionnaireService,
    private processingOrderService: ProcessingOrderService,
    private trackJS: TrackJsErrorLogService,
    private questionnaireRoutingService: QuestionnaireRoutingService,
    private orderService: OrderService,
    private router: Router,
  ) { }

  public prepareSaveAndGetMappedUserAnswers(context: any): IQueueEntry {
    const that = this;
    return {
      name: 'prepareSaveAndGetMappedUserAnswers ' + this.constructor.name,
      pre: () => {
        // Map all the answers
        this.mappedLLC = this.questionnaireMappingService.doMapping(this.questionnaireService.llc, this.appService.processingOrderId);
        const answerRequest: IUserAnswerRequest = {
          questionnaireFieldGroupAnswers: {
            userOrderId: this.mappedLLC.userOrderId,
            questionnaireId: that.appService.app.questionnaireId,
            fieldAnswers: this.mappedLLC.fieldAnswers,
            groupAnswers: this.mappedLLC.groupAnswerCollections
          }
        };
        return this.questionnaireAnswerService.saveAndGetMappedUserAnswers(
          answerRequest,
          answerRequest.questionnaireFieldGroupAnswers.questionnaireId
        );
      },
      post: (response) => {
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'remaining-question.component', error);
        return of(null);
      }
    };
  }

  // quick fix D-10173 LLC On API - Request Received - Governing State/State of Formation Discrepancy
  private get STATES(): { name: string, abbr: string, id: number }[] {
    return [
      { name: 'Alabama', abbr: 'AL', id: 51 },
      { name: 'Alaska', abbr: 'AK', id: 1 },
      { name: 'Arizona', abbr: 'AZ', id: 12 },
      { name: 'Arkansas', abbr: 'AR', id: 22 },
      { name: 'California', abbr: 'CA', id: 5 },
      { name: 'Colorado', abbr: 'CO', id: 11 },
      { name: 'Connecticut', abbr: 'CT', id: 27 },
      { name: 'Delaware', abbr: 'DE', id: 28 },
      { name: 'Dist. of Columbia', abbr: 'DC', id: 29 },
      { name: 'Florida', abbr: 'FL', id: 30 },
      { name: 'Georgia', abbr: 'GA', id: 31 },
      { name: 'Hawaii', abbr: 'HI', id: 6 },
      { name: 'Idaho', abbr: 'ID', id: 7 },
      { name: 'Illinois', abbr: 'IL', id: 26 },
      { name: 'Indiana', abbr: 'IN', id: 17 },
      { name: 'Iowa', abbr: 'IA', id: 33 },
      { name: 'Kansas', abbr: 'KS', id: 19 },
      { name: 'Kentucky', abbr: 'KY', id: 32 },
      { name: 'Louisiana', abbr: 'LA', id: 23 },
      { name: 'Maine', abbr: 'ME', id: 34 },
      { name: 'Maryland', abbr: 'MD', id: 35 },
      { name: 'Massachusetts', abbr: 'MA', id: 36 },
      { name: 'Michigan', abbr: 'MI', id: 37 },
      { name: 'Minnesota', abbr: 'MN', id: 16 },
      { name: 'Mississippi', abbr: 'MS', id: 38 },
      { name: 'Missouri', abbr: 'MO', id: 24 },
      { name: 'Montana', abbr: 'MT', id: 8 },
      { name: 'Nebraska', abbr: 'NE', id: 18 },
      { name: 'Nevada', abbr: 'NV', id: 4 },
      { name: 'New Hampshire', abbr: 'NH', id: 39 },
      { name: 'New Jersey', abbr: 'NJ', id: 40 },
      { name: 'New Mexico', abbr: 'NM', id: 13 },
      { name: 'New York', abbr: 'NY', id: 41 },
      { name: 'North Carolina', abbr: 'NC', id: 42 },
      { name: 'North Dakota', abbr: 'ND', id: 14 },
      { name: 'Ohio', abbr: 'OH', id: 43 },
      { name: 'Oklahoma', abbr: 'OK', id: 20 },
      { name: 'Oregon', abbr: 'OR', id: 3 },
      { name: 'Pennsylvania', abbr: 'PA', id: 44 },
      { name: 'Rhode Island', abbr: 'RI', id: 45 },
      { name: 'South Carolina', abbr: 'SC', id: 46 },
      { name: 'South Dakota', abbr: 'SD', id: 15 },
      { name: 'Tennessee', abbr: 'TN', id: 47 },
      { name: 'Texas', abbr: 'TX', id: 21 },
      { name: 'Utah', abbr: 'UT', id: 10 },
      { name: 'Vermont', abbr: 'VT', id: 48 },
      { name: 'Virginia', abbr: 'VA', id: 49 },
      { name: 'Washington', abbr: 'WA', id: 2 },
      { name: 'West Virginia', abbr: 'WV', id: 50 },
      { name: 'Wisconsin', abbr: 'WI', id: 25 },
      { name: 'Wyoming', abbr: 'WY', id: 9 }];
  }

  public prepareUpdateProcessingOrder(context: any): IQueueEntry {
    const that = this;
    return {
      name: 'prepareUpdateProcessingOrder ' + this.constructor.name,
      pre: () => {
        const updateProcessingOrderRequest: IUpdateProcessingOrderRequest = {
          // quick fix D-10173 LLC On API - Request Received - Governing State/State of Formation Discrepancy
          stateId: this.STATES.find(e => e.name === context.entityState).id,
          isQuestionnaireCompleted: true,
          postOption: null,
          shippingMethodId: null,
          lastPageVisited: 1000,
          comment: 'LZWebApp-LLC',
          customerId: that.appService.app.customerId
        };
        return that.processingOrderService.updateProcessingOrder(
          that.appService.app.processingOrderId,
          updateProcessingOrderRequest
        );
      },
      post: (response) => {
        that.updateProcessingOrderResponse = response;
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'remaining-question.component', error);
        return of(null);
      }
    };
  }

  public preparePostFinalizeOrder(context: any): IQueueEntry {
    const that = this;
    return {
      name: 'preparePostFinalizeOrder ' + this.constructor.name,
      pre: () => {
        const postFinalizeOrderRequest: IPostFinalizeOrderRequest = {
          orderId: this.appService.app.orderId,
          processingOrderId: this.appService.app.processingOrderId,
          customerId: this.appService.app.customerId,
          updateOnly: true,
          processId: this.appService.processId
        };
        return that.orderService.postFinalizeOrder(
          that.appService.app.cartId,
          postFinalizeOrderRequest
        );
      },
      post: (bPostFinalize) => {
        if (bPostFinalize && that.updateProcessingOrderResponse.processingOrder.processingOrderId === this.mappedLLC.userOrderId && bPostFinalize) {
          const nextPage = this.questionnaireRoutingService.getNextPage(PagePath.RemainingQuestions);
          this.router.navigate(['./' + nextPage]);
        }
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'remaining-question.component', error);
        return of(null);
      }
    };
  }

  public prepareAddAddOnToOrder(addAddOnToOrder: any): IQueueEntry {
    const that = this;
    return {
      name: 'prepareAddAddOnToOrder ' + this.constructor.name,
      pre: () => {
        return that.orderService.addAddOnToOrder(
          that.appService.app.orderId,
          addAddOnToOrder
        );
      },
      post: () => {
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'post-checkout.service', error);
        return of(null);
      }
    };
  }

}
