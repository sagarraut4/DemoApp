import { ProcessingOrderModule } from '@legalzoom/processing-order-sdk';
import { TestBed } from '@angular/core/testing';
import { ProcessingOrderService } from './processing-order.service';
import { ProcessingOrderService as SdkProcessingOrderService } from '@legalzoom/processing-order-sdk';
import { QueueService } from '@legalzoom/business-formation-sdk';
import { of } from 'rxjs';
import { ProductName } from '../constants/product-domain';

describe('ProcessingOrderService', () => {
  let mockProService = jasmine.createSpyObj(['getProcessingOrdersById']);
  beforeEach(() => TestBed.configureTestingModule({
    imports: [ProcessingOrderModule],
    providers: [ProcessingOrderService,
      { provide: SdkProcessingOrderService, useValue: mockProService }]
  }));

  it('ProcessingOrderService should be created', () => {
    const service: ProcessingOrderService = TestBed.get(ProcessingOrderService);
    expect(service).toBeTruthy();
  });

  it('prepareGetProcessingOrderById method should set processingOrder', () => {
    const service: ProcessingOrderService = TestBed.get(ProcessingOrderService);
    const mockQueueService = TestBed.get(QueueService);
    let appservice = { app: { processingOrderId: 0, isQuestionnaireComplete: false } };
    mockProService.getProcessingOrdersById.and.returnValue(of({ processingOrder: { processingOrderId: 12, isQuestionnaireCompleted: true } }));
    mockQueueService.add(service.prepareGetProcessingOrderById({ constructor: { name: 'test' } }, appservice,
      123, 'authToken', 123465, ProductName.LLC));
    mockQueueService.process().subscribe();
    expect(mockProService.getProcessingOrdersById).toHaveBeenCalled();
    expect(appservice.app.isQuestionnaireComplete).toBe(true);
    expect(appservice.app.processingOrderId).toBe(12);
  });
});
