import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CheckOwnerDuplicationService {

  constructor() { }

  public checkDuplicateName(thisIndex, currentFormArr, nameList, totalCount, showWarningObj, ownerIsManagerList?) {
    let counter = 0;
    const filteredList = [];
    const showOwnerMgrWarning = [];

    // This loop helps to collect elements that match the old value of the current element
    while (counter < totalCount) {
      if ((thisIndex !== counter) &&
        (nameList[thisIndex].toLowerCase() === currentFormArr.value[counter].fullName.toLowerCase())) {
        filteredList.push(counter);
      }
      counter++;
    }

    // If the old value of current element matches only 1 other value,
    // then remove the warning message from the other element
    if (filteredList.length === 1) {
      // For owner is manager section in business manager
      if (ownerIsManagerList) {
        const newOwnerMgrList = ownerIsManagerList.map(name => name.toLowerCase());
        const foundOwner = newOwnerMgrList.indexOf(currentFormArr.value[filteredList[0]].fullName.toLowerCase());

        if (foundOwner > -1) {
          showWarningObj[filteredList[0]] = true;
        } else {
          showWarningObj[filteredList[0]] = false;
        }
      } else {
        showWarningObj[filteredList[0]] = false;
      }
    }

    // Reset counter for the next loop
    counter = 0;

    // Check duplicate value and add a warning to the current element
    while ((totalCount > 1) && (counter < totalCount)) {
      if ((thisIndex !== counter) &&
        (currentFormArr.value[thisIndex].fullName.toLowerCase() === currentFormArr.value[counter].fullName.toLowerCase())) {
        showWarningObj[thisIndex] = true;
        counter = totalCount;
      } else {
        showWarningObj[thisIndex] = false;
        counter++;
      }
    }

    // To match manager name with ownerIsManager checkbox List
    if (ownerIsManagerList) {
      const newOwnerMgrList = ownerIsManagerList.map(name => name.toLowerCase());
      const foundOwner = newOwnerMgrList.indexOf(currentFormArr.value[thisIndex].fullName.toLowerCase());
      if (foundOwner > -1) {
        showOwnerMgrWarning[thisIndex] = true;
      } else {
        if(thisIndex === counter)
        {
          showWarningObj[thisIndex]=false;
        }
        showOwnerMgrWarning[thisIndex] = false;
      }
    }

    if (showOwnerMgrWarning[thisIndex] || showWarningObj[thisIndex]) {
      showWarningObj[thisIndex] = true;
    }

    return showWarningObj;
  }

  public removeDuplicationWarning(currentFormArr, checkName, totalCount, showWarningObj) {
    const filteredList = [];
    let counter = 0;

    while (counter < totalCount) {
      if ((checkName.toLowerCase() === currentFormArr.value[counter].fullName.toLowerCase())) {
        filteredList.push(counter);
      }
      counter++;
    }

    // If the old value of current element matches only 1 other value,
    // then remove the warning message from the other element
    if (filteredList.length === 1) {
      showWarningObj[filteredList[0]] = false;
    }

    return showWarningObj;
  }
}