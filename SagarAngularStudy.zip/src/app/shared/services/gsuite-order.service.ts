import { IUpdateProcessingOrderRequest, ProcessingOrderService } from '@legalzoom/processing-order-sdk';
import { AppService } from './../state/app/app.service';
import {
  QueueService, IQueueEntry, TrackJsErrorLogService, IUpdateProcessingStatusRequest
} from '@legalzoom/business-formation-sdk';
import { TaggingService, ITagOrderByIdRequest, ITagOrderByIdResponse, TagType } from '@legalzoom/tagging-sdk';
import { EmailNotificationService, IEmailHandlerRequest } from '@legalzoom/notification-sdk';
import { Injectable } from '@angular/core';
import { of } from 'rxjs';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { ProductDefinitionService } from './product-definition/product-definition.service';
import { QuestionnaireService } from './questionnaire/questionnaire.service';
import { ProductName } from '../constants/product-domain';
import { ExpressOrderResponse } from '../models/express-order-model';
import { ResellerService, ICreateProratedPaymentRequest } from '@legalzoom/reseller-sdk';
import { OrderService, ICreateCrossSellOrderRequest, ICreateCrossSellOrderResponse, IOrderContact } from '@legalzoom/order-sdk';
import { PaymentService, ICreatePaymentRequest } from '@legalzoom/payment-sdk';
import { ConstantsService } from './constants.service';

// Map of package type to configId
// tslint:disable-next-line: variable-name
export const gsuite_package_id_mapping = {
  'Business Starter': 6784,
  'Business Standard': 6785
};

@Injectable()
export class GsuiteOrderService {
  private gsuitePackages: any;
  private tagOrderByIdResponse: ITagOrderByIdResponse;

  constructor(
    private productDefinitionService: ProductDefinitionService,
    private questionnaireService: QuestionnaireService,
    private queueService: QueueService,
    private appService: AppService,
    private orderService: OrderService,
    private trackJS: TrackJsErrorLogService,
    private paymentService: PaymentService,
    private resellerService: ResellerService,
    private emailNotificationService: EmailNotificationService,
    private taggingService: TaggingService,
    private processingOrderService: ProcessingOrderService
  ) {
    this.gsuitePackages = this.productDefinitionService.getGSuitePackages();
    this.questionnaireService.llc.GSuiteOrderResponse = new ExpressOrderResponse();
  }

  public calcProRatedPrice(total: number): string {
    const currentDate = new Date();
    const currentDay = currentDate.getDate();
    const daysInAMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate();

    return (((daysInAMonth - currentDay + 1) / daysInAMonth) * total).toFixed(2);
  }

  public calcTotal(gsuiteType: string, gsuiteSeats: number): { total: number, proratedPrice: string } {
    let total: number;
    if (gsuiteType && gsuiteSeats) {
      if (gsuiteType === this.gsuitePackages.basic.packageType) {
        total = this.gsuitePackages.basic.price * gsuiteSeats;
      } else if (gsuiteType === this.gsuitePackages.business.packageType) {
        total = this.gsuitePackages.business.price * gsuiteSeats;
      }
      return { total, proratedPrice: this.calcProRatedPrice(total) };
    }
  }

  public loadQueueForCrossSellOrder(type: string, seats: number, proratedPrice: number) {
    this.questionnaireService.llc.gsuitePackageType = type;
    this.questionnaireService.llc.gsuiteNumSeats = seats;
    const crossSellConfigId = gsuite_package_id_mapping[type];
    this.queueService.add(
      this.prepareCreateCrossSellsOrder_CrossSell(crossSellConfigId));
    this.queueService.add([
      this.prepareCreateOrderContactPrimary(),
      this.prepareCreateOrderContactShipping(),
      this.prepareCreateOrderContactBilling(),
    ]);

    this.queueService.add(this.prepareProratedPayment(seats, proratedPrice));
    this.queueService.add(this.prepareCreateBillOrder_CrossSell(proratedPrice));
    this.queueService.add(this.prepareTagOrderById_CrossSell());
    this.queueService.add(this.prepareSendEmailNotification());
    this.queueService.add(this.prepareUpdateProcessingOrder());
    this.queueService.add(this.prepareUpdateProcessingOrderStatus());
  }

  public prepareCreateCrossSellsOrder_CrossSell(crossSellConfigId: number): IQueueEntry {
    const newOrder = true;
    return {
      name: 'prepareCreateCrossSellsOrder_CrossSell ' + this.constructor.name,
      pre: () => {
        const createCrossSellOrderRequest: ICreateCrossSellOrderRequest = {
          productConfigurationId: crossSellConfigId,
          createdBy: this.appService.customerId.toString()
        };
        return this.orderService.createCrossSellOrder(
          this.appService.orderId,
          createCrossSellOrderRequest,
          newOrder
        );
      },
      post: response => {
        this.appService.gSuiteCrossSellOrderResponse = response;
        this.questionnaireService.llc.GSuiteOrderResponse.ExpressOrderId = response.orderId;
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'gsuite-order.service', error);
        return of(null);
      }
    };
  }

  private prepareCreateOrderContactPrimary(): IQueueEntry {
    let crossSellOrder: ICreateCrossSellOrderResponse;
    return {
      name: 'prepareCreateOrderContactPrimary ' + this.constructor.name,
      pre: () => {
        crossSellOrder = this.appService.gSuiteCrossSellOrderResponse;
        const createOrderContactRequest: IOrderContact = {
          orderContactId: null,
          contactType: 'Primary',
          firstName: this.appService.firstName,
          lastName: this.appService.lastName,
          addressLine1: this.questionnaireService.llc.businessAddress.address1,
          addressLine2: this.questionnaireService.llc.businessAddress.address2,
          city: this.questionnaireService.llc.businessAddress.city,
          state: ConstantsService.getStateByAbbr(this.questionnaireService.llc.businessAddress.state),
          county: this.questionnaireService.llc.businessAddress.county,
          zipCode: this.questionnaireService.llc.businessAddress.zipCode,
          emailAddresses: [{ emailAddress: this.appService.loginEmail.toString() }],
          homePhone: this.questionnaireService.llc.contactPhone,
          workPhone: '',
          mobilePhone: '',
          faxPhone: '',
          country: null,
          stateId: null,
          dateCreated: null,
          createdBy: this.appService.customerId.toString(),
          dateLastModified: null,
          lastModifiedBy: null,
        };
        if (createOrderContactRequest) {
          return this.orderService.createOrderContact(
            crossSellOrder.orderId,
            createOrderContactRequest
          );
        } else {
          return of(null);
        }

      },
      post: response => {

      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'gsuite-order.service', error);
        return of(null);
      }
    };
  }

  private prepareCreateOrderContactShipping(): IQueueEntry {
    let crossSellOrder: ICreateCrossSellOrderResponse;
    return {
      name: 'prepareSubmitExpressOrder ' + this.constructor.name,
      pre: () => {
        crossSellOrder = this.appService.gSuiteCrossSellOrderResponse;
        const createOrderContactRequest: IOrderContact = {
          orderContactId: null,
          contactType: 'Shipping',
          firstName: this.appService.firstName,
          lastName: this.appService.lastName,
          addressLine1: this.questionnaireService.llc.businessAddress.address1,
          addressLine2: this.questionnaireService.llc.businessAddress.address2,
          city: this.questionnaireService.llc.businessAddress.city,
          state: ConstantsService.getStateByAbbr(this.questionnaireService.llc.businessAddress.state),
          county: this.questionnaireService.llc.businessAddress.county,
          zipCode: this.questionnaireService.llc.businessAddress.zipCode,
          emailAddresses: [{ emailAddress: this.appService.loginEmail.toString() }],
          homePhone: this.questionnaireService.llc.contactPhone,
          workPhone: '',
          mobilePhone: '',
          faxPhone: '',
          country: null,
          stateId: null,
          dateCreated: null,
          createdBy: this.appService.customerId.toString(),
          dateLastModified: null,
          lastModifiedBy: null,
        };
        if (createOrderContactRequest) {
          return this.orderService.createOrderContact(
            crossSellOrder.orderId,
            createOrderContactRequest
          );
        } else {
          return of(null);
        }
      },
      post: response => {

      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'gsuite-order.service', error);
        return of(null);
      }
    };
  }

  private prepareCreateOrderContactBilling(): IQueueEntry {
    let crossSellOrder: ICreateCrossSellOrderResponse;
    return {
      name: 'prepareCreateOrderContactBilling ' + this.constructor.name,
      pre: () => {
        crossSellOrder = this.appService.gSuiteCrossSellOrderResponse;
        const createOrderContactRequest: IOrderContact = {
          orderContactId: null,
          contactType: 'Billing',
          firstName: this.appService.firstName,
          lastName: this.appService.lastName,
          addressLine1: this.questionnaireService.llc.businessAddress.address1,
          addressLine2: this.questionnaireService.llc.businessAddress.address2,
          city: this.questionnaireService.llc.businessAddress.city,
          state: ConstantsService.getStateByAbbr(this.questionnaireService.llc.businessAddress.state),
          county: this.questionnaireService.llc.businessAddress.county,
          zipCode: this.questionnaireService.llc.businessAddress.zipCode,
          emailAddresses: [{ emailAddress: this.appService.loginEmail.toString() }],
          homePhone: this.questionnaireService.llc.contactPhone,
          workPhone: '',
          mobilePhone: '',
          faxPhone: '',
          country: null,
          stateId: null,
          dateCreated: null,
          createdBy: this.appService.customerId.toString(),
          dateLastModified: null,
          lastModifiedBy: null,
        };
        if (createOrderContactRequest) {
          return this.orderService.createOrderContact(
            crossSellOrder.orderId,
            createOrderContactRequest
          );
        } else {
          return of(null);
        }
      },
      post: response => {
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'gsuite-order.service', error);
        return of(null);
      }
    };
  }

  public prepareProratedPayment(seats: number, propatedPrice: number): IQueueEntry {
    let crossSellOrder: ICreateCrossSellOrderResponse;
    return {
      name: 'prepareProratedPayment ' + this.constructor.name,
      pre: () => {
        crossSellOrder = this.appService.gSuiteCrossSellOrderResponse;
        const createPaymentRequest: ICreateProratedPaymentRequest = {
          orderItemId: crossSellOrder.orderItem.orderItemId,
          seatCount: seats,
          extendedPrice: propatedPrice
        };

        return this.resellerService.createProratedPayment(
          createPaymentRequest,
          this.appService.customerId
        );
      },
      post: response => {
        return of(null);
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'checkout.service', error);
        return of(null);
      }
    };
  }

  public prepareCreateBillOrder_CrossSell(propatedPrice: number): IQueueEntry {
    let crossSellOrder: ICreateCrossSellOrderResponse;
    return {
      name: 'prepareCreateBillOrder_CrossSell ' + this.constructor.name,
      pre: () => {
        crossSellOrder = this.appService.gSuiteCrossSellOrderResponse;
        const createPaymentRequest: ICreatePaymentRequest = {
          orderId: crossSellOrder.orderId,
          amount: (propatedPrice).toFixed(2),
          createdBy: this.appService.customerId.toString(),
          comments: 'Cross Sell Order',
          reasonId: '1',
          paymentProfileId: this.appService.paymentProfileId,
          gateway: this.appService.paymentGateway.toString(),
          source: '100',
          notificationEmail: this.appService.loginEmail,
          transactionType: 'Charge'
        };

        return this.paymentService.createPayment(
          createPaymentRequest
        );
      },
      post: response => {
        this.appService.gSuiteCrossSellPaymentResponse = response;
        this.questionnaireService.llc.GSuiteOrderResponse.PaymentStatus = response.transactionStatus;

      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'checkout.service', error);
        return of(null);
      }
    };
  }

  private prepareTagOrderById_CrossSell(): IQueueEntry {
    let crossSellOrder: ICreateCrossSellOrderResponse;
    const tagName = 'LLC_Crosssell_GSuite_Q2';
    return {
      name: 'prepareTagOrderById_ExpressOrder ' + this.constructor.name,
      pre: () => {
        crossSellOrder = this.appService.gSuiteCrossSellOrderResponse;

        const tagOrderByIdRequest: ITagOrderByIdRequest = {
          tagType: TagType.system,
          tag: tagName,
          createdBy: this.appService.customerId.toString()
        };

        return this.taggingService.tagOrderById(
          crossSellOrder.orderId,
          tagOrderByIdRequest
        );
      },
      post: tagOrderByIdResponse => {
        this.tagOrderByIdResponse = tagOrderByIdResponse;
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'gsuite-order.service', error);
        return (of(null));
      }
    };
  }

  private prepareSendEmailNotification(): IQueueEntry {
    let crossSellOrder: ICreateCrossSellOrderResponse;
    return {
      name: 'prepareSubmitExpressOrder ' + this.constructor.name,
      clearQueueOnError: false,
      pre: () => {

        crossSellOrder = this.appService.gSuiteCrossSellOrderResponse;
        const emailHandlerRequest: IEmailHandlerRequest = {
          RequestType: 'SendOrderEmailAWSStepFunction',
          OrderId: crossSellOrder.orderId,
          CustomerId: this.appService.customerId,
          QuestionnaireId: this.appService.questionnaireId,
          ProcessId: this.appService.processId,
          ProcessingOrderId:
            crossSellOrder.orderItem.processingOrder.processingOrderId
        };
        return this.emailNotificationService.sendEmailNotification(
          emailHandlerRequest
        );
      },
      post: emailHandlerResponse => {
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'gsuite-order.service', error);
        return of(null);
      }
    };
  }

  private prepareUpdateProcessingOrder(): IQueueEntry {
    return {
      name: 'prepareUpdateProcessingOrder' + this.constructor.name,
      pre: () => {
        const updateProcessingOrderRequest: IUpdateProcessingOrderRequest = {
          stateId: null,
          isQuestionnaireCompleted: true,
          postOption: null,
          shippingMethodId: null,
          lastPageVisited: 1000,
          comment: '',
          customerId: this.appService.customerId
        };
        return this.processingOrderService.updateProcessingOrder(
          this.appService.gSuiteCrossSellOrderResponse.orderItem.processingOrder.processingOrderId,
          updateProcessingOrderRequest
        );
      },
      post: response => {
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'gSuite-order.service', error);
        return of(null);
      }
    };
  }

  private prepareUpdateProcessingOrderStatus(): IQueueEntry {
    return {
      name: 'prepareUpdateProcessingOrderStatus ' + this.constructor.name,
      pre: () => {
        const request: IUpdateProcessingStatusRequest = {
          comment: '',
          updatedBy: 'gSuite Order service LLC on API'
        };
        return this.processingOrderService.updateProcessingStatus(
          this.appService.app.gSuiteCrossSellOrderResponse.orderItem.processingOrder.processingOrderId,
          1468,
          request,
          this.appService.app.customerId
        );
      },
      post: response => {
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'gSuite-order.service', error);
        return of(null);
      }
    };
  }
}
