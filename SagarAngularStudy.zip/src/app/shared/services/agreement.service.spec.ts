import { TestBed, inject } from '@angular/core/testing';
import { CookieService } from 'ngx-cookie';
import { TrackingService } from './tracking/tracking.service';
import { AgreementService } from './agreement.service';
import { EnvironmentService } from './environment.service';
import { DatePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { AppService } from '../state/app/app.service';

describe('EnvironmentService', () => {
  let mockCookieService: CookieService;
  let mockTrackingService: TrackingService;
  const mockHttpClient = jasmine.createSpyObj(['get', 'post', 'put', 'delete']);
  let mockAppService = {
    accessToken: 'tetstetstetst',
    customerId: 12345
  };
  beforeEach(() => {
    mockTrackingService = jasmine.createSpyObj(['mobileViewTrack', 'mobileTrack']);
    mockCookieService = jasmine.createSpyObj(['get', 'check', 'getAll', 'set', 'delete']);
    TestBed.configureTestingModule({
      providers: [
        DatePipe,
        EnvironmentService,
        { provide: HttpClient, useValue: mockHttpClient },
        { provide: CookieService, useValue: mockCookieService },
        { provide: TrackingService, useValue: mockTrackingService },
        { provide: AppService, useValue: mockAppService }
      ]
    });
  });

  it('should be created', inject([AgreementService], (service: AgreementService) => {
    expect(service).toBeTruthy();
  }));
});
