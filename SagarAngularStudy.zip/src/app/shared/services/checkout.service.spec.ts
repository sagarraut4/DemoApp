// import { TestBed, fakeAsync } from '@angular/core/testing';
// import { CheckoutService } from './checkout.service';
// import { TrackingService } from './tracking/tracking.service';
// import { ExperimentsService } from './experiments/experiments.service';
// import { CookieService } from 'ngx-cookie';
// import { AppService } from '../state/app';
// import { CheckoutService as GCCheckoutService, Checkout } from '@legalzoom/lib-checkout';
// import { TaggingService, ITagOrderByIdResponse } from '@legalzoom/tagging-sdk';
// import { of } from 'rxjs';
// import { QuestionnaireService } from './questionnaire/questionnaire.service';
// import { EventService } from './event.service';
// import { CartBalance, UserContactInfo, ContactInfoType } from '@legalzoom/sdk-checkout';

// describe('CheckoutService', () => {
//   let mockTrackingService;
//   let mockExperimentService;
//   let mockGCCheckoutService;
//   let mockQuestionnaireService;
//   let mockEventService;
//   let mockCookieService;
//   let mockTaggingService;
//   let mockAppService = {
//     currentView: '',
//     loginEmail: '',
//     app: {
//       processingOrderId: 123,
//       customerId: 12345,
//       accessToken: 'tetstetstetst'
//     },
//     customerId: 12345
//   };
//   let service: CheckoutService;
//   let mockTagOrderResponse: ITagOrderByIdResponse;
//   let mockCartInstallments;
//   let mockCartItems;
//   let mockOrderSuccessResponse: Checkout;
//   let mockCart;
//   let mockCartBalance: CartBalance;
//   let mockContactInfo: UserContactInfo;


//   beforeEach(() => {
//     mockTrackingService = jasmine.createSpyObj(['SetCurrentPageToTrack', 'triggerClickTrack', 'SetECommerceTracking', 'triggerCheckoutPixels']);
//     mockExperimentService = jasmine.createSpyObj(['getOrderTagName', 'getExperimentName']);
//     mockGCCheckoutService = jasmine.createSpyObj(['agreeAndPayNow', 'gcLoaded', 'processCheckoutInit', 'processCheckoutOrderCharged']);
//     mockQuestionnaireService = jasmine.createSpyObj(['llc']);
//     mockEventService = jasmine.createSpyObj(['saveAndContinue']);
//     mockTaggingService = jasmine.createSpyObj(['tagOrderById']);

//     TestBed.configureTestingModule({

//       providers: [
//         CheckoutService, GCCheckoutService, TrackingService, ExperimentsService, AppService, CookieService, TaggingService, QuestionnaireService, EventService,
//         { provide: TrackingService, useValue: mockTrackingService },
//         { provide: ExperimentsService, useValue: mockExperimentService },
//         { provide: AppService, useValue: mockAppService },
//         { provide: CookieService, useValue: mockCookieService },
//         { provide: TaggingService, useValue: mockTaggingService },
//         { provide: GCCheckoutService, useValue: mockGCCheckoutService },
//         { provide: QuestionnaireService, useValue: mockQuestionnaireService },
//         { provide: EventService, useValue: mockEventService }
//       ]
//     });
//     service = TestBed.get(CheckoutService);
//     mockTagOrderResponse = {
//       orderTag: {
//         tagId: 123,
//         tagType: '',
//         tag: '',
//         dateCreated: '',
//         createdBy: '',
//         dateUpdated: '',
//         updatedBy: ''
//       }
//     };
//     mockTaggingService.tagOrderById.and.returnValue(of(
//       mockTagOrderResponse
//     ));

//     mockExperimentService.getExperimentName.and.returnValue(of(
//       'LLC_CTRL'
//     ));

//     mockTrackingService.SetECommerceTracking.and.returnValue(of(''))

//     mockCartInstallments = {
//       firstInstallment: {
//         installmentAmount: 379.67,
//         dueDate: '2020-05-11T07:00:00Z'
//       },
//       secondInstallment: {
//         installmentAmount: 379.67,
//         dueDate: '2020-06-11T07:00:00Z'
//       },
//       thirdInstallment: {
//         installmentAmount: 379.66,
//         dueDate: '2020-07-11T07:00:00Z'
//       }
//     };

//     mockCartItems = [
//       {
//         cartItemId: 58464390,
//         parentCartItemId: null,
//         productComponentId: 113,
//         productConfigurationId: 147,
//         productName: 'Express Gold LLC',
//         productTypeId: 2,
//         processingOrderId: 510183656,
//         basePrice: 359.0,
//         extendedPrice: 349.0,
//         adjustedPrice: 349.0,
//         quantity: 1,
//         isPrePaid: false,
//         shouldDisplayOnBill: true,
//         isCancelled: false,
//         productBasePriceId: 3058,
//         productPriceAdjustment: 1540,
//         stateId: 5,
//         countyId: null,
//         cartItemSource: 'UserAction',
//         sourceOrderItemId: null,
//         lineNumber: 1,
//         dateCreated: '2020-10-19T15:41:12.05Z',
//         createdBy: '15406367',
//         dateUpdated: '2020-10-19T15:41:15.657Z',
//         updatedBy: '15406367'
//       },
//       {
//         cartItemId: 58464392,
//         parentCartItemId: 58464390,
//         productComponentId: 322,
//         productConfigurationId: 804,
//         productName: 'State Filing Fee - {state}',
//         productTypeId: 8,
//         processingOrderId: null,
//         basePrice: 70.0,
//         extendedPrice: 70.0,
//         adjustedPrice: 70.0,
//         quantity: 1,
//         isPrePaid: false,
//         shouldDisplayOnBill: true,
//         isCancelled: true,
//         productBasePriceId: 7325,
//         productPriceAdjustment: null,
//         stateId: 5,
//         countyId: null,
//         cartItemSource: 'System',
//         sourceOrderItemId: null,
//         lineNumber: 101,
//         dateCreated: '2020-10-19T15:40:40.283Z',
//         createdBy: '15406367',
//         dateUpdated: '2020-10-19T15:41:15.657Z',
//         updatedBy: '15406367'
//       }
//     ];

//     mockOrderSuccessResponse = {
//       userId: 123456,
//       loginEmail: 'test123@test.com',
//       sessionId: 'sdfsdfdsf',
//       accessToken: 'fsdfsdfsdf',
//       orderId: 8856464,
//       processingOrderId: 78967556,
//       isThreePay: false,
//       cart: mockCart,
//       cartBalance: mockCartBalance,
//       amount: 500,
//       shippingContact: mockContactInfo,
//       isGuestConvertedOnCheckout: true,
//       isGuestUser: true
//     };

//     mockCart = {
//       cart: {
//         cartId: 22421539,
//         customerId: 15406367,
//         startDate: "2020-10-19T15:40:40.123Z",
//         cartType: "General",
//         cartMode: "General",
//         cartStatus: "Open",
//         orderSource: 1,
//         cartFlags: {
//           collectTax: false,
//           threePay: false,
//           phoneOrder: false,
//           showOrderTerms: false,
//           fiveInFive: false,
//           conversionTest: false,
//           isSamsClub: false,
//           bundle: false,
//           printingOptional: false,
//           amazon: false,
//           thirdPartyOrder: false,
//           ribbon: false
//         },
//         cartItems: [
//           {
//             cartItemId: 58464390,
//             parentCartItemId: null,
//             productComponentId: 113,
//             productConfigurationId: 147,
//             productName: "Express Gold LLC",
//             productTypeId: 2,
//             processingOrderId: 510183656,
//             basePrice: 359.0,
//             extendedPrice: 349.0,
//             adjustedPrice: 349.0,
//             quantity: 1,
//             isPrePaid: false,
//             shouldDisplayOnBill: true,
//             isCancelled: false,
//             productBasePriceId: 3058,
//             productPriceAdjustment: 1540,
//             stateId: 5,
//             countyId: null,
//             cartItemSource: "UserAction",
//             sourceOrderItemId: null,
//             lineNumber: 1,
//             dateCreated: "2020-10-19T15:41:12.05Z",
//             createdBy: "15406367",
//             dateUpdated: "2020-10-19T15:41:15.657Z",
//             updatedBy: "15406367"
//           },
//           {
//             cartItemId: 58464392,
//             parentCartItemId: 58464390,
//             productComponentId: 322,
//             productConfigurationId: 804,
//             productName: "State Filing Fee - {state}",
//             productTypeId: 8,
//             processingOrderId: null,
//             basePrice: 70.0,
//             extendedPrice: 70.0,
//             adjustedPrice: 70.0,
//             quantity: 1,
//             isPrePaid: false,
//             shouldDisplayOnBill: true,
//             isCancelled: true,
//             productBasePriceId: 7325,
//             productPriceAdjustment: null,
//             stateId: 5,
//             countyId: null,
//             cartItemSource: "System",
//             sourceOrderItemId: null,
//             lineNumber: 101,
//             dateCreated: "2020-10-19T15:40:40.283Z",
//             createdBy: "15406367",
//             dateUpdated: "2020-10-19T15:41:15.657Z",
//             updatedBy: "15406367"
//           }
//         ],
//         dateCreated: "2020-10-19T15:40:40.283Z",
//         createdBy: "15406367",
//         dateUpdated: "2020-10-19T15:40:40.283Z",
//         updatedBy: "15406367"
//       }
//     }

//     mockCartBalance = {
//       cartId: 22421539,
//       customerId: 15406367,
//       totalTax: 0,
//       storeCreditAvailable: 0,
//       totalAmount: 1139,
//       totalDiscount: 0,
//       discountCode: null,
//       cartBalance: 1139,
//       cartDiscounts: [
//         {
//           cartId: 0,
//           discountType: 1,
//           discountMethod: 2,
//           memberGroupCodeId: null,
//           userDiscountId: null,
//           percentage: null,
//           discount: 0,
//           memberGroupDiscount: null,
//           customerId: 0,
//           discountCode: null,
//           userDiscountDto: null
//         }
//       ],
//       cartInstallments: {
//         firstInstallment: {
//           installmentAmount: 379.67,
//           dueDate: '2020-05-11T07:00:00Z'
//         },
//         secondInstallment: {
//           installmentAmount: 379.67,
//           dueDate: '2020-06-11T07:00:00Z'
//         },
//         thirdInstallment: {
//           installmentAmount: 379.66,
//           dueDate: '2020-07-11T07:00:00Z'
//         }
//       }
//     };

//     mockContactInfo = {
//       userContactInfoId: 45645654,
//       customerId: 7897897,
//       description: 'dfdsfdf',
//       firstName: 'test',
//       lastName: 'test',
//       addressLine1: '100 test test',
//       addressLine2: '',
//       city: 'test',
//       stateId: 5,
//       county: 1,
//       zipcode: '91203',
//       email1: 'test123@test.com',
//       email2: '',
//       email3: '',
//       homePhone: '',
//       workPhone: '',
//       cellPhone: '',
//       fax: '',
//       country: 1,
//       state: '5',
//       taxID: 0,
//       active: 1,
//       statusChanged: '2020-05-11T07:00:00Z',
//       statusChangedBy: '4563412',
//       crmContactId: '123',
//       contactInfoType: ContactInfoType.shipping,
//       updateSource: 0,
//       stateFullName: 'California',
//       abbr: 'CA',
//       existingContact: false,
//       contactCreated: false,
//       contactUpdated: false,
//       message: 'test'
//     }

//   });

//   it('checkout service should be created', () => {
//     expect(service).toBeTruthy();
//   });

//   it('checkout service should be defined', () => {
//     expect(service).toBeDefined();
//   });

//   it('checkout service => setAppStateAfterCheckout should be defined', () => {
//     expect(service.setAppStateAfterCheckout).toBeDefined();
//   });

//   it('checkout service => setAppStateAfterCheckout should be called', () => {
//     const service: CheckoutService = TestBed.get(CheckoutService);
//     spyOn(service, 'setAppStateAfterCheckout');
//     service.setAppStateAfterCheckout(mockOrderSuccessResponse);
//     expect(service.setAppStateAfterCheckout).toHaveBeenCalled();
//   });

//   it('checkout service => performTracking should be defined', () => {
//     expect(service.performTracking).toBeDefined();
//   });

//   it('checkout service => performTracking should be called', () => {
//     const service: CheckoutService = TestBed.get(CheckoutService);
//     spyOn(service, 'performTracking');
//     service.performTracking(mockOrderSuccessResponse);
//     expect(service.performTracking).toHaveBeenCalled();
//   });

//   it('checkout service => mapCartItems should be defined', () => {
//     expect(service.mapCartItems).toBeDefined();
//   });

//   it('checkout service => mapCartItems should be called', () => {
//     const service: CheckoutService = TestBed.get(CheckoutService);
//     spyOn(service, 'mapCartItems');
//     service.mapCartItems(mockCartItems);
//     expect(service.mapCartItems).toHaveBeenCalled();
//   });

//   it('checkout service => subscribeToCheckoutEvents should be defined', () => {
//     const service: CheckoutService = TestBed.get(CheckoutService);
//     expect(service.subscribeToCheckoutEvents).toBeDefined();
//   });

//   it('checkout service => subscribeToCheckoutEvents should be called', fakeAsync(() => {
//     const service: CheckoutService = TestBed.get(CheckoutService);
//     spyOn(service, 'subscribeToCheckoutEvents');
//     service.subscribeToCheckoutEvents();
//     expect(service.subscribeToCheckoutEvents).toHaveBeenCalled();
//     expect(mockGCCheckoutService.agreeAndPayNow);
//     expect(mockGCCheckoutService.gcLoaded);
//     expect(mockGCCheckoutService.processCheckoutInit);
//     expect(mockGCCheckoutService.processCheckoutOrderCharged);
//   }));

//   it('checkout service => getCartInstallment should be defined', () => {
//     const service: CheckoutService = TestBed.get(CheckoutService);
//     expect(service.getCartInstallment).toBeTruthy();
//   });

//   it('checkout service => getCartInstallment should be called', () => {
//     const service: CheckoutService = TestBed.get(CheckoutService);
//     spyOn(service, 'getCartInstallment');
//     service.getCartInstallment(mockCartInstallments);
//     expect(service.getCartInstallment).toHaveBeenCalled();
//   });

//   it('checkout service => orderTagByIdForApiHandlerExp should be defined', () => {
//     const service: CheckoutService = TestBed.get(CheckoutService);
//     expect(service.orderTagByIdForApiHandlerExp).toBeTruthy();
//   });

//   it('checkout service => orderTagByIdForApiHandlerExp should be called', () => {
//     const service: CheckoutService = TestBed.get(CheckoutService);
//     spyOn(service, 'orderTagByIdForApiHandlerExp');
//     service.orderTagByIdForApiHandlerExp();
//     expect(service.orderTagByIdForApiHandlerExp).toHaveBeenCalled();
//   });

// });
