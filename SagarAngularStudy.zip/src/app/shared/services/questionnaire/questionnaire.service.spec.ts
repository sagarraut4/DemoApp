import { QuestionnaireStorageModule, QuestionnaireStorageService } from '@legalzoom/questionnaire-storage-sdk';
import { EnvironmentService } from './../environment.service';
import { TestBed, inject } from '@angular/core/testing';
import { QuestionnaireService } from './questionnaire.service';
import { HttpClient } from '@angular/common/http';
import { LLC, QuestionnaireStorage } from '../../models/questionnaire-model';
import { UserOrder } from '../../models/user-order-model';
import { ProductName } from '../../constants/product-domain';
import { QueueService } from '@legalzoom/business-formation-sdk';
import { of } from 'rxjs';

describe('QuestionnaireService', () => {
  const mockHttpClient = jasmine.createSpyObj(['get', 'post', 'put', 'delete']);
  const mockQuestionnaireStorageService = jasmine.createSpyObj(['getQuestionnaireStorage']);
  const llcObj = new LLC();

  const mockQuestionnaireStorage = new QuestionnaireStorage();
  mockQuestionnaireStorage.Answers = 'llc answers';
  mockQuestionnaireStorage.UserOrderId = 123;

  const mockUserOrder = new UserOrder();
  mockUserOrder.processId = 1;
  mockUserOrder.processName = 'llc';
  mockUserOrder.questionnaireId = 1;
  mockUserOrder.questionnaireStorage = mockQuestionnaireStorage;
  mockUserOrder.reopen = 'false';
  mockUserOrder.revisionNumber = 1;

  const mockUserOrderService = {
    userOrder: mockUserOrder
  };
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [QuestionnaireStorageModule],
      providers: [QuestionnaireService,
        { provide: HttpClient, useValue: mockHttpClient },
        { provide: QuestionnaireStorageService, useValue: mockQuestionnaireStorageService },
        { provide: UserOrder, useValue: mockQuestionnaireStorageService }]
    });
  });

  it('QuestionnaireService should be created', inject([QuestionnaireService], (service: QuestionnaireService) => {
    expect(service).toBeTruthy();
  }));

  it('setLC method should set the LLC object', () => {
    const service: QuestionnaireService = TestBed.get(QuestionnaireService);
    llcObj.entityState = 'California';
    service.setLLC(llcObj);
    expect(service.llc.entityState).toEqual('California');
  });

  it('setStateTaxRegistration should fill correct value in isLZStateTaxId, isLZSellersPermit', () => {
    const service: QuestionnaireService = TestBed.get(QuestionnaireService);

    service.setStateTaxRegistration(false);
    expect(service.llc.isLZStateTaxId).toBe(false);
    expect(service.llc.isLZSellersPermit).toBe(false);

    service.llc.entityState = 'Arizona';
    service.setStateTaxRegistration(true);
    expect(service.llc.isLZStateTaxId).toBe(true);
    expect(service.llc.isLZSellersPermit).toBe(false);

    service.llc.entityState = 'Colorado';
    service.setStateTaxRegistration(true);
    expect(service.llc.isLZStateTaxId).toBe(false);
    expect(service.llc.isLZSellersPermit).toBe(true);

    service.llc.entityState = 'California';
    service.setStateTaxRegistration(true);
    expect(service.llc.isLZStateTaxId).toBe(true);
    expect(service.llc.isLZSellersPermit).toBe(true);

    service.llc.entityState = 'Delware';
    service.setStateTaxRegistration(true);
    expect(service.llc.isLZStateTaxId).toBe(false);
    expect(service.llc.isLZSellersPermit).toBe(false);
  });

  it('prepareGetQuestionnaireStorage method should prepare the questionnaire', () => {
    const service: QuestionnaireService = TestBed.get(QuestionnaireService);
    const mockQueueService = TestBed.get(QueueService);
    let check = false;
    mockQuestionnaireStorageService.getQuestionnaireStorage.and.returnValue(of(true));
    mockQueueService.add(service.prepareGetQuestionnaireStorage({ constructor: { name: 'test' } }, 123456,
      123, 'authToken', ProductName.LLC, (data) => { check = true; }));
    mockQueueService.process().subscribe();
    expect(mockQuestionnaireStorageService.getQuestionnaireStorage).toHaveBeenCalled();
    expect(check).toEqual(true);
  });

});
