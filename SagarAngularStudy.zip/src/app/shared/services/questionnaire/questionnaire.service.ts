import { AppService } from '../../state/app/app.service';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { of } from 'rxjs';
import { LLC } from '../../models/questionnaire-model';
import { EnvironmentService } from '../environment.service';
import { IQueueEntry } from '@legalzoom/business-formation-sdk';
import { ProductName } from '../../constants/product-domain';
import { IQuestionnaireStorageResponse, QuestionnaireStorageService as SdkQuestionnaireService } from '@legalzoom/questionnaire-storage-sdk';
declare var trackJs: any;
@Injectable()
export class QuestionnaireService {
  [x: string]: any;
  public llc: LLC;
  public broswerHistory: string[] = [];

  constructor(
    private appService: AppService,
    private http: HttpClient,
    private environmentService: EnvironmentService,
    private sdkQuestionnaireService: SdkQuestionnaireService
  ) {
    this.llc = new LLC();
  }

  setLLC(obj: any) {
    const isMobile = this.llc.isMobile;
    this.llc = obj;
    this.llc.currentView = obj.currentView || '';
    this.llc.currentView = this.llc.currentView.startsWith('/') ? this.llc.currentView.slice(1) : this.llc.currentView;
    this.llc.isMobile = isMobile;
  }

  public setStateTaxRegistration(isOptin: boolean): void {
    if (isOptin) {
      if (['Arizona', 'Florida', 'Illinois', 'Minnesota', 'Pennsylvania', 'Texas', 'Washington', 'Wisconsin', 'New Jersey'].includes(this.llc.entityState)) {
        this.llc.isLZStateTaxId = true;
        this.llc.isLZSellersPermit = false;
      } else if (['Colorado', 'South Carolina', 'Virginia'].includes(this.llc.entityState)) {
        this.llc.isLZStateTaxId = false;
        this.llc.isLZSellersPermit = true;
      } else if (['California', 'Ohio'].includes(this.llc.entityState)) {
        this.llc.isLZStateTaxId = true;
        this.llc.isLZSellersPermit = true;
      } else {
        this.llc.isLZStateTaxId = false;
        this.llc.isLZSellersPermit = false;
      }
    } else {
      this.llc.isLZStateTaxId = false;
      this.llc.isLZSellersPermit = false;
    }
  }

  public prepareGetQuestionnaireStorage(
    context: any,
    customerId: number,
    processingOrderId: number,
    authToken: string,
    productName: ProductName,
    successGetQuestionnaireStorage: (response: IQuestionnaireStorageResponse) => void
  ): IQueueEntry {
    const that = this;
    return {
      name: 'prepareGetQuestionnaireStorage questionnaire.service' + context.constructor.name,
      pre: () => {
        return that.sdkQuestionnaireService.getQuestionnaireStorage(customerId, processingOrderId);
      },
      post: (response) => {
        if (!!response) {
          context.questionnaireStorage = response;
          successGetQuestionnaireStorage(response);
        }
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        trackJs.track(productName, 'questionnaire.service' + context.constructor.name, error);
        return of(null);
      }
    };
  }

  public prepareUpdateQuestionnaireStorage(
    data: object, processingOrderId?
  ): IQueueEntry {
    const that = this
    return {
      name: 'prepareUpdateQuestionnaireStorage ' + this.constructor.name,
      pre: () => {
        return that.sdkQuestionnaireService.updateQuestionnaireStorage(processingOrderId ? processingOrderId: that.appService.processingOrderId, {...that.llc, ...data });
      },
      post: (response) => {},
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, `${this.constructor.name} called from ${this.parentComponentName}`, error);
        return of(null);
      }
    };
  }
}
