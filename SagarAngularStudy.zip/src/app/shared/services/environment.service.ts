import { Injectable } from '@angular/core';

import { environment } from '../../../environments/environment';

@Injectable()
export class EnvironmentService {

  constructor() { }

  public getAccessKey() {
    return environment.accessKey;
  }

  public getLzApiKey() {
    return environment.lzApiKey;
  }

  public getBusinessActivitiesUrl(): string {
    return environment.businessActivitiesUrl;
  }

  public getBusinessActivityUrl(): string {
    return environment.businessActivityUrl;
  }

  public getIsBusinessNameAvailableUrl() {
    return environment.isBusinessNameAvailableUrl;
  }
  public getCartBillingItemsUrl(): string {
    return environment.cartBillingItemsUrl;
  }

  public getApplyDiscountUrl(): string {
    return environment.applyDiscountUrl;
  }

  public getSaveQuestionnaireUrl() {
    return environment.saveQuestionnaireUrl;
  }

  public getSetQuestionnaireUrl() {
    return environment.setQuestionnaireUrl;
  }

  public getGetQuestionnaireUrl() {
    return environment.getQuestionnaireUrl;
  }

  public getCheckoutUrl() {
    return environment.checkoutUrl;
  }

  public getGetCartUrl() {
    return environment.getCartUrl;
  }

  public getPostCartUrl() {
    return environment.postCartUrl;
  }

  public getGuestPassSignInUrl() {
    return environment.guestPassSignInUrl;
  }

  public getPackagesURL() {
    return environment.getPackagesUrl;
  }

  public getSEMTrackingUrl() {
    return environment.getSEMTrackingUrl;
  }

  public getTealiumConfig() {
    return environment.tealium;
  }

  public getSetOrderCompleteUrl() {
    return environment.getSetOrderCompleteUrl;
  }

  public getEmailHandlerUrl() {
    return environment.getEmailHandlerUrl;
  }

  public getTaggingHandlerUrl() {
    return environment.getTaggingHandlerUrl;
  }

  public getAddressAutocompleteUrl(): string {
    return environment.addressAutocompleteUrl;
  }

  public getAddressValidationUrl(): string {
    return environment.addressValidationUrl;
  }

  public getPostCheckoutUrl(): string {
    return environment.getPostCheckoutUrl;
  }

  public getLlcStartPageUrl(): string {
    return environment.llcStartPageUrl;
  }

  public isProduction() {
    return environment.production;
  }

  public isInKenshooTestMode() {
    return environment.testKenshoo;
  }

  public getOptimizelyUrl() {
    return environment.optimizelyUrl;
  }

  public getTestKenshooData() {
    const kenshooData = {
      url: environment.kenshooUrl,
      id: environment.kenshooID,
    };

    return kenshooData;
  }

  public getFilingFeesUrl(): string {
    return environment.filingFeesUrl;
  }

  public getFilingFeeUrl(): string {
    return environment.filingFeeUrl;
  }

  public getExpressOrderUrl(): string {
    return environment.getExpressOrderUrl;
  }

  getSetCartPackageItemURL(): any {
    return environment.setPackageItemURL;
  }

  getGeoLocationUrl(): string {
    return environment.geoLocationUrl;
  }

  getLaunchDarklyClientId(): string {
    return environment.launchDarklyClientId;
  }

  public getAgreementsUrl(): string {
    return environment.agreementsUrl;
  }

  public getDrupalAgreementsUrl(): string {
    return environment.drupalAgreementsUrl;
  }

  public getSetPasswordUrl(): string {
    return environment.sso.ssoProxyConfig.apiBaseUri + environment.setPasswordUrl;
  }
  
  public getCustomerUrl(): string {
    return environment.getCustomerUrl;
  }

  public getPartnerOptInUrl(): string {
    return environment.partnerOptInUrl;
  }
  /**
   * This method:
   *   a) Loads "env.json" to get the current working environment (e.g.: 'production', 'development')
   *   b) Loads "config.[env].json" to get all env's variables (e.g.: 'config.development.json')
   */

  public load() {
    return;
  }
}