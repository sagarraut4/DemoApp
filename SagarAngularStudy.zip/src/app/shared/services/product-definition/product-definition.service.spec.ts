import { QuestionnaireService } from './../questionnaire/questionnaire.service';
import { ExperimentsService } from './../experiments/experiments.service';
import { TestBed, inject } from '@angular/core/testing';
import { ProductDefinitionService } from './product-definition.service';
import { ProductConfigurationIds } from '../../models/cart-model';

describe('ProductDefinitionService', () => {
  let mockExpService;
  let mockQuestionnaireService = { llc: { packageSelected: ProductConfigurationIds.economyLLCPackage } };
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ProductDefinitionService,
        { provide: ExperimentsService, useValue: mockExpService },
        { provide: QuestionnaireService, useValue: mockQuestionnaireService }]
    });
  });

  it('ProductDefinitionService should be created', inject([ProductDefinitionService], (service: ProductDefinitionService) => {
    expect(service).toBeTruthy();
  }));

  it('RA method should return RA price', () => {
    const service: ProductDefinitionService = TestBed.get(ProductDefinitionService);
    const raPrice = service.RA();
    expect(raPrice).not.toBeNull();
    expect(raPrice.price).toBe('249');
  });

  it('TAX method should return TAX', () => {
    const service: ProductDefinitionService = TestBed.get(ProductDefinitionService);
    const tax = service.TAX();
    expect(tax).not.toBeNull();
    expect(tax.daysInTrial).toBe('10');
    expect(tax.name).toBe('Affordable Tax');
  });

  it('COMPLIANCE method should return COMPLIANCE', () => {
    const service: ProductDefinitionService = TestBed.get(ProductDefinitionService);
    const compliance = service.COMPLIANCE();
    expect(compliance).not.toBeNull();
    expect(compliance.daysInTrial).toBe('10');
    expect(compliance.name).toBe('Total Compliance');
    expect(compliance.price).toBe('$280');
  });

  it('COMPLIANCE method should return COMPLIANCE', () => {
    const service: ProductDefinitionService = TestBed.get(ProductDefinitionService);
    const compliance = service.COMPLIANCE();
    expect(compliance).not.toBeNull();
    expect(compliance.daysInTrial).toBe('10');
    expect(compliance.name).toBe('Total Compliance');
    expect(compliance.price).toBe('$280');
  });

  it('PROCESSING method should return processing', () => {
    const service: ProductDefinitionService = TestBed.get(ProductDefinitionService);

    mockQuestionnaireService.llc.packageSelected = ProductConfigurationIds.economyLLCPackage;

    const processing = service.PROCESSING();
    expect(processing).not.toBeNull();
    expect(processing.NonExpdTimeFrame).toBe(30);
    expect(processing.name).toBe('Expedited Processing');
    expect(processing.price).toBe(149);
  });

  it('ESSENTIAL_DOCS_PKGS method should return essential packages', () => {
    const service: ProductDefinitionService = TestBed.get(ProductDefinitionService);
    const packages = service.PROCESSING();
    expect(packages).not.toBeNull();
  });

  it('CHECKOUT_SUBS_DISCLAIMER method should return checkout disclaimers packages', () => {
    const service: ProductDefinitionService = TestBed.get(ProductDefinitionService);
    const disclaimers = service.CHECKOUT_SUBS_DISCLAIMER();
    expect(disclaimers).not.toBeNull();
    expect(disclaimers.simple.begin).toBe('You have selected the following subscription(s) that renew automatically. ');
  });

  it('getLLCPackageName method should return llc package name', () => {
    const service: ProductDefinitionService = TestBed.get(ProductDefinitionService);
    let packageName = service.getLLCPackageName(ProductConfigurationIds.economyLLCPackage);
    expect(packageName).not.toBeNull();
    expect(packageName).toBe('Economy LLC');

    packageName = service.getLLCPackageName(ProductConfigurationIds.standarLLCPackage);
    expect(packageName).not.toBeNull();
    expect(packageName).toBe('Standard LLC');

    packageName = service.getLLCPackageName(ProductConfigurationIds.expressGoldLLCPackage);
    expect(packageName).not.toBeNull();
    expect(packageName).toBe('Express Gold LLC');

    packageName = service.getLLCPackageName(ProductConfigurationIds.tier1LLCPackage);
    expect(packageName).not.toBeNull();
    expect(packageName).toBe('LLC - Get Me Started');

    packageName = service.getLLCPackageName(ProductConfigurationIds.tier2LLCPackage);
    expect(packageName).not.toBeNull();
    expect(packageName).toBe('LLC - Support Me');

    packageName = service.getLLCPackageName(ProductConfigurationIds.tier3LLCPackage);
    expect(packageName).not.toBeNull();
    expect(packageName).toBe('LLC - Help Me Grow');
  });

  it('getGSuitePackages method should return gsuite packages', () => {
    const service: ProductDefinitionService = TestBed.get(ProductDefinitionService);
    const gSuitePackage = service.getGSuitePackages();
    expect(gSuitePackage).not.toBeNull();
    expect(gSuitePackage.basic.packageType).toBe('Basic');
    expect(gSuitePackage.basic.price).toBe(6);
    expect(gSuitePackage.business.packageType).toBe('Business');
    expect(gSuitePackage.business.price).toBe(12);
  });

  it('getProcessingFee method should return procesing fees', () => {
    const service: ProductDefinitionService = TestBed.get(ProductDefinitionService);
    let fees = service.getProcessingFee(ProductConfigurationIds.economyLLCPackage);
    expect(fees).not.toBeNull();
    expect(fees).toBe(149);

    fees = service.getProcessingFee(ProductConfigurationIds.standarLLCPackage);
    expect(fees).not.toBeNull();
    expect(fees).toBe(99);

    fees = service.getProcessingFee(ProductConfigurationIds.expressGoldLLCPackage);
    expect(fees).not.toBeNull();
    expect(fees).toBe(0);
  });
});
