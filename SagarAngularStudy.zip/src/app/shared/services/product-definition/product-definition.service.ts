import { Injectable } from '@angular/core';
import { ExperimentsService } from '../experiments/experiments.service';
import { ProductConfigurationIds } from '../../models/cart-model';
import { QuestionnaireService } from '../questionnaire/questionnaire.service';

@Injectable()
export class ProductDefinitionService {

  constructor(
    private experimentService: ExperimentsService,
    private questionnaireService: QuestionnaireService
  ) { }

  public RA() {
    return {
      price: '249'
    };
  }

  public TAX() {
    return {
      daysInTrial: '10',
      name: 'Affordable Tax'
    };
  }

  public COMPLIANCE() {
    return {
      daysInTrial: '10',
      name: 'Total Compliance',
      price: '$280'
    };
  }

  public PROCESSING() {
    if (this.questionnaireService.llc.packageSelected === ProductConfigurationIds.economyLLCPackage) {
      return {
        name: 'Expedited Processing',
        price: 149,
        NonExpdTimeFrame: 30
      };
    } else if (this.questionnaireService.llc.packageSelected === ProductConfigurationIds.standarLLCPackage) {
      return {
        name: 'Expedited Processing',
        price: 99,
        NonExpdTimeFrame: 15
      };
    }
  }

  public ESSENTIAL_DOCS_PKGS() {
    // control
    return {
      basic: {
        title: 'Operating Agreement',
        price: '$99',
        body: `An operating agreement is critical: it's your LLC's constitution.`

      },
      standard: {
        title: 'Operating Agreement and EIN',
        price: '$159',
        body: 'An EIN is required to open a business bank account.'
      },
      recommended: {
        title: 'Operating Agreement, EIN, and Licenses',
        price: '$249',
        body: 'This provides the key documents your LLC needs at an affordable price. State and local licenses are required to run your business. <a href="javascript:">Read more details.</a>'

      }
    };
  }

  // Hari created on 10/30/2018 for LLC checkout disclaimer test
  public CHECKOUT_SUBS_DISCLAIMER() {
    return{
      simple: {
        begin: 'You have selected the following subscription(s) that renew automatically. ',
        beginbap:  'You will be charged for ',
        tax: 'Affordable Tax (<strong>$320</strong>/first year)',
        legallp: 'Legal Protect Plan (<strong>$39.99</strong>/month)',
        legalse: 'Legal Protect Plan (<strong>$39.99</strong>/month)',
        legalsewi: 'Legal Protect Plan (<strong>$15.99</strong>/month)',
        legallpwi: 'Legal Protect Plan (<strong>$15.99</strong>/month)',
        totalcp: 'Total Compliance (<strong>$280</strong>/first year)',
        ra: 'You will be charged for Registered Agent (<strong>$249</strong>/first year) at the time of your entity’s filing. ',
        end: ' in 10 days. ',
        raend: 'To cancel Registered Agent subscription, you will need to first appoint a new Registered Agent. ',
        endcommon: 'Renewal rates subject to change. You can cancel renewals anytime by visiting your LegalZoom account. ' ,
        ratitle: 'Registered Agent',
        raprice: '$249',
        cmpltitle: 'Total Compliance',
        cmplprice: '$280',
        taxandlegalsetitle: 'Affordable Tax + Legal Protect Plan',
        taxandlegallptitle: 'Affordable Tax + Legal Protect Plan',
        taxandlegalprice: '$640',
        taxandlegalpricewi: '$520',
        taxtitle: 'Affordable Tax',
        taxprice: '$320',
        legallptitle: 'Legal Protect Plan',
        legalsetitle: 'Legal Protect Plan',
        legalprice: '$320',
        legalpricewi: '$200',
        gsuit: 'You will be charged for G Suite on a prorated basis today and then again on the 1st of each month. '
      }
    };
  }

  public getLLCPackageName(configId: number): string {
    let packageName = '';
    switch (configId) {
      case ProductConfigurationIds.economyLLCPackage:
        packageName = 'Economy LLC';
        break;
      case ProductConfigurationIds.standarLLCPackage:
        packageName = 'Standard LLC';
        break;
      case ProductConfigurationIds.expressGoldLLCPackage:
        packageName = 'Express Gold LLC';
        break;
      case ProductConfigurationIds.tier1LLCPackage:
        packageName = 'LLC - Get Me Started';
        break;
      case ProductConfigurationIds.tier2LLCPackage:
        packageName = 'LLC - Support Me';
        break;
      case ProductConfigurationIds.tier3LLCPackage:
        packageName = 'LLC - Help Me Grow';
        break;
      case ProductConfigurationIds.basicLLC:
        packageName = 'LLC Basic Package'
        break;
      case ProductConfigurationIds.proLLC:
        packageName = 'LLC Pro Package'
        break;
      case ProductConfigurationIds.attrAssistProLLC:
        packageName = 'LLC Premium Package'
        break;
      case ProductConfigurationIds.attrAssistPremiumLLC:
        packageName = 'LLC Premium Plus Package'
        break;
    }

    return packageName;
  }

  public getGSuitePackages() {
    return {
      basic: {
        packageType: 'Business Starter',
        price: 6,
      },
      business: {
        packageType: 'Business Standard',
        price: 12,
      }
    };
  }

  public getProcessingFee(pkg: number): number {
    if (pkg === ProductConfigurationIds.economyLLCPackage) {
     return 149;
    } else if (pkg === ProductConfigurationIds.standarLLCPackage) {
    return 99;
    } else {
      return 0;
    }
  }
}
