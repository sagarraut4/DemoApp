import { AppService } from '../state/app';
import { CheckoutReturnType } from './../constants/checkout-return-type';
import {
  IQueueEntry,
  QueueService,
  TrackJsErrorLogService,
} from '@legalzoom/business-formation-sdk';
import { EmailNotificationService, IEmailHandlerRequest } from '@legalzoom/notification-sdk';
import { environment } from './../../../environments/environment';
import { EventService } from './event.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { of } from 'rxjs';
import { PagePath } from './../models/page-model';
import { ProductConfigurationIds } from '../models/cart-model';
import { ProductName } from './../constants/product-domain';
import { ConstantsService, QuestionnaireId } from './constants.service';
import { QuestionnaireService } from './questionnaire/questionnaire.service';
import { TrackingService } from './tracking/tracking.service';
import { CrossSellPackages } from './../constants/cross-sell-packages';
import { ExpressOrderResponse } from '../models/express-order-model';
import { ProcessingOrderService, IProcessingOrderQueueResponse, IUpdateProcessingOrderRequest } from '@legalzoom/processing-order-sdk';
import { OrderService, ICreateCrossSellOrderRequest, ICreateCrossSellOrderResponse, IOrderContact } from '@legalzoom/order-sdk';
import { QuestionnaireAnswerService, IUserAnswerRequest } from '@legalzoom/questionnaire-answer-sdk';
import { PaymentService, ICreatePaymentRequest, IGetPaymentResponse } from '@legalzoom/payment-sdk';
import { TaggingService, ITagOrderByIdRequest, TagType } from '@legalzoom/tagging-sdk';
import { CustomerService } from '@legalzoom/customer-sdk';
import { Address } from '../models/address-model';
import { Payment } from '@legalzoom/sdk-checkout';
import { CrossSellOrder } from '../models/crossSell-order-model';

@Injectable({
  providedIn: 'root'
})
export class CrossSellService {
  public tagOrderByIdResponse;
  public newSkuArray = [];
  constructor(
    private appService: AppService,
    private queueService: QueueService,
    private orderService: OrderService,
    private trackJS: TrackJsErrorLogService,
    private paymentService: PaymentService,
    private emailNotificationService: EmailNotificationService,
    private questionnaireService: QuestionnaireService,
    private processingOrderService: ProcessingOrderService,
    private trackingService: TrackingService,
    private eventService: EventService,
    private questionnaireAnswerService: QuestionnaireAnswerService,
    private taggingService: TaggingService,
    private customerService: CustomerService
  ) { }

  public savePackage(selectedPackage) {
    if (selectedPackage === CrossSellPackages.tms || selectedPackage === CrossSellPackages.both) {
      this.loadQueueForCrossSellOrder(ProductConfigurationIds.tmsCrosssell);
    }
    if (selectedPackage === CrossSellPackages.lwt || selectedPackage === CrossSellPackages.both) {
      this.loadQueueForCrossSellOrder(ProductConfigurationIds.lwtCrosssell);
    }

    this.queueService.add(this.preprareSaveAndContinue());

    this.queueService.process().subscribe(() => { });
  }

  public loadQueueForCrossSellOrder(crossSellConfigId: number) {
    this.queueService.add(
      this.prepareCreateCrossSellsOrder_CrossSell(crossSellConfigId)
    );
    this.queueService.add([
      this.prepareCreateBillOrder_CrossSell(crossSellConfigId),
      this.prepareCreateProcessingOrderQueue(crossSellConfigId)
    ]);

    if (crossSellConfigId === ProductConfigurationIds.tmsCrosssell) {
      this.queueService.add(
        this.prepareUpdateQuestionnaireForTms()
      );
      this.queueService.add(
        this.prepareUpdateProcessingOrderForTms()
      );
    }
    if (crossSellConfigId === ProductConfigurationIds.lwtCrosssell) {
      this.queueService.add(
        this.prepareUpdateQuestionnaireForLWT()
      );
    }
    this.queueService.add(this.prepareTagOrderById_CrossSell(crossSellConfigId));
    this.queueService.add([
      this.prepareCreateOrderContactPrimary(crossSellConfigId),
      this.prepareCreateOrderContactShipping(crossSellConfigId),
      this.prepareCreateOrderContactBilling(crossSellConfigId),
      this.prepareTrackCrosssellOrderItems()
    ]);
    this.queueService.add(
      this.prepareSendEmailNotification(crossSellConfigId)
    );
  }

  public prepareCreateCrossSellsOrder_CrossSell(crossSellConfigId: number): IQueueEntry {
    const newOrder = true;
    return {
      name: 'prepareCreateCrossSellsOrder_CrossSell ' + this.constructor.name,
      pre: () => {
        const createCrossSellOrderRequest: ICreateCrossSellOrderRequest = {
          productConfigurationId: crossSellConfigId,
          createdBy: this.appService.customerId.toString()
        };
        return this.orderService.createCrossSellOrder(
          this.appService.orderId,
          createCrossSellOrderRequest,
          newOrder
        );
      },
      post: response => {

        if (!environment.production) {
          console.log(
            '1. createCrossSellsOrder_CrossSell: productConfigId: ' +
            crossSellConfigId +
            ' | RESPONSE: Order Id: ' +
            response.orderId +
            ' processing order Id: ' +
            response.orderItem.processingOrder.processingOrderId +
            ' extended Price: ' +
            response.orderItem.extendedPrice
          );
          console.log(
            '1. createCrossSellsOrder_CrossSell: getOrderContactResponse  ' +
            response
          );
        }

        if (crossSellConfigId === ProductConfigurationIds.tmsCrosssell) {
          this.appService.tmsCrossSellOrderResponse = response;
          this.questionnaireService.llc.TMSExpressOrderResponse = new ExpressOrderResponse();
          this.questionnaireService.llc.TMSExpressOrderResponse.ExpressOrderId = response.orderId;
        } else if (
          crossSellConfigId === ProductConfigurationIds.lwtCrosssell
        ) {
          this.appService.lwtCrossSellOrderResponse = response;
          this.questionnaireService.llc.LWTExpressOrderResponse = new ExpressOrderResponse();
          this.questionnaireService.llc.LWTExpressOrderResponse.ExpressOrderId = response.orderId;
        }
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'cross-sell.service', error);
        this.appService.expressOrderProcessType = CheckoutReturnType.createCrossSellOrder;
        return of(null);
      }
    };
  }

  public prepareCreateBillOrder_CrossSell(crossSellConfigId: number): IQueueEntry {
    let crossSellOrder: ICreateCrossSellOrderResponse;
    return {
      name: 'prepareCreateBillOrder_CrossSell ' + this.constructor.name,
      pre: () => {
        if (crossSellConfigId === ProductConfigurationIds.tmsCrosssell) {
          crossSellOrder = this.appService.tmsCrossSellOrderResponse;
        } else if (
          crossSellConfigId === ProductConfigurationIds.lwtCrosssell
        ) {
          crossSellOrder = this.appService.lwtCrossSellOrderResponse;
        }

        const createPaymentRequest: ICreatePaymentRequest = {
          orderId: crossSellOrder.orderId,
          amount: crossSellOrder.orderItem.extendedPrice.toFixed(2),
          createdBy: this.appService.customerId.toString(),
          comments: 'Cross Sell Order',
          reasonId: '1',
          paymentProfileId: this.appService.paymentProfileId,
          gateway: this.appService.paymentGateway,
          source: '100',
          notificationEmail: this.appService.loginEmail,
          transactionType: 'Charge'
        };

        return this.paymentService.createPayment(
          createPaymentRequest
        );
      },
      post: response => {
        if (!environment.production) {
          console.log(
            '2. createBillOrder_CrossSell: crossSell_orderId: ' +
            crossSellOrder.orderId +
            ' | RESPONSE: order Id ' +
            response.orderId +
            '| transactionStatus: ' +
            response.transactionStatus
          );
        }

        if (crossSellConfigId === ProductConfigurationIds.tmsCrosssell) {
          this.appService.tmsCrossSellPaymentResponse = response;
          this.questionnaireService.llc.TMSExpressOrderResponse.PaymentStatus = response.transactionStatus;
        } else if (crossSellConfigId === ProductConfigurationIds.lwtCrosssell) {
          this.appService.lwtCrossSellPaymentResponse = response;
          this.questionnaireService.llc.LWTExpressOrderResponse.PaymentStatus = response.transactionStatus;
        }
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'cross-sell.service', error);
        return of(null);
      }
    };
  }

  private prepareCreateProcessingOrderQueue(crossSellConfigId: number): IQueueEntry {
    return {
      name: 'prepareCreateProcessingOrderQueue ' + this.constructor.name,
      pre: () => {
        let crossSellOrder: ICreateCrossSellOrderResponse;
        if (crossSellConfigId === ProductConfigurationIds.tmsCrosssell) {
          crossSellOrder = this.appService.tmsCrossSellOrderResponse;
          return this.processingOrderService.createProcessingOrderQueue(
            crossSellOrder.orderItem.processingOrder.processingOrderId,
            crossSellOrder.orderItem.orderItemId
          );
        } else if (crossSellConfigId === ProductConfigurationIds.lwtCrosssell) {
          crossSellOrder = this.appService.lwtCrossSellOrderResponse;
          return of(null);
        }
      },
      post: response => {
        if (response) {
          this.appService.createProcessingOrderQueue = response as IProcessingOrderQueueResponse;
        }
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'cross-sell.service', error);
        return of(null);
      }
    };
  }

  private prepareSendEmailNotification(crossSellConfigId: number): IQueueEntry {
    let crossSellOrder: ICreateCrossSellOrderResponse;
    return {
      name: 'prepareSendEmailNotification ' + this.constructor.name,
      clearQueueOnError: false,
      pre: () => {
        if (crossSellConfigId === ProductConfigurationIds.tmsCrosssell) {
          crossSellOrder = this.appService.tmsCrossSellOrderResponse;
        } else if (
          crossSellConfigId === ProductConfigurationIds.lwtCrosssell
        ) {
          crossSellOrder = this.appService.lwtCrossSellOrderResponse;
        }
        const emailHandlerRequest: IEmailHandlerRequest = {
          RequestType: 'SendOrderEmailAWSStepFunction',
          OrderId: crossSellOrder.orderId,
          CustomerId: this.appService.customerId,
          QuestionnaireId: this.appService.questionnaireId,
          ProcessId: this.appService.processId,
          ProcessingOrderId:
            crossSellOrder.orderItem.processingOrder.processingOrderId
        };
        return this.emailNotificationService.sendEmailNotification(
          emailHandlerRequest
        );
      },
      post: emailHandlerResponse => {
        if (!environment.production) {
          console.log(
            '6. email sent. Cross-sell Order Id: ' +
            crossSellOrder.orderId +
            ' Message: ' +
            emailHandlerResponse.Message
          );
        }
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'cross-sell.service', error);
        return of(null);
      }
    };
  }

  private prepareCreateOrderContactPrimary(crossSellConfigId: number): IQueueEntry {
    let crossSellOrder: ICreateCrossSellOrderResponse;
    return {
      name: 'prepareCreateOrderContactPrimary ' + this.constructor.name,
      pre: () => {
        if (crossSellConfigId === ProductConfigurationIds.tmsCrosssell) {
          crossSellOrder = this.appService.tmsCrossSellOrderResponse;
        } else if (
          crossSellConfigId === ProductConfigurationIds.lwtCrosssell
        ) {
          crossSellOrder = this.appService.lwtCrossSellOrderResponse;
        }

        const createOrderContactRequest: IOrderContact = {
          orderContactId: null,
          contactType: 'Primary',
          firstName: this.appService.firstName,
          lastName: this.appService.lastName,
          addressLine1: this.questionnaireService.llc.businessAddress.address1,
          addressLine2: this.questionnaireService.llc.businessAddress.address2,
          city: this.questionnaireService.llc.businessAddress.city,
          state: ConstantsService.getStateByAbbr(this.questionnaireService.llc.businessAddress.state),
          county: this.questionnaireService.llc.businessAddress.county,
          zipCode: this.questionnaireService.llc.businessAddress.zipCode,
          emailAddresses: [{ emailAddress: this.appService.loginEmail.toString() }],
          homePhone: this.questionnaireService.llc.contactPhone,
          workPhone: '',
          mobilePhone: '',
          faxPhone: '',
          country: null,
          stateId: null,
          dateCreated: null,
          createdBy: this.appService.customerId.toString(),
          dateLastModified: null,
          lastModifiedBy: null,
        };
        if (createOrderContactRequest) {
          return this.orderService.createOrderContact(
            crossSellOrder.orderId,
            createOrderContactRequest
          );
        } else {
          return of(null);
        }
      },
      post: response => {
        if (!environment.production) {
          console.log(
            '5. createBillOrder_CrossSell: createOrderContactPrimaryResponse  ' +
            +crossSellOrder.orderId +
            response
          );
        }
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'cross-sell.service', error);
        return of(null);
      }
    };
  }

  private prepareCreateOrderContactShipping(crossSellConfigId: number): IQueueEntry {
    let crossSellOrder: ICreateCrossSellOrderResponse;
    return {
      name: 'prepareCreateOrderContactShipping ' + this.constructor.name,
      pre: () => {
        if (crossSellConfigId === ProductConfigurationIds.tmsCrosssell) {
          crossSellOrder = this.appService.tmsCrossSellOrderResponse;
        } else if (
          crossSellConfigId === ProductConfigurationIds.lwtCrosssell
        ) {
          crossSellOrder = this.appService.lwtCrossSellOrderResponse;
        }

        const createOrderContactRequest: IOrderContact = {
          orderContactId: null,
          contactType: 'Shipping',
          firstName: this.appService.firstName,
          lastName: this.appService.lastName,
          addressLine1: this.questionnaireService.llc.businessAddress.address1,
          addressLine2: this.questionnaireService.llc.businessAddress.address2,
          city: this.questionnaireService.llc.businessAddress.city,
          state: ConstantsService.getStateByAbbr(this.questionnaireService.llc.businessAddress.state),
          county: this.questionnaireService.llc.businessAddress.county,
          zipCode: this.questionnaireService.llc.businessAddress.zipCode,
          emailAddresses: [{ emailAddress: this.appService.loginEmail.toString() }],
          homePhone: this.questionnaireService.llc.contactPhone,
          workPhone: '',
          mobilePhone: '',
          faxPhone: '',
          country: null,
          stateId: null,
          dateCreated: null,
          createdBy: this.appService.customerId.toString(),
          dateLastModified: null,
          lastModifiedBy: null,
        };
        if (createOrderContactRequest) {
          return this.orderService.createOrderContact(
            crossSellOrder.orderId,
            createOrderContactRequest
          );
        } else {
          return of(null);
        }
      },
      post: response => {
        if (!environment.production) {
          console.log(
            '5. createBillOrder_CrossSell: createOrderContactShippingResponse ' +
            crossSellOrder.orderId +
            response
          );
        }
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'cross-sell.service', error);
        return of(null);
      }
    };
  }

  private prepareCreateOrderContactBilling(crossSellConfigId: number): IQueueEntry {
    let crossSellOrder: ICreateCrossSellOrderResponse;
    return {
      name: 'prepareCreateOrderContactBilling ' + this.constructor.name,
      pre: () => {
        if (crossSellConfigId === ProductConfigurationIds.tmsCrosssell) {
          crossSellOrder = this.appService.tmsCrossSellOrderResponse;
        } else if (
          crossSellConfigId === ProductConfigurationIds.lwtCrosssell
        ) {
          crossSellOrder = this.appService.lwtCrossSellOrderResponse;
        }

        const createOrderContactRequest: IOrderContact = {
          orderContactId: null,
          contactType: 'Billing',
          firstName: this.appService.firstName,
          lastName: this.appService.lastName,
          addressLine1: this.questionnaireService.llc.businessAddress.address1,
          addressLine2: this.questionnaireService.llc.businessAddress.address2,
          city: this.questionnaireService.llc.businessAddress.city,
          state: ConstantsService.getStateByAbbr(this.questionnaireService.llc.businessAddress.state),
          county: this.questionnaireService.llc.businessAddress.county,
          zipCode: this.questionnaireService.llc.businessAddress.zipCode,
          emailAddresses: [{ emailAddress: this.appService.loginEmail.toString() }],
          homePhone: this.questionnaireService.llc.contactPhone,
          workPhone: '',
          mobilePhone: '',
          faxPhone: '',
          country: null,
          stateId: null,
          dateCreated: null,
          createdBy: this.appService.customerId.toString(),
          dateLastModified: null,
          lastModifiedBy: null,
        };
        if (createOrderContactRequest) {
          return this.orderService.createOrderContact(
            crossSellOrder.orderId,
            createOrderContactRequest
          );
        } else {
          return of(null);
        }
      },
      post: response => {
        if (!environment.production) {
          console.log(
            '5. createBillOrder_CrossSell: createOrderContactBillingResponse  ' +
            crossSellOrder.orderId +
            response
          );
        }
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'cross-sell.service', error);
        return of(null);
      }
    };
  }

  private prepareUpdateQuestionnaireForTms(): IQueueEntry {
    return {
      name: 'prepareUpdateQuestionnaireForTMS ' + this.constructor.name,
      pre: () => {
        let fullName = this.questionnaireService.llc.entityName;
        if (this.questionnaireService.llc) {
          if (this.questionnaireService.llc.pllcDesignator) {
            fullName += ', ' + this.questionnaireService.llc.pllcDesignator;
          } else if (this.questionnaireService.llc.entityNameDesignator) {
            fullName += ' ' + this.questionnaireService.llc.entityNameDesignator;
          }
        }
        fullName = (fullName) || 'Business Name';

        const userAnswerRequest: IUserAnswerRequest = {
          questionnaireFieldGroupAnswers: {
            userOrderId: this.appService.tmsCrossSellOrderResponse.orderItem.processingOrder.processingOrderId,
            questionnaireId: QuestionnaireId.TrademarkSearch,
            fieldAnswers: [
              {
                fieldName: 'search_query',
                fieldValue: fullName
              },
              {
                fieldName: 'bExpressCheckout',
                fieldValue: 'LLC_Crosssell_TMS_Federal_99'
              },
              {
                fieldName: 'Foreign_translation',
                fieldValue: 'Search with LLC Order'
              },
              {
                fieldName: 'logo_MC',
                fieldValue: 'No'
              },
              {
                fieldName: 'list_goods_services',
                fieldValue: this.questionnaireService.llc.businessPurpose
              },
              {
                fieldName: 'class_number',
                fieldValue: ''
              },
              {
                fieldName: 'contains_foreign_word',
                fieldValue: ''
              },
              {
                fieldName: 'class_1',
                fieldValue: ''
              },
              {
                fieldName: 'class_2',
                fieldValue: ''
              },
              {
                fieldName: 'class_3',
                fieldValue: ''
              },
              {
                fieldName: 'class_4',
                fieldValue: ''
              },
              {
                fieldName: 'class_5',
                fieldValue: ''
              },
              {
                fieldName: 'class_6',
                fieldValue: ''
              },
              {
                fieldName: 'class_7',
                fieldValue: ''
              },
              {
                fieldName: 'class_8',
                fieldValue: ''
              },
              {
                fieldName: 'class_9',
                fieldValue: ''
              },
              {
                fieldName: 'class_10',
                fieldValue: ''
              },
              {
                fieldName: 'class_11',
                fieldValue: ''
              },
              {
                fieldName: 'class_12',
                fieldValue: ''
              },
              {
                fieldName: 'class_13',
                fieldValue: ''
              },
              {
                fieldName: 'class_14',
                fieldValue: ''
              },
              {
                fieldName: 'class_15',
                fieldValue: ''
              },
              {
                fieldName: 'class_16',
                fieldValue: ''
              },
              {
                fieldName: 'class_17',
                fieldValue: ''
              },
              {
                fieldName: 'class_18',
                fieldValue: ''
              },
              {
                fieldName: 'class_19',
                fieldValue: ''
              },
              {
                fieldName: 'class_20',
                fieldValue: ''
              },
              {
                fieldName: 'class_21',
                fieldValue: ''
              },
              {
                fieldName: 'class_22',
                fieldValue: ''
              },
              {
                fieldName: 'class_23',
                fieldValue: ''
              },
              {
                fieldName: 'class_24',
                fieldValue: ''
              },
              {
                fieldName: 'class_25',
                fieldValue: ''
              },
              {
                fieldName: 'class_26',
                fieldValue: ''
              },
              {
                fieldName: 'class_27',
                fieldValue: ''
              },
              {
                fieldName: 'class_28',
                fieldValue: ''
              },
              {
                fieldName: 'class_29',
                fieldValue: ''
              },
              {
                fieldName: 'class_30',
                fieldValue: ''
              },
              {
                fieldName: 'class_31',
                fieldValue: ''
              },
              {
                fieldName: 'class_32',
                fieldValue: ''
              },
              {
                fieldName: 'class_33',
                fieldValue: ''
              },
              {
                fieldName: 'class_34',
                fieldValue: ''
              },
              {
                fieldName: 'class_35',
                fieldValue: ''
              },
              {
                fieldName: 'class_36',
                fieldValue: ''
              },
              {
                fieldName: 'class_37',
                fieldValue: ''
              },
              {
                fieldName: 'class_38',
                fieldValue: ''
              },
              {
                fieldName: 'class_39',
                fieldValue: ''
              },
              {
                fieldName: 'class_40',
                fieldValue: ''
              },
              {
                fieldName: 'class_41',
                fieldValue: ''
              },
              {
                fieldName: 'class_42',
                fieldValue: ''
              },
              {
                fieldName: 'class_43',
                fieldValue: ''
              },
              {
                fieldName: 'class_44',
                fieldValue: ''
              },
              {
                fieldName: 'class_45',
                fieldValue: ''
              }
            ],
            groupAnswers: []
          }
        };

        return this.questionnaireAnswerService.saveAndGetMappedUserAnswers(
          userAnswerRequest,
          QuestionnaireId.TrademarkSearch,
        );
      },
      post: response => {
        if (!environment.production) {
          console.log('3. update questionnaire for TMS');
        }
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'cross-sell.service', error);
        return of(null);
      }
    };
  }

  private prepareUpdateQuestionnaireForLWT(): IQueueEntry {
    return {
      name: 'prepareUpdateQuestionnaireForLWT ' + this.constructor.name,
      pre: () => {
        const userAnswerRequest: IUserAnswerRequest = {
          questionnaireFieldGroupAnswers: {
            userOrderId: this.appService.lwtCrossSellOrderResponse.orderItem.processingOrder.processingOrderId,
            questionnaireId: QuestionnaireId.LastWillAndTestament,
            fieldAnswers: [
              {
                fieldName: 'bGroupPlan',
                fieldValue: 'Null'
              },
              {
                fieldName: 'bExpressCheckout',
                fieldValue: 'LLC_Crosssell_LWT_Basic_49'
              }
            ],
            groupAnswers: []
          }
        };

        return this.questionnaireAnswerService.saveAndGetMappedUserAnswers(
          userAnswerRequest,
          QuestionnaireId.LastWillAndTestament,
        );
      },
      post: response => {
        if (!environment.production) {
          console.log('3. update questionnaire for LWT');
        }
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'cross-sell.service', error);
        return of(null);
      }
    };
  }

  private prepareUpdateProcessingOrderForTms(): IQueueEntry {
    return {
      name: 'prepareUpdateProcessingOrderForTms ' + this.constructor.name,
      pre: () => {
        const updateProcessingOrderRequest: IUpdateProcessingOrderRequest = {
          stateId: null,
          isQuestionnaireCompleted: true,
          postOption: null,
          shippingMethodId: null,
          lastPageVisited: 1000,
          comment: '',
          customerId: this.appService.customerId
        };
        return this.processingOrderService.updateProcessingOrder(
          this.appService.tmsCrossSellOrderResponse.orderItem.processingOrder
            .processingOrderId,
          updateProcessingOrderRequest
        );
      },
      post: response => {
        if (!environment.production) {
          console.log('4. Mark processing order as completed');
        }
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'cross-sell.service', error);
        return of(null);
      }
    };
  }

  private prepareTrackCrosssellOrderItems(): IQueueEntry {
    const that = this;
    return {
      name: 'prepareTrackCrosssellOrderItems ' + this.constructor.name,
      pre: () => {
        return of(null);
      },
      post: response => {
        that.trackCrosssellOrderItems();
        if (!environment.production) {
          console.log('5. prepareTrackCrosssellOrderItems');
        }
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'cross-sell.service', error);
        return of(null);
      }
    };
  }

  private trackCrosssellOrderItems(): void {
    const win = this.trackingService.winRef.nativeWindow;
    if (win.oCMOrder !== undefined) {
      this.trackingService.ClearOAItems();
      win.oCMOrder.oaItems = win.oCMOrder.oaItems.concat(this.newSkuArray);
    }
  }

  private preprareSaveAndContinue(): IQueueEntry {
    return {
      name: 'prepareSaveAndContinue ' + this.constructor.name,
      pre: () => {
        return of(this.eventService.saveAndContinue(PagePath.ExpressOffersPage));
      },
      post: response => { },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'cross-sell.service', error);
        return of(null);
      }
    };
  }

  private prepareTagOrderById_CrossSell(configId): IQueueEntry {
    return {
      name: 'prepareTagOrderById_ExpressOrder ' + this.constructor.name,
      pre: () => {
        let crossSellOrder: ICreateCrossSellOrderResponse;
        let tagName: string;
        if (configId === ProductConfigurationIds.lwtCrosssell) {
          crossSellOrder = this.appService.lwtCrossSellOrderResponse;
          tagName = 'LLC_Crosssell_LWT_Basic_49';
        }
        if (configId === ProductConfigurationIds.tmsCrosssell) {
          crossSellOrder = this.appService.tmsCrossSellOrderResponse;
          tagName = 'LLC_Crosssell_TMS_Federal_99';
        }
        const tagOrderByIdRequest: ITagOrderByIdRequest = {
          tagType: TagType.system,
          tag: tagName,
          createdBy: this.appService.customerId.toString()
        };

        return this.taggingService.tagOrderById(
          crossSellOrder.orderId,
          tagOrderByIdRequest
        );
      },
      post: tagOrderByIdResponse => {
        this.tagOrderByIdResponse = tagOrderByIdResponse;
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'cross-sell.service', error);
        return (of(null));
      }
    };
  }

  public prepareGetPaymentProfileByCustomerId(customerId: number): IQueueEntry {
    return {
      name: 'prepareGetPaymentProfileByCustomerId ' + this.constructor.name,
      pre: () => {
        return this.paymentService.getPaymentProfileIdByCustomerId(customerId);
      },
      post: (response) => {
        if (response.paymentProfiles.length > 0) {
          this.appService.paymentGateway = response.paymentProfiles[0].gateway;
          this.appService.paymentProfileId = response.paymentProfiles[0].profileId;
        } else {
          this.trackJS.track(ProductName.LLC, 'cross-sell.service', 'No Payment profile found for customer :- ' + customerId);
        }
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'cross-sell.service', error);
        return of(null);
      }
    };
  }

  public prepareGetCustomerContactByCustomerId(appService: any, customerId: number): IQueueEntry {
    const that = this;
    return {
      name: 'prepareGetCustomerContactByCustomerId ' + this.constructor.name,
      clearQueueOnError: false,
      pre: () => {
        return that.customerService.getCustomerContactById(customerId);
      },
      post: (response) => {
        if (response.contacts.length > 0) {
          const appState = appService;
          let contact = response.contacts.find(c => c.contactInfoType == 1);
          this.questionnaireService.llc.businessAddress = new Address();
          this.questionnaireService.llc.businessAddress.address1 = contact.addressLine1;
          this.questionnaireService.llc.businessAddress.address2 = contact.addressLine2;
          this.questionnaireService.llc.businessAddress.city = contact.city;
          this.questionnaireService.llc.businessAddress.state = contact.state;
          this.questionnaireService.llc.businessAddress.zipCode = contact.zipcode;
          this.questionnaireService.llc.businessAddress.county = contact.county !== null ? contact.county.toString() : null;
          this.questionnaireService.llc.contactPhone = contact.homePhone;
          appState.firstName = contact.firstName;
          appState.lastName = contact.lastName;
          appService = appState;
        } else {
          this.trackJS.track(ProductName.LLC, 'cross-sell.service', 'No contacts found for customer:-' + customerId);
        }
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'cross-sell.service', error);
        return of(null);
      }
    };
  }

  public prepareGetPaymentByOrderId(appService: any, orderId: number, customerId: number, isCrossSellOrder = false): IQueueEntry {
    return {
      name: 'prepareGetPaymentByOrderId ' + this.constructor.name,
      pre: () => {
        return this.paymentService.getPaymentByOrderId(orderId);
      },
      post: (response: IGetPaymentResponse) => {
        
        if (response.payments.length > 0 && isCrossSellOrder != true) {
          this.appService.payment = {
            creationDate: response.payments[0].creationDate.toString(),
            transactionStatus: response.payments[0].transactionStatus
          } as Payment;
        } else if (isCrossSellOrder) {
          const crossSellOrder = appService.app.crossSellOrderResponse;
          const appState = appService.app;
          appState.crossSellOrderResponse = new CrossSellOrder();
          appState.crossSellOrderResponse.orderId = crossSellOrder.orderId;
          appState.crossSellOrderResponse.orderItemId = crossSellOrder.orderItemId;
          appState.crossSellOrderResponse.processingOrderId = crossSellOrder.processingOrderId;
          appState.crossSellOrderResponse.productName = crossSellOrder.productName;
          appState.crossSellOrderResponse.productConfigurationId = crossSellOrder.productConfigurationId;
          appState.crossSellOrderResponse.shippingOrderContactId = crossSellOrder.shippingOrderContactId;
          appState.crossSellOrderResponse.billingOrderContactId = crossSellOrder.billingOrderContactId;
          appState.crossSellOrderResponse.primaryOrderContactId = crossSellOrder.primaryOrderContactId;
          appState.crossSellOrderResponse.amount = response.payments[0].amount;
          appState.crossSellOrderResponse.paymentResponseStatus = response.payments[0].transactionStatus;
          appService.app = appState;
        } else {
          this.trackJS.track(ProductName.LLC, 'cross-sell.service', 'No Payment details found for customer and order :- ' + customerId);
        }
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'cross-sell.service', error);
        return of(null);
      }
    };
  }
}
