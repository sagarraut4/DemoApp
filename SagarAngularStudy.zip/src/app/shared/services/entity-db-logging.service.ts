import { Injectable } from '@angular/core';
import { FEATURE_FLAG_NAMECHECK_LOGGING, FeatureFlagService } from "./feature-flag/feature-flag.service";
import { FormGroup } from '@angular/forms';
import { concatMap } from 'rxjs/operators';
import { EntitydbService, EntityType, IEntityDbResponse } from '@legalzoom/entitydb-sdk';
import { ConstantsService } from './constants.service';
import { AppService } from '../state/app';
import { iif, Observable, of, throwError } from 'rxjs';
import { QuestionnaireService } from './questionnaire/questionnaire.service';
import {
  IBusinessNameCheckEntityDBResponse,
} from '@legalzoom/entitydb-sdk/lib/models/entitydb.model';

export enum EntityDbLoggingErrorStates {
  FeatureFlagOff = 'Feature Flag Is Off',
  EntityStateNotPartOfFeature = 'Entity State Is Not Part Of Feature',
}

@Injectable({
  providedIn: 'root',
})
export class EntityDbLoggingService {
  public constructor(
    private featureFlagService: FeatureFlagService,
    private entityDBService: EntitydbService,
    private appService: AppService,
    private questionnaireService: QuestionnaireService,
  ) {
  }

  /**
   * Check entity name and log
   */
  public checkNameAndLog(formGroup: FormGroup): Observable<any> {
    // Get Root Form Group
    const rootFormGroup: FormGroup = formGroup.root as FormGroup;

    // Get business details from Root FormGroup
    const businessDetailsFormGroup: FormGroup = rootFormGroup.get('businessDetails') as FormGroup;

    // Get Business Name and Entity State
    const {businessName} = businessDetailsFormGroup.value;
    const {entityState} = this.questionnaireService.llc;

    // State Abbreviation ( sanitization to ensure it's the correct LZ format )
    const entityStateAbbreviation: string = ConstantsService.getStateAbbr(entityState);

    // Test for Feature Existence
    return this.buildIsFeatureOnStream()
      .pipe(
        // Check for Entity Availability
        concatMap(
          () => this.entityDBService.getEntityAvailability(
            businessName,
            EntityType.LLC,
            entityStateAbbreviation,
          )
        ),

        // Log Response
        concatMap(entityAvailableResponse => this.logEntityName(entityAvailableResponse, businessName, entityState)),
      );
  }

  /**
   * Build Stream: Is Feature On
   */
  private buildIsFeatureOnStream(): Observable<boolean> {
    // Figure out if Feature is ON + Business Name Caching
    return this.featureFlagService.isFeatureOn(FEATURE_FLAG_NAMECHECK_LOGGING).pipe(
      // Test if the Feature IsOn
      concatMap(isFeatureOn => {
          // Determine if the value has already been Cached
          return iif(
            // Test if name has already been cached
            () => isFeatureOn,

            // Pass through response
            of(isFeatureOn),

            // Break stream - throw error
            throwError(EntityDbLoggingErrorStates.FeatureFlagOff),
          );
        },
      ),
    );
  }

  /**
   * Log Entity Name
   */
  public logEntityName(entityDbResponse: IEntityDbResponse, entityName: string, entityState: string): Observable<IBusinessNameCheckEntityDBResponse> {
    // Received a response for EntityDB
    return this.entityDBService.saveEntityAvailabilityLog(
      this.appService.processingOrderId,
      {
        availabilityLog: entityDbResponse,
        entityName,
        entityState: ConstantsService.getStateAbbr(entityState),
        entityType: EntityType.LLC,
        orderId: this.appService.orderId,
        responseJson: JSON.stringify(entityDbResponse),
        agentResponse: null,
        agentNotes: null,
        applicationId: 10,
        createdBy: `${this.appService.customerId}`,
      },
    );
  }
}
