import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpHandler, HttpRequest, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class NoCacheInterceptor implements HttpInterceptor {
  constructor() { }

  intercept(request: HttpRequest<any>, next: HttpHandler):
    Observable<HttpEvent<any>> {
    if (!request.url.includes('business-name-check') && !request.url.includes('/sites/lz.com/views/uuid')) {
      if (request.method === 'GET') {
        const customRequest = request.clone({
          // adds query string to disable caching for IE
          params: request.params.set('cacheBust', Date.now().toString())
        });
        return next.handle(customRequest);
      }
    }
    return next.handle(request);
  }
}
