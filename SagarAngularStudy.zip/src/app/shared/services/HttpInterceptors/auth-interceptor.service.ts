import { Injectable } from '@angular/core';
import { WindowRef } from '../windowRef.service';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpResponse, HttpErrorResponse, HttpSentEvent, HttpHeaderResponse, HttpProgressEvent, HttpUserEvent, HttpClient } from '@angular/common/http';
import { PagePath, Chapter } from '../../models/page-model';
import { Observable, BehaviorSubject, throwError as observableThrowError } from 'rxjs';
import { Router } from '@angular/router';
import { TrackJsErrorLogService } from '@legalzoom/business-formation-sdk';
import { AuthService } from './../auth.service';
import { AppService } from './../../state/app/app.service';
import { UtilityService } from './../utility.service';
import { switchMap, catchError, finalize, filter, take } from 'rxjs/operators';
import { from } from 'rxjs';
import { CustomerService } from '@legalzoom/customer-sdk';
import { SsoFeatureFlagService } from '@legalzoom/site-sdk-sso';
import { environment } from '../../../../environments/environment';

@Injectable()
export class AuthInterceptorService implements HttpInterceptor {
  numFailed = 0;
  isRefreshingToken = false;
  tokenSubject: BehaviorSubject<string> = new BehaviorSubject<string>(null);

  constructor(
    private http: HttpClient,
    private router: Router,
    private windowRef: WindowRef,
    private utilityService: UtilityService,
    private appService: AppService,
    private authService: AuthService,
    private customerService: CustomerService,
    private trackJsErrorLogService: TrackJsErrorLogService,
    private featureFlagService: SsoFeatureFlagService,
  ) { }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpSentEvent | HttpHeaderResponse | HttpProgressEvent | HttpResponse<any> | HttpUserEvent<any>> {
    const featureFlagName = environment.sso.configuration.launchDarkly.ssoFeatureFlag;

    return from(this.featureFlagService.isFlagEnabledAsync(featureFlagName)).pipe(
      switchMap((isSsoEnabled) => {
        if (isSsoEnabled) {
          return next.handle(request);
        }

        const appState = this.appService.app;
        return next.handle(request).pipe(
          catchError((error) => {
            if (error instanceof HttpErrorResponse) {
              switch ((error as HttpErrorResponse).status) {
                case 401:
                  if (error.error.errors && error.error.errors.findIndex((x: { code: string }) => x.code === 'oAuth_return_zero_customer_id') > -1) {
                  this.trackJsErrorLogService.track('LLC', 'API-401 Unauthorized Error: ' + request.urlWithParams, error);
                  return observableThrowError(error);
                } else if (error.error.fault && error.error.fault.faultstring.toLowerCase() === 'access token expired') {
                  return this.handle401Error(request, error);
                } else if (error.error.fault && error.error.fault.faultstring.toLowerCase() === 'invalid access token') {
                  if (appState.accessToken && this.numFailed < 1) {
                    this.trackJsErrorLogService.track('LLC', 'API-401 Unauthorized Error: ' + request.urlWithParams, error);
                    this.numFailed++;
                    request = request.clone({ setHeaders: { Authorization: 'Bearer ' + appState.accessToken } });
                    return this.http.request(request);
                  } else {
                    return this.handle401Error(request, error);
                  }
                } else {
                  this.trackJsErrorLogService.track('LLC', 'API-401 Unauthorized Error: ' + request.urlWithParams, error);

                  this.utilityService.clearAppState(true);

                  this.windowRef.nativeWindow.location.href = PagePath.LLCLandingPage;
                }
                break;
                case 400:
                  return this.handle400Error(request, error);
                case 500:
                  return this.handle500Error(request, error);
                default:
                  this.trackJsErrorLogService.track('LLC', 'API-Default Error: ' + request.urlWithParams, error);
                return observableThrowError(error);
              }
            }
          })
        );
      })
    );
  }

  handle401Error(req: HttpRequest<any>, error: any): Observable<HttpSentEvent | HttpHeaderResponse | HttpProgressEvent | HttpResponse<any> | HttpUserEvent<any>> {
    if (!this.isRefreshingToken) {
      this.isRefreshingToken = true;

      // Reset here so that the following requests wait until the token
      // comes back from the refreshToken call.
      this.tokenSubject.next(null);

      return this.authService.refreshToken().pipe(
        switchMap((newToken: string) => {
          if (newToken) {
            this.tokenSubject.next(newToken);
            req = req.clone({ setHeaders: { Authorization: 'Bearer ' + newToken } });
            return this.http.request(req);
          }
          return observableThrowError(error);
        }),
        catchError((er) => {
          return observableThrowError(er);
        }),
        finalize(() => {
          this.isRefreshingToken = false;
        })
      );
    } else {
      return this.tokenSubject.pipe(
        filter((token) => token != null),
        take(1),
        switchMap((token) => {
          req = req.clone({ setHeaders: { Authorization: 'Bearer ' + token } });
          return this.http.request(req);
        })
      );
    }
  }

  handle500Error(req: HttpRequest<any>, error: HttpErrorResponse): Observable<HttpSentEvent | HttpHeaderResponse | HttpProgressEvent | HttpResponse<any> | HttpUserEvent<any>> {
    this.handleBadSession(error);
    this.trackJsErrorLogService.track('LLC', 'API-500 Internal Server Error: ' + req.urlWithParams, error);
    return observableThrowError(error);
  }

  handle400Error(req: HttpRequest<any>, error: HttpErrorResponse): Observable<HttpSentEvent | HttpHeaderResponse | HttpProgressEvent | HttpResponse<any> | HttpUserEvent<any>> {
    this.handleBadSession(error);
    this.trackJsErrorLogService.track('LLC', 'API-400 Bad Request Error: ' + req.urlWithParams, error);
    return observableThrowError(error);
  }

  handleBadSession(error: HttpErrorResponse) {
    if (error.url.indexOf('/web-sessions/token') > 0) {
      if (this.utilityService.getStringParamFromQueryString('entity') || this.utilityService.getStringParamFromQueryString('state')) {
        this.utilityService.clearAppState(true);
        window.location.reload();
      } else {
        this.utilityService.clearAppState(true);
        this.windowRef.nativeWindow.location.href = PagePath.Overview;
      }
    }
  }
}
