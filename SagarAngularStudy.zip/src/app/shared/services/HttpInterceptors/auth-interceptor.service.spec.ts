import { TestBed, inject } from '@angular/core/testing';
import { AuthInterceptorService } from './auth-interceptor.service';
import { HTTP_INTERCEPTORS, HttpClient } from '@angular/common/http';
import { AuthService } from '../auth.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { Router, RouterEvent } from '@angular/router';
import { UtilityService } from '../utility.service';
import { AppService } from '../../state/app';
import { TrackJsErrorLogService } from '@legalzoom/business-formation-sdk';
import { ReplaySubject } from 'rxjs';
import { Chapter } from '../../models/page-model';
import { WindowRef } from '../windowRef.service';
import { CustomerService} from '@legalzoom/customer-sdk';

describe('AuthInterceptorService', () => {
  let service: AuthInterceptorService;
  let httpMock: HttpTestingController;
  let http: HttpClient;
  let mockAuthService;
  const mockUtilityService: UtilityService = undefined;
  const mockAppService = {
    app: {}
  };
  const mockCustomerService: CustomerService = undefined;
  let mockTrackJsErrorLogService;
  const eventSubject = new ReplaySubject<RouterEvent>(1);
  const mockRouter: any = {
    navigate: jasmine.createSpy('navigate'),
    events: eventSubject.asObservable(),
    url: '/' + Chapter.PostOrder
  };
  const mockWindowRef = jasmine.createSpyObj(['nativeWindow']);
  beforeEach(() => {
    mockAuthService = jasmine.createSpyObj(['refreshToken']);
    mockTrackJsErrorLogService = jasmine.createSpyObj(['track']);
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        AuthInterceptorService,
        { provide: UtilityService, useValue: mockUtilityService },
        { provide: AppService, useValue: mockAppService },
        { provide: CustomerService, useValue: mockCustomerService },
        { provide: TrackJsErrorLogService, useValue: mockTrackJsErrorLogService },
        { provide: AuthService, useValue: mockAuthService },
        { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptorService, multi: true },
        { provide: Router, useValue: mockRouter },
        { provide: WindowRef, useValue: mockWindowRef },
        HttpClient
      ]
    });
    service = TestBed.get(AuthInterceptorService);
    httpMock = TestBed.get(HttpTestingController);

  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should log error on error code 400', () => {
    let response: any;
    let errResponse: any;
    const mockErrorResponse = { status: 400, statusText: 'Bad Request' };
    const data = 'Invalid request parameters';
    http = TestBed.get(HttpClient);
    http.get('http://.../test').subscribe(res => {
      response = res;
    }, error => errResponse = error);

    httpMock.expectOne('http://.../test').flush(data, mockErrorResponse);
    httpMock.verify();
    expect(mockTrackJsErrorLogService.track).toHaveBeenCalled();
  });
  it('should log error on error code 500', () => {
    let response: any;
    let errResponse: any;
    const mockErrorResponse = { status: 500, statusText: 'Bad Request' };
    const data = 'Invalid request parameters';
    http = TestBed.get(HttpClient);
    http.get('http://.../test').subscribe(res => {
      response = res;
    }, error => errResponse = error);

    httpMock.expectOne('http://.../test').flush(data, mockErrorResponse);
    httpMock.verify();
    expect(mockTrackJsErrorLogService.track).toHaveBeenCalled();
  });

});
