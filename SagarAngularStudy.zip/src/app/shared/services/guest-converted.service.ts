import { AppService } from '../state/app/app.service';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { EnvironmentService } from './environment.service';

@Injectable({
  providedIn: 'root'
})
export class GuestConvertedService {
  constructor(
    private http: HttpClient,
    private appService: AppService,
    private environmentService: EnvironmentService,
  ) { }

  private optionsWithSessionCookie = {
    headers: new HttpHeaders()
      .set('x-lz-api-key', this.environmentService.getLzApiKey()),
    withCredentials : true
}

  public updateIsGuestConvertedOnCheckout() {
      const customerId = this.appService.customerId.toString();
      const url = this.environmentService.getCustomerUrl().replace('{0}', customerId);
      this.http.get<any>(url, this.optionsWithSessionCookie).subscribe((res) => {
          //Update state & session storage
          const appState = this.appService.app;
          appState.isGuestConvertedOnCheckout = !res.customerInfo.isPasswordSet;
          this.appService.app = appState;
      })
    }
}
