import { TestBed, async } from '@angular/core/testing';
import { CanActivatePostCoQxGuard } from './can-activate-post-co-qx.guard';
import { QuestionnaireService } from '../questionnaire/questionnaire.service';
import { CookieService } from 'ngx-cookie';
import { EnvironmentService } from '../environment.service';
import { ExperimentsService } from '../experiments/experiments.service';
import { WindowRef } from '../windowRef.service';
import { Router, ActivatedRouteSnapshot } from '@angular/router';
import { LLC } from '../../models/questionnaire-model';

// TODO: fix test suite
xdescribe('CanActivatePostCoQxGuard', () => {
  let service: CanActivatePostCoQxGuard;
  const mockRouter: any = {};
  let mockCookieService;
  let mockEnvironmentService;
  let mockExperimentsService;

  const mockQuestionnaireService = {
    llc: new LLC()
  };
  beforeEach(() => {
    mockCookieService = jasmine.createSpyObj(['put']);
    mockEnvironmentService = jasmine.createSpyObj(['getTimestringCookie']);
    mockExperimentsService = jasmine.createSpyObj([
      'getExperimentName',
      'GetBShowPriceTest1ValueForQ2Crosssells',
      'GetBFunnelTestValue',
      'GetBShowPriceTestValue',
      'GetBShowPriceTest1Value'
    ]);

    TestBed.configureTestingModule({
      providers: [
        CanActivatePostCoQxGuard,
        { provide: Router, useValue: mockRouter },
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: CookieService, useValue: mockCookieService },
        { provide: EnvironmentService, useValue: mockEnvironmentService },
        { provide: ExperimentsService, useValue: mockExperimentsService },
        { provide: WindowRef, useValue: mockExperimentsService }
      ]
    });
    service = TestBed.get(CanActivatePostCoQxGuard);
  });

  it('should create', () => {
    expect(service).toBeTruthy();
  });

  it('set auth cookies if timestring and mobile_app exist in query string and session exists', async () => {
    const activatedRoute: ActivatedRouteSnapshot = new ActivatedRouteSnapshot();
    activatedRoute.queryParams = {
      TIMESTRING: 'test',
      mobile_app: true
    };
    const result = await service.canActivate(activatedRoute, null);
    expect(result).toBe(true);
  });

  it('should set isMobile in questionnaire ', async(async () => {
    const activatedRoute: ActivatedRouteSnapshot = new ActivatedRouteSnapshot();
    activatedRoute.queryParams = {
      TIMESTRING: 'test',
      mobile_app: true
    };
    const result = await service.canActivate(activatedRoute, null);
    expect(result).toBe(true);
    expect(TestBed.get(QuestionnaireService).llc.isMobileApp).toBe(true);
  }));

  it('should set q2 exprement variables', async(() => {
    const activatedRoute: ActivatedRouteSnapshot = new ActivatedRouteSnapshot();
    activatedRoute.queryParams = {
      TIMESTRING: 'test',
      mobile_app: true,
      uo: 1234
    };
    service.canActivate(activatedRoute, null);
    expect(mockExperimentsService.GetBFunnelTestValue).toHaveBeenCalled();
    expect(mockExperimentsService.GetBShowPriceTestValue).toHaveBeenCalled();
    expect(mockExperimentsService.GetBShowPriceTest1ValueForQ2Crosssells).toHaveBeenCalled();
  }));

  it('should set q1 exprement variables', async(() => {
    const activatedRoute: ActivatedRouteSnapshot = new ActivatedRouteSnapshot();
    activatedRoute.queryParams = {
      TIMESTRING: 'test',
      mobile_app: true
    };
    service.canActivate(activatedRoute, null);
    expect(mockExperimentsService.GetBFunnelTestValue).toHaveBeenCalled();
    expect(mockExperimentsService.GetBShowPriceTestValue).toHaveBeenCalled();
    expect(mockExperimentsService.GetBShowPriceTest1Value).toHaveBeenCalled();
  }));
});
