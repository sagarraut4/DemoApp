import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot } from '@angular/router';
import { ExperimentsService } from '../experiments/experiments.service';
import { QuestionnaireService } from '../questionnaire/questionnaire.service';
import { UtilitiesService, WebSessionService, GetCustomerAndSessionResponse, SessionData } from '@legalzoom/business-formation-sdk';
import { CookieService } from 'ngx-cookie';

@Injectable()
export class CanActivatePostCoQxGuard implements CanActivate {
  constructor(
    private questionnaireService: QuestionnaireService,
    private experimentService: ExperimentsService, 
    private webSessionService: WebSessionService, 
    private utilitiesService: UtilitiesService, 
    private cookieService: CookieService
  ) {}

  /**
   * Checks the querystring for presence of the parameter mobile_app set to true
   * indicating the request is from the mobile native app.
   * If so, makes a call to the web session API and populates the required identity fields
   * accordingly.
   * @param qs querystring params
   */
  async setMobileSession(qs: any): Promise<boolean> {
    // yea i would say return false here, but just trying to keep the logic the same
    // of always returning true so we don't break anything.
    // the app initialization guard will do a redirect anyways as a side effect
    if (!qs || !qs.mobile_app || !qs.TIMESTRING) { return true; }

    const sessionId = qs.TIMESTRING;
    const res: GetCustomerAndSessionResponse = await this.webSessionService.getSession(sessionId).toPromise();

    const val = (key) => (res.session.find((x: SessionData) => x.key === key) || new SessionData()).value;

    const accessToken = val('accessToken');
    const customerId = res.customerId;

    this.utilitiesService.saveCookies(sessionId, accessToken, customerId);

    // hack: add active session.
    // we will eventually need to come up with a way to handle session transition from 
    // ios to a webview instead of this function
    this.cookieService.put('ActiveSession', 'true', { domain: 'legalzoom.com' });

    return true;
  }

  async canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<boolean> {
    if (next && next.queryParams && next.queryParams.uo && !this.questionnaireService.llc.currentView) {      
      this.questionnaireService.llc.bShowPriceTest1 = this.experimentService.GetBShowPriceTest1ValueForQ2Crosssells();
    } else {      
      this.questionnaireService.llc.bShowPriceTest1 = this.experimentService.GetBShowPriceTest1Value();
    }
    
    this.questionnaireService.llc.bFunnelTest = this.experimentService.GetBFunnelTestValue();

    if (next && next.queryParams && next.queryParams.mobile_app) {
      this.questionnaireService.llc.isMobileApp = true;

      return await this.setMobileSession(next.queryParams);
    }

    return true;
  }
}
