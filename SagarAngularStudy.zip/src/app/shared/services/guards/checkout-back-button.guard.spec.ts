import { TestBed, async, inject } from '@angular/core/testing';

import { CheckoutBackButtonGuard } from './checkout-back-button.guard';
import { BackButtonService } from '../back-button.service';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

describe('CheckoutBackButtonGuard', () => {
  let service: CheckoutBackButtonGuard;
  let mockBackButtonService;
  const mockRouter = {
    url: ''
  };
  beforeEach(() => {
    mockBackButtonService = jasmine.createSpyObj(['verifyRoute']);
    TestBed.configureTestingModule({
      providers: [CheckoutBackButtonGuard,
        { provide: BackButtonService, useValue: mockBackButtonService },
        { provide: Router, useValue: mockRouter }]
    });
    service = TestBed.get(CheckoutBackButtonGuard);
  });

  it('should create', () => {
    expect(service).toBeTruthy();
  });
  it('should return true if backbutton service verifyRoute return true', () => {
    mockBackButtonService.verifyRoute.and.returnValue(true);
    const activatedRoute: ActivatedRouteSnapshot = new ActivatedRouteSnapshot();
    activatedRoute.queryParams = {
      TIMESTRING: 'test',
      mobile_app: true,
      uo: 1234
    };
    const mockSnapshot = jasmine.createSpyObj<RouterStateSnapshot>('RouterStateSnapshot', ['toString']);
    const result = service.canActivateChild(activatedRoute, mockSnapshot);
    expect(result).toBe(true);
  });
});
