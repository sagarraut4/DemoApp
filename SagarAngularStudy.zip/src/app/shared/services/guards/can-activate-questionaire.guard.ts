import { AppInitializationService } from './../app-initialization.service';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { ExperimentsService } from '../experiments/experiments.service';
import { QuestionnaireService } from '../questionnaire/questionnaire.service';

@Injectable({
  providedIn: 'root'
})
export class CanActivateQuestionaireGuard implements CanActivate {
  constructor(
      private questionnaireService: QuestionnaireService
    , private experimentService: ExperimentsService
    , private appInitializationService: AppInitializationService
  ) { }

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    if ( next && next.queryParams && next.queryParams.uo && !this.questionnaireService.llc.currentView) {
       this.questionnaireService.llc.bFunnelTest = this.experimentService.GetBFunnelTestValue();
       this.questionnaireService.llc.bShowPriceTest1 = this.experimentService.GetBShowPriceTest1Value();
    }
    return this.appInitializationService.initializeApp(state.url);
  }
}
