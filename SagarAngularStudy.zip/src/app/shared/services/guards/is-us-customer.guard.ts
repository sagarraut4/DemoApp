import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { UtilityService } from '../utility.service';
import { QuestionnaireRoutingService } from '../questionnaire-routing/questionnaire-routing.service';
import { PagePath } from '../../models/page-model';
import { catchError, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class IsUsCustomerGuard implements CanActivate {
  constructor(
    private utilityService: UtilityService,
    private router: Router,
    private routingService: QuestionnaireRoutingService,
  ) { }

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    const pageAfterGSuite: string = this.routingService.getNextPage(PagePath.GSuitePackage);
    // Check if isUSCustomer is already set
    if (this.utilityService.isUSCustomer === null) {
      // Request the geolocation and return if they are a US customer
      return this.utilityService.requestIsUSCustomer().pipe(
        map(
          (response: boolean): boolean => {
            // If they aren't a US customer skip the GSuite page
            if (!response) {
              this.router.navigate([pageAfterGSuite]);
              return false;
            }
            return true;
          }
        ),
        catchError(
          (err) => {
            // If there are any errors with the request skip the GSuite page
            this.router.navigate([pageAfterGSuite]);
            return of(false);
          }
        )
      );
    } else {
      if (this.utilityService.isUSCustomer === false) {
        this.router.navigate([pageAfterGSuite]);
      }
      return of(this.utilityService.isUSCustomer);
    }
  }
}
