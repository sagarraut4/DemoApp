import { TestBed, async, inject } from '@angular/core/testing';

import { IsUsCustomerGuard } from './is-us-customer.guard';
import { QuestionnaireRoutingService } from '../questionnaire-routing/questionnaire-routing.service';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { UtilityService } from '../utility.service';
import { of } from 'rxjs';

describe('IsUsCustomerGuard', () => {
  let service: IsUsCustomerGuard;
  let mockQuestionnaireRoutingService;
  let mockRouter;
  let mockUtilityService;
  const activatedRoute: ActivatedRouteSnapshot = new ActivatedRouteSnapshot();
  activatedRoute.queryParams = {
    TIMESTRING: 'test',
    mobile_app: true,
    uo: 1234
  };
  const mockSnapshot = jasmine.createSpyObj<RouterStateSnapshot>('RouterStateSnapshot', ['toString']);
  beforeEach(() => {
    mockQuestionnaireRoutingService = jasmine.createSpyObj(['getNextPage']);
    mockRouter = jasmine.createSpyObj(['navigate']);
    mockUtilityService = jasmine.createSpyObj(['requestIsUSCustomer', 'isUSCustomer']);
    mockUtilityService.isUSCustomer = false;
    TestBed.configureTestingModule({
      providers: [
        IsUsCustomerGuard,
        { provide: Router, useValue: mockRouter },
        { provide: UtilityService, useValue: mockUtilityService },
        { provide: QuestionnaireRoutingService, useValue: mockQuestionnaireRoutingService }
      ]
    });
    service = TestBed.get(IsUsCustomerGuard);
  });

  it('should create', () => {
    expect(service).toBeTruthy();
  });
  it('should return false if UtilityService.isUSCustomer is false', () => {
    const result = service.canActivate(activatedRoute, mockSnapshot);
    result.subscribe(data => {
      expect(data).toBe(false);
    });
    expect(mockRouter.navigate).toHaveBeenCalled();
  });
  it('should return true if UtilityService.isUSCustomer is true', () => {
    const utilityService = TestBed.get(UtilityService);
    utilityService.isUSCustomer = true;
    const result = service.canActivate(activatedRoute, mockSnapshot);
    result.subscribe(data => {
      expect(data).toBe(true);
    });
  });
  it('should call requestIsUSCustomer', () => {
    const utilityService = TestBed.get(UtilityService);
    utilityService.isUSCustomer = null;
    utilityService.requestIsUSCustomer.and.returnValues(of(true));
    service.canActivate(activatedRoute, mockSnapshot);
    expect(mockUtilityService.requestIsUSCustomer).toHaveBeenCalled();
  });
});
