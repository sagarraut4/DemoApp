import { Injectable } from '@angular/core';
import { CanActivateChild, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { BackButtonService } from '../back-button.service';
import { Router } from '@angular/router';

@Injectable()
export class CheckoutBackButtonGuard implements CanActivateChild {
  constructor(
    private backButtonService: BackButtonService,
    private router: Router,
  ) {

  }

  canActivateChild(childRoute: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    return this.backButtonService.verifyRoute(this.router.url);
  }
}
