import { TestBed, async, inject } from '@angular/core/testing';

import { CanActivateQuestionaireGuard } from './can-activate-questionaire.guard';
import { AppInitializationService } from '../app-initialization.service';
import { ExperimentsService } from '../experiments/experiments.service';
import { QuestionnaireService } from '../questionnaire/questionnaire.service';
import { LLC } from '../../models/questionnaire-model';
import { RouterStateSnapshot, ActivatedRouteSnapshot } from '@angular/router';
import { of } from 'rxjs';

describe('CanActivateQuestionaireGuard', () => {
  let service: CanActivateQuestionaireGuard;
  let mockExperimentsService;
  let mockAppInitializationService;
  const mockQuestionnaireService = {
    llc: new LLC()
  };

  beforeEach(() => {
    mockExperimentsService = jasmine.createSpyObj(['getExperimentName',
      'GetBShowPriceTest1ValueForQ2Crosssells',
      'GetBFunnelTestValue', 'GetBShowPriceTestValue', 'GetBShowPriceTest1Value']);
    mockAppInitializationService = jasmine.createSpyObj(['initializeApp']);
    TestBed.configureTestingModule({
      providers: [CanActivateQuestionaireGuard,
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: ExperimentsService, useValue: mockExperimentsService },
        { provide: AppInitializationService, useValue: mockAppInitializationService }
      ]
    });
    service = TestBed.get(CanActivateQuestionaireGuard);
  });

  it('should create', () => {
    expect(service).toBeTruthy();
  });
  it('should return true if initializeApp return true', async(() => {
    mockAppInitializationService.initializeApp.and.returnValue(of(true));
    const activatedRoute: ActivatedRouteSnapshot = new ActivatedRouteSnapshot();
    activatedRoute.queryParams = {
      TIMESTRING: 'test',
      mobile_app: true,
      uo: 1234
    };
    const mockSnapshot = jasmine.createSpyObj<RouterStateSnapshot>('RouterStateSnapshot', ['toString']);
    const result = service.canActivate(activatedRoute, mockSnapshot);
    result.subscribe(data => {
      expect(data).toBe(true);
    });
    expect(mockExperimentsService.GetBFunnelTestValue).toHaveBeenCalled();
    expect(mockExperimentsService.GetBShowPriceTestValue).toHaveBeenCalled();
    expect(mockExperimentsService.GetBShowPriceTest1Value).toHaveBeenCalled();
  }));
});
