import { Component } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Subject } from 'rxjs';
import { WindowRef } from '../../services/windowRef.service';
import { UtilitiesService } from '@legalzoom/business-formation-sdk';
import { SessionStorageType } from './../../services/tracking/session-storage';
import { SsoService } from '../../services/sso.service';
import { SEADService } from '../../services/tracking/sead.service';

@Component({
  selector: 'app-desktop-save-your-work-modal',
  templateUrl: './save-your-work-modal.component.html',
  styleUrls: ['./save-your-work-modal.component.scss']
})

export class SaveYourWorkModalComponent {
  private unsubscribe: Subject<void> = new Subject();

  constructor(
    public activeModal: NgbActiveModal,
    public ssoService: SsoService,
    private windowRef: WindowRef,
    private utilitiesService: UtilitiesService,
    private seadService: SEADService,
  ) { }

  signIn(): void {
    return this.ssoService.login({displayContext: 'saveProgress'});
  }

  signUp(): void {
    this.seadService.TrackingObject.user_fname = 'LegalZoom';
    this.seadService.TrackingObject.user_lname = 'Customer';
    this.seadService.PushToTealium();

    return this.ssoService.login({ initialScreen: 'signup', displayContext: 'saveProgress' });
  }

  gotoHomePage(): void {
    this.utilitiesService.clearUserSession(true, SessionStorageType.APP);
    this.windowRef.nativeWindow.location.href = '/';
  }
}
