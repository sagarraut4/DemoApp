import { HeaderDialogFormType } from '../../models/dialog-model';
import { WebSessionService } from '@legalzoom/web-session-sdk';
import { CustomerService } from '@legalzoom/customer-sdk';
import { WindowRef } from '../../services/windowRef.service';
import { SEADService } from '../../services/tracking/sead.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SaveYourWorkModalComponent } from './save-your-work-modal.component';
import { FormsModule, ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpClient } from '@angular/common/http';
import { AppService } from '../../state/app';
import { By } from '@angular/platform-browser';
import { of } from 'rxjs';
import { UtilitiesService } from '@legalzoom/business-formation-sdk';
import { UserCartService } from '../../../pl-features/glo-design/shared/services/user-cart.service';

describe('SaveYourWorkModalComponent', () => {
  let component: SaveYourWorkModalComponent;
  let fixture: ComponentFixture<SaveYourWorkModalComponent>;
  let mockNgbActiveModal;
  let mockSeadService;
  let mockWebSessionService;
  let mockUserCartService;
  let mockUtilitiesService;
  const mockAppService = {
    customerId: 123,
    accessToken: 'testTOken',
    sessionId: 'sessionId',
    app: { customerId: 123 }
  };
  let mockCustomerService;
  let mockWindowRef;
  const formBuilder: FormBuilder = new FormBuilder();
  beforeEach(async(() => {
    mockWindowRef = jasmine.createSpyObj(['nativeWindow', 'utag']);
    mockWebSessionService = jasmine.createSpyObj(['convertGuestToCustomerAndSession', 'loginCustomerAndSession']);
    mockNgbActiveModal = jasmine.createSpyObj(['close', 'dismiss']);
    mockSeadService = jasmine.createSpyObj(['PushToTealium']);
    mockCustomerService = jasmine.createSpyObj(['getCustomerInfo', 'forgetPassword']);
    mockUserCartService = jasmine.createSpyObj(['updateCartAndProcessingOrderByCustomerId', 'updateCustomerInfoInAppService']);
    mockUtilitiesService = jasmine.createSpyObj(['clearUserSession']);
    mockSeadService.TrackingObject = {
      user_fname: '',
      user_lname: ''
    };
    TestBed.configureTestingModule({
      declarations: [SaveYourWorkModalComponent],
      imports: [FormsModule, ReactiveFormsModule, HttpClientTestingModule],
      providers: [
        { provide: NgbActiveModal, useValue: mockNgbActiveModal },
        { provide: SEADService, useValue: mockSeadService },
        { provide: WebSessionService, useValue: mockWebSessionService },
        { provide: UserCartService, useValue: mockUserCartService },
        { provide: AppService, useValue: mockAppService },
        { provide: CustomerService, useValue: mockCustomerService },
        { provide: WindowRef, useValue: mockWindowRef },
        { provide: UtilitiesService, useValue: mockUtilitiesService },
        HttpClient
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SaveYourWorkModalComponent);
    component = fixture.componentInstance;
    component.form = formBuilder.group({
      email: [''],
      password: ['']
    });
    fixture.detectChanges();
  });

  it('should create save your work modal component', () => {
    expect(component).toBeTruthy();
  });

  it('cross button should close the active modal', () => {
    const crossBtn = fixture.debugElement.query(By.css('.close')).nativeElement;
    crossBtn.click();
    expect(mockNgbActiveModal.dismiss).toHaveBeenCalled();
  });


  it('changeFormType should change the currentFormType value', () => {
    component.changeFormType(HeaderDialogFormType.Login);
    expect(component.currentFormType).toBe(HeaderDialogFormType.Login);
  });

  it('create account btn click should create account', () => {
    spyOn(component, 'createMyAccount');
    const createAccountBtn = fixture.debugElement.query(By.css('#btn-create-account')).nativeElement;
    setInputValue('#guestExistingUserEmail', 'test@legalzoom.com');
    setInputValue('#password', 'testPass');
    createAccountBtn.click();
    expect(component.createMyAccount).toHaveBeenCalled();
  });

  it('createMyAccount method should create account', () => {
    mockCustomerService.getCustomerInfo.and.returnValue(of({ isCustomerExists: false }));
    mockWebSessionService.convertGuestToCustomerAndSession.and.returnValue(of({ customer: { customerId: 123 }, session: {} }));
    mockUserCartService.updateCustomerInfoInAppService.and.returnValues(of({ customer: { customerId: 123 }, session: {} }));
    const createAccountBtn = fixture.debugElement.query(By.css('#btn-create-account')).nativeElement;
    setInputValue('#guestExistingUserEmail', 'test@legalzoom.com');
    setInputValue('#password', 'testPass');
    createAccountBtn.click();
    expect(mockWebSessionService.convertGuestToCustomerAndSession).toHaveBeenCalled();
  });

  it('togglePasswordVisibility should toggle the visiblity of password', () => {
    component.togglePasswordVisibility();
    expect(component.passwordViewType).toBe('text');
  });

  it('signIn method should signIn', () => {
    mockWebSessionService.loginCustomerAndSession.and.returnValue(of({ customer: { customerId: 123 }, session: {} }));
    mockUserCartService.updateCartAndProcessingOrderByCustomerId.and.returnValue(of({ customer: { customerId: 123 }, session: {} }));
    component.form.controls.email.setValue('test@test.com');
    component.form.controls.email.markAsDirty();
    component.form.controls.email.markAsTouched();
    component.form.controls.password.setValue('testPAss');
    component.form.controls.password.markAsDirty();
    component.form.controls.password.markAsTouched();
    component.signIn();
    expect(mockWebSessionService.loginCustomerAndSession).toHaveBeenCalled();
  });

  it('forgotPassword method should call customer service forgot password method', () => {
    mockCustomerService.forgetPassword.and.returnValue(of({ requestPasswordMessage: { status: 5, message: '' } }));
    mockUserCartService.updateCartAndProcessingOrderByCustomerId.and.returnValue(of({ customer: { customerId: 123 }, session: {} }));
    component.form.controls.email.setValue('test@test.com');
    component.form.controls.email.markAsDirty();
    component.form.controls.email.markAsTouched();
    component.form.controls.password.setValue('testPAss');
    component.form.controls.password.markAsDirty();
    component.form.controls.password.markAsTouched();
    component.forgotPassword();
    expect(mockCustomerService.forgetPassword).toHaveBeenCalled();
  });

  function setInputValue(selector: string, value: string) {
    fixture.detectChanges();
    const input = fixture.debugElement.query(By.css(selector)).nativeElement;
    input.value = value;
    input.dispatchEvent(new Event('input'));
    fixture.whenStable().then(() => {
      fixture.detectChanges();
    });
  }
});
