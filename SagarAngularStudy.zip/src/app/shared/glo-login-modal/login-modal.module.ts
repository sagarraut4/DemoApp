import { environmentCommon } from '../../../environments/environment';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { SaveYourWorkModalComponent } from './save-your-work-modal/save-your-work-modal.component';
import { CartModule } from '@legalzoom/cart-sdk';
import { UserCartService } from '../../../app/pl-features/glo-design/shared/services/user-cart.service';
import { CustomerModule } from '@legalzoom/customer-sdk';


@NgModule({
  imports: [
    CommonModule, ReactiveFormsModule,
    CartModule.forRoot(environmentCommon),
    CustomerModule.forRoot(environmentCommon)
  ],
  declarations: [SaveYourWorkModalComponent],
  entryComponents: [SaveYourWorkModalComponent],
  providers: [UserCartService]
})
export class GloLoginModalModule { }
