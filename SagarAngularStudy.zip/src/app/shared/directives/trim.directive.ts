import {Directive, ElementRef, Self, Output, EventEmitter, HostListener} from '@angular/core';
import {NgControl} from '@angular/forms';

@Directive({
  // tslint:disable-next-line: directive-selector
  selector: '[trimFormatter]'
})
export class TrimDirective {
  @Output() ngModelChange = new EventEmitter();

  @HostListener('change') onchange() {
    let outputValue = '';
    const inputValue = this.el.nativeElement.value;

    if (inputValue != null) {
      outputValue = outputValue + inputValue.trim();
    }

    this.ngControl.reset(outputValue);
    this.el.nativeElement.value = outputValue;
  }

  constructor(private el: ElementRef, @Self() private ngControl: NgControl) {
  }
}
