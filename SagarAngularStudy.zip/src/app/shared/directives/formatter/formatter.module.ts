import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NameformatterDirective } from '../nameformatter.directive';
import { ZipCodeFormatterDirective } from '../zip-code-formatter.directive';
import { FocusNextInputDirective } from '../focus-next-input.directive';
import { TrimDirective } from '../trim.directive';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    NameformatterDirective,
    TrimDirective,
    ZipCodeFormatterDirective,
    FocusNextInputDirective
  ],
  exports: [
    NameformatterDirective,
    TrimDirective,
    ZipCodeFormatterDirective,
    FocusNextInputDirective
  ]
})
export class FormatterModule { }
