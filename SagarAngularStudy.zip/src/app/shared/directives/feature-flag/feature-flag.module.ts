import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FeatureFlagShowIfOffDirective} from './feature-flag-show-if-off.directive';
import {FeatureFlagShowIfOnDirective} from './feature-flag-show-if-on.directive';

@NgModule({
  imports: [
    CommonModule,
  ],
  declarations: [
    FeatureFlagShowIfOnDirective,
    FeatureFlagShowIfOffDirective,
  ],
  exports: [
    FeatureFlagShowIfOnDirective,
    FeatureFlagShowIfOffDirective,
  ]
})
export class FeatureFlagModule {
}
