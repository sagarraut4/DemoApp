import {
  Directive,
  EmbeddedViewRef,
  Input,
  OnChanges,
  SimpleChanges,
  TemplateRef,
  ViewContainerRef,
} from '@angular/core';
import {FeatureFlagService} from '../../services/feature-flag/feature-flag.service';
import {Subject} from "rxjs";
import {takeUntil} from "rxjs/operators";

@Directive({
  selector: '[appFeatureFlagShowIfOff]',
})
export class FeatureFlagShowIfOffDirective implements OnChanges {
  // tslint:disable-next-line:no-input-rename
  @Input('appFeatureFlagShowIfOff') public key: string;
  // tslint:disable-next-line:no-input-rename
  @Input('appFeatureFlagShowIfOffInitPatternLibOnComplete') public initPatternLibOnComplete: any;

  private unsubscribe: Subject<void> = new Subject();

  public constructor(
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef,
    private featureFlagService: FeatureFlagService,
  ) {
    this.viewContainer.clear();
  }

  public ngOnChanges({key}: SimpleChanges) {
    // Only Evaluate if Current Values Exists
    if ((typeof key !== 'undefined') &&
      (typeof key.currentValue !== 'undefined')) {
      this.evaluateVisibility();
    }
  }

  private evaluateVisibility(): void {
    this.featureFlagService.isFeatureOff(this.key).pipe(takeUntil(this.unsubscribe)).subscribe(isFeatureOff => {
      // Show Directive if the Feature is OFF
      if (isFeatureOff) {
        // Add Template to UI
        const output: EmbeddedViewRef<any> = this.viewContainer.createEmbeddedView(this.templateRef);

        // PL2 Hack - show on COMPLETE
        if (this.initPatternLibOnComplete) {
          // Run through Nodes
          output.rootNodes.forEach(
            node => {
              // Only Update tags that exist ( comments are injected by angular by default if you use ng-container )
              if (typeof node.tagName !== 'undefined') {
                // Init PL2
                (window as any).patternLib.init(node);
              }
            },
          );
        }
      }

      // Clear the don since the feature is on
      else {
        this.viewContainer.clear();
      }
    });
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }

}
