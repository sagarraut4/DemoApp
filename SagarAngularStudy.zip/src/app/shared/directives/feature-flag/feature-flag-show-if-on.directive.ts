import {
  Directive,
  EmbeddedViewRef,
  Input,
  OnChanges,
  SimpleChanges,
  TemplateRef,
  ViewContainerRef,
} from '@angular/core';
import {FeatureFlagService} from '../../services/feature-flag/feature-flag.service';
import {Subject} from "rxjs";
import {takeUntil} from "rxjs/operators";

@Directive({
  selector: '[appFeatureFlagShowIfOn]',
})
export class FeatureFlagShowIfOnDirective implements OnChanges {
  // tslint:disable-next-line:no-input-rename
  @Input('appFeatureFlagShowIfOn') public key: string;
  // tslint:disable-next-line:no-input-rename
  @Input('appFeatureFlagShowIfOnInitPatternLibOnComplete') public initPatternLibOnComplete: any;

  private unsubscribe: Subject<void> = new Subject();

  public constructor(
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef,
    private featureFlagService: FeatureFlagService,
  ) {
    this.viewContainer.clear();
  }

  public ngOnChanges({key}: SimpleChanges) {
    // Only Evaluate if Current Values Exists
    if ((typeof key !== 'undefined') &&
      (typeof key.currentValue !== 'undefined')) {
      this.evaluateVisibility();
    }
  }

  private evaluateVisibility(): void {
    this.featureFlagService.isFeatureOn(this.key).pipe(takeUntil(this.unsubscribe)).subscribe(isFeatureOn => {
      if (isFeatureOn) {
        // Add Template to UI
        const output: EmbeddedViewRef<any> = this.viewContainer.createEmbeddedView(this.templateRef);

        // PL2 Hack - show on COMPLETE
        if (this.initPatternLibOnComplete) {
          // Run through Nodes
          output.rootNodes.forEach(
            node => {
              // Only Update tags that exist ( comments are injected by angular by default if you use ng-container )
              if (typeof node.tagName !== 'undefined') {
                // Init PL2
                (window as any).patternLib.init(node);
              }
            },
          );
        }
      }

      // Clear the don since the feature is off
      else {
        this.viewContainer.clear();
      }
    });
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }

}
