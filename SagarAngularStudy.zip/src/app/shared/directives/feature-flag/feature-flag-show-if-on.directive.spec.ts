import { Component, DebugElement } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { By } from '@angular/platform-browser';
import { Observable, of } from 'rxjs';
import { FeatureFlagShowIfOnDirective } from './feature-flag-show-if-on.directive';
import { FeatureFlagService } from '../../services/feature-flag/feature-flag.service';

const MOCK_FEATURE_ID = 'mock-element';
const MOCK_FEATURE_KEY = 'mock-feature';
const MOCK_FEATURE_KEY_BAD = `${MOCK_FEATURE_KEY}-bad`;
const MOCK_FEATURE_DATA_ON = 'on';
const MOCK_FEATURE_DATA_OFF = 'off';

@Component({
  template: `
    <section class="mock-wrapper">
      <ng-container
        *appFeatureFlagShowIfOn="mockFeatureKey; initPatternLibOnComplete: mockInitPatternLibOnComplete;">
        <div id="${MOCK_FEATURE_ID}">
          <span>MOCK CONTENT</span>
        </div>
      </ng-container>
    </section>
  `,
})
class MockComponent {
  public mockFeatureKey: string;
  public mockFeatureValue: string;
  public mockInitPatternLibOnComplete: boolean;
}

describe(
  'FeatureFlagShowIfOnDirective',
  () => {
    let component: MockComponent;
    let fixture: ComponentFixture<MockComponent>;
    let htmlDebugWrapperElement: DebugElement;
    let htmlDebugElement: DebugElement;

    const mockFeatureFlagService = {
      isFeatureOn: (flagKey: string): Observable<boolean> => {
        return of(
            flagKey === MOCK_FEATURE_KEY,
        );
      },
    };

    beforeEach(
      async(
        () => {
          TestBed.configureTestingModule(
            {
              imports: [
                CommonModule,
              ],
              providers: [
                {provide: FeatureFlagService, useValue: mockFeatureFlagService},
              ],
              declarations: [
                MockComponent,
                FeatureFlagShowIfOnDirective,
              ],
            },
          ).compileComponents()
            .then(
              () => {
                fixture = TestBed.createComponent(MockComponent);

                component = fixture.componentInstance;

                fixture.detectChanges();

                htmlDebugWrapperElement = fixture.debugElement.query(By.css('.mock-wrapper'));
              },
            );
        },
      ),
    );

    it('should have a wrapper', () => {
      expect(htmlDebugWrapperElement.nativeElement).toBeDefined();
    });

    // Feature On Set
    describe('[Feature On]', () => {
      beforeEach(
        () => {
          component.mockFeatureKey = MOCK_FEATURE_KEY;
        },
      );

      it('should show with correct value', () => {
        component.mockFeatureValue = MOCK_FEATURE_DATA_ON;

        fixture.detectChanges();

        htmlDebugElement = htmlDebugWrapperElement.query(By.css(`#${MOCK_FEATURE_ID}`));

        expect(htmlDebugElement).toBeDefined();
      });

      it('should show with correct value and init PL on complete', () => {
        component.mockFeatureValue = MOCK_FEATURE_DATA_ON;
        component.mockInitPatternLibOnComplete = true;

        fixture.detectChanges();

        htmlDebugElement = htmlDebugWrapperElement.query(By.css(`#${MOCK_FEATURE_ID}`));

        expect(htmlDebugElement).toBeDefined();
      });

      it('should not show with incorrect value', () => {
        component.mockFeatureValue = MOCK_FEATURE_DATA_OFF;

        fixture.detectChanges();

        htmlDebugElement = htmlDebugWrapperElement.query(By.css(`#${MOCK_FEATURE_ID}`));

        expect(htmlDebugElement).toBeNull();
      });

      it('should not show with no data', () => {
        component.mockFeatureValue = undefined;

        fixture.detectChanges();

        htmlDebugElement = htmlDebugWrapperElement.query(By.css(`#${MOCK_FEATURE_ID}`));

        expect(htmlDebugElement).toBeNull();
      });
    });


    // Feature Off Set
    describe('[Feature Off]', () => {
      beforeEach(
        () => {
          component.mockFeatureKey = MOCK_FEATURE_KEY_BAD;
        },
      );

      it('should not show with data', () => {
        component.mockFeatureValue = MOCK_FEATURE_DATA_ON;

        fixture.detectChanges();

        htmlDebugElement = htmlDebugWrapperElement.query(By.css(`#${MOCK_FEATURE_ID}`));

        expect(htmlDebugElement).toBeNull();
      });

      it('should not show with incorrect data', () => {
        component.mockFeatureValue = MOCK_FEATURE_DATA_OFF;

        fixture.detectChanges();

        htmlDebugElement = htmlDebugWrapperElement.query(By.css(`#${MOCK_FEATURE_ID}`));

        expect(htmlDebugElement).toBeNull();
      });

      it('should not show w/o data', () => {
        component.mockFeatureValue = undefined;

        fixture.detectChanges();

        htmlDebugElement = htmlDebugWrapperElement.query(By.css(`#${MOCK_FEATURE_ID}`));

        expect(htmlDebugElement).toBeNull();
      });
    });

    afterEach(() => {
      fixture.destroy();
    });
  },
);
