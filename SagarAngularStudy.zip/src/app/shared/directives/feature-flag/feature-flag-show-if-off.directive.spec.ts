import { Component, DebugElement } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { By } from '@angular/platform-browser';
import { Observable, of } from 'rxjs';
import { FeatureFlagShowIfOffDirective } from './feature-flag-show-if-off.directive';
import { FeatureFlagService } from '../../services/feature-flag/feature-flag.service';

const MOCK_FEATURE_ID = 'mock-element';
const MOCK_FEATURE_KEY = 'mock-feature';
const MOCK_FEATURE_KEY_BAD = `${MOCK_FEATURE_KEY}-bad`;
const MOCK_FEATURE_DATA_ON = 'on';
const MOCK_FEATURE_DATA_OFF = 'off';

@Component({
  template: `
    <section class="mock-wrapper">
      <ng-container
        *appFeatureFlagShowIfOff="mockFeatureKey; initPatternLibOnComplete: mockInitPatternLibOnComplete;">
        <div id="${MOCK_FEATURE_ID}">
          <span>MOCK CONTENT</span>
        </div>
      </ng-container>
    </section>
  `,
})
class MockComponent {
  public mockFeatureKey: string;
  public mockFeatureValue: string;
  public mockInitPatternLibOnComplete: boolean;
}

describe(
  'FeatureFlagShowIfOffDirective',
  () => {
    let component: MockComponent;
    let fixture: ComponentFixture<MockComponent>;
    let htmlDebugWrapperElement: DebugElement;
    let htmlDebugElement: DebugElement;

    const mockFeatureFlagService = {
      isFeatureOff: (flagKey): Observable<boolean> => {
        return of(
            flagKey !== MOCK_FEATURE_KEY
        );
      },
    };

    beforeEach(
      async(
        () => {
          TestBed.configureTestingModule(
            {
              imports: [
                CommonModule,
              ],
              providers: [
                {provide: FeatureFlagService, useValue: mockFeatureFlagService},
              ],
              declarations: [
                MockComponent,
                FeatureFlagShowIfOffDirective,
              ],
            },
          ).compileComponents()
            .then(
              () => {
                fixture = TestBed.createComponent(MockComponent);

                component = fixture.componentInstance;

                fixture.detectChanges();

                htmlDebugWrapperElement = fixture.debugElement.query(By.css('.mock-wrapper'));
              },
            );
        },
      ),
    );

    it('should have a wrapper', () => {
      expect(htmlDebugWrapperElement.nativeElement).toBeDefined();
    });

    // Feature On Set
    describe('[Feature On]', () => {
      beforeEach(
        () => {
          component.mockFeatureKey = MOCK_FEATURE_KEY;
        },
      );

      it('should not show with data', () => {
        component.mockFeatureValue = MOCK_FEATURE_DATA_ON;

        fixture.detectChanges();

        htmlDebugElement = htmlDebugWrapperElement.query(By.css(`#${MOCK_FEATURE_ID}`));

        expect(htmlDebugElement).toBeNull();
      });

      it('should show with incorrect value', () => {
        component.mockFeatureValue = MOCK_FEATURE_DATA_OFF;

        fixture.detectChanges();

        htmlDebugElement = htmlDebugWrapperElement.query(By.css(`#${MOCK_FEATURE_ID}`));

        expect(htmlDebugElement).toBeDefined();
      });

      it('should show with incorrect value', () => {
        component.mockFeatureValue = MOCK_FEATURE_DATA_OFF;
        component.mockInitPatternLibOnComplete = true;

        fixture.detectChanges();

        htmlDebugElement = htmlDebugWrapperElement.query(By.css(`#${MOCK_FEATURE_ID}`));

        expect(htmlDebugElement).toBeDefined();
      });

      it('should not show without data', () => {
        component.mockFeatureValue = undefined;

        fixture.detectChanges();

        htmlDebugElement = htmlDebugWrapperElement.query(By.css(`#${MOCK_FEATURE_ID}`));

        expect(htmlDebugElement).toBeNull();
      });
    });

    // Feature Off Set
    describe('[Feature Off]', () => {
      beforeEach(
        () => {
          component.mockFeatureKey = MOCK_FEATURE_KEY_BAD;
        },
      );

      it('should show with data', () => {
        component.mockFeatureValue = MOCK_FEATURE_DATA_ON;

        fixture.detectChanges();

        htmlDebugElement = htmlDebugWrapperElement.query(By.css(`#${MOCK_FEATURE_ID}`));

        expect(htmlDebugElement).toBeDefined();
      });

      it('should show with incorrect data', () => {
        component.mockFeatureValue = MOCK_FEATURE_DATA_OFF;

        fixture.detectChanges();

        htmlDebugElement = htmlDebugWrapperElement.query(By.css(`#${MOCK_FEATURE_ID}`));

        expect(htmlDebugElement).toBeDefined();
      });

      it('should show without data', () => {
        component.mockFeatureValue = undefined;

        fixture.detectChanges();

        htmlDebugElement = htmlDebugWrapperElement.query(By.css(`#${MOCK_FEATURE_ID}`));

        expect(htmlDebugElement).toBeDefined();
      });
    });

    afterEach(() => {
      fixture.destroy();
    });
  },
);

