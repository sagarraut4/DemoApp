import { TrackingDirective } from './tracking.directive';

describe('TrackingDirective', () => {
  it('should create an instance', () => {
    const directive = new TrackingDirective();
    expect(directive).toBeTruthy();
  });
});
