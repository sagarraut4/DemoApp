import { Directive, HostListener, Input} from '@angular/core';
import { TrackingAmplitudeData, TrackingPayloadAmplitudeEvent } from '../models/tracking-model';
import { TrackingService } from '../services/tracking/tracking.service';

@Directive({
  selector: '[appTracking]'
})
export class TrackingDirective {
  @Input() public appTracking: TrackingAmplitudeData;
  @Input() public appTrackingEnabled: boolean = true;

  public constructor(
    private trackingService: TrackingService,
  ) {
  }

  @HostListener('click', [])
  public handleClick(): void {
    if (this.appTracking && this.appTrackingEnabled) {
      let amplitudeEventPayload: TrackingPayloadAmplitudeEvent = null;

      if (this.appTracking) {
        amplitudeEventPayload = {
          amplitude_event_label: this.appTracking.label,
          amplitude_event_properties: this.appTracking.properties,
        };
      }

      this.trackingService.trackPayload(        
        amplitudeEventPayload,
        null,
      );

    }
  }
}
