import { ZipCodeFormatterDirective } from './zip-code-formatter.directive';

describe('ZipCodeFormatterDirective', () => {
  it('should create an instance', () => {
    const directive = new ZipCodeFormatterDirective(null, null);
    expect(directive).toBeTruthy();
  });
});
