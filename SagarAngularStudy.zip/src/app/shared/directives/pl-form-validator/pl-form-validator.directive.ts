import {
  Directive,
  ElementRef,
  forwardRef,
  HostListener,
  Inject,
  Injector,
  OnDestroy,
  OnInit,
  Optional,
  Renderer2,
  Input
} from '@angular/core';

import {
  COMPOSITION_BUFFER_MODE,
  ControlValueAccessor,
  DefaultValueAccessor,
  FormControl,
  NG_VALUE_ACCESSOR,
  NgControl
} from '@angular/forms';

import {Subscription} from 'rxjs';


export const DEFAULT_VALUE_ACCESSOR: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => PlFormValidatorDirective),
  multi: true
};

@Directive({
  // tslint:disable-next-line: directive-selector
  selector: '[plFormValidator]',
  providers: [DEFAULT_VALUE_ACCESSOR]
})
export class PlFormValidatorDirective extends DefaultValueAccessor implements OnInit, OnDestroy {
  private plNativeComponent: ControlValueAccessor | any;
  private deferredActionRegistry: any = {};

  private formControl: FormControl;
  private formStatusSubscription$: Subscription;

  @Input() plFormValidator: any;

  constructor(
    public renderer: Renderer2,
    public elementRef: ElementRef,
    private inj: Injector,
    @Optional() @Inject(COMPOSITION_BUFFER_MODE) private compositionMode: boolean
  ) {
    super(renderer, elementRef, compositionMode);
  }

  ngOnInit(): void {
    // tslint:disable-next-line: deprecation
    this.formControl = this.inj.get(NgControl);

    this.plNativeComponent = this.elementRef.nativeElement;

    this.renderer.setAttribute(this.plNativeComponent, 'pl-no-validate', 'true');
  }

  ngOnDestroy(): void {
    if (this.formStatusSubscription$) {
      this.formStatusSubscription$.unsubscribe();
    }
  }

  @HostListener('plHasMounted')
  plOnMount() {
    Object.keys(this.deferredActionRegistry).forEach(
      key => this.passThroughOrDeffer(key, this.deferredActionRegistry[key])
    );

    this.deferredActionRegistry = {};

    this.formStatusSubscription$ = this.formControl.statusChanges.subscribe(() => {
      this.reportValidity();
      // If input then take message based on error and post it
      // If !input then use default message *create default message
    });
  }

  private reportValidity() {
    if (!!this.formControl.errors) {
      if (this.plFormValidator) {
        const firstErrorMessage = this.plFormValidator[Object.keys(this.formControl.errors).pop()];
        if (firstErrorMessage) {
          this.plNativeComponent.setCustomValidity(firstErrorMessage);
        }
      }
    } else {
      this.plNativeComponent.setCustomValidity('');
    }
  }

  @HostListener('plChange', ['$event.detail'])
  plHandleChange(event) {
    const val = event; // force trigger a value read, not always passing on value state change
    this.onChange(val);
  }

  @HostListener('plBlur')
  plHandleBlur() {
    this.onTouched();
    this.reportValidity();
  }

  writeValue(value: any): void {
    if (value !== null) { // set value only if there is one
      this.passThroughOrDeffer('plValue', value);
    }
  }

  registerOnChange(fn: (_: any) => void): void {
    this.onChange = value => {
      fn(value);
    };
  }

  registerOnTouched(fn: () => void): void {
    this.onTouched = () => {
      fn();
    };
  }

  setDisabledState(isDisabled: boolean): void {
    this.renderer.setProperty(this.plNativeComponent, 'disabled', isDisabled);
    this.passThroughOrDeffer('plDisabled', isDisabled);
  }

  private passThroughOrDeffer(key: string, value: any): void {
    if ((typeof this.plNativeComponent === 'undefined') ||
        (typeof(this.plNativeComponent[key]) === 'undefined')) {
      this.deferredActionRegistry[key] = value;
    } else {
      this.plNativeComponent[key] = value;
    }
  }
}
