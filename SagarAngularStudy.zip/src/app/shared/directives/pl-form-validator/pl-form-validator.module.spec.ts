import {PlFormValidatorModule} from './pl-form-validator.module';

describe('PlFormValidatorModule', () => {
  let plFormValidatorModule: PlFormValidatorModule;

  beforeEach(() => {
    plFormValidatorModule = new PlFormValidatorModule();
  });

  it('should create an instance', () => {
    expect(plFormValidatorModule).toBeTruthy();
  });
});
