import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {PlFormValidatorDirective} from './pl-form-validator.directive';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  declarations: [
    PlFormValidatorDirective
  ],
  exports: [
    PlFormValidatorDirective
  ]
})
export class PlFormValidatorModule {
}
