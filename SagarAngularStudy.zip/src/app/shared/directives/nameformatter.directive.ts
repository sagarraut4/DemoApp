import { Directive, HostListener, Input, ElementRef, Renderer, EventEmitter, Output, Self } from '@angular/core';
import { NgControl, ControlValueAccessor } from '@angular/forms';
import { CaseTransformationHelper } from '../helpers/case-transformation.helper';

@Directive({
  // tslint:disable-next-line:directive-selector
  selector: '[nameformatter]'
})

export class NameformatterDirective {
  private plNativeComponent: ControlValueAccessor | any;
  constructor(private el: ElementRef, @Self() private ngControl: NgControl) { }
  @Output() ngModelChange = new EventEmitter();
  @Input() nameformatter: any;
  @Input() delayedProcessor: boolean;
  prefixArrays: Array<string> = ['jr', 'sr', 'mr', 'ms', 'dr'];
  specialWOrdArrays: Array<string> = ['no', 'n/a', 'na', 'not applicable', 'none', 'tbd', 'to be determined', 'to be decided', 'don\'t know', 'do not know'];
  romanRegex = '^M{0,4}(CM|CD|D?C{0,3})(XC|XL|L?X{0,3})(IX|IV|V?I{0,3})$';
  capitalLetterRegex = '^[A-Z]*$';
  lowerLetterRegex = '^[a-z]*$';
  numericValueRegex = '^[0-9]*$';
  firstLetterNumeric = '^[0-9][a-zA-Z]*$';

  @HostListener('plChange', ['$event.detail'])
  plHandleChange(event: any) {
    const val = event; // force trigger a value read, not always passing on value state change
    this.onChange(val);
  }

  @HostListener('change', ['$event.target.value'])
  onChange(event: any) {

    const formatterCore = () => {
      let outputValue = '';
      // let inputValue = '';

      let inputValue = event;
      if (inputValue === undefined || inputValue === null) {
        inputValue = this.el.nativeElement.value;
      }

      let inputValueArray = new Array<string>();
      let dashSeparatedArray = new Array<string>();
      inputValueArray = inputValue.trim().split(' ');
      if (this.specialWOrdArrays.indexOf(inputValue.trim().toLowerCase()) >= 0) {

        this.ngControl.reset();
        this.el.nativeElement.value = '';
        return;
      }
      switch (this.nameformatter) {
        case 'sentenceCase':
          outputValue = outputValue + this.sentenceCase(inputValue);
          break;
        case 'sentence':
          outputValue = outputValue + this.titleCaseSentence(inputValue);
          break;
        // added to cover the pattern library form elements
        case 'trim':
          outputValue = outputValue + inputValue.trim();
          break;
        case 'name':
          inputValueArray.forEach(obj => {
            if (obj.split('').indexOf('-') >= 0) {
              let dashSeparatedStr = '';
              dashSeparatedArray = obj.split('-');
              dashSeparatedArray.forEach(dashObj => dashSeparatedStr = dashSeparatedStr + CaseTransformationHelper.titleCaseFormat(dashObj) + '-');
              outputValue = outputValue + dashSeparatedStr.substring(0, dashSeparatedStr.length - 1) + ' ';
            } else if (!obj.toLowerCase().localeCompare('llc') || !obj.toLowerCase().localeCompare('l.l.c')) {
              outputValue = outputValue + obj.toUpperCase() + ' ';
            } else if (obj.trim().length > 0 && obj.toUpperCase().match(this.romanRegex)) {
              outputValue = outputValue + CaseTransformationHelper.romanNumberFormat(obj) + ' ';
            } else if (this.prefixArrays.indexOf(obj.toLowerCase()) >= 0) {
              outputValue = outputValue + CaseTransformationHelper.titleCaseFormat(obj) + ' ';
            } else if (obj.match(this.firstLetterNumeric)) {
              outputValue = outputValue + obj.toLowerCase() + ' ';
            } else if (obj.trim().length === 2 && obj.match(this.capitalLetterRegex)) {
              outputValue = outputValue + obj.toUpperCase() + ' ';
            } else if (obj.trim().length === 2 && (obj.toLowerCase() !== obj || obj.toUpperCase() !== obj)) {
              outputValue = outputValue + CaseTransformationHelper.titleCaseFormat(obj) + ' ';
            } else if (obj.match(this.capitalLetterRegex) || obj.match(this.lowerLetterRegex)) {
              outputValue = outputValue + CaseTransformationHelper.titleCaseFormat(obj) + ' ';
            } else if (obj.toLowerCase() !== obj || obj.toUpperCase() !== obj) {
              outputValue = outputValue + obj.trim() + ' ';
            }
          });
          break;
        case 'address':
          inputValueArray.forEach(obj => {
            if (obj.split('').indexOf('-') >= 0) {
              let dashSeparatedStr = '';
              dashSeparatedArray = obj.split('-');
              dashSeparatedArray.forEach(dashObj => dashSeparatedStr = dashSeparatedStr + CaseTransformationHelper.titleCaseFormat(dashObj) + '-');
              outputValue = outputValue + dashSeparatedStr.substring(0, dashSeparatedStr.length - 1) + ' ';
            } else if (!obj.toLowerCase().localeCompare('llc') || !obj.toLowerCase().localeCompare('l.l.c')) {
              outputValue = outputValue + obj.trim().toUpperCase() + ' ';
            } else if (obj.trim().length > 0 && obj.toUpperCase().match(this.romanRegex)) {
              outputValue = outputValue + CaseTransformationHelper.romanNumberFormat(obj.trim()) + ' ';
            } else if (this.prefixArrays.indexOf(obj.toLowerCase()) >= 0) {
              outputValue = outputValue + CaseTransformationHelper.titleCaseFormat(obj.trim()) + ' ';
            } else if (obj.match(this.firstLetterNumeric)) {
              outputValue = outputValue + obj.trim().toLowerCase() + ' ';
            } else if (obj.trim().length === 2 && obj.match(this.capitalLetterRegex)) {
              outputValue = outputValue + obj.trim().toUpperCase() + ' ';
            } else if (obj.trim().length === 2 && (obj.toLowerCase() !== obj || obj.toUpperCase() !== obj)) {
              outputValue = outputValue + CaseTransformationHelper.titleCaseFormat(obj.trim()) + ' ';
            } else if (obj.trim().length > 0 && (obj.match(this.capitalLetterRegex) || obj.match(this.lowerLetterRegex))) {
              outputValue = outputValue + CaseTransformationHelper.titleCaseFormat(obj.trim()) + ' ';
            } else if (obj.trim().length > 0 && (obj.toLowerCase() !== obj || obj.toUpperCase() !== obj)) {
              // step 1 - remove all special characters from the string
              const stringWithoutSpecialCharacters = obj.trim().replace(/[^a-zA-Z ]/g, '');
              if (stringWithoutSpecialCharacters.toLowerCase() !== stringWithoutSpecialCharacters && stringWithoutSpecialCharacters.toUpperCase() !== stringWithoutSpecialCharacters) {
                // step 2 - it is mixed casing
                outputValue = outputValue + obj.trim() + ' ';
              } else {
                // step 3 - not mixed casing
                outputValue = outputValue + CaseTransformationHelper.titleCaseFormat(obj.trim()) + ' ';
              }
            } else if (obj.trim().length > 0 && obj.match(this.numericValueRegex)) {
              outputValue = outputValue + obj.trim() + ' ';
            } else if (obj.trim().length > 0) {
              outputValue = outputValue + obj.trim() + ' ';
            }
          });
          break;
      }
      this.ngControl.reset(outputValue.trim());
      this.el.nativeElement.value = outputValue.trim();
    };

    if ('delayedProcessor' in this) {

      setTimeout(() => {
        formatterCore();
      }, 10);
    } else {

      formatterCore();
    }
  }

  public prefixFormat(value: string): string {
    return value.toUpperCase();
  }

  public titleCaseSentence(constr): string {
    let sentenceValue = '';
    const sentenceArrray = constr.toLowerCase().split('.').map((str) => {
      if (str === '') {
        return;
      }
      return str.toLowerCase().split(' ').map((word) => {
        if (word.length === 0) {
          return;
        }
        return word.replace(word[0], word[0].toUpperCase());
      });
    });
    sentenceArrray.forEach(senetence => {
      if (senetence !== undefined) {
        sentenceValue = sentenceValue + senetence.join(' ') + '.';
      }
    });
    return sentenceValue.substring(0, sentenceValue.length - 1);
  }

  sentenceCase(str): string {
    return str.toLowerCase().replace(/[a-z]|/i, (letter) => {
      return letter.toUpperCase();
    }).trim();
  }
}
