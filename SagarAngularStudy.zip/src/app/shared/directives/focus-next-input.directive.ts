import { Directive, ElementRef, HostListener, Input } from '@angular/core';

@Directive({
  // tslint:disable-next-line: directive-selector
  selector: '[focusNextInput]'
})
export class FocusNextInputDirective {

  @Input() focusNextInput: any;

  constructor(private el: ElementRef) { }

  @HostListener('keyup') onKeyDown() {
    if (this.el.nativeElement) {
      if (this.el.nativeElement.value.trim().length === parseInt(this.focusNextInput, 10)) {
        if (this.el.nativeElement.nextElementSibling) {
          this.el.nativeElement.nextElementSibling.focus();
        }
      }
    }
  }
}
