import { Directive, ElementRef, Self, EventEmitter, Output, HostListener } from '@angular/core';
import { NgControl } from '@angular/forms';

@Directive({
  // tslint:disable-next-line: directive-selector
  selector: '[zipCodeFormatter]'
})
export class ZipCodeFormatterDirective {

  @Output() ngModelChange = new EventEmitter();

  constructor(private el: ElementRef, @Self() private ngControl: NgControl) { }

  @HostListener('keyup')
  onkeyUp() {
    let outputValue = '';
    let inputValue = '';
    const directTarget = this.el.nativeElement && this.el.nativeElement.value;
    // tslint:disable-next-line: no-string-literal
    const internalTarget = !directTarget && this.ngControl && this.ngControl['viewModel'];
    if (directTarget) {
      inputValue = this.el.nativeElement.value.trim();
    } else if (internalTarget) {
      // tslint:disable-next-line: no-string-literal
      inputValue = this.ngControl['viewModel'].trim();
    }
    const regex = /^[0-9]+$/;
    const keysAllowed = ['backspace', 'tab'];
    if ( inputValue && (inputValue.match(regex) !== null || keysAllowed.indexOf(inputValue.toLowerCase()) > -1)) {
      outputValue = inputValue;
    } else {
      outputValue = inputValue.substring(0, inputValue.length - 1);
    }
    this.ngControl.reset(outputValue.trim());

    if (directTarget) {
      this.el.nativeElement.value = outputValue.trim();
    } else if (internalTarget) {
      // tslint:disable-next-line: no-string-literal
      this.ngControl['viewModel'] = outputValue.trim();
    }
  }

}
