import { HeaderDialogFormType } from '../../models/dialog-model';
import { WebSessionService } from '@legalzoom/web-session-sdk';
import { CustomerService } from '@legalzoom/customer-sdk';
import { WindowRef } from '../../services/windowRef.service';
import { SEADService } from '../../services/tracking/sead.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SaveYourWorkModalComponent } from './save-your-work-modal.component';
import { FormsModule, ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpClient } from '@angular/common/http';
import { UserCartService } from '../../../pl-features/glo-design/shared/services/user-cart.service';
import { AppService } from '../../state/app';
import { By } from '@angular/platform-browser';
import { of } from 'rxjs';
import { UtilitiesService } from '@legalzoom/business-formation-sdk';
import { PrepareCartService } from '../../services/prepare-cart.service';


describe('SaveYourWorkModalComponent', () => {
  let component: SaveYourWorkModalComponent;
  let fixture: ComponentFixture<SaveYourWorkModalComponent>;
  const mockNgbActiveModal = jasmine.createSpyObj(['close', 'dismiss']);
  const mockSeadService = jasmine.createSpyObj(['PushToTealium']);
  const mockWebSessionService = jasmine.createSpyObj(['convertGuestToCustomerAndSession', 'loginCustomerAndSession']);
  const mockUserCartService = jasmine.createSpyObj(['updateCartAndProcessingOrderByCustomerId', 'updateCustomerInfoInAppService']);
  const mockUtilitiesService = jasmine.createSpyObj(['clearUserSession']);
  const mockPrepareCartService = jasmine.createSpyObj(['saveAndRefreshCart']);
  const mockAppService = {
    customerId: 123,
    accessToken: 'testTOken',
    sessionId: 'sessionId',
    app: { customerId: 123 }
  };
  const mockCustomerService = jasmine.createSpyObj(['getCustomerInfo', 'forgetPassword']);
  const mockWindowRef = jasmine.createSpyObj(['nativeWindow', 'utag']);
  const formBuilder: FormBuilder = new FormBuilder();
  beforeEach(async(() => {
    mockSeadService.TrackingObject = {
      user_fname: '',
      user_lname: ''
    };
    TestBed.configureTestingModule({
      declarations: [SaveYourWorkModalComponent],
      imports: [FormsModule, ReactiveFormsModule, HttpClientTestingModule],
      providers: [
        { provide: NgbActiveModal, useValue: mockNgbActiveModal },
        { provide: SEADService, useValue: mockSeadService },
        { provide: WebSessionService, useValue: mockWebSessionService },
        { provide: UserCartService, useValue: mockUserCartService },
        { provide: AppService, useValue: mockAppService },
        { provide: CustomerService, useValue: mockCustomerService },
        { provide: WindowRef, useValue: mockWindowRef },
        { provide: UtilitiesService, useValue: mockUtilitiesService },
        { provide: PrepareCartService, useValue: mockPrepareCartService },
        HttpClient
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SaveYourWorkModalComponent);
    component = fixture.componentInstance;
    component.form = formBuilder.group({
      email: [''],
      password: ['']
    });
    fixture.detectChanges();
  });

  it('should create save your work modal component', () => {
    expect(component).toBeTruthy();
  });

  it('cross button should close the active modal', () => {
    const crossBtn = fixture.debugElement.query(By.css('.close')).nativeElement;
    crossBtn.click();
    expect(mockNgbActiveModal.dismiss).toHaveBeenCalled();
  });

  it('changeFormType should change the currentFormType value', () => {
    component.changeFormType(HeaderDialogFormType.Login);
    expect(component.currentFormType).toBe(HeaderDialogFormType.Login);
  });

  it('togglePasswordVisibility should toggle the visiblity of password', () => {
    component.togglePasswordVisibility();
    expect(component.isPasswordVisible).toBe(true);
  });

  it('create account btn click should create account', () => {
    spyOn(component, 'createMyAccount');
    const createAccountBtn = fixture.debugElement.query(By.css('#btn-create-account')).nativeElement;
    setInputValue('#guestExistingUserEmail', 'test@legalzoom.com');
    setInputValue('#password', 'testPass');
    createAccountBtn.click();
    expect(component.createMyAccount).toHaveBeenCalled();
  });

  it('createMyAccount method should create account', () => {
    mockCustomerService.getCustomerInfo.and.returnValue(of({ isCustomerExists: false }));
    mockWebSessionService.convertGuestToCustomerAndSession.and.returnValue(of({ customer: { customerId: 123 }, session: {} }));
    mockUserCartService.updateCustomerInfoInAppService.and.returnValues(of({ customer: { customerId: 123 }, session: {} }));
    const createAccountBtn = fixture.debugElement.query(By.css('#btn-create-account')).nativeElement;
    setInputValue('#guestExistingUserEmail', 'test@legalzoom.com');
    setInputValue('#password', 'testPass');
    createAccountBtn.click();
    expect(mockWebSessionService.convertGuestToCustomerAndSession).toHaveBeenCalled();
  });

  it('signIn method should signIn', () => {
    mockWebSessionService.loginCustomerAndSession.and.returnValue(of({ customer: { customerId: 123 }, session: {} }));
    mockUserCartService.updateCartAndProcessingOrderByCustomerId.and.returnValue(of({ customer: { customerId: 123 }, session: {} }));
    component.form.controls.email.setValue('test@test.com');
    component.form.controls.email.markAsDirty();
    component.form.controls.email.markAsTouched();
    component.form.controls.password.setValue('testPAss');
    component.form.controls.password.markAsDirty();
    component.form.controls.password.markAsTouched();
    component.signIn();
    expect(mockWebSessionService.loginCustomerAndSession).toHaveBeenCalled();
  });

  it('forgotPassword method should call customer service forgot password method', () => {
    mockCustomerService.forgetPassword.and.returnValue(of({ requestPasswordMessage: { status: 5, message: '' } }));
    mockUserCartService.updateCartAndProcessingOrderByCustomerId.and.returnValue(of({ customer: { customerId: 123 }, session: {} }));
    component.form.controls.email.setValue('test@test.com');
    component.form.controls.email.markAsDirty();
    component.form.controls.email.markAsTouched();
    component.form.controls.password.setValue('testPAss');
    component.form.controls.password.markAsDirty();
    component.form.controls.password.markAsTouched();
    component.forgotPassword();
    expect(mockCustomerService.forgetPassword).toHaveBeenCalled();
  });

  function setInputValue(selector: string, value: string) {
    fixture.detectChanges();
    const input = fixture.debugElement.query(By.css(selector)).nativeElement;
    input.value = value;
    input.dispatchEvent(new Event('input'));
    fixture.whenStable().then(() => {
      fixture.detectChanges();
    });
  }
});
