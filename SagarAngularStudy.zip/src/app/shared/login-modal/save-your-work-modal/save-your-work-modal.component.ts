import { HttpResponse } from '@angular/common/http';
import { Component, OnInit, ViewChild, ElementRef, Renderer2, OnDestroy } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Subject } from 'rxjs';
import { ValidateEmail } from '../../validators/form-control.validator';
import { SEADService } from '../../services/tracking/sead.service';
import { WindowRef } from '../../services/windowRef.service';
import { HeaderDialogFormType } from '../../models/dialog-model';
import {
  LoginCustomerAndSessionRequest, LoginCustomerAndSessionResponse, ConvertGuestToCustomerAndSessionRequest, ConvertGuestToCustomerAndSessionResponse, ForgetPasswordRequest, RequestPasswordDto, OrderType,
  ForgetPasswordResponse
} from '@legalzoom/web-session-sdk';
import { UserCartService } from '../../../../app/pl-features/glo-design/shared/services/user-cart.service';
import { AppService } from '../../state/app';
import { WebSessionService } from '@legalzoom/web-session-sdk';
import { CustomerService } from '@legalzoom/customer-sdk';
import { UtilitiesService } from '@legalzoom/business-formation-sdk';
import { SessionStorageType } from './../../services/tracking/session-storage';
import { PrepareCartService } from './../../services/prepare-cart.service';
@Component({
  selector: 'app-desktop-save-your-work-modal',
  templateUrl: './save-your-work-modal.component.html',
  styleUrls: ['./save-your-work-modal.component.scss']
})
export class SaveYourWorkModalComponent implements OnInit, OnDestroy {
  public formTypeEnum: any = HeaderDialogFormType;
  public currentFormType: HeaderDialogFormType = HeaderDialogFormType.SaveYourWork;
  public form: FormGroup;
  public accountProcessingError = '';
  public forgotPasswordMessage = 'You will receive an email with instructions to reset your password. '
    + 'If you don\'t receive this email within 15 minutes, check your junk mail and spam folders. '
    + 'If you still have problems, call our customer care team at (800)773-0888 M-F from 6 a.m.-7p.m. PT.';
  public isLoading: boolean;
  public isPasswordVisible = false;
  @ViewChild('password', { static: false }) passwordRef: ElementRef;
  private unsubscribe: Subject<void> = new Subject();

  constructor(
    private fb: FormBuilder,
    public activeModal: NgbActiveModal,
    private renderer: Renderer2,
    private seadService: SEADService,
    private windowRef: WindowRef,
    private websessionService: WebSessionService,
    private userCartService: UserCartService,
    private appService: AppService,
    private customerService: CustomerService,
    private utilitiesService: UtilitiesService,
    private prepareCartService: PrepareCartService
  ) { }

  ngOnInit() {
    const nativeWin = this.windowRef.nativeWindow;
    this.createForm();
    if (nativeWin.LZWebsite && nativeWin.LZWebsite.attribution) {
      nativeWin.LZWebsite.attribution.UUIDTasks.setBlurListener();
    }
  }

  createForm() {
    this.form = this.fb.group({
      email: ['', [Validators.required, ValidateEmail]],
      password: ['', Validators.required]
    });
  }

  changeFormType(formType: number): void {
    if (this.currentFormType !== this.formTypeEnum.ForgotPassword) {
      // clear error message
      this.accountProcessingError = '';
    }

    this.markFieldsClean();
    this.currentFormType = formType;

    // may need to change this to subscribe to currentFormType if we plan to use this modal with an input form type
    if (formType === this.formTypeEnum.ForgotPassword) {
      // remove password validation
      this.form.controls.password.clearValidators();
      this.form.controls.password.updateValueAndValidity();
    } else {
      this.form.controls.password.setValidators([Validators.required]);
      this.form.controls.password.updateValueAndValidity();
    }
  }

  togglePasswordVisibility(): void {
    const inputType = this.passwordRef.nativeElement.getAttribute('type') === 'password' ? 'text' : 'password';
    this.renderer.setAttribute(this.passwordRef.nativeElement, 'type', inputType);
    this.isPasswordVisible = inputType === 'password' ? false : true;
  }

  signIn(): void {
    this.markFieldsDirty();

    if (this.form.invalid) {
      return;
    }

    this.isLoading = true;
    this.accountProcessingError = '';

    const request = new LoginCustomerAndSessionRequest();
    request.emailId = this.form.get('email').value;
    request.password = this.form.get('password').value;

    this.websessionService.loginCustomerAndSession(request).subscribe((res: LoginCustomerAndSessionResponse) => {
      if (res.customer) {
        const nativeWin = this.windowRef.nativeWindow;
        if (nativeWin.LZWebsite && nativeWin.LZWebsite.attribution) {
          nativeWin.LZWebsite.attribution.UUIDTasks.getUUID(request.emailId);
        }
        this.userCartService.updateCartAndProcessingOrderByCustomerId(this.appService.app.customerId, res.customer.customerId, res)
          .subscribe((result: LoginCustomerAndSessionResponse) => {
            this.prepareCartService.saveAndRefreshCart();
            this.activeModal.close({ Response: 'Success', newAccountCreated: false, ...res });
          });
      } else {
        this.accountProcessingError = 'You entered an incorrect email and/or password.';
      }
    }, err => {
      this.accountProcessingError = 'You entered an incorrect email and/or password.';
    });
  }

  createMyAccount(): void {
    this.seadService.TrackingObject.user_fname = 'LegalZoom';
    this.seadService.TrackingObject.user_lname = 'Customer';
    this.seadService.PushToTealium();
    this.markFieldsDirty();

    if (this.form.invalid) {
      return;
    }

    this.isLoading = true;
    this.accountProcessingError = '';

    this.customerService.getCustomerInfo(this.form.get('email').value, this.appService.customerId).subscribe(res => {
      if (res.isCustomerExists) {
        this.changeFormType(this.formTypeEnum.Login);
        this.form.controls.password.setValue('');
        this.isLoading = false;
      } else {
        const request = new ConvertGuestToCustomerAndSessionRequest();
        request.emailId = this.form.get('email').value;
        request.password = this.form.get('password').value;
        request.customerId = this.appService.customerId;

        this.websessionService.convertGuestToCustomerAndSession(request).subscribe(
          // tslint:disable-next-line: no-shadowed-variable
          (res: ConvertGuestToCustomerAndSessionResponse) => {
            this.userCartService.updateCustomerInfoInAppService(res).subscribe((result: LoginCustomerAndSessionResponse) => {
              this.isLoading = false;
              this.activeModal.close({ Response: 'Success', newAccountCreated: true, ...res });
            });
            this.isLoading = false;
          }, err => {
            console.log(err);
            this.isLoading = false;
            if (err.error.errors && err.error.errors.findIndex(x => x.code === 'session_data_not_deleted_convert_guest') > -1) {
              // user is existing user
              this.changeFormType(this.formTypeEnum.Login);
              this.form.controls.password.setValue('');
            }
          }
        );
      }
    }, err => {
      this.isLoading = false;
    });
  }

  openForm(selectedFormType: HeaderDialogFormType): void {
    this.currentFormType = selectedFormType;
  }

  gotoHomePage(): void {
    this.utilitiesService.clearUserSession(true, SessionStorageType.APP);
    this.windowRef.nativeWindow.location.href = '/';
  }

  forgotPassword(): void {
    this.markFieldsDirty();

    if (this.form.invalid) {
      return;
    }

    this.isLoading = true;

    const request = new ForgetPasswordRequest();
    request.requestPassword = new RequestPasswordDto();
    request.requestPassword.email = this.form.get('email').value;
    request.requestPassword.orderType = OrderType.LegalZoom;

    this.customerService.forgetPassword(request).subscribe(
      (res: ForgetPasswordResponse) => {
        // send reset password link and redirect to signin view with email address
        this.accountProcessingError = this.forgotPasswordMessage;
        this.changeFormType(this.formTypeEnum.Login);
        this.isLoading = false;
      }, err => {
        this.changeFormType(this.formTypeEnum.Login);
        this.isLoading = false;
      }
    );
  }

  private markFieldsDirty(): void {
    // enables angular visible validation
    this.form.controls.email.markAsTouched();
    this.form.controls.email.markAsDirty();
    this.form.controls.password.markAsTouched();
    this.form.controls.password.markAsDirty();
  }

  private markFieldsClean(): void {
    this.form.controls.email.markAsPristine();
    this.form.controls.password.markAsPristine();
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}
