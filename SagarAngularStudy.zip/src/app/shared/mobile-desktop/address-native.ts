import { FormGroup } from '@angular/forms';
import { IAutocompleteAddress, AddressAutocompleteService } from '@legalzoom/address-autocomplete-sdk';
import { Observable, merge, timer, of, Subject } from 'rxjs';
import { debounce, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { isString, isNullOrUndefined } from 'util';

export interface SearchSubject {
  search: string, 
  selected: string
}

export function handleSelected(address: IAutocompleteAddress, 
  addressForm : FormGroup, 
  searchSubject$: Subject<SearchSubject>, 
  callback = () => null) : void
  {
    // This window.setTimeout is necessary to allow for the default behavior of ngbootstrap's "selectedAddress"
    // to complete before we execute a more accurate search.
    // When the user clicks on a suggestion in the form of "100 Congress Ave Apt (39 entries) Bath, ME 04530"
    // we then run a second search to get all the "39 entries" and show those as the suggestions.

    if(!address) {
      return;
    }

    window.setTimeout(()=>  {
      if (address.entries > 1) {
        // initiate deeper search
        searchSubject$.next({
          search: addressForm.controls.address1.value,
          selected: formatSelectedParameter(address)
        });
      } else {
        setAddress(address, addressForm)
        callback();
      }
   }, 0)
}

export function setAddress(address: IAutocompleteAddress, addressForm : FormGroup): void {
  if (!address) {
    return;
  }

  addressForm.controls.address1.setValue(getAddressLine1Helper(address));

  if (address.secondary) {
    addressForm.controls.address2.setValue(address.secondary);
  } else if (address.address2) {
    addressForm.controls.address2.setValue(address.address2);
  } else {
    addressForm.controls.address2.setValue("");
  }
 
  addressForm.controls.city.setValue(address.city);
  addressForm.controls.county.setValue('');
  addressForm.controls.state.setValue(address.state);

  if(address.zipcode){
    addressForm.controls.zipCode.setValue(address.zipcode);
  } else if (address.zipCode) {
    addressForm.controls.zipCode.setValue(address.zipCode);
  } else {
    addressForm.controls.zipCode.setValue("");
  }
}

export function getAddressLine1Helper(address: any): string  { 
  if(!address){
    return;
  }

  return address.streetLine ?
  address.streetLine : ((address.address1 !== null && typeof(address.address1) === 'object') ?
    address.address1.streetLine : (address.address1 || (typeof(address) === 'string' ? address : '')))
  }

export function formatSelectedParameter(address: IAutocompleteAddress): string {
  if (!address) {
    return;
  }
  // format for 'selected' param as: street_line secondary (entries) city state zipcode
  return address.streetLine + ' ' + address.secondary + ' (' + address.entries + ') ' + address.city + ' ' + address.state + ' ' + address.zipcode;
}

export function formatAutoCompleteSuggestion(address: IAutocompleteAddress): string {
  if (!address) {
    return;
  }

  let returnString = address.streetLine + ' ';
  if (address.secondary) {
    if (address.entries > 1) {
      returnString += address.secondary + ' (' + address.entries + ' entries) ';
    } else {
      returnString += address.secondary + ' ';
    }
  }
  return returnString + address.city + ', ' + address.state + ' ' + address.zipcode;
}

export function autocompeteSearch(text$: Observable<string>, 
  sbjct$: Subject<SearchSubject>, 
  autocompleteService: AddressAutocompleteService): Observable<IAutocompleteAddress | null[]> 
  {
  return merge(text$, sbjct$).pipe(
    debounce((term) => (isString(term) ? timer(350) : timer(0))),
    distinctUntilChanged(),
    switchMap((term) => {
      if (isString(term)) {
        return autocompleteService.getAddressSuggestions(term);
      } else if (!isNullOrUndefined(term) && 'selected' in term && 'search' in term) {
        return autocompleteService.getAddressSuggestions(term.search, term.selected);
      } else {
        return of([]);
      }
    })
  );
}