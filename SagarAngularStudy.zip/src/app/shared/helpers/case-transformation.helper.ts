export class CaseTransformationHelper {

    public static romanNumberFormat(value: string): string {
        return value.toUpperCase();
    }

    public static titleCaseFormat(value: string): string {
        let out = new Array<string>();
        out = value.toLowerCase().split('');
        out[0] = out[0] !== undefined ? out[0].toUpperCase() : '';
        return out.join('');
    }

}
