export enum CookieName {
    USERIDENTIFICATION = 'LZUserIdentification',
    TIMESTRING1 = 'TIMESTRING',
    ACTIVESESSION = 'ActiveSession',
    LZ_LLC_HOLISTIC_FLOW_V3 = 'LZ_LLC_HOLISTIC_FLOW_V3',

}
export enum ProductName {
    LLC = 'llc',
    TM = 'tm',
    LWT = 'lwt'
}
