export enum TrackingAmplitudeEventLabel {

    //LLC Onboarding
    Create_Password_Open = 'view create password',
    Create_Password = 'password created',
    Create_Password_Error = 'create password system error',
    
    // NameCheck Screen
    Namecheck_Open = 'view q2',
    Namecheck_Modal = 'view modal',
    Namecheck_Modal_Call = 'call now',
    Namecheck_Modal_Tryagain = 'launch go back and try again',
    Namecheck_Modal_Continue = 'continue with this name anyway',
    
    // File My LLC
    Q2_Complete = 'complete q2'
  }
  