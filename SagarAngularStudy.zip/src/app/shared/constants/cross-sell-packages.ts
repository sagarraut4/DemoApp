export enum CrossSellPackages {
  lwt = 'express-lwt',
  tms = 'express-tms',
  both = 'express-both'
}

export enum PartnerOffer {
  bofa = 'bofa',
  square = 'square'
}
