export enum TrackingAmplitudeEventProperties {
  BusinessHours = 'during business hours',
  ModalNumber = 'modal number',
  BusinessType = 'business type',
  ProductName = 'product name',
  CartValue= 'cart value',
  Upsells = 'upsells',
  CrossSell = 'cross sell',
  Package = 'package',
  FilingFee = 'filing fee',
  Subscriptions = 'subscriptions',
  PaymentType = 'payment type',
  RawCart = 'raw cart',
  OrderId = 'order id',
  ParentOrderId = 'parent order id',
  ProductCategory = 'product category',
  ProductSubcategory = 'product subcategory',
  Product = 'product',
  PaymentPlan = 'payment plan',
  PackageId = 'package id',
  CartItems = 'cart items'

}

export enum TrackingAmplitudeEventPropertyProduct {
  LLC = 'llc',
  SMB = 'smb',
  BusinessFormation = 'business formation'

}
