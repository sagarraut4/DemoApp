import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'formatPhone'})
/*
 * Converts a phone number to another format
 * Usage:
 *   value | formatPhone:format(optional)
 * Example:
 *   {{ 3234450000 | formatPhone }}
 *   formats to: (323) 445-0000
*/
export class FormatPhonePipe implements PipeTransform {
  transform(value: string, format: string | 'link' = null): string {
    let finalFormat = format;
    switch (format) {
      case 'link':
        finalFormat = 'tel:+1$1-$2-$3';
        break;
      case null:
      case undefined:
        finalFormat = '($1) $2-$3';
        break;
    }
    return value.replace(/\D+/g, '').replace(/(\d{3})(\d{3})(\d{4})/, finalFormat);
  }
}
