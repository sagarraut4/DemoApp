export interface UserDetailResponse {
    TimeString: string;
    UserID: string;
    Response: string;
    ForgotPasswordLink: string;
    UserLoginID: string;
    IsGuestUser: string;
    ErrorMessage: string;
    uUID: string;
    FirstName: string;
    LastName: string;
    newAccountCreated: boolean;
}
