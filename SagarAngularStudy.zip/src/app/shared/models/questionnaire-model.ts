import { Address, Contact, Trust, Individual, BusinessEntity } from './address-model';
import { ExpressOrderResponse } from './express-order-model';
import { RegisteredAgent } from './registered-agent.model';

export class LLC {

  // @todo: decide if this should be implemented in a more elegant way
  public isMobile: boolean;
  public isMobileApp: boolean;

  public entityName: string;
  public entityNameDesignator: string;

  // tslint:disable-next-line: variable-name
  public currentView: string;
  public entityState: string;
  public isEntityStateSelected = false;
  public businessStartTime: string;
  public selling: string;

  public businessPurpose: string;
  public businessPurposeObject;
  public isRestaurant: boolean;
  public acceptCash: string;
  public obtainEIN: string;
  public isproffessionalbusiness: string;
  public howManyOwners: string;
  public ownersHaveAuthority: string;
  public documents: string;
  public taxAdvice: boolean;
  public legalAdvice: boolean;
  public employerTaxAdvice: boolean;
  public employerLegalAdvice: boolean;
  public compliance: boolean;
  public package: string;
  public lzRA: string;
  public optInGSuite: boolean;
  public gsuitePackageType: string;
  public gsuiteNumSeats: number;
  public documentsPackage: string;
  public raDetails: RegisteredAgent;
  // TODO: This is temp for now
  public tradeName: string;
  public taxAndLegalAdvice: boolean;
  public protectPersonalAssets: boolean;
  public bofa: boolean;
  public squarePartnerOffer: boolean;
  public brexPartnerOffer: boolean;
  public toastPartnerOffer: boolean;
  public bofaShown: boolean;
  public squarePartnerOfferShown: boolean;
  public brexPartnerOfferShown: boolean;
  public toastPartnerOfferShown: boolean;
  public totalCompliance: boolean;
  public maxPage: number;
  public lastPage: number;
  public isBusinessNameAvailable = true;
  public affordableTax: boolean;
  public employeeManangement: boolean;
  public upsellOffer: string; // tm and ep offer
  public alternateName: string;
  public alternateNameDesignator: string;
  public businessNameExplanation: string;
  public businessAddress: Address;
  public businessPhone: string;
  public businessEmail: string;
  public contactPhone: string;
  public hireEmployees: string; // TODO: Hari why is this a string
  public isFirstLLC: boolean;
  public businessPurposeDescription: string;
  public isProfessional: boolean;
  public naicsCode: number;
  public dissolveDate: string;
  public willAutoDisolve: boolean;
  public owners: Contact[];
  public individualOwners: Individual[];
  public businessEntityOwners: BusinessEntity[];
  public trustOwners: Trust[];
  public managers: Contact[];
  public whoAreManagers: string;
  public areOwnersMarried: boolean;
  public ruleRegardingOwnership: string;
  public endFiscalYrMonth: string;
  public endFiscalYrDay: string;
  public doingBusinessAs: boolean;
  public dbaName: string;
  public complimentaryConsultation: boolean;
  public adp: boolean;
  public accountant1800: boolean;
  public bBookKeepingOffer: boolean;
  public bDelayLLCCA: boolean;
  public mylo: boolean;
  public bofaCardOffer: boolean;
  public isProfessionalLLC: boolean;
  public pllcDesignator: string;
  public industryOrProfession: string;
  public pllcAcknowledgement: boolean;
  public packageSelected: number;
  public classification: string;
  public ownershipDivision: string;
  public willSellExciseTaxGoods: boolean;
  public willOwnTransportVehicle: boolean;
  public willGamble: boolean;
  public willSellAlcohol: boolean;
  public irsContact: Contact;
  public bizLicenseOffer: boolean;
  public alreadyHaveEIN: boolean;
  public existingEinNumber: string;
  public is3Pay: boolean;
  public taxationTypeChoice: string;
  public isLaborJudgment: boolean;

  public numberOfAgriculturalEmployees: number;
  public numberOfHouseholdEmployees: number;
  public numberOfEmployees: number;
  public willhaveAgriculturalEmployees: boolean;
  public startEmpPayDate: string;
  public willPayEmpOverThreshold: boolean;

  public orderId: number;
  public checkoutEmail: string;
  public bShowPriceTest: string;
  public bShowPriceTest1: string;
  public bFunnelTest: string;
  public bFunnelTest1: string;
  public customerPhoneNumber: string;
  public customerEmail: string;
  public professionalPrintSelected = false;
  public isChooseEntityNameLater: boolean;
  public isExpedite: boolean;
  public isStateTaxReg: boolean;
  public isLZStateTaxId: boolean;
  public isLZSellersPermit: boolean;

  public LWTExpressOrderResponse: ExpressOrderResponse;
  public TMSExpressOrderResponse: ExpressOrderResponse;
  public GSuiteOrderResponse: ExpressOrderResponse;
  public isBusinessName: boolean;
  public taxPackageSelected: number;
  public isSimilarNameRiskAccepted: boolean;
  public isConditionalNameRiskAccepted:boolean;
  public isBizAddressValidated:boolean;
  constructor() {
    this.businessAddress = new Address();
    this.raDetails = new RegisteredAgent();
    this.irsContact = new Contact();
  }
}

export class QuestionnaireStorage {
  public UserOrderId: number;
  public Answers: string;
}