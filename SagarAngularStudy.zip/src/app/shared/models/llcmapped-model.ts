/**
 * FieldAnswer Object
 */
export interface FieldAnswer {
  fieldName: string;
  fieldValue: string;
}

/**
 * GroupFieldAnswer Object
 */
export interface GroupFieldAnswer {
  cellName: string;
  value: string;
}

/**
 * GroupAnswer Object
 */
export interface GroupAnswer {
  groupName: string;
  fieldName: string;
  fieldValue: string;
}

export class LLCMapped {
  public userOrderId: number;
  public fieldAnswers: Array<FieldAnswer> = []; // Array of FieldAnswer
  public groupAnswerCollections: Array<GroupAnswer> = [];
  constructor() {
  }
}
