import { TrackingAmplitudeEventLabel } from '../constants/tracking-amplitude-event-label.enum';

export class OCMOrder {
  public OrderTestCheck: OrderTestCheck;
  public iProcess: number;
  public iQuestionnaire: number;
  public sRevision: number;
  public sPage: string;
  public sUserOrderID: number;
  public sReopen: number;
}

export class OrderTestCheck {
  public sCheckType: string;
  public sCheckValue: string;
}

export interface TrackingData {
  Amplitude?: TrackingAmplitudeData | TrackingAmplitudePuchaseData ;
}

export interface TrackingAmplitudeData {
  label: TrackingAmplitudeEventLabel;
  properties?: TrackingAmplitudeEventProperties;
}

export interface TrackingAmplitudePuchaseData {
  name: string;
  price: number;
  type: string;
  quantity: number;
  properties?: TrackingAmplitudeEventProperties;
}

export interface AmplitudeCartItems {
  'package name': string;
  type: string;
  amount: number;
  'package id': number;
  quantity: number;
}

export interface TrackingAmplitudeEventProperties {
  // The Key's should be from this enum: TrackingAmplitudeEventProperties
  'during business hours'?: boolean;
  'modal number'?: number;
  'business type'?: string;
  'product name'?: string;
  'cart value'?: number;
  'upsells'?: any;
  'cross sell'?: any;
  'package'?: string;
  'filing fee'?: number;
  'subscriptions'?: any;
  'payment type'?: string;
  'order id'?: any;
  'parent order id'?: number;
  'product category'?: string;
  'product subcategory'?: string;
  'product'?: string;
  'payment plan'?: string;
  'package id'?: any;
  'cart items'?: any;
  'raw cart'?: object;
}

export interface TrackingPayloadData<T = string | string[] | number | number[]> {
  [key: string]: T;
}

export interface TrackingPayloadAmplitudeEvent {
  amplitude_event_label: string;
  amplitude_event_properties?: TrackingAmplitudeEventProperties;
}

export interface TrackingPayloadAmplitudeUser {
  amplitude_user_properties: TrackingPayloadData;
  amplitude_user_properties_setOnce: TrackingPayloadData;
}
export interface TrackingPayloadAmplitudePurchaseEvent {
  amplitude_purchase_name: string;
  amplitude_purchase_price: number;
  amplitude_purchase_type: string;
  amplitude_purchase_quantity: number;
  amplitude_purchase_properties?: TrackingAmplitudeEventProperties;
}

export type TrackingPayload = TrackingPayloadAmplitudeEvent | TrackingPayloadAmplitudeUser | TrackingPayloadAmplitudePurchaseEvent;

export interface TrackingPageView {
  [key: string]: TrackingPageViewData;
}

export interface TrackingPageViewData {
  Amplitude: TrackingAmplitudeEventLabel;
}
