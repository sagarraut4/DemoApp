export enum HeaderDialogFormType {
  SaveYourWork,
  Login,
  ForgotPassword,
  LZLogoSaveYourProgress,
  SignInExistingUser
}
