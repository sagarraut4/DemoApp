export class Included {
    title: string;
    description: string;
    economy: boolean;
    standard: boolean;
    expressGold: boolean;
}

export const PACKAGEINCLUDES: Included[] = [
  {
    title: 'LLC Next Steps Guide',
    description: 'We include step-by-step instructions to review your LLC documents and get your business started.',
    economy: true,
    standard: true,
    expressGold: true
  },
  {
    title: 'Peace of Mind Review ™',
    description: 'We conduct a personal review of your order before your business is formed.',
    economy: true,
    standard: true,
    expressGold: true
  },
  {
    title: 'Lifetime Customer Support',
    description: 'Our team is available 7 days a week to answer questions about your new business documents, personalized packet, and related products and services.',
    economy: true,
    standard: true,
    expressGold: true
  },
  {
    title: 'Financial Account Authorization Letter',
    description: 'A document provided indicating who is authorized to open a bank account for the LLC.',
    economy: true,
    standard: true,
    expressGold: true
  },
  {
    title: 'Deluxe Organizer',
    description: 'Our organizer is embossed with the name of your business.',
    economy: false,
    standard: true,
    expressGold: true
  },
  {
    title: 'Official Certificates and Seal',
    description: 'We include 20 personalized company membership certificates and an official company seal to record ownership in your business.',
    economy: false,
    standard: true,
    expressGold: true
  },
  {
    title: 'LegalZoom VIP Processing',
    description: 'We prioritize your order internally to ensure faster processing.',
    economy: false,
    standard: true,
    expressGold: true
  },
  {
    title: 'Rush Processing With Secretary of State',
    description: 'If you select Express Gold, we prioritize your order and rush our process to complete it within 7-10 business days.',
    economy: false,
    standard: false,
    expressGold: true
  },
  {
    title: 'Express shipping',
    description: 'Express shipping - fastest delivery.',
    economy: false,
    standard: false,
    expressGold: true
  }
];
