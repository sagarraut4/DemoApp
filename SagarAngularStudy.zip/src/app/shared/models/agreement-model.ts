export interface LegalAgreementInfo {
    entityProcessingOrderId: number;
    entityOrderId: number;
    orderId: number;
    processingOrderId: number;
    givenYear: number;
    productId: number;
}

export interface Agreement {
    agreementId: number;
    contentType: string;
    entityOrderId:number;
    productId:number;
    acceptStatus:string
    orders:order[];
}
export interface order
    {
        agreementId: number,
        orderId: number,
        processingOrderId: number,
        productId: number,
        active: boolean,
        productType: string
    }

export interface Agreements {
    agreements: Agreement[];
}

export interface AgreementRequest {
    acceptStatus: AgreementStatus;
    ipAddress: string;
    firstName: string;
    middleInitial: string;
    lastName: string;
    acceptedDate: string;
    contentVersion: number;
}

export enum AgreementStatus {
    Pending = 'Pending',
    Accepted = 'Accepted',
    Decline = 'Declined'
}