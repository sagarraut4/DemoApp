export class BusinessNameRule {
     state: string;
     stateCode: string;
     isCharacterLimit:boolean;
     charaterLength?:number;
     isAccentCharAllow:boolean;
     isAllCharacterAllow:boolean;
     reStrictedChar:string[];
     isDesignatorAllow:boolean;
     allowedCharRegex:string
     allowedCharMssg:string
     allowedAccentedCharRegex:string
     constructor() {

     }
}
export interface IEntityErrorReasons {
     errorFromInputValue:boolean;
     errorsFromReasons:string;
     errorType:string;
     issueDetails:string;      
}