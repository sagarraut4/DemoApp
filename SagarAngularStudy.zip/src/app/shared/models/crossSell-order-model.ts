export class CrossSellOrder {
    orderId: number;
    orderItemId: number;
    processingOrderId: number;
    productName: string;
    productConfigurationId: number;
    amount: number;
    shippingOrderContactId: number;
    billingOrderContactId: number;
    primaryOrderContactId: number;
    paymentResponseStatus: number;
  }
  