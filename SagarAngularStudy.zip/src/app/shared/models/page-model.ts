export interface IPage {
  nextPage(): string;
  previousPage(): string;
}

export enum PagePath {
  BusinessState = 'state',
  ChangeName = 'change-name',
  NameAvailable = 'name-available',
  BusinessActivity = 'business-activity',
  BusinessStartTime = 'timeframe',
  BusinessStartTimeDetail = 'timeframe-confirm',
  AlreadyInBusiness = 'in-business', // deprecated page route
  LaunchingSoon = 'soon', // deprecated page route
  LaunchingInFuture = 'infuture', // deprecated page route
  FirstLlc = 'first-llc',
  BusinessPurpose = 'industry',
  BusinessPurposeDetail = 'industry-confirm',
  HireEmployees = 'hire-employees',
  HaveEmployees = 'employees', // deprecated page route
  EmployeesSoon = 'employees-soon', // deprecated page route
  EmployeesInFuture = 'employees-infuture', // deprecated page route
  HowManyOwners = 'owners-number',
  OwnersAuthority = 'owners-management',
  EssentialExtras = 'extras',
  RegisteredAgent = 'registered-agent',
  RegisteredAgent_old = 'ra', // deprecated page route
  CriticalDocuments = 'critical-docs',
  CriticalDocumentsB = 'critical-docs-b',
  CriticalDocuments_old = 'documents', // deprecated page route
  GSuitePackage = 'google-workspace-package',
  StateTax = 'state-tax-registration',
  Extras = 'extra-services',
  Tax = 'tax',
  Legal = 'legal',
  Compliance = 'compliance',
  Clientbooks = 'clientbooks',
  BofA = 'b-of-a-checking',
  Partners = 'partners',
  BofA_old = 'bofa', // deprecated page route
  PackageSelection = 'package-selection',
  PackageSelection_old = 'select', // deprecated page route
  PackageSelection2 = 'select-2',
  ReviewYourOrder = 'review-your-order',
  ReviewYourOrder_old = 'cart', // deprecated page route
  Checkout = 'checkout',
  Checkout_old = 'payment', // deprecated page route
  OrderConfirmation = 'order-confirmation',
  OrderLoading = 'order-loading',
  RemainingQuestions = 'remaining-questions',
  ExpressOffersPage = 'express-offers',
  BofaCardOffer = 'bofa-card-offer',
  PartnerOffers = 'partner-offers',
  OrderConfirmationRibbon = 'order-confirmation-ribbon',
  OrderConfirmationCongrats = 'order-confirmation-congratulations',
  CorpLandingPage = '/business/business-formation/inc-overview.html',
  LLCLandingPage = '/business/business-formation/llc-overview.html',
  BusinessLegalPlan = '/attorneys/legal-plans/business.html',
  ThankYou = 'payment-received',
  Overview = 'overview',
  MyAccount = '/lzweb/myaccount/',
  IQFlow = '/hft',
  IQFlowCheckout = '/hft/checkout?cartId=',
  CreatePassword = 'create-password'
}

export enum Chapter {
  Name = 'name',
  Business = 'business',
  Essentials = 'essentials',
  Services = 'services',
  Package = 'package',
  Checkout = 'checkout',
  PostOrder = 'order'
}
