
import { QuestionnaireStorage } from './questionnaire-model';
import { UserOrder } from './user-order-model';
import { OCMOrder } from './tracking-model';

export interface Cart {
  packageTitle: string;
  dueNow: number;
  discount: number;
  cartItems: CartItem[];
  installmentAmount: number;
  storeCredit: number;
}

export interface CartItem {
  productConfigurationId: number;
  type: CartItemType;
  title: string;
  description: string;
  details: CartItemDetails;
  amount: number;
  hideAmount: boolean;
}

export interface RankedCartItem extends CartItem {
  rank: number;
}

export interface CartItemDetails {
  intro: string;
  body: string;
}

export interface BillingItemsResponse {
  RootPackageItem: PackageItem;
  FilingFeeItems: PackageItem[];
  CrossSellAndAddOnItems: PackageItem[];
  AddOnItems: PackageItem[];
  CrossSellAndAddOnItemsSummary: PackageItem[];
  ShippingItems: PackageItem[];
  Prices: Prices;
}

export interface PackageItem {
  Name: string;
  BillingDisplayName: string;
  PurchaseLockDisplayName: string;
  Description: string;
  LongDescription: string;
  BillingDisplayOrder: number;
  PurchaseLockDisplayOrder: number;
  Amount: number;
  ProductComponentId: number;
  ProductConfigurationId: number;
  RelationshipTypeId: number;
  UserOrderId: number;
  ProcessingStatus: number;
  ProcessingStatusIndex: number;
  HasPrintingOption: boolean;
  StateId: number;
  StateName: string;
  QPageUrl: string;
}

export interface Prices {
  ThreePayAmounts: ThreePayAmounts;
  StoreCreditAmount: number;
  StoreCreditBalanceAmount: number;
  StoreCreditSubTotalAmount: number;
  DiscountAmount: number;
  BundleSavings: BundleSavings;
  TotalAmount: number;
  LawyerSavingsAmount: number;
  TaxAmount: number;
}

export interface ThreePayAmounts {
  FirstInstallmentAmount: number;
  SecondInstallmentAmount: number;
  ThirdInstallmentAmount: number;
  SecondInstallmentDueDate: string;
  ThirdInstallmentDueDate: string;
  TotalAmount: number;
}

export interface BundleSavings {
  SavingsAmount: number;
  SavingsPercentage: number;
  UnbundledPrice: number;
}

export interface SubscriptionCrosssellDetail {
  ProductComponentId: number;
  ProductConfigurationId: number;
  Name: string;
  PolicyDurationType: string;
  PolicyDuration: number;
  Amount: number;
  RenewalComponentDetails: RenewalComponentDetail[];
}

export interface RenewalComponentDetail {
  ProductComponentId: number;
  ProductConfigurationId: number;
  Name: string;
  PolicyDurationType: string;
  PolicyDuration: number;
  Amount: number;
  RenewalComponentDetails: string;
}

export interface DetailsResponse {
  PackageTitle: string;
  LineItems: BillingItemsResponse;
  Offer: any;
  Disclaimers: any;
  CartType: number;
  SubscriptionCrosssellDetails: any;
}

export enum CartItemType {
  RootPackage = 2,
  FilingFee = 8,
  CrossSellAndAddOn = 9,
  CrossSellAndAddOn_Offer = -9,
  AddOnItems = 3,
  AddOnItem_Offer = -3,
  ShippingItems = 7,
}

export enum ProductComponentId {
  operatingAgreement = 132,
  ein = 553,
  businessLicense = 493,
  economyLLCPackage = 111,
  standardLLCPackage = 112,
  expressGoldLLCPackage = 113,
  tier1LLCPackage = 2524,
  tier2LLCPackage = 2525,
  tier3LLCPackag = 2526,
  custom_Company = 0,
  custom_EntityName = -1,
  custom_OAEinBL = -6,
  custom_OAEinBL_NoThanks = -7,
  custom_RegisteredAgent_NoThanks = -8,
  custom_SalesTax = -5,
  custom_SalesTaxDetails = -6,
  custom_DigitalDownload2_details = -10,
  custom_ProfessionPrint = -11,
  custom_TotalCompliance = -12,
  custom_Affordable_Tax = -13,
  custom_LegalProtext_SmartEmployer = -14,
  custom_LegalProtext_SmartEmployer_WI = -15,
  custom_ItemSubTotal = -16,
  custom_FilingFee = -17,
  custom_Tax_Package = -18,
  tax_Prep_Essentials_Plan = 2949,
  accounting_Full_Service_Tax_Plan = 2953,
  accounting_Full_Service_Tax_Plan_Stand_Ready = 3015,
  tax_Prep_Essentials_Plan_annual = 3010,
  accounting_Full_Service_Tax_Plan_annual = 3008,
  accounting_Full_Service_Tax_Plan_annual_Stand_Ready = 3027,
  freemiumPremiumBAP = 2988
}

export enum ProductConfigurationIds {
  registeredAgent = 3476,
  registeredAgent_199 = 6281,
  registeredAgent_249 = 6286,
  essentialComplianceTaxPreparationPackage = 7198,
  bapAnnualTax = 6573, // 6255,
  bapMonthlyLegal = 7327, // 6805, // Smart Employer // now Legal Protect Plan
  bapMonthlyLegalWisconsin = 7330, // 6804,
  bapMonthlyLegalProtect = 7689, // 7328 for $39,
  bapMonthlyLegalProtectWisconsin = 7331, // 6802,
  economyLLCPackage = 145,
  standarLLCPackage = 146,
  expressGoldLLCPackage = 147,
  basicLLC= 7820,
  proLLC = 7846,
  attrAssistProLLC = 7847,
  attrAssistPremiumLLC = 7848,

  tier1LLCPackage = 6640,
  tier2LLCPackage = 6642,
  tier3LLCPackage = 6644,

  oAPackage = 5893,
  oAEinPackage = 4526,
  oAEinLicensesPackage = 3975,
  // compliancePackage = 6256,
  compliancePackage = 7198,
  compliancePackage_noThanks = -12,

  economyLLCShipping = 159,
  standardLLCShipping = 162,
  expressGoldLLCShipping = 171,

  economyLLCStateFilingFee = 803,
  standardLLCStateFilingFee = 804,
  goldExpressLLCStateFilingFee = 805,
  standardExpediteFilingFee = 4876,

  standardFilingFee = 6647,
  expediteFilingFee = 6646,

  statementOfInformation = 4384,
  statementOfInformationFilingFee = 3917,
  smallBusinessBankingConsultation = 2809,
  squarePartnerOffer = 7488,
  taxSavingAnalysisOffer = 6292,
  taxSavingAnalysisOffer2 = 7213,
  clientBooksOffer = 6296,
  priorityRushService = 4877,
  digitalDownload = 6553,
  digitalDownload2 = 6579,
  customLogoDesign = 6652,
  smartBusinessPlanCreator = 6653,
  // LZ Express offers - TMS and LWT config ids
  tmsCrosssell = 6076,
  tmsCrosssellFree = 6656,
  lwtCrosssell = 6075,
  // Q2 INIT Expedite/Standard Delivery config ids
  LLCTier1StandardShipping = 6641,

  LLCTier2ExpediteShipping = 6651,
  LLCTier3ExpediteShipping = 6649,

  LLCTier2DeliveryStandard = 6643,
  LLCTier3DeliveryStandard = 6650,

  processingExpedited = 1994,

  /* Custom config id's for display only */

  // bapAnnualTax_details_noThanks = -12,
  // compliancePackage_details = -3,
  // bapLegal_details = -4,
  salesTax = -5,
  salesTax_details = -6,
  processingStandard_details = -7,
  processingExpedited_details = -8,
  processingStandard = -9,
  digitalDownload2_details = -10,
  storageSubscription = 5793,
  custom_Company = 0,
  custom_EntityName = -1,
  custom_OAEinBL = -2,
  custom_OAEinBL_NoThanks = -4,
  oAEinPackage1 = 4531,
  oAEinPackage2 = 4532,
  oAEinLicensesPackage1 = 6342,
  custom_RegisteredAgent_details = -11,
  custom_Total_Compliance = -12,
  custom_Affordable_Tax = -13,
  custom_LegalProtext_SmartEmployer = -14,
  custom_LegalProtext_SmartEmployer_WI = -15,
  custom_ItemSubTotal = -16,
  custom_FilingFee = -17,
  custom_Tax_Package = -18,
  tax_Prep_Essentials_Plan = 7684,
  accounting_Full_Service_Tax_Plan = 7685,
  accounting_Full_Service_Tax_Plan_Stand_Ready = 8044,
  tax_Prep_Essentials_Plan_annual = 8010,
  accounting_Full_Service_Tax_Plan_annual = 8011, 
  accounting_Full_Service_Tax_Plan_annual_Stand_Ready = 8101,
  tax = 7381, 
  brexPartnerOffer = 7603,
  toastPartnerOffer = 7604,
}

export const CartItemsPkgIdDisplayOrder: number[] = [
  ProductConfigurationIds.custom_Company,
  ProductConfigurationIds.economyLLCPackage,
  ProductConfigurationIds.standarLLCPackage,
  ProductConfigurationIds.expressGoldLLCPackage,
  ProductConfigurationIds.economyLLCStateFilingFee,
  ProductConfigurationIds.economyLLCShipping,
  ProductConfigurationIds.standardLLCStateFilingFee,
  ProductConfigurationIds.standardExpediteFilingFee,
  ProductConfigurationIds.goldExpressLLCStateFilingFee,
  ProductConfigurationIds.tier1LLCPackage,
  ProductConfigurationIds.tier2LLCPackage,
  ProductConfigurationIds.tier3LLCPackage,
  ProductConfigurationIds.standardFilingFee,
  ProductConfigurationIds.expediteFilingFee,
  ProductConfigurationIds.oAPackage,
  ProductConfigurationIds.custom_OAEinBL,
  ProductConfigurationIds.custom_OAEinBL_NoThanks,
  ProductConfigurationIds.registeredAgent,
  ProductConfigurationIds.registeredAgent_199,
  ProductConfigurationIds.registeredAgent_249,
  ProductConfigurationIds.custom_RegisteredAgent_details,

  ProductConfigurationIds.essentialComplianceTaxPreparationPackage,
  ProductConfigurationIds.custom_Total_Compliance,
  ProductConfigurationIds.statementOfInformationFilingFee,

  ProductConfigurationIds.custom_Tax_Package,
  ProductConfigurationIds.accounting_Full_Service_Tax_Plan,
  ProductConfigurationIds.tax_Prep_Essentials_Plan,

  ProductConfigurationIds.bapAnnualTax,
  ProductConfigurationIds.bapMonthlyLegal,
  ProductConfigurationIds.bapMonthlyLegalProtect,
  ProductConfigurationIds.bapMonthlyLegalWisconsin,
  ProductConfigurationIds.bapMonthlyLegalProtectWisconsin,
  ProductConfigurationIds.custom_LegalProtext_SmartEmployer,
  ProductConfigurationIds.custom_LegalProtext_SmartEmployer_WI,

  ProductConfigurationIds.processingStandard,
  ProductConfigurationIds.processingStandard_details,
  ProductConfigurationIds.processingExpedited,
  ProductConfigurationIds.processingExpedited_details,
  ProductConfigurationIds.salesTax,
  ProductConfigurationIds.salesTax_details,
  ProductConfigurationIds.digitalDownload,
  ProductConfigurationIds.digitalDownload2,
  ProductConfigurationIds.digitalDownload2_details,
  // added hidden config id's to push them to the end of the array since subitems are required to follow parent line item
  ProductConfigurationIds.standardLLCShipping,
  ProductConfigurationIds.expressGoldLLCShipping,
  ProductConfigurationIds.statementOfInformation,
  ProductConfigurationIds.smallBusinessBankingConsultation,
  ProductConfigurationIds.squarePartnerOffer,
  ProductConfigurationIds.taxSavingAnalysisOffer,
  ProductConfigurationIds.clientBooksOffer,
  ProductConfigurationIds.custom_ItemSubTotal,
  ProductConfigurationIds.salesTax,
  ProductConfigurationIds.custom_FilingFee,
  ProductConfigurationIds.economyLLCStateFilingFee,
  ProductConfigurationIds.standardLLCStateFilingFee,
  ProductConfigurationIds.standardExpediteFilingFee,
  ProductConfigurationIds.goldExpressLLCStateFilingFee,
];

export const CustomFilingFeeIncludes: number[] = [
  ProductConfigurationIds.economyLLCStateFilingFee,
  ProductConfigurationIds.standardLLCStateFilingFee,
  ProductConfigurationIds.standardExpediteFilingFee,
  ProductConfigurationIds.goldExpressLLCStateFilingFee,
  ProductConfigurationIds.standardFilingFee,
  ProductConfigurationIds.expediteFilingFee,
  ProductConfigurationIds.statementOfInformationFilingFee
]

export const CustomItemSubTotalIncludes: number[] = [
  ProductConfigurationIds.economyLLCPackage,
  ProductConfigurationIds.standarLLCPackage,
  ProductConfigurationIds.expressGoldLLCPackage,
  ProductConfigurationIds.custom_OAEinBL,
  ProductConfigurationIds.economyLLCShipping
]

export const ComponentsToShowZeroAmount: number[] = [
  ProductConfigurationIds.custom_Company,
  ProductConfigurationIds.custom_EntityName,
  ProductConfigurationIds.custom_Total_Compliance,
  ProductConfigurationIds.custom_RegisteredAgent_details,
  ProductConfigurationIds.custom_LegalProtext_SmartEmployer,
  ProductConfigurationIds.custom_LegalProtext_SmartEmployer_WI
];

// tslint:disable-next-line: variable-name
export const Additional_CartItemDetails_Data = [
  {
    productConfigurationId: [ProductConfigurationIds.registeredAgent],
    cartItemDetails: {
      intro: '(No fees until documents sent to state)',
      body: 'LegalZoom\'s Registered Agent Service only starts when your LLC is submitted to state. '
        + 'When we receive official notification that your LLC has been registered, your card will automatically be charged $159. '
        + 'The service renews automatically each year, billed to your card, for the service price (currently $159). '
        + 'You may cancel online or by calling us at (844) 962-7490. You will first need to appoint a new RA for your business.'
    }
  },
  {
    productConfigurationId: [ProductConfigurationIds.registeredAgent_199],
    cartItemDetails: {
      intro: '(No fees until documents sent to state)',
      body: 'LegalZoom\'s Registered Agent Service only starts when your LLC is submitted to state. '
        + 'When we receive official notification that your LLC has been registered, your card will automatically be charged $199. '
        + 'The service renews automatically each year, billed to your card, for the service price (currently $199). '
        + 'You may cancel online or by calling us at (844) 962-7490. You will first need to appoint a new RA for your business.'
    }
  },
  {
    productConfigurationId: [ProductConfigurationIds.registeredAgent_249],
    cartItemDetails: {
      intro: '(No fees until documents sent to state)',
      body: 'LegalZoom\'s Registered Agent Service only starts when your LLC is submitted to state. '
        + 'When we receive official notification that your LLC has been registered, your card will automatically be charged $249. '
        + 'The service renews automatically each year, billed to your card, for the service price (currently $249). '
        + 'You may cancel online or by calling us at (844) 962-7490. You will first need to appoint a new RA for your business.'
    }
  },
  {
    productConfigurationId: [ProductConfigurationIds.essentialComplianceTaxPreparationPackage],
    cartItemDetails: {
      intro: '(10 days included)',
      body: 'This package is offered for 10 days. '
        + 'After the 10-day period, benefits continue automatically for the same term and rate unless otherwise notified. '
        + 'Cancel online or by calling (888) 310-0151. '
        + 'For full details, please see our <a href="http://www.legalzoom.com/legal/product-service-terms/supplemental-terms-of-service-for-advantage-subscriptions" target="_blank">Subscription Terms</a> '
        + 'and <a href="https://www.legalzoom.com/legal/product-service-terms/legal-plan-contract" target="_blank">Legal Plan Contract</a>.'
    }
  },
  {
    productConfigurationId: [ProductConfigurationIds.bapAnnualTax],
    cartItemDetails: {
      intro: '(10 days included)',
      body: 'This package is offered as a trial for 10 days. '
        + 'After the 10-day trial period, benefits continue automatically for the same term and rate unless otherwise notified. '
        + 'Cancel online or by calling (888) 310-0151. '
        + 'For full details, please see our <a href="http://www.legalzoom.com/legal/product-service-terms/supplemental-terms-of-service-for-advantage-subscriptions" target="_blank">Subscription Terms</a> '
        + 'and <a href="https://www.legalzoom.com/legal/product-service-terms/legal-plan-contract" target="_blank">Legal Plan Contract</a>.'
    }
  },
  {
    productConfigurationId: [ProductConfigurationIds.bapMonthlyLegal, ProductConfigurationIds.bapMonthlyLegalWisconsin],
    cartItemDetails: {
      intro: '(10 days included) ',
      body: 'This package is offered as a trial for 10 days. '
        + 'After the 10-day trial period, benefits continue automatically for the same term and rate unless otherwise notified. '
        + 'Cancel online or by calling (888) 310-0151. '
        + 'For full details, please see our <a href="http://www.legalzoom.com/legal/product-service-terms/supplemental-terms-of-service-for-advantage-subscriptions" target="_blank">Subscription Terms</a> '
        + 'and <a href="https://www.legalzoom.com/legal/product-service-terms/legal-plan-contract" target="_blank">Legal Plan Contract</a>.'
    }
  },
  // this below is only for testing the UI modals, please update as needed
  // per business rules and existing logic
  {
    productConfigurationId: [2400],
    cartItemDetails: {
      intro: 'Filing Fee',
      body: ''
    }
  },
  {
    productConfigurationId: [4529],
    cartItemDetails: {
      intro: '',
      body: ''
    }
  },
];

export class CartRequest {
  public processId: number;
  public userOrderId: number;
  public createGuestuser: boolean;
  public tagUserAs: string;
  public questionnaireStorage: QuestionnaireStorage;
}

export class CartResponse {
  public userOrder: UserOrder;
  public email: string;
  public error: string;
  public userId: number;
  public userOrderId: number;
  public timestring: string;

  public questionnaireStorage: QuestionnaireStorage;
  public isGuestUser: boolean;
}

export class AvailablePackageConfiguration {
  public BasePrice: number;
  public ExtendedPrice: number;
  public StateId: number;
  public ConfigurationID: number;
  public ComponentId: number;
  public ParentProductId: number;
  public BillingDisplayName: string;
  public FilingFee: string;
  public DisplayName: string;
}

export interface RankedAvailablePackageConfiguration extends AvailablePackageConfiguration {
  Rank: number;
}

export class AvailablePackageConfigurations {
  public lstAvailablePackageConfigurations: Array<AvailablePackageConfiguration>;
  public SelectedConfiguration: number;
}

export interface TaxAndLegalInfo {
  productConfigurationId: number;
  title: string;
  subTitle: string;
  description: string;
  modalText?: string;
}

export interface IUserCartItemContent {
  title: string;
  intro: string;
  body: string;
  isShowAmountText: boolean;
  amountText: string;
  isSelected: boolean;
  isAdded: boolean;
  subscriptionMessage: string;
}
