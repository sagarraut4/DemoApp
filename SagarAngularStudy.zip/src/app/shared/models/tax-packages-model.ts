import { CartItemType, ProductComponentId, ProductConfigurationIds } from './cart-model';

export const TaxPackages = [
  {
    productConfigurationId: ProductConfigurationIds.accounting_Full_Service_Tax_Plan,
    productComponentId: ProductComponentId.accounting_Full_Service_Tax_Plan,
    type: CartItemType.CrossSellAndAddOn,
    title: 'Full-Service Tax + Accounting Plan',
    amount: 159,
    description: '/month (annual plan, paid monthly)',
    terms: 'Annual plan, paid monthly. Billed separately.',
    confirmationDisclaimer: 'The Full-Service Tax + Accounting Plan is ' +
      'an annual plan, paid monthly ($159/month). It automatically renews ' +
      'each year, and you’ll be responsible for all 12 monthly payments. ' +
      'All payments will be billed to your card for the then-current service ' +
      'price, which is subject to change. You may cancel renewal of your ' +
      'subscription online or by calling us at (888) 310-0151.',
    subscriptionTerm: 'monthly',
    qboValue: 'true'
  },
  {
    productConfigurationId: ProductConfigurationIds.accounting_Full_Service_Tax_Plan_Stand_Ready,
    productComponentId: ProductComponentId.accounting_Full_Service_Tax_Plan_Stand_Ready,
    type: CartItemType.CrossSellAndAddOn,
    title: 'Full-Service Tax + Accounting Plan',
    amount: 159,
    description: '/month (annual plan, paid monthly)',
    terms: 'Annual plan, paid monthly. Billed separately.',
    confirmationDisclaimer: 'The Full-Service Tax + Accounting Plan is ' +
      'an annual plan, paid monthly ($159/month). It automatically renews ' +
      'each year, and you’ll be responsible for all 12 monthly payments. ' +
      'All payments will be billed to your card for the then-current service ' +
      'price, which is subject to change. You may cancel renewal of your ' +
      'subscription online or by calling us at (888) 310-0151.',
    subscriptionTerm: 'monthly',
    qboValue: 'true'
  },
  {
    productConfigurationId: ProductConfigurationIds.tax_Prep_Essentials_Plan,
    productComponentId: ProductComponentId.tax_Prep_Essentials_Plan,
    type: CartItemType.CrossSellAndAddOn,
    title: 'Tax Prep Essentials Plan',
    amount: 99,
    description: '/month (annual plan, paid monthly)',
    terms: 'Annual plan, paid monthly. Billed separately.',
    confirmationDisclaimer: 'The Tax Prep Essentials Plan is an annual plan, ' +
      'paid monthly ($99/month). It automatically renews each year, and you’ll ' +
      'be responsible for all 12 monthly payments. All payments will be billed ' +
      'to your card for the then-current service price, which is subject to ' +
      'change. You may cancel renewal of your subscription online or by calling ' +
      'us at (888) 310-0151.',
    subscriptionTerm: 'monthly',
    qboValue: 'false'
  },
  {
    productConfigurationId: ProductConfigurationIds.accounting_Full_Service_Tax_Plan_annual,
    productComponentId: ProductComponentId.accounting_Full_Service_Tax_Plan_annual,
    type: CartItemType.CrossSellAndAddOn,
    title: 'Full-Service Tax + Accounting Plan',
    amount: 1428,
    description: 'Annual plan, pre-paid ($1,428 /yr)',
    terms: '',
    confirmationDisclaimer: 'The Full-Service Tax + Accounting Plan is an annual plan, ' +
      'prepaid ($1,428/year). It automatically renews each year, and payment will be billed to your card ' +
      'for the then-current service price, which is subject to change. ' +
      'You may cancel renewal of your subscription online or by calling us at (888) 310-0151.',
    subscriptionTerm: 'annual',
    qboValue: 'true'
  },
  {
    productConfigurationId: ProductConfigurationIds.accounting_Full_Service_Tax_Plan_annual_Stand_Ready,
    productComponentId: ProductComponentId.accounting_Full_Service_Tax_Plan_annual_Stand_Ready,
    type: CartItemType.CrossSellAndAddOn,
    title: 'Full-Service Tax + Accounting Plan',
    amount: 1428,
    description: 'Annual plan, pre-paid ($1,428 /yr)',
    terms: '',
    confirmationDisclaimer: 'The Full-Service Tax + Accounting Plan is an annual plan, ' +
      'prepaid ($1,428/year). It automatically renews each year, and payment will be billed to your card ' +
      'for the then-current service price, which is subject to change. ' +
      'You may cancel renewal of your subscription online or by calling us at (888) 310-0151.',
    subscriptionTerm: 'annual',
    qboValue: 'true'
  },
  {
    productConfigurationId: ProductConfigurationIds.tax_Prep_Essentials_Plan_annual,
    productComponentId: ProductComponentId.tax_Prep_Essentials_Plan_annual,
    type: CartItemType.CrossSellAndAddOn,
    title: 'Tax Prep Essentials Plan',
    amount: 948,
    description: 'Annual plan, pre-paid ($948 /yr)',
    terms: '',
    confirmationDisclaimer: 'The Tax Prep Essentials Plan is an annual plan, ' +
      'prepaid ($948/year). It automatically renews each year, ' +
      'and payment will be billed to your card for the then-current service price, ' +
      'which is subject to change. You may cancel renewal of your subscription online or by calling us at (888) 310-0151.',
    subscriptionTerm: 'annual',
    qboValue: 'false'
  },
];
