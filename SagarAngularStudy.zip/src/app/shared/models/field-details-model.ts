export class FieldDetails {
  public fieldName: string;
  public isVisible = false;
  public isMandatory = false;
  public labelText = '';
  public labelTitle = '';
  public labelErrorMessage = '';
  public isDisable = false;
}
