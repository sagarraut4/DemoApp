export class Address {
  public address1: string;
  public address2: string;
  public city: string;
  public state: string;
  public county: string;
  public zipCode: string;
}


export class Contact {
  public title: string;
  public suffix: string;
  public fullName: string;
  public firstName: string;
  public middleName: string;
  public lastName: string;
  public email: string;
  public address: Address;
  public phoneNumber: string;
  public ssn: string;
  public ein: string;
  public ssnArea: string;
  public ssnGroup: string;
  public ssnSerial: string;
  public einLocation: string;
  public einNumber: string;
  // public ownerIsEntity: boolean;
  public ownerIsManager: boolean;
  public ownershipUnit: string;
  public ownershipQty: string;
  public individualPhoneNumber: string;
  public individualssnArea: string;
  public individualssnGroup: string;
  public individualssnSerial: string;
  public businessEntityPhoneNumber: string;
  constructor() {
    this.address = new Address();
  }
}

export class Trust extends Contact {
  public isIrsContact: boolean;
  public trustGrantorContact: Contact;
}

export class BusinessEntity extends Contact {
  public isIrsContact: boolean;
  public contact: Contact;
}

export class Individual extends Contact {
  public isIrsContact: boolean;
}

export enum ContactType {
  Individual,
  BusinessEntity,
  Trust
}

