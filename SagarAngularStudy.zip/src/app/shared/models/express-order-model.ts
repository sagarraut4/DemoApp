export class ExpressOrderResponse {
    ExpressOrderId: number;
    PaymentStatus: number;
}
