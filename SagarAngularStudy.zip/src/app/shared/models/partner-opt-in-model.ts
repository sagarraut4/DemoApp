export interface PartnerOptInRequest {
    orderId: string;
    partnerId: number;
    customerDetails: {
        customerId: string,
        email: string,
        firstName: string,
        lastName: string,
        clientIp: string 
    }
}


