import { Contact } from './address-model';

export class RegisteredAgent extends Contact {
  public typeIndicator: RegisteredAgentType;
  public isCRA: boolean; // is commercially registered agent
  public raIdNumber: string;
  public isRaLawfirmService:boolean;
  public isPaperWorkDeadlineReviewed:boolean;
  public isRAAddressValidated:boolean;
}

export enum RegisteredAgentType {
  Individual = 'Individual',
  BusinessEntity = 'BusinessEntity'
}
