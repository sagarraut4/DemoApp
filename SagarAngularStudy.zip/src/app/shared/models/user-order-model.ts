import { QuestionnaireStorage } from './questionnaire-model';

export class UserOrder {
    public processId: number;
    public questionnaireId: number;
    public userOrderId: number;
    public reopen: string;
    public processName: string;
    public revisionNumber: number;
    public userOrderStatus: number; // bcomplete

    public questionnaireStorage: QuestionnaireStorage;
}
