
import { Component } from '@angular/core';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { PagePath } from '../../../../shared/models/page-model';
import { EventService } from '../../../../shared/services/event.service';
@Component({
  selector: 'app-owners-authority',
  templateUrl: './owners-authority.component.html',
  styleUrls: ['./owners-authority.component.scss']
})
export class OwnersAuthorityComponent {

  constructor(
    private eventService: EventService,
    private questionnaireService: QuestionnaireService,
  ) { }

  save(answer: string) {
    this.questionnaireService.llc.ownersHaveAuthority = answer;
    this.eventService.saveAndContinue(PagePath.OwnersAuthority);
  }
}
