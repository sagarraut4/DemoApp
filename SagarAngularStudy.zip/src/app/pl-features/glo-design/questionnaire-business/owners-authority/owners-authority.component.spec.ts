import { EventService } from '../../../../shared/services/event.service';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { OwnersAuthorityComponent } from './owners-authority.component';
import { RouterTestingModule } from '@angular/router/testing';
import { of } from 'rxjs';

describe('OwnersAuthorityComponent', () => {
  let component: OwnersAuthorityComponent;
  let fixture: ComponentFixture<OwnersAuthorityComponent>;
  const llc: any = {
    ownersHaveAuthority: 'yes'
  };
  let mockQuestionnaireService;
  let mockEventService = jasmine.createSpyObj(['saveAndContinue']);
  beforeEach(async(() => {
    mockQuestionnaireService = jasmine.createSpyObj(['setQuestionnaire', 'llc']);
    mockQuestionnaireService.setQuestionnaire.and.returnValue(of(null));
    mockQuestionnaireService.llc = llc;
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [OwnersAuthorityComponent],
      providers: [
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: EventService, useValue: mockEventService }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OwnersAuthorityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should click on #rd-owners-authority-yes', async(() => {
    const button = fixture.debugElement.nativeElement.querySelector('#rd-owners-authority-yes');
    button.click();
    fixture.whenStable().then(() => {
      expect(mockEventService.saveAndContinue).toHaveBeenCalled();
    });
  }));

  it('should click on #rd-owners-authority-no', async(() => {
    const button = fixture.debugElement.nativeElement.querySelector('#rd-owners-authority-no');
    button.click();
    fixture.whenStable().then(() => {
      expect(mockEventService.saveAndContinue).toHaveBeenCalled();
    });
  }));
});
