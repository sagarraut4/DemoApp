import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { QuestionnaireService } from '../../../../../app/shared/services/questionnaire/questionnaire.service';
import { PagePath } from '../../../../shared/models/page-model';
import { EventService } from '../../../../shared/services/event.service';

@Component({
  selector: 'app-how-many-owners',
  templateUrl: './how-many-owners.component.html',
  styleUrls: ['./how-many-owners.component.scss']
})
export class HowManyOwnersComponent implements OnInit {
  public howManyOwnersForm: FormGroup;

  constructor(
    private questionnaireService: QuestionnaireService,
    private fb: FormBuilder,
    private eventService: EventService
  ) { }

  ngOnInit() {
    this.howManyOwnersForm = this.fb.group({
      //  howManyOwners: this.questionnaireService.llc.howManyOwners
    });
  }

  save(s) {
    // this.questionnaireService.llc.howManyOwners = s;
    // clear out next field incase user goes back and revises answer
    this.questionnaireService.llc.ownersHaveAuthority = undefined;
    this.eventService.saveAndContinue(PagePath.HowManyOwners);
  }
}
