import { EventService } from '../../../../shared/services/event.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { LLC } from '../../../../shared/models/questionnaire-model';
import { FormBuilder } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { HowManyOwnersComponent } from './how-many-owners.component';
import { QuestionnaireRoutingService } from '../../../../shared/services/questionnaire-routing/questionnaire-routing.service';

describe('HowManyOwnersComponent', () => {
  let component: HowManyOwnersComponent;
  let fixture: ComponentFixture<HowManyOwnersComponent>;
  const mockQuestionnaireService = {
    llc: new LLC()
  };
  const mockQuestionnaireRoutingService = jasmine.createSpyObj(['getNextPage']);
  let mockEventService = jasmine.createSpyObj(['saveAndContinue']);
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [HowManyOwnersComponent],
      providers: [
        FormBuilder,
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: QuestionnaireRoutingService, useValue: mockQuestionnaireRoutingService },
        { provide: EventService, useValue: mockEventService }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HowManyOwnersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create how many owners component', () => {
    expect(component).toBeTruthy();
  });

  it('should click on #rd-owners-1', async(() => {
    const button = fixture.debugElement.nativeElement.querySelector('#rd-owners-1');
    button.click();
    expect(mockEventService.saveAndContinue).toHaveBeenCalled();

  }));

  it('should click on #rd-owners-2', async(() => {
    const button = fixture.debugElement.nativeElement.querySelector('#rd-owners-2');
    button.click();
    expect(mockEventService.saveAndContinue).toHaveBeenCalled();
  }));

  it('should click on #rd-owners-3', async(() => {
    const button = fixture.debugElement.nativeElement.querySelector('#rd-owners-3');
    button.click();
    expect(mockEventService.saveAndContinue).toHaveBeenCalled();
  }));

});
