import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { BusinessPurposeComponent } from './business-purpose.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { LLC } from '../../../../shared/models/questionnaire-model';
import { BusinessActivityService } from '../../../../shared/services/business-activity.service';
import { SEADService } from '../../../../shared/services/tracking/sead.service';
import { EventService } from '../../../../shared/services/event.service';
import { By } from '@angular/platform-browser';
import { Component, Input } from '@angular/core';
import { MockComponent } from 'ng-mocks';
import { CtaButtonComponent } from '../../shared/components/cta-button/cta-button.component';

describe('BusinessPurposeComponent', () => {
  let component: BusinessPurposeComponent;
  let fixture: ComponentFixture<BusinessPurposeComponent>;
  const mockQuestionnaireService = {
    llc: new LLC()
  };
  const mockBusinessActivityService = jasmine.createSpyObj(['setBizActivities']);
  const mockSEADService = jasmine.createSpyObj(['PushToTealium', 'TrackingObject']);
  const mockEventService = jasmine.createSpyObj(['saveAndContinue']);

  @Component({
    // tslint:disable-next-line:component-selector
    selector: 'cta-button',
    template: '<div></div>'
  })
  class FakeCtabutton {
    @Input() type = 'button';
    @Input() disabled = false;
    @Input() noIcon = false;
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, FormsModule, NgbModule],
      declarations: [BusinessPurposeComponent, FakeCtabutton, MockComponent(CtaButtonComponent)],
      providers: [FormBuilder,
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: BusinessActivityService, useValue: mockBusinessActivityService },
        { provide: EventService, useValue: mockEventService },
        { provide: SEADService, useValue: mockSEADService }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BusinessPurposeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create BusinessPurposeComponent', () => {
    expect(component).toBeTruthy();
  });

  it('should return if businessPurposeForm is valid', () => {
    setInputValue('#tb-biz-industry', 'infrastructure');
    component.save();
    expect(component.businessPurposeForm.valid).toBeTruthy();
    expect(mockEventService.saveAndContinue).toHaveBeenCalled();
    expect(mockSEADService.PushToTealium).toHaveBeenCalled();
  });

  it('should return if businessPurposeForm is invalid', () => {
    setInputValue('#tb-biz-industry', '');
    component.save();
    expect(component.businessPurposeForm.invalid).toBeTruthy();
  });

  it('should return true if isFirstLLC is true ', () => {
    TestBed.get(QuestionnaireService).llc.isFirstLLC = true;
    const result = component.isFirstLLC();
    expect(result).toBe(true);
  });

  function setInputValue(selector: string, value: string) {
    fixture.detectChanges();
    const input = fixture.debugElement.query(By.css(selector)).nativeElement;
    input.value = value;
    input.dispatchEvent(new Event('input'));
  }
});
