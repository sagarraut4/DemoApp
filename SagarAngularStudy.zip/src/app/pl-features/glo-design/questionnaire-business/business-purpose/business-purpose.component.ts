import { Component, OnInit, SecurityContext } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { AllHtmlEntities } from 'html-entities';
import { Observable } from 'rxjs';
import { debounceTime, distinctUntilChanged, map } from 'rxjs/operators';
import { QuestionnaireService } from '../../../../../app/shared/services/questionnaire/questionnaire.service';
import { PagePath } from '../../../../shared/models/page-model';
import { BusinessActivityService } from '../../../../shared/services/business-activity.service';
import { EventService } from '../../../../shared/services/event.service';
import { SEADService } from '../../../../shared/services/tracking/sead.service';

@Component({
  selector: 'app-business-purpose',
  templateUrl: './business-purpose.component.html',
  styleUrls: ['./business-purpose.component.scss']
})
export class BusinessPurposeComponent implements OnInit {
  public businessPurposeForm: FormGroup;
  public submitted: boolean;

  constructor(
    public questionnaireService: QuestionnaireService,
    private fb: FormBuilder,
    private businessActivityService: BusinessActivityService,
    private seadService: SEADService,
    private sanitizer: DomSanitizer,
    private eventService: EventService
  ) {
    this.submitted = false;

    this.businessActivityService.setBizActivities();
  }

  ngOnInit(): void {
    let bizPurpose;
    if (this.questionnaireService.llc.businessPurposeObject != null) {
      bizPurpose = this.questionnaireService.llc.businessPurposeObject;
    } else if (this.questionnaireService.llc.businessPurpose) {
      bizPurpose = { title: this.questionnaireService.llc.businessPurpose };
    }
    this.businessPurposeForm = this.fb.group({
      businessPurpose: new FormControl(bizPurpose, [Validators.required])
    });
  }

  search = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(200),
      distinctUntilChanged(),
      map(term =>
        term.length < 2 ? []
          : this.businessActivityService.bizActivities.filter(v => v.title.toLowerCase().indexOf(term.toLowerCase()) > -1
          ).slice(0, 10)))

  formatter = (x: { title: string }) => this.sanitizer.sanitize(SecurityContext.HTML, x.title);

  isFirstLLC(): boolean {
    return this.questionnaireService.llc.isFirstLLC;
  }

  save(): void {
    this.submitted = true;

    if (this.businessPurposeForm.invalid) {
      return;
    }

    let bizPurposeVal = '';
    if (this.businessPurposeForm.get('businessPurpose').value
      && typeof (this.businessPurposeForm.get('businessPurpose').value) === 'object') {

      this.questionnaireService.llc.businessPurposeObject = this.businessPurposeForm.get('businessPurpose').value;
      bizPurposeVal = this.businessPurposeForm.get('businessPurpose').value.title;
    } else {
      this.questionnaireService.llc.businessPurposeObject = null;
      bizPurposeVal = this.businessPurposeForm.get('businessPurpose').value;
    }

    bizPurposeVal = AllHtmlEntities.decode(bizPurposeVal);
    this.questionnaireService.llc.businessPurpose = bizPurposeVal;
    this.seadService.TrackingObject.business_activity = bizPurposeVal;
    this.seadService.PushToTealium();

    this.eventService.saveAndContinue(PagePath.BusinessPurpose);
  }
}
