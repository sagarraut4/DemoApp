import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BusinessStartimeDetailComponent } from './business-startime-detail.component';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { EventService } from '../../../../shared/services/event.service';
import { Component } from '@angular/core';
import { By } from '@angular/platform-browser';
import { MockComponent } from 'ng-mocks';
import { CtaButtonComponent } from '../../shared/components/cta-button/cta-button.component';

describe('BusinessStartimeDetailComponent', () => {
  let component: BusinessStartimeDetailComponent;
  let fixture: ComponentFixture<BusinessStartimeDetailComponent>;
  const mockQuestionnaireService = {
    llc: {
      businessStartTime : 'already'
    }
  };
  const mockEventService = jasmine.createSpyObj(['saveAndContinue']);
  @Component({
    selector: 'app-cta-button',
    template: '<div></div>'
  })
  class FakeButtonComponent {
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BusinessStartimeDetailComponent, MockComponent(CtaButtonComponent)],
      providers: [{ provide: QuestionnaireService, useValue: mockQuestionnaireService },
      { provide: EventService, useValue: mockEventService }]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BusinessStartimeDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create business starttime detail component', () => {
    expect(component).toBeTruthy();
  });

  it('should save', () => {
    component.save();
    expect(mockEventService.saveAndContinue).toHaveBeenCalled();
  });

  it('bizStartTimeType have value based on llc.businessStartTime', () => {
    expect(component.bizStartTimeType).toBe(BizStartTimeType.AlreadyInBusiness);
  });

  it('next button should call save method', () => {
    spyOn(component, 'save');
    const saveButton = fixture.debugElement.query(By.css('#llc-overview-next')).nativeElement;
    saveButton.click();
    expect(component.save).toHaveBeenCalled()
  });
});
enum BizStartTimeType {
  AlreadyInBusiness,
  LaunchingSoon,
  LaunchingInFuture
}
