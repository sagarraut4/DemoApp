import { Component, OnInit } from '@angular/core';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { EventService } from '../../../../shared/services/event.service';
import { PagePath } from '../../../../shared/models/page-model';

enum BizStartTimeType {
  AlreadyInBusiness,
  LaunchingSoon,
  LaunchingInFuture
}

@Component({
  selector: 'app-desktop-business-startime-detail',
  templateUrl: './business-startime-detail.component.html',
  styleUrls: ['./business-startime-detail.component.scss']
})
export class BusinessStartimeDetailComponent implements OnInit {
  public bizStartTimeEnum = BizStartTimeType;
  public bizStartTimeType: BizStartTimeType;
  public content = [
    {
      iconUrl: 'assets/img/shield.svg',
      iconAlt: 'Icon of a shield',
      title: 'Protect yourself',
      subtitle: 'Set things up correctly from the start to protect your personal assets',
    },
    {
      iconUrl: 'assets/img/talk-bubble.svg',
      iconAlt: 'Icon of a speech bubble',
      title: 'Do things right',
      subtitle: 'Get legal and compliance advice to form your LLC the right way',
    },
    {
      iconUrl: 'assets/img/checkmark-circle.svg',
      iconAlt: 'Icon of a checkmark in a circle',
      title: 'Have peace of mind',
      subtitle: 'Let us take care of legal documents and requirements',
    },
  ]

  constructor(
    public questionnaireService: QuestionnaireService,
    private eventService: EventService
  ) {

  }

  ngOnInit() {
    switch (this.questionnaireService.llc.businessStartTime) {
      case 'already':
        this.bizStartTimeType = BizStartTimeType.AlreadyInBusiness;
        break;
      case 'soon':
        this.bizStartTimeType = BizStartTimeType.LaunchingSoon;
        break;
      default:
        this.bizStartTimeType = BizStartTimeType.LaunchingInFuture;
        break;
    }
  }

  save(): void {
    this.eventService.saveAndContinue(PagePath.BusinessStartTimeDetail);
  }
}
