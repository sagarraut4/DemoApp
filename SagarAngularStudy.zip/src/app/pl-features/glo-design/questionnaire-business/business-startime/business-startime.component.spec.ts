import { CtaButtonComponent } from './../../shared/components/cta-button/cta-button.component';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { LLC } from '../../../../shared/models/questionnaire-model';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { BusinessStartimeComponent } from './business-startime.component';
import { EventService } from '../../../../shared/services/event.service';
import { FormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { CookieService } from 'ngx-cookie';

describe('GloBusinessStartimeComponent', () => {
  let component: BusinessStartimeComponent;
  let fixture: ComponentFixture<BusinessStartimeComponent>;
  const mockQuestionnaireService = {
    llc: new LLC()
  };
  const mockEventService = jasmine.createSpyObj(['saveAndContinue']);
  const mockCookieService = jasmine.createSpyObj(['get', 'post', 'put', 'delete']);
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BusinessStartimeComponent, CtaButtonComponent],
      imports: [FormsModule, ReactiveFormsModule],
      providers: [
        FormBuilder,
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: CookieService, useValue: mockCookieService },
        { provide: EventService, useValue: mockEventService }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BusinessStartimeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create business-startime component', () => {
    expect(component).toBeTruthy();
  });

  it('should click on #already', async(() => {
    const button = fixture.debugElement.query(By.css('#already')).nativeElement;
    button.click();
    const nextButton = fixture.debugElement.query(By.css('#btn-save')).nativeElement;
    nextButton.click();
    fixture.whenStable().then(() => {
      expect(component.questionnaireService.llc.businessStartTime).toEqual('already');
      expect(mockEventService.saveAndContinue).toHaveBeenCalled();
    });
  }));

  it('should click on #soon', async(() => {
    const button = fixture.debugElement.query(By.css('#soon')).nativeElement;
    button.click();
    const nextButton = fixture.debugElement.query(By.css('#btn-save')).nativeElement;
    nextButton.click();
    fixture.whenStable().then(() => {
      expect(component.questionnaireService.llc.businessStartTime).toEqual('soon');
      expect(mockEventService.saveAndContinue).toHaveBeenCalled();
    });
  }));

  it('should click on #future', async(() => {
    const button = fixture.debugElement.query(By.css('#future')).nativeElement;
    button.click();
    const nextButton = fixture.debugElement.query(By.css('#btn-save')).nativeElement;
    nextButton.click();
    fixture.whenStable().then(() => {
      expect(component.questionnaireService.llc.businessStartTime).toEqual('future');
      expect(mockEventService.saveAndContinue).toHaveBeenCalled();
    });
  }));

  it('save button click should call save method', async(() => {
    spyOn(component, 'save');
    const button = fixture.debugElement.query(By.css('#future')).nativeElement;
    button.click();
    const nextButton = fixture.debugElement.query(By.css('#btn-save')).nativeElement;
    nextButton.click();
    expect(component.save).toHaveBeenCalled();
  }));
});
