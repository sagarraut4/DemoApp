import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { QuestionnaireService } from '../../../../../app/shared/services/questionnaire/questionnaire.service';
import { PagePath } from '../../../../shared/models/page-model';
import { EventService } from '../../../../shared/services/event.service';
import { BreakpointObserver } from '@angular/cdk/layout';

@Component({
  selector: 'app-business-startime',
  templateUrl: './business-startime.component.html',
  styleUrls: ['./business-startime.component.scss']
})
export class BusinessStartimeComponent implements OnInit {
  public bizStartTimeForm: FormGroup;
  public entityName: string;
  public isMobile = true;
  public submitted: boolean;

  constructor(
    public questionnaireService: QuestionnaireService,
    private fb: FormBuilder,
    private eventService: EventService,
    private breakpointObserver: BreakpointObserver
  ) {
    this.bizStartTimeForm = this.fb.group({
      changeType: [{}, Validators.required]
    });

    this.submitted = false;
    const size = '(min-width: 768px)';

    breakpointObserver.observe([
      size
    ]).subscribe(result => {
      this.isMobile = !result.matches;
    });
  }

  ngOnInit(): void {
    this.entityName = this.questionnaireService.llc.entityName;
    this.bizStartTimeForm = this.fb.group({
      businessStartTime: [this.questionnaireService.llc.businessStartTime, Validators.required]
    });
  }

  save(): void {
    this.submitted = true;

    if (this.bizStartTimeForm.invalid) {
      return;
    }

    this.questionnaireService.llc.businessStartTime = this.bizStartTimeForm.get('businessStartTime').value;
    this.eventService.saveAndContinue(PagePath.BusinessStartTime);
  }
}
