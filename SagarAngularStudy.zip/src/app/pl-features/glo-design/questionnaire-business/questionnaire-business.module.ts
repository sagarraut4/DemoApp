import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { SharedComponentsModule } from '../../../shared/components/shared-components.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { BusinessStartimeComponent } from './business-startime/business-startime.component';
import { BusinessPurposeComponent } from './business-purpose/business-purpose.component';
import { HowManyOwnersComponent } from './how-many-owners/how-many-owners.component';
import { OwnersAuthorityComponent } from './owners-authority/owners-authority.component';
import { BusinessActivityService } from '../../../shared/services/business-activity.service';
import { BusinessPurposeDetailComponent } from './business-purpose-detail/business-purpose-detail.component';
import { FirstLlcComponent } from './first-llc/first-llc.component';
import { BusinessStartimeDetailComponent } from './business-startime-detail/business-startime-detail.component';
import { HireEmployeesComponent } from './hire-employees/hire-employees.component';
import { GloComponentsModule } from '../shared/components/glo-components.module';

@NgModule({
  imports: [
    CommonModule,
    NgbModule,
    ReactiveFormsModule,
    SharedComponentsModule,
    GloComponentsModule,
  ],
  providers: [BusinessActivityService],
  declarations: [
    BusinessStartimeComponent,
    BusinessPurposeComponent,
    BusinessPurposeDetailComponent,
    HowManyOwnersComponent,
    OwnersAuthorityComponent,
    BusinessPurposeDetailComponent,
    FirstLlcComponent,
    BusinessStartimeDetailComponent,
    HireEmployeesComponent
  ],
  exports: [
    BusinessStartimeComponent,
    BusinessPurposeComponent,
    BusinessPurposeDetailComponent,
    HowManyOwnersComponent,
    OwnersAuthorityComponent,
    BusinessPurposeDetailComponent,
    FirstLlcComponent,
    BusinessStartimeDetailComponent,
    HireEmployeesComponent
  ]
})

export class QuestionnaireBusinessModule { }
