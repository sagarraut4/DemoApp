import { Component, OnInit } from '@angular/core';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { EventService } from '../../../../shared/services/event.service';
import { PagePath } from '../../../../shared/models/page-model';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { SEADService } from '../../../../shared/services/tracking/sead.service';
import { isNullOrUndefined } from 'util';

@Component({
  selector: 'app-first-llc',
  templateUrl: './first-llc.component.html',
  styleUrls: ['./first-llc.component.scss']
})
export class FirstLlcComponent implements OnInit {

  public firstLLCForm: FormGroup;
  public entityName: string;
  public submitted = false;

  constructor(
    public questionnaireService: QuestionnaireService,
    private eventService: EventService,
    private formBuilder: FormBuilder,
    private seadService: SEADService,

  ) {
    this.firstLLCForm = this.formBuilder.group({
      firstLLC: new FormControl(isNullOrUndefined(this.questionnaireService.llc.isFirstLLC) ? null : this.questionnaireService.llc.isFirstLLC, Validators.required)
    });
   }

  ngOnInit() {
    this.entityName = this.questionnaireService.llc.entityName;
  }

  optionSelected(val: string): void {
    this.firstLLCForm.controls.firstLLC.setValue((val === 'yes'));
  }

  continue() {
    this.submitted = true;

    if (this.firstLLCForm.invalid) {
      return;
    }

    this.questionnaireService.llc.isFirstLLC = this.firstLLCForm.controls.firstLLC.value;
    this.seadService.TrackingObject.first_entity = this.firstLLCForm.controls.firstLLC.value.toString();
    this.seadService.PushToTealium();
    this.eventService.saveAndContinue(PagePath.FirstLlc);
  }


}

