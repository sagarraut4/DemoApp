import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { EventService } from '../../../../shared/services/event.service';
import { SEADService } from '../../../../shared/services/tracking/sead.service';
import { FirstLlcComponent } from './first-llc.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Component } from '@angular/core';
import { By } from '@angular/platform-browser';

describe('FirstLlcComponent', () => {
  let component: FirstLlcComponent;
  let fixture: ComponentFixture<FirstLlcComponent>;
  const mockQuestionnaireService = {
    llc: {
      entityName: 'ABC'
    }
  };
  const mockEventService = jasmine.createSpyObj(['saveAndContinue']);
  const mockSEADService = jasmine.createSpyObj(['PushToTealium', 'TrackingObject']);
  @Component({
    selector: 'app-cta-button',
    template: '<div></div>'
  })
  class FakeButtonComponent {
  }
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [FirstLlcComponent, FakeButtonComponent],
      imports: [FormsModule, ReactiveFormsModule],
      providers: [
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: EventService, useValue: mockEventService },
        { provide: SEADService, useValue: mockSEADService }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FirstLlcComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create first-llc component', () => {
    expect(component).toBeTruthy();
  });

  it('entityName should have value', () => {
    expect(component.entityName).toBe('ABC');
  });



  it('should save with true into questionnaireService', () => {
    component.optionSelected('yes');
    component.continue();
    expect(component.questionnaireService.llc.isFirstLLC).toBe(true);
    expect(mockSEADService.TrackingObject.first_entity).toEqual('true');
    expect(mockSEADService.PushToTealium).toHaveBeenCalled();
    expect(mockEventService.saveAndContinue).toHaveBeenCalled();
  });

  it('should save with false into questionnaireService', () => {
    component.optionSelected('no');
    component.continue();
    expect(component.questionnaireService.llc.isFirstLLC).toBe(false);
    expect(mockSEADService.TrackingObject.first_entity).toEqual('false');
    expect(mockSEADService.PushToTealium).toHaveBeenCalled();
    expect(mockEventService.saveAndContinue).toHaveBeenCalled();
  });

  it('on selecting yes should call optionSelected with yes value', () => {
    spyOn(component, 'optionSelected');
    const button = fixture.debugElement.query(By.css('#rd-first-llc-1')).nativeElement;
    button.click();
    expect(component.optionSelected).toHaveBeenCalledWith('yes');
  });

  it('on selecting yes should call optionSelected and update value in form as true', () => {
    const button = fixture.debugElement.query(By.css('#rd-first-llc-1')).nativeElement;
    button.click();
    expect(component.firstLLCForm.controls.firstLLC.value).toBe(true);
  });

  it('on selecting no should call optionSelected with no value', () => {
    spyOn(component, 'optionSelected');
    const button = fixture.debugElement.query(By.css('#rd-first-llc-2')).nativeElement;
    button.click();
    expect(component.optionSelected).toHaveBeenCalledWith('no');
  });

  it('on selecting no should call optionSelected and update value in form as false', () => {
    const button = fixture.debugElement.query(By.css('#rd-first-llc-2')).nativeElement;
    button.click();
    expect(component.firstLLCForm.controls.firstLLC.value).toBe(false);
  });


  it('on click next button it should call continue method', () => {
    spyOn(component, 'continue');
    const button = fixture.debugElement.query(By.css('#btn-next')).nativeElement;
    button.click();
    expect(component.continue).toHaveBeenCalled();
  });
});
