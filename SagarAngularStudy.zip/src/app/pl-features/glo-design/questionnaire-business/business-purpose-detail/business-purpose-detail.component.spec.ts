import { EventService } from '../../../../shared/services/event.service';
import { async, ComponentFixture, TestBed, fakeAsync } from '@angular/core/testing';
import { BusinessPurposeDetailComponent } from './business-purpose-detail.component';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { BusinessActivityService } from '../../../../shared/services/business-activity.service';
import { RouterTestingModule } from '@angular/router/testing';
import { DeviceDetectorService } from 'ngx-device-detector';
import { of } from 'rxjs';

describe('BusinessPurposeDetailComponent', () => {
  let component: BusinessPurposeDetailComponent;
  let fixture: ComponentFixture<BusinessPurposeDetailComponent>;
  const llc: any = {
    currentView: '/industry-confirm',
    businessPurposeObject: {}
  };
  const mockdata = {
    BusinessActivities: {
      image: 'testpath',
      quote: 'testquote',
      source: 'testsource',
      responseContent: 'responseContent'
    }
  };
  let mockQuestionnaireService;
  let mockBusinessActivityService;
  let mockEventService;

  beforeEach(async(() => {
    mockQuestionnaireService = jasmine.createSpyObj(['setQuestionnaire', 'llc']);
    mockQuestionnaireService.setQuestionnaire.and.returnValue(of(null));
    mockQuestionnaireService.llc = llc;
    mockEventService = jasmine.createSpyObj(['saveAndContinue']);
    mockBusinessActivityService = jasmine.createSpyObj(['getBizActivity']);
    mockBusinessActivityService.getBizActivity.and.returnValues(of(mockdata));
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [BusinessPurposeDetailComponent],
      providers: [DeviceDetectorService,
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: BusinessActivityService, useValue: mockBusinessActivityService },
        { provide: EventService, useValue: mockEventService }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BusinessPurposeDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create business-purpose component', () => {
    expect(component).toBeTruthy();
  });

  it('save should call save and continue from event service', () => {
    component.save();
    expect(mockEventService.saveAndContinue).toHaveBeenCalled();
  });

  it('bizPurposeImg path should change based on data', fakeAsync(() => {
    mockBusinessActivityService.getBizActivity.and.returnValues(of(mockdata));
    component.ngOnInit();

    fixture.whenStable().then(() => {
      expect(component.bizPurposeImg).toBe(mockdata.BusinessActivities.image);
      expect(component.bizPurposeQuote).toBe(mockdata.BusinessActivities.quote);
      expect(component.bizPurposeQuoteBy).toBe(mockdata.BusinessActivities.source);
      expect(component.bizPurposeUpsellText).toBe(mockdata.BusinessActivities.responseContent);
    });
  }));
});
