import { Component, OnInit } from '@angular/core';
import { DeviceDetectorService } from 'ngx-device-detector';
import { PagePath } from '../../../../shared/models/page-model';
import { BusinessActivityService } from '../../../../shared/services/business-activity.service';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { EventService } from '../../../../shared/services/event.service';

@Component({
  selector: 'app-desktop-business-purpose-detail',
  templateUrl: './business-purpose-detail.component.html',
  styleUrls: ['./business-purpose-detail.component.scss']
})
export class BusinessPurposeDetailComponent implements OnInit {
  public bizPurposeImg: string;
  public bizPurposeQuote: string;
  public bizPurposeQuoteBy: string;
  public bizPurposeUpsellText: string;
  public deviceInfo;

  constructor(
    public questionnaireService: QuestionnaireService,
    private businessActivityService: BusinessActivityService,
    private deviceService: DeviceDetectorService,
    private eventService: EventService) {

    this.bizPurposeImg = 'assets/img/business-purposes/default.jpg';
    this.bizPurposeQuote = 'Build your own dreams, or someone else will hire you to build theirs.';
    this.bizPurposeQuoteBy = 'Farrah Gray',
      this.bizPurposeUpsellText = 'We\'ve formed thousands of businesses like yours so we know exactly how to help.';
  }

  ngOnInit() {
    this.deviceInfo = this.deviceService.browser;
    if (this.questionnaireService.llc.businessPurposeObject
      && this.questionnaireService.llc.businessPurposeObject != null) {

      this.businessActivityService.getBizActivity().subscribe(r => {
        if (!r || !r.BusinessActivities) {
          return;
        }

        if (typeof (r.BusinessActivities.image) !== 'undefined') {
          this.bizPurposeImg = r.BusinessActivities.image;
        } else {
          this.bizPurposeImg = './llc/assets/img/business-purposes/default.jpg';
        }

        if (typeof (r.BusinessActivities.quote) !== 'undefined') {
          this.bizPurposeQuote = r.BusinessActivities.quote;
        }

        if (typeof (r.BusinessActivities.source) !== 'undefined') {
          this.bizPurposeQuoteBy = r.BusinessActivities.source;
        }

        if (typeof (r.BusinessActivities.responseContent) !== 'undefined') {
          this.bizPurposeUpsellText = r.BusinessActivities.responseContent;
        }
      });
    }
  }
  save() {
    // go to next page
    this.eventService.saveAndContinue(PagePath.BusinessPurposeDetail);
  }
}
