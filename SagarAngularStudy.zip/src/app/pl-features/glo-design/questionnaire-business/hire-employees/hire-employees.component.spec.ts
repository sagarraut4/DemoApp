import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HireEmployeesComponent } from './hire-employees.component';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { EventService } from '../../../../shared/services/event.service';
import { LLC } from '../../../../shared/models/questionnaire-model';
import { Component } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';

describe('HireEmployeesComponent', () => {
  let component: HireEmployeesComponent;
  let fixture: ComponentFixture<HireEmployeesComponent>;
  @Component({
    selector: 'app-cta-button',
    template: '<div></div>'
  })
  class FakeButtonComponent {
  }
  const mockQuestionnaireService = {
    llc: new LLC()
  };
  let mockEventService: EventService;

  beforeEach(async(() => {
    mockEventService = jasmine.createSpyObj(['saveAndContinue']);
    TestBed.configureTestingModule({
      declarations: [HireEmployeesComponent,FakeButtonComponent],
      imports: [FormsModule, ReactiveFormsModule],
      providers: [{ provide: QuestionnaireService, useValue: mockQuestionnaireService },
      { provide: EventService, useValue: mockEventService }]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HireEmployeesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create hire employees component', () => {
    expect(component).toBeTruthy();
  });

  
  it('should save with true into questionnaireService', () => {
    component.optionSelected('yes');
    component.continue();
    expect(component.hireEmployeesForm.controls.hireEmployees.value).toBe('yes');
    expect(mockEventService.saveAndContinue).toHaveBeenCalled();
  });

  it('should save with false into questionnaireService', () => {
    component.optionSelected('no');
    component.continue();
    expect(component.hireEmployeesForm.controls.hireEmployees.value).toBe('no');
    expect(mockEventService.saveAndContinue).toHaveBeenCalled();
  });

  it('on click of yes it should call optionSelected with value yes', () => {
    spyOn(component, 'optionSelected');
    const button = fixture.debugElement.query(By.css('#rd-employees-yes')).nativeElement;
    button.click();
    expect(component.optionSelected).toHaveBeenCalledWith('yes');
  });

  it('on click of no it should call optionSelected with value no', () => {
    spyOn(component, 'optionSelected');
    const button = fixture.debugElement.query(By.css('#rd-employees-no')).nativeElement;
    button.click();
    expect(component.optionSelected).toHaveBeenCalledWith('no');
  });

  it('on click of next button should call continue', () => {
    spyOn(component, 'continue');
    const button = fixture.debugElement.query(By.css('#btn-next')).nativeElement;
    button.click();
    expect(component.continue).toHaveBeenCalled();
  });
});
