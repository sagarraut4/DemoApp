import { Component, OnInit } from '@angular/core';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { EventService } from '../../../../shared/services/event.service';
import { PagePath } from '../../../../shared/models/page-model';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-desktop-hire-employees',
  templateUrl: './hire-employees.component.html',
  styleUrls: ['./hire-employees.component.scss']
})
export class HireEmployeesComponent implements OnInit {

  public hireEmployeesForm: FormGroup;
  public submitted = false;

  constructor(
    public questionnaireService: QuestionnaireService,
    private eventService: EventService,
    private formBuilder: FormBuilder
  ) {

    let defaultValue;
    if (this.questionnaireService && this.questionnaireService.llc  && this.questionnaireService.llc.hireEmployees && this.questionnaireService.llc.hireEmployees.length > 0 ) {
      defaultValue = this.questionnaireService.llc.hireEmployees;
    } else {
      defaultValue = null;
    }
    this.hireEmployeesForm = this.formBuilder.group({
      hireEmployees: new FormControl(defaultValue, Validators.required)
    });

   }

  ngOnInit() {
  }

  optionSelected(val: string): void {
    this.hireEmployeesForm.controls.hireEmployees.setValue(val);
  }

  continue() {
    this.submitted = true;

    if (this.hireEmployeesForm.invalid) {
      return;
    }

    this.questionnaireService.llc.hireEmployees = this.hireEmployeesForm.controls.hireEmployees.value;
    this.eventService.saveAndContinue(PagePath.HireEmployees);
  }
}
