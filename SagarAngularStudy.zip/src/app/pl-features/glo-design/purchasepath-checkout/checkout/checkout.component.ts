import { AfterViewInit, Component, OnDestroy, OnInit } from '@angular/core';
import { HelperService, GCPageInput } from '@legalzoom/lib-checkout';
import { CheckoutService } from '../../../../shared/services/checkout.service';
import { NotificationService } from '../../shared/services/notification.service';
import { Subscription } from 'rxjs';
import { FormatPhonePipe } from '../../../../shared/pipes/format-phone';

@Component({
  selector: 'app-pl-desktop-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.scss'],
  providers: [FormatPhonePipe]
})
export class CheckoutPlComponent implements OnInit, OnDestroy, AfterViewInit {  
  public cartId = '';
  public authToken = '';  
  private notificationSubscription: Subscription;
  public globalCheckoutObject: GCPageInput;

  constructor(
    public helperService: HelperService,
    private checkoutService: CheckoutService,
    private formatPhonePipe: FormatPhonePipe,
    private notificationService: NotificationService    
  ) {
    this.globalCheckoutObject = this.checkoutService.setGlobalCheckoutObject();    
    this.globalCheckoutObject.desktopPhoneNumber = this.formatPhonePipe.transform(this.globalCheckoutObject.desktopPhoneNumber);
    this.globalCheckoutObject.mobilePhoneNumber = this.formatPhonePipe.transform(this.globalCheckoutObject.mobilePhoneNumber);  
    this.notificationSubscription = helperService.showNotificationEvent.subscribe(r => {
      this.notificationService.showNotification(r);
    });
  }

  ngOnInit() {
    this.checkoutService.subscribeToCheckoutEvents();
  }

  ngOnDestroy(): void {
    if (this.notificationSubscription) {
      this.notificationSubscription.unsubscribe();
    }
  }

  ngAfterViewInit() {
  }
}
