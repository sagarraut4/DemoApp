import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LLC } from '../../../../../app/shared/models/questionnaire-model';
import { CheckoutPlComponent } from './checkout.component';
import { CheckoutService } from '../../../../shared/services/checkout.service';
import { HelperService, CheckoutService as GCCheckoutService, GcPlCheckoutModule } from '@legalzoom/lib-checkout';
import { QuestionnaireService } from '../../../../../app/shared/services/questionnaire/questionnaire.service';
import { EventService } from '../../../../../app/shared/services/event.service';
import { ExperimentsService } from '../../../../shared/services/experiments/experiments.service';
import { AppService } from '../../../../shared/state/app';
import { HttpClient } from '@angular/common/http';
import { Cart, CartBalance, GuestUserAuthService, CartService } from '@legalzoom/sdk-checkout';
import { ProductComponentId } from '../../../../shared/models/cart-model';
import { of } from 'rxjs';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { environmentGC } from '../../../../../environments/environment.dev';

describe('CheckoutPlComponent', () => {
  let component: CheckoutPlComponent;
  let fixture: ComponentFixture<CheckoutPlComponent>;
  let mockCheckoutService;
  let mockEventService;
  let mockExperimentService;
  let mockGCCheckoutService;
  let mockGuestAuthService;
  let mockCartService;
  let modalService;
  const mockQuestionnareService = {
    llc: new LLC()
  };
  const mockAppService = {
    currentView: '',
    loginEmail: '',
    app: {
      processingOrderId: 123,
      customerId: 123,
      accessToken: 'tetstetstetst'
    }
  };
  const mockHttpClient = jasmine.createSpyObj(['get', 'post', 'put', 'delete']);
  beforeEach(async(() => {
    mockCheckoutService = jasmine.createSpyObj(['subscribeToCheckoutEvents']);
    mockEventService = jasmine.createSpyObj(['saveAndContinue']);
    mockExperimentService = jasmine.createSpyObj(['getOrderTagName']);
    mockGCCheckoutService = jasmine.createSpyObj('GCCheckoutService', ['getCartPromoCode', 'getCartInstallmentFee',
      'createContacts', 'createCartContact', 'finalizeOrder', 'makePaymentAndCreateContacts',
      'getCartFlagValues', 'setDisclaimerProperties']);
    mockGuestAuthService = jasmine.createSpyObj(['getCustomerAndSession']);
    mockCartService = jasmine.createSpyObj(['updateCart', 'getCart', 'getCartBalance', 'updatePaymentOption',
      'updateCartFlags']);
    TestBed.configureTestingModule({
      imports: [GcPlCheckoutModule.forRoot(environmentGC)],
      declarations: [CheckoutPlComponent],
      providers: [
        CheckoutService, HelperService, Cart, CartBalance, GuestUserAuthService,
        { provide: CheckoutService, useValue: mockCheckoutService },
        { provide: QuestionnaireService, useValue: mockQuestionnareService },
        { provide: EventService, useValue: mockEventService },
        { provide: ExperimentsService, useValue: mockExperimentService },
        { provide: AppService, useValue: mockAppService },
        { provide: HttpClient, useValue: mockHttpClient },
        { provide: GuestUserAuthService, useValue: mockGuestAuthService },
        { provide: CartService, useValue: mockCartService },
        {
          provide: GCCheckoutService, useValue: {
            mockGCCheckoutService,
            setDisclaimerProperties() {
              return {
                disclaimerText: '',
                dueNow: 0,
                hasAffordableTax: false,
                hasCompliance: true,
                hasLegalAdvice: true,
                hasRA: true,
                isHireEmployees: true,
                parentProduct: 2,
                showDisclaimer: false,
                stateAbbr: '',
                subscriptions: null
              };
            },
            getCartInstallmentFee() {
              return 208;
            },
            getCartPromoCode() {
              return null;
            },
            getCartFlagValues() {
              return [
                {
                  cartFlag: 256,
                  newFlagValue: false
                }
              ];
            },
            finalizeOrder() {
              return of({});
            },
            gcAgreeAndPayNow: { emit: jasmine.createSpy('emit'), subscribe: jasmine.createSpy('subscribe') },
            gcUserSessionUpdated: { emit: jasmine.createSpy('emit'), subscribe: jasmine.createSpy('subscribe') },
            gcProcessCheckoutInit: { emit: jasmine.createSpy('emit'), subscribe: jasmine.createSpy('subscribe') },
            gcLoaded: { emit: jasmine.createSpy('emit'), subscribe: jasmine.createSpy('subscribe') },
            gcHeaderLoaded: { emit: jasmine.createSpy('emit'), subscribe: jasmine.createSpy('subscribe') },
            gcProcessCheckoutOrderCharged: { emit: jasmine.createSpy('emit'), subscribe: jasmine.createSpy('subscribe') },
            gcErrorRaised: { emit: jasmine.createSpy('emit'), subscribe: jasmine.createSpy('subscribe') }
          }
        }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckoutPlComponent);
    component = fixture.componentInstance;
    component.globalCheckoutObject = {
      userId: 15406367,
      sessionId: 'zi6ZHyG1Ab/ZT7scEr3LsQ==',
      loginEmail: 'guest_LZ6373659818353002290_LZ6373659818353003041@legalzoom.com',
      cartId: 22421539,
      processingOrderId: 64564545,
      accessToken: '0nFGKQDPY1N9691mUTO1XP9FkUoy',
      primaryContact: {
        email: 'test234324@test.com',
        phone: '7894561231',
      },
      professionalPrintComponents: [ProductComponentId.economyLLCPackage]
    };

    mockGuestAuthService.getCustomerAndSession.and.returnValue(of(
      {
        customerId: 15345640, session: [{ key: 'accessToken', value: 'LsRlritkFcgu5pMiABdTx7ynPShj' },
        { key: 'iUser', value: '15345640' }, { key: 'expiresAt', value: '9/28/2020 1:01:22 AM' },
        { key: 'bGuest', value: 'true' },
        { key: 'UserName', value: 'guest_LZ6373684988210841780_LZ6373684988210842531@legalzoom.com' },
        { key: 'TIMESTRING', value: 'xans6sw2Wza8h3lfbYMAfQ==' }]
      }
    ));
    mockCheckoutService.subscribeToCheckoutEvents.and.returnValue(of(
      {}
    ));
    modalService = TestBed.get(NgbModal);
    fixture.detectChanges();
  });

  it('checkout component => should create', () => {
    expect(component).toBeTruthy();
    modalService.dismissAll();
  });

  it('checkout component => globalCheckoutObject should be defined', () => {
    expect(component.globalCheckoutObject).toBeDefined();
    modalService.dismissAll();
  });

  it('checkout component => on load subscribeToCheckoutEvents should be called', () => {
    expect(mockCheckoutService.subscribeToCheckoutEvents).toHaveBeenCalled();
    modalService.dismissAll();
  });

  it('checkout component => on load Global checkout page should load', () => {
    fixture.detectChanges();
    const el = fixture.debugElement.nativeElement;
    const title = el.querySelectorAll('#checkout-title')[0].innerHTML;
    fixture.detectChanges();
    expect(title).toEqual(' Enter your info to check out ');
    modalService.dismissAll();
  });

  it('checkout component => on load Global checkout page should load with session error', () => {
    fixture.detectChanges();
    const el = fixture.debugElement.nativeElement;
    const title = document.querySelectorAll('.title-2')[0].innerHTML;
    fixture.detectChanges();
    expect(title).toEqual('Sorry, we can\'t find that cart');
    modalService.dismissAll();
  });
});
