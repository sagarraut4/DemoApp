import { Component, OnInit } from '@angular/core';
import { QuestionnaireRoutingService } from '../../../../shared/services/questionnaire-routing/questionnaire-routing.service';
import { PagePath } from '../../../../shared/models/page-model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-thankyou',
  templateUrl: './thankyou.component.html',
  styleUrls: ['./thankyou.component.css']
})
export class ThankyouComponent implements OnInit {

  constructor(
    private questionnaireRoutingService: QuestionnaireRoutingService,
    private router: Router
  ) { }

  ngOnInit() {
  }

  save() {
    const nextPage = this.questionnaireRoutingService.getNextPage(PagePath.ThankYou);
    this.router.navigate(['./' + nextPage]);
  }

}
