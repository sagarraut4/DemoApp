import { QuestionnaireRoutingService } from '../../../../shared/services/questionnaire-routing/questionnaire-routing.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ThankyouComponent } from './thankyou.component';
import { RouterTestingModule } from '@angular/router/testing';

describe('ThankyouComponent', () => {
  let component: ThankyouComponent;
  let fixture: ComponentFixture<ThankyouComponent>;
  let mockQuestionnaireRoutingService;

  beforeEach(async(() => {
    mockQuestionnaireRoutingService = jasmine.createSpyObj(['getNextPage']);
    TestBed.configureTestingModule({
      declarations: [ThankyouComponent],
      imports: [RouterTestingModule],
      providers: [
        { provide: QuestionnaireRoutingService, useValue: mockQuestionnaireRoutingService }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ThankyouComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create thankyou component', () => {
    expect(component).toBeTruthy();
  });

  it('should save', () => {
    component.save();
    expect(mockQuestionnaireRoutingService.getNextPage).toHaveBeenCalled();
  });
});
