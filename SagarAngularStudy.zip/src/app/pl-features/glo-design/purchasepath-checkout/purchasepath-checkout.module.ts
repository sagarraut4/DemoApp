import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { CheckoutPlComponent } from './checkout/checkout.component';
import { ThankyouComponent } from './thankyou/thankyou.component';
import { AddressModule } from '../../../shared/address.module';
import { NgXCreditCardsModule } from 'ngx-enhance-credit-cards';
import { SharedComponentsModule } from '../../../shared/components/shared-components.module';
import { CoreModule } from '../../../core/core.module';
import { TextMaskModule } from 'angular2-text-mask';
import { FormatterModule } from '../../../shared/directives/formatter/formatter.module';
import { GcPlCheckoutModule } from '@legalzoom/lib-checkout';
import { environmentGC } from '../../../../../src/environments/environment';

@NgModule({
  imports: [
    TextMaskModule,
    CommonModule,
    CoreModule,
    ReactiveFormsModule,
    NgXCreditCardsModule,
    AddressModule,
    SharedComponentsModule,
    FormatterModule,
    GcPlCheckoutModule.forRoot(environmentGC)
  ],
  declarations: [
    CheckoutPlComponent,
    ThankyouComponent
  ]
})
export class PurchasepathPlCheckoutModule { }
