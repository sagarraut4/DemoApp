import { By } from '@angular/platform-browser';
import { EventService } from '../../../../shared/services/event.service';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { EssentialExtrasComponent } from './essential-extras.component';
import { Component } from '@angular/core';

describe('EssentialExtrasComponent', () => {
  let component: EssentialExtrasComponent;
  let fixture: ComponentFixture<EssentialExtrasComponent>;
  let mockEventService = jasmine.createSpyObj(['saveAndContinue']);
  const mockQuestionnaireService = {
    llc: {
      entityName: 'llcEntity',
      isMobile: false
    }
  };

  @Component({
    selector: 'app-cta-button',
    template: '<div></div>'
  })
  class FakeButtonComponent {
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [EssentialExtrasComponent, FakeButtonComponent],
      providers: [{ provide: QuestionnaireService, useValue: mockQuestionnaireService },
      { provide: EventService, useValue: mockEventService }]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EssentialExtrasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create essential extras component', () => {
    expect(component).toBeTruthy();
  });

  it('entityName and isRaRequired should have value', () => {
    expect(component.entityName).not.toBeNull();
    expect(component.isRARequired).not.toBeNull();
  });

  it('on click of save button save method should get called', () => {
    spyOn(component, 'save');
      const saveButton = fixture.debugElement.query(By.css('#btn-save-container')).nativeElement;
      saveButton.click();
      expect(component.save).toHaveBeenCalled();
  });

  it('save method should get called with saveAndContinue method of eventService', () => {
      const saveButton = fixture.debugElement.query(By.css('#btn-save-container')).nativeElement;
      saveButton.click();
      expect(mockEventService.saveAndContinue).toHaveBeenCalled()
  });
});
