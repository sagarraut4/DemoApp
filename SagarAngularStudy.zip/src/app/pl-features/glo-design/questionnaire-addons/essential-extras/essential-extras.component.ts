import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { ConstantsService } from '../../../../shared/services/constants.service';
import { PagePath } from '../../../../shared/models/page-model';
import { EventService } from '../../../../shared/services/event.service';
import { InfoPanelComponent } from '../../shared/components/info-panel/info-panel.component';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';

@Component({
  selector: 'app-essential-extras',
  templateUrl: './essential-extras.component.html',
  styleUrls: ['./essential-extras.component.scss']
})
export class EssentialExtrasComponent implements OnInit {

  public isMobile = true;


  public entityName: string;
  public isRARequired: boolean;

  private matcher: MediaQueryList;


  constructor(
    public questionnaireService: QuestionnaireService,
    private eventService: EventService,
    private breakpointObserver: BreakpointObserver
  ) {
    const size = '(min-width: 768px)';

    breakpointObserver.observe([
      size
    ]).subscribe(result => {
      if (result.matches) {
        this.isMobile = false;
      } else {
        this.isMobile = true;
      }
    });

   }

  ngOnInit() {
    this.entityName = this.questionnaireService.llc.entityName;
    this.isRARequired = ConstantsService.STATES_REQUIRING_RA.indexOf(this.questionnaireService.llc.entityState) >= 0;
  }

  save(): void {
    this.eventService.saveAndContinue(PagePath.EssentialExtras);
  }



}
