import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RegisteredAgentConfirmModalComponent } from './registered-agent-confirm-modal.component';
import { By } from '@angular/platform-browser';

describe('RegisteredAgentConfirmModalComponent', () => {
  let component: RegisteredAgentConfirmModalComponent;
  let fixture: ComponentFixture<RegisteredAgentConfirmModalComponent>;
  let mockActiveModal;
  const mockQuestionnaireService = {
    llc: {
      isMobile: false,
    }
  };

  beforeEach(async(() => {
    mockActiveModal = jasmine.createSpyObj(['close', 'dismiss']);
    TestBed.configureTestingModule({
      declarations: [RegisteredAgentConfirmModalComponent],
      providers: [{ provide: NgbActiveModal, useValue: mockActiveModal },
      { provide: QuestionnaireService, useValue: mockQuestionnaireService }]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisteredAgentConfirmModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('close modal method should get called when user clicks on continue with legalzoom button', () => {
    spyOn(component, 'closeModal');
    const continueWithLZButton = fixture.debugElement.query(By.css('#btn-save-ra')).nativeElement;
    continueWithLZButton.click();
    expect(component.closeModal).toHaveBeenCalled();
  });

  it('dismiss method should get called when user clicks on cross button', () => {
    spyOn(component, 'dismiss');
    const closeButton = fixture.debugElement.query(By.css('.close')).nativeElement;
    closeButton.click();
    expect(component.dismiss).toHaveBeenCalled();
  });

  it('close modal method should call close method of activeModal', async(() => {
    component.closeModal(true);
    fixture.whenStable().then(() => {     
      expect(mockActiveModal.close).toHaveBeenCalledWith(true);
    });
  }));

  it('dismiss method should call dismiss method of activeModal', async(() => {
    component.dismiss()
    fixture.whenStable().then(() => {
      expect(mockActiveModal.dismiss).toHaveBeenCalledWith('cross clicked');
    });
  }));
});
