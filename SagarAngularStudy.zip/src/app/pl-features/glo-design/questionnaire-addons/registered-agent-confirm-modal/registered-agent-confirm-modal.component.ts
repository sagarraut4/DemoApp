import { Component } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';

@Component({
  selector: 'app-registered-agent-confirm-modal',
  templateUrl: './registered-agent-confirm-modal.component.html',
  styleUrls: ['./registered-agent-confirm-modal.component.scss']
})
export class RegisteredAgentConfirmModalComponent {
  constructor(
    private activeModal: NgbActiveModal,
    public questionnaireService: QuestionnaireService
  ) { }

  closeModal(val: boolean): void {
    this.activeModal.close(val);
  }

  dismiss(): void {
    this.activeModal.dismiss('cross clicked');
  }
}
