import { BusinessLicensesComponent } from '../modals/business-licenses/business-licenses.component';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CommonModule } from '@angular/common';
import { EssentialExtrasComponent } from './essential-extras/essential-extras.component';
import { RegisteredAgentComponent } from './registered-agent/registered-agent.component';
import { SharedComponentsModule } from '../../../../app/shared/components/shared-components.module';
import { RegisteredAgentConfirmModalComponent } from './registered-agent-confirm-modal/registered-agent-confirm-modal.component';
import { GloComponentsModule } from '../shared/components/glo-components.module';
import { CriticalDocumentsComponent } from './critical-documents/critical-documents.component';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    SharedComponentsModule,
    ReactiveFormsModule,
    NgbModule,
    GloComponentsModule
  ],
  providers: [],
  declarations: [
    EssentialExtrasComponent,
    RegisteredAgentComponent,
    RegisteredAgentConfirmModalComponent,
    BusinessLicensesComponent,
    CriticalDocumentsComponent,
  ],
  entryComponents: [RegisteredAgentConfirmModalComponent, BusinessLicensesComponent]
})
export class QuestionnaireAddonModule { }
