import { Component, OnInit, ViewChild } from '@angular/core';
import { QuestionnaireService } from '../../../../../app/shared/services/questionnaire/questionnaire.service';
import { PagePath } from '../../../../shared/models/page-model';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { RegisteredAgentConfirmModalComponent } from '../registered-agent-confirm-modal/registered-agent-confirm-modal.component';
import { ExperimentsService } from '../../../../shared/services/experiments/experiments.service';
import { ProductDefinitionService } from '../../../../shared/services/product-definition/product-definition.service';
import { SEADService } from '../../../../shared/services/tracking/sead.service';
import { ConstantsService } from '../../../../shared/services/constants.service';
import { EventService } from '../../../../shared/services/event.service';
import { InfoPanelComponent } from '../../shared/components/info-panel/info-panel.component';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { TrackingService } from '../../../../shared/services/tracking/tracking.service';

@Component({
  selector: 'app-registered-agent',
  templateUrl: './registered-agent.component.html',
  styleUrls: ['./registered-agent.component.scss']
})
export class RegisteredAgentComponent implements OnInit {
  public registerMyOwnAgent: boolean;
  public isCollapsed = false;
  public entityName: string;
  public isMobile = true;
  public specialState = ['Minnesota', 'New York', 'Pennsylvania'].includes(this.questionnaireService.llc.entityState);

  @ViewChild('moreInfo', {static: false}) moreInfo: InfoPanelComponent;

  constructor(
    public questionnaireService: QuestionnaireService,
    public constantsService: ConstantsService,
    private modalService: NgbModal,
    private seadService: SEADService,
    public productDefinitionService: ProductDefinitionService,
    public experimentsService: ExperimentsService,
    public eventService: EventService,
    private breakpointObserver: BreakpointObserver,
    private trackingService: TrackingService
  ) {
    const size = '(min-width: 768px)';

    breakpointObserver.observe([
      size
    ]).subscribe(result => {
      if (result.matches) {
        this.isMobile = false;
      } else {
        this.isMobile = true;
      }
    });
  }

  public showTermsTop = false;
  public showTermsBottom = false;
  public isRARequired: boolean;

  raAnimation() {
    const agentAnimation = document.getElementById('agent_animation');
    if (agentAnimation === null) {
      window.removeEventListener('scroll', this.raAnimation);
      window.removeEventListener('resize', this.raAnimation);
      return;
    }

    const supportPageOffset = window.pageXOffset !== undefined;
    const isCSS1Compat = ((document.compatMode || '') === 'CSS1Compat');
    const scrollTop = supportPageOffset ? window.pageYOffset : isCSS1Compat ? document.documentElement.scrollTop : document.body.scrollTop;
    const bodyScrollTop = document.documentElement.scrollTop || document.body.scrollTop;
    const a = window.innerHeight;
    const n = scrollTop;
    const o = n + a;
    const i = agentAnimation.offsetHeight;
    const r = agentAnimation.getBoundingClientRect().top + bodyScrollTop;
    const s = r + i;
    const c = r + i / 2;

    if (s >= n && r <= o) {
      const l = Math.round(100 * n / c);
      const raImg = document.querySelectorAll('.ra-img');
      if (l <= 40) {
        raImg.forEach(el => {
          el.classList.remove('anim-100');
          el.classList.remove('anim-50');
          el.classList.remove('anim-30');
          el.classList.add('anim-0');
        });
      } else if (l > 40 && l <= 65) {
        raImg.forEach(el => {
          el.classList.remove('anim-100');
          el.classList.remove('anim-50');
          el.classList.remove('anim-0');
          el.classList.add('anim-30');
        });
      } else if (l > 65 && l <= 80) {
        raImg.forEach(el => {
          el.classList.remove('anim-100');
          el.classList.remove('anim-30');
          el.classList.remove('anim-0');
          el.classList.add('anim-50');
        });
      } else {
        raImg.forEach(el => {
          el.classList.remove('anim-50');
          el.classList.remove('anim-30');
          el.classList.remove('anim-0');
          el.classList.add('anim-100');
        });
      }
    }
  }

  ngOnInit() {
    this.registerMyOwnAgent = false;
    this.entityName = this.questionnaireService.llc.entityName;

    window.addEventListener('resize', this.raAnimation);
    window.addEventListener('scroll', this.raAnimation);

    this.isRARequired = ConstantsService.STATES_REQUIRING_RA.indexOf(this.questionnaireService.llc.entityState) < 0 ? false : true;
  }

  acceptRaOffer(accept: boolean) {
    if (!accept) {
      const modalRef = this.modalService.open(RegisteredAgentConfirmModalComponent, { size: 'lg', windowClass: 'glo-modal', centered: true, scrollable: true  });
      modalRef.result.then((result: boolean) => {

        this.saveAndContinue(result);

      }).catch(err => {

      });
    } else {
      this.saveAndContinue(accept);
    }
  }

  private saveAndContinue(val: boolean): void {
    this.questionnaireService.llc.lzRA = val ? 'Yes' : 'No';
    if (val) {
      this.seadService.addOptin(this.seadService.seadOptins.RA);
    } else {
      this.seadService.removeOptin(this.seadService.seadOptins.RA);
    }

    this.eventService.saveAndContinue(PagePath.RegisteredAgent);
  }

  toggleTermsTop(): void {
    this.showTermsTop = !this.showTermsTop;
  }

  toggleTermsBottom(): void {
    this.showTermsBottom = !this.showTermsBottom;
  }

  public openInfoPanel() {
    this.trackingService.triggerClickTrack('llc_flow', 'ra_more_info_link');
    this.moreInfo.open();
  }
}
