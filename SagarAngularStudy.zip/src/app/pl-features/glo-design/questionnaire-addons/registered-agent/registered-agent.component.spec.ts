import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { EventService } from '../../../../shared/services/event.service';
import { ExperimentsService } from '../../../../shared/services/experiments/experiments.service';
import { ProductDefinitionService } from '../../../../shared/services/product-definition/product-definition.service';
import { SEADService } from '../../../../shared/services/tracking/sead.service';
import { ConstantsService } from '../../../../shared/services/constants.service';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RegisteredAgentComponent } from './registered-agent.component';
import { By } from '@angular/platform-browser';
import { InfoPanelComponent } from '../../shared/components/info-panel/info-panel.component';
import { TrackingService } from '../../../../shared/services/tracking/tracking.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Component, Input } from '@angular/core';

describe('RegisteredAgentComponent', () => {
  let component: RegisteredAgentComponent;
  let fixture: ComponentFixture<RegisteredAgentComponent>;
  // tslint:disable-next-line:prefer-const
  let mockConstantService: ConstantsService;
  let mockSeadService;
  let mockProductDefination;
  // tslint:disable-next-line:prefer-const
  let mockExperimentService;
  let mockEventService;
  let mockTrackingService;
  let mockModalService;
  const mockQuestionnaireService = { llc: { entityName: 'llcEntity', entityState: 'California', lzRA: '' } };
  const seadOptins = { RA: 'register-agent' };
  const RA = { price: '249' };
  const mockModalRef = {
    componentInstance: {},
    result: Promise.resolve({})
  };
  @Component({
    selector: 'app-cta-button',
    template: '<div></div>'
  })
  class FakeCtabutton {
    @Input() type = 'button';
    @Input() disabled = false;
    @Input() noIcon = false;
  }

  beforeEach(async(() => {
    mockSeadService = jasmine.createSpyObj(['addOptin', 'removeOptin', 'seadOptins']);
    mockProductDefination = jasmine.createSpyObj(['RA']);
    mockEventService = jasmine.createSpyObj(['saveAndContinue']);
    mockTrackingService = jasmine.createSpyObj(['triggerClickTrack']);
    TestBed.configureTestingModule({
      imports: [BrowserAnimationsModule],
      declarations: [RegisteredAgentComponent, FakeCtabutton, InfoPanelComponent],
      providers: [
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: ConstantsService, useValue: mockConstantService },
        { provide: SEADService, useValue: mockSeadService },
        { provide: ProductDefinitionService, useValue: mockProductDefination },
        { provide: ExperimentsService, useValue: mockExperimentService },
        { provide: EventService, useValue: mockEventService },
        { provide: TrackingService, useValue: mockTrackingService },
        NgbModal
      ]
    })
      .compileComponents();
    mockSeadService.seadOptins = seadOptins;
    mockProductDefination.RA.and.returnValue(RA);
    mockModalService = TestBed.get(NgbModal);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisteredAgentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create registered agent component', () => {
    expect(component).toBeTruthy();
  });

  it('isRARequired, entityName,  should have value', () => {
    expect(component.isRARequired).not.toBeNull();
    expect(component.entityName).not.toBeNull();
  });

  it('continue with legalzoom button should acceptRaOffer method', () => {
    spyOn(component, 'acceptRaOffer');
    const continueWithLZButton = fixture.debugElement.query(By.css('#btn-accept-1')).nativeElement;
    continueWithLZButton.click();
    expect(component.acceptRaOffer).toHaveBeenCalled();
  });

  it('acceptRaOffer method should call save and continue from event service', async(() => {
    component.acceptRaOffer(true);
    fixture.whenStable().then(() => {
      expect(mockSeadService.addOptin).toHaveBeenCalled();
      expect(mockEventService.saveAndContinue).toHaveBeenCalled();
    });
  }));
  it('acceptRaOffer method should call modalService.open if package not selected', async(() => {
    mockModalRef.result = Promise.resolve({ Response: 'Success' });
    spyOn(mockModalService, 'open').and.returnValue(mockModalRef);
    component.acceptRaOffer(false);
    fixture.whenStable().then(() => {
      expect(mockModalService.open).toHaveBeenCalled();
    });
  }));

  it('toggleTermsTop should change the value of showTermsTop', () => {
    component.showTermsTop = false;
    component.toggleTermsTop();
    expect(component.showTermsTop).toBe(true);
  });

  it('toggleTermsBottom should change the value of showTermsTop', () => {
    component.showTermsBottom = false;
    component.toggleTermsBottom();
    expect(component.showTermsBottom).toBe(true);
  });
  
  it('should triggerClickTrack', () => {
    spyOn(component.moreInfo, 'open');
    component.openInfoPanel();
    expect(component.moreInfo.open).toHaveBeenCalled();
    expect(mockTrackingService.triggerClickTrack).toHaveBeenCalled();
  });
});
