import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CriticalDocumentsComponent } from './critical-documents.component';
import { RouterTestingModule } from '@angular/router/testing';
import { ReactiveFormsModule, FormsModule, FormBuilder } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedComponentsModule } from 'src/app/shared/components/shared-components.module';
import { TextMaskModule } from 'angular2-text-mask';
import { EventService } from 'src/app/shared/services/event.service';
import { WindowRef } from 'src/app/shared/services/windowRef.service';
import { HttpClient } from '@angular/common/http';
import { SEADService } from 'src/app/shared/services/tracking/sead.service';
import { CookieService } from 'ngx-cookie';
import { QuestionnaireService } from 'src/app/shared/services/questionnaire/questionnaire.service';
import { ProductDefinitionService } from 'src/app/shared/services/product-definition/product-definition.service';
import { PageScrollService } from 'ngx-page-scroll';
import { Component } from '@angular/core';
import { TrackingService } from '../../../../shared/services/tracking/tracking.service';

describe('CriticalDocumentsComponent', () => {
  let component: CriticalDocumentsComponent;
  let fixture: ComponentFixture<CriticalDocumentsComponent>;
  let mockCookieService;
  let mockProductDefinitionService;
  let mockEventService;
  let mockSeadService;
  let mockQuestionnaireService;
  let mockTrackingService;

  @Component({
    selector: 'app-cta-button',
    template: '<div></div>'
  })
  class FakeButtonComponent {
  }

  @Component({
    selector: 'app-info-panel',
    template: '<div></div>'
  })
  class FakeInfoPanelComponent {
  }

  const llc: any = {
    isBusinessNameAvailable: true,
    isChooseNameLater: true,
    entityName: 'ABC',
    documentsPackage: 'ABC'
  };
  const seadOptins = {
    OA: 'operating-agreement',
    OA_EIN: 'operating-agreement-and-federal-taxid',
    OA_EIN_LICENCES: 'operating-agreement-federal-taxid-and-licenses'
  };
  const essentialDocs = {
    basic: {
      title: 'Operating Agreement',
      price: '$99',
      body: `An operating agreement is critical: it's your LLC's constitution.`

    },
    standard: {
      title: 'Operating Agreement and EIN',
      price: '$159',
      body: 'An EIN is required to open a business bank account.'
    },
    recommended: {
      title: 'Operating Agreement, EIN, and Licenses',
      price: '$249',
      body: 'This provides the key documents your LLC needs at an affordable price. State and local licenses are required to run your business. <a href="javascript:">Read more details.</a>'

    }
  };
  beforeEach(async(() => {
    mockCookieService = jasmine.createSpyObj(['put', 'get']);
    mockSeadService = jasmine.createSpyObj(['removeOptin', 'addOptin', 'seadOptins']);
    mockSeadService.seadOptins = seadOptins;
    mockProductDefinitionService = jasmine.createSpyObj(['ESSENTIAL_DOCS_PKGS']);
    mockQuestionnaireService = jasmine.createSpyObj(['setQuestionnaire', 'llc']);
    mockQuestionnaireService.llc = llc;
    mockEventService = jasmine.createSpyObj(['saveAndContinue']);
    mockTrackingService = jasmine.createSpyObj(['triggerClickTrack']);
    mockProductDefinitionService.ESSENTIAL_DOCS_PKGS.and.returnValue(essentialDocs);
    TestBed.configureTestingModule({
      declarations: [CriticalDocumentsComponent, FakeButtonComponent, FakeInfoPanelComponent],
      imports: [RouterTestingModule,
        ReactiveFormsModule,
        HttpClientTestingModule,
        NgbModule,
        SharedComponentsModule,
        TextMaskModule, FormsModule],
      providers: [
        FormBuilder,
        { provide: EventService, useValue: mockEventService },
        WindowRef,
        HttpClient,
        PageScrollService,
        { provide: SEADService, useValue: mockSeadService },
        { provide: CookieService, useValue: mockCookieService },
        { provide: ProductDefinitionService, useValue: mockProductDefinitionService },
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: TrackingService, useValue: mockTrackingService }
      ]
    })
      .compileComponents();
    fixture = TestBed.createComponent(CriticalDocumentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));
  it('should create critical document component', () => {
    expect(component).toBeTruthy();
  });

  it('entityName should not be null ', () => {
    expect(component.entityName).toBe('ABC');
  });

  it('ItemList should not be null ', () => {
    expect(component.itemList[0].optin).toBe('OA_EIN_LICENCES');
  });

  it('sead service addOptin have been called ', () => {
    component.onItemChange('OA_EIN_LICENCES');
    expect(mockSeadService.addOptin).toHaveBeenCalled();
    expect(mockSeadService.removeOptin).toHaveBeenCalled();
  });

  it('sead service removeOptin have been called ', () => {
    component.onItemChange('no');
    expect(mockSeadService.addOptin).toHaveBeenCalled();
    expect(mockSeadService.removeOptin).toHaveBeenCalled();
  });

  it('event service saveAndContinue have been called ', () => {
    component.onItemChange('OA_EIN_LICENCES');
    expect(mockEventService.saveAndContinue).toHaveBeenCalled();
  });

  it('save should call saveAndContinue from event service ', () => {
    component.save();
    expect(mockEventService.saveAndContinue).toHaveBeenCalled();
  });

  it('should click on #rd-docs-3', async(() => {
    spyOn(component, 'onItemChange');

    const button = fixture.debugElement.nativeElement.querySelector('#rd-docs-3');
    button.click();

    fixture.whenStable().then(() => {
      expect(component.onItemChange).toHaveBeenCalled();
    });
  }));

  it('should click on #rd-docs-2', async(() => {
    spyOn(component, 'onItemChange');

    const button = fixture.debugElement.nativeElement.querySelector('#rd-docs-2');
    button.click();

    fixture.whenStable().then(() => {
      expect(component.onItemChange).toHaveBeenCalled();
    });
  }));

  it('should click on #rd-docs-1', async(() => {
    spyOn(component, 'onItemChange');

    const button = fixture.debugElement.nativeElement.querySelector('#rd-docs-1');
    button.click();

    fixture.whenStable().then(() => {
      expect(component.onItemChange).toHaveBeenCalled();
    });
  }));

  it('should save with \'OA\' into questionnaireService', () => {
    component.onItemChange('OA');
    expect(component.questionnaireService.llc.documentsPackage).toBe('OA');
  });

  it('should save with \'OA_EIN\' into questionnaireService', () => {
    component.onItemChange('OA_EIN');
    expect(component.questionnaireService.llc.documentsPackage).toBe('OA_EIN');
  });

  it('should save with \'OA_EIN_LICENCES\' into questionnaireService', () => {
    component.onItemChange('OA_EIN_LICENCES');
    expect(component.questionnaireService.llc.documentsPackage).toBe('OA_EIN_LICENCES');
  });

});
