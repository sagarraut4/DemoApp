import { Component, OnInit, ViewChild } from '@angular/core';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { BusinessLicensesComponent } from '../../modals/business-licenses/business-licenses.component';
import { PagePath } from '../../../../shared/models/page-model';
import { SEADService } from '../../../../shared/services/tracking/sead.service';
import { EventService } from '../../../../shared/services/event.service';
import { InfoPanelComponent } from '../../shared/components/info-panel/info-panel.component';
import { TrackingService } from '../../../../shared/services/tracking/tracking.service';
import { FormBuilder, FormGroup } from '@angular/forms';


@Component({
  selector: 'app-critical-documents',
  templateUrl: './critical-documents.component.html',
  styleUrls: ['./critical-documents.component.scss']
})
export class CriticalDocumentsComponent implements OnInit {
  // tracking data attribute
  public entityName: string;
  public currentSelection: string;
  public form: FormGroup;

  get shouldShowNextButton(): boolean {
    return this.questionnaireService.llc.isMobile
      && this.questionnaireService.llc.documentsPackage
      && this.questionnaireService.llc.documentsPackage !== 'NO';
  }

  @ViewChild('moreInfo', {static: false}) moreInfo: InfoPanelComponent;
  itemList = [];

  constructor(
    public questionnaireService: QuestionnaireService,
    private modalService: NgbModal,
    public seadService: SEADService,
    private eventService: EventService,
    private trackingService: TrackingService,
    private formBuilder: FormBuilder
  ) {
    this.form = this.formBuilder.group({
      optin: [this.questionnaireService.llc.documentsPackage],
    });
   }

  ngOnInit() {
    this.entityName = this.questionnaireService.llc.entityName;
    this.currentSelection = this.questionnaireService.llc.documentsPackage;

    this.itemList = [{
      optin: 'OA_EIN_LICENCES',
      title: 'Operating agreement, EIN, and licenses',
      price: 199,
      description: 'Key documents—including help with required federal, state and local permits and licenses.',
    }, {
      optin: 'OA_EIN',
      title: 'Operating agreement plus EIN',
      price: 159,
      description: 'EIN is required, without it you can’t file taxes or open a bank account.',
    }, {
      optin: 'OA',
      title: 'Operating agreement',
      price: 99,
      description: 'An operating agreement is essential—it’s the constitution for your business.',
    }];
  }

  readMore(): void {
    this.modalService.open(BusinessLicensesComponent, { size: 'lg' });
  }

  onItemChange(input: string): void {

    // this block handles when a checked item is clicked again.
    if(input === this.currentSelection) {
      this.seadService.removeOptin(this.seadService.seadOptins.OA);
      this.seadService.removeOptin(this.seadService.seadOptins.OA_EIN);
      this.seadService.removeOptin(this.seadService.seadOptins.OA_EIN_LICENCES);
      this.questionnaireService.llc.documentsPackage = '';
      this.currentSelection = '';
      return;
    }

    this.currentSelection = input;
    this.questionnaireService.llc.documentsPackage = input;

    if (input === 'NO') {
      // lets just remove any OA package
      this.seadService.removeOptin(this.seadService.seadOptins.OA);
      this.seadService.removeOptin(this.seadService.seadOptins.OA_EIN);
      this.seadService.removeOptin(this.seadService.seadOptins.OA_EIN_LICENCES);
      this.eventService.saveAndContinue(PagePath.CriticalDocuments);
    } else {
      // lets just remove any OA package still to just clean it up and
      // add the newly selected package after
      this.seadService.removeOptin(this.seadService.seadOptins.OA);
      this.seadService.removeOptin(this.seadService.seadOptins.OA_EIN);
      this.seadService.removeOptin(this.seadService.seadOptins.OA_EIN_LICENCES);
      // add our selected package now or again, we don't need the over head of checking if it exists or not KISS
      this.seadService.addOptin(this.seadService.seadOptins[input]);

      if (!this.questionnaireService.llc.isMobile) {
        this.eventService.saveAndContinue(PagePath.CriticalDocuments);
      }
    }
  }

  save(): void {
    this.eventService.saveAndContinue(PagePath.CriticalDocuments);
  }

  onClickModalLink($event) {
    $event.preventDefault();
    this.trackingService.triggerClickTrack('llc_flow', 'essential_docs_more_info_link');
    this.moreInfo.open();
  }

}
