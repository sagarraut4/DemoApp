import { PackageService } from '../../../../shared/services/package.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ReactiveFormsModule, FormsModule, FormBuilder } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedComponentsModule } from 'src/app/shared/components/shared-components.module';
import { TextMaskModule } from 'angular2-text-mask';
import { Component } from '@angular/core';
import { CookieService } from 'ngx-cookie';
import { QuestionnaireService } from 'src/app/shared/services/questionnaire/questionnaire.service';
import { EventService } from 'src/app/shared/services/event.service';
import { SEADService } from 'src/app/shared/services/tracking/sead.service';
import { PageScrollService } from 'ngx-page-scroll';
import { ProductDefinitionService } from 'src/app/shared/services/product-definition/product-definition.service';
import { of } from 'rxjs';
import { ProtectPersonalAssetsComponent } from './protect-personal-assets.component';
import { TrackingService } from '../../../../shared/services/tracking/tracking.service';
import { By } from '@angular/platform-browser';

describe('ProtectPersonalAssetsComponent', () => {
  let component: ProtectPersonalAssetsComponent;
  let fixture: ComponentFixture<ProtectPersonalAssetsComponent>;
  let mockQuestionnaireService;
  let mockProductDefService;
  let mockSeadService;
  let mockEventService;
  let mockCookieService;
  let mockPackageService;
  let mockTrackingService;

  const llc: any = {
    isBusinessNameAvailable: true,
    isChooseNameLater: true,
    entityName: 'ABC',
    entityState: 'Alaska',
    protectAssets: true
  };
  const compliance = {
    daysInTrial: '10',
    name: 'Total Compliance',
    price: '$280'
  };
  const seadOptins = {
    OA: 'operating-agreement',
    OA_EIN: 'operating-agreement-and-federal-taxid',
    OA_EIN_LICENCES: 'operating-agreement-federal-taxid-and-licenses',
    BUSINESS_TAX_PLAN: 'affordable-tax',
    BUSINESS_LEGAL_PLAN: 'legal-protect'
  };
  @Component({
    selector: 'app-cta-button',
    template: '<div></div>'
  })
  class FakeButtonComponent {
  }
  @Component({
    selector: 'app-info-panel',
    template: '<div></div>'
  })
  class FakeInfoPanelComponent {
    open() { };
  }

  beforeEach(async(() => {
    mockCookieService = jasmine.createSpyObj(['put', 'get']);
    mockQuestionnaireService = jasmine.createSpyObj(['llc']);
    mockEventService = jasmine.createSpyObj(['saveAndContinue']);
    mockProductDefService = jasmine.createSpyObj(['COMPLIANCE']);
    mockPackageService = jasmine.createSpyObj(['getPackages']);
    mockSeadService = jasmine.createSpyObj(['addOptin', 'removeOptin', 'seadOptins']);
    mockTrackingService = jasmine.createSpyObj('Tracking Service', ['triggerClickTrack'])
    mockSeadService.seadOptins = seadOptins;
    mockQuestionnaireService.llc = llc;
    mockProductDefService.COMPLIANCE.and.returnValue(of(compliance));
    TestBed.configureTestingModule({
      declarations: [ProtectPersonalAssetsComponent, FakeInfoPanelComponent, FakeButtonComponent],
      imports: [RouterTestingModule,
        ReactiveFormsModule,
        HttpClientTestingModule,
        NgbModule,
        SharedComponentsModule,
        TextMaskModule, FormsModule],
      providers: [
        { provide: ProductDefinitionService, useValue: mockProductDefService },
        { provide: CookieService, useValue: mockCookieService },
        { provide: SEADService, useValue: mockSeadService },
        { provide: EventService, useValue: mockEventService },
        { provide: PackageService, useValue: mockPackageService },
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: TrackingService, useValue: mockTrackingService },
        PageScrollService
      ]
    }).compileComponents().then(() => {
      fixture = TestBed.createComponent(ProtectPersonalAssetsComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });
  }));

  it('it should create ProtectPersonalAssetsComponent', () => {
    expect(component).toBeTruthy();
  });

  it('compliance, entityName, entityState should have values', () => {
    expect(component.compliance).not.toBeNull();
    expect(component.entityName).toBe('ABC');
    expect(component.entityState).toBe('Alaska');
  });

  it('addOptin should have been called', () => {
    component.save(true);
    expect(mockSeadService.addOptin).toHaveBeenCalled();
    expect(mockEventService.saveAndContinue).toHaveBeenCalled();
  });

  it('removeOptin should have been called', () => {
    component.save(false);
    expect(mockSeadService.removeOptin).toHaveBeenCalled();
    expect(mockEventService.saveAndContinue).toHaveBeenCalled();
  });

  it('isLoading should be false', () => {
    TestBed.get(PackageService).packageConfigurations = {
      lstAvailablePackageConfigurations: {
        BasePrice: 99,
        ExtendedPrice: 100,
        StateId: 1,
        ConfigurationID: 2
      },
      SelectedConfiguration: 1
    };
    component.save(false);
    expect(component.isLoading).toBeFalsy();
  });

  it(' Take my included trial button click should call save method with true value', () => {
    spyOn(component, 'save');
    const saveButton = fixture.debugElement.query(By.css('#btn-accept-1')).nativeElement;
    saveButton.click();
    expect(component.save).toHaveBeenCalledWith(true)
  });
  it(' No thanks button click should call save method with false value', () => {
    spyOn(component, 'save');
    const saveButton = fixture.debugElement.query(By.css('#btn-decline-2')).nativeElement;
    saveButton.click();
    expect(component.save).toHaveBeenCalledWith(false)
  });

  it('view terms click should call toggleDisclaimer method ', () => {
    spyOn(component, 'toggleDisclaimer');
    const viewTerms = fixture.debugElement.query(By.css('#view-terms')).nativeElement;
    viewTerms.click();
    expect(component.toggleDisclaimer).toHaveBeenCalled();
  });

  it('view terms click should call toggleDisclaimer method and change the value for showDisclaimer to show disclaimer ', () => {
    const saveButton = fixture.debugElement.query(By.css('#view-terms')).nativeElement;
    saveButton.click();
    expect(component.showDisclaimer).toBe(true);
  });

  // TODO: fix test
  xit('more info click should call openInfoPanel method', () => {
    spyOn(component, 'openInfoPanel');
    const moreInfoBtn = fixture.debugElement.query(By.css('#more-info-button')).nativeElement;
    moreInfoBtn.click();
    expect(component.openInfoPanel).toHaveBeenCalled();
  });

  // TODO: fix test
  xit('more info click should call openInfoPanel method and track data', () => {
    spyOn(component.moreInfo, 'open');
    const moreInfoBtn = fixture.debugElement.query(By.css('#more-info-button')).nativeElement;
    moreInfoBtn.click();
    expect(mockTrackingService.triggerClickTrack).toHaveBeenCalled();
  });
});
