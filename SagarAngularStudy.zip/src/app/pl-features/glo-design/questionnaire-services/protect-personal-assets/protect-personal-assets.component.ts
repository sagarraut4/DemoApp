import { Component, OnInit, ViewChild } from '@angular/core';
import { QuestionnaireService } from '../../../../../app/shared/services/questionnaire/questionnaire.service';
import { PagePath } from '../../../../shared/models/page-model';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ExperimentsService } from '../../../../shared/services/experiments/experiments.service';
import { ProductDefinitionService } from '../../../../shared/services/product-definition/product-definition.service';
import { SEADService } from '../../../../shared/services/tracking/sead.service';
import { ConstantsService } from '../../../../shared/services/constants.service';
import { EventService } from '../../../../shared/services/event.service';
import { PackageService } from '../../../../shared/services/package.service';
import { InfoPanelComponent } from '../../shared/components/info-panel/info-panel.component';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { TrackingService } from '../../../../shared/services/tracking/tracking.service';

@Component({
  selector: 'app-protect-personal-assets',
  templateUrl: './protect-personal-assets.component.html',
  styleUrls: ['./protect-personal-assets.component.scss']
})
export class ProtectPersonalAssetsComponent implements OnInit {
  public isCollapsed = false;
  public showDisclaimer = false;
  public entityState: string;
  public compliance: any;
  public isLoading: boolean;
  public entityName: string;
  public isMobile = true;

  @ViewChild('moreInfo', {static: false}) moreInfo: InfoPanelComponent;

  constructor(
    public questionnaireService: QuestionnaireService,
    private seadService: SEADService,
    private modalService: NgbModal,
    private productDefService: ProductDefinitionService,
    private packageService: PackageService,
    public eventService: EventService,
    private breakpointObserver: BreakpointObserver,
    private trackingService: TrackingService

  ) {
    const size = '(min-width: 768px)';

    breakpointObserver.observe([
      size
    ]).subscribe(result => {
      if (result.matches) {
        this.isMobile = false;
      } else {
        this.isMobile = true;
      }
    });
  }

  ngOnInit() {
    this.compliance = this.productDefService.COMPLIANCE();
    this.entityName = this.questionnaireService.llc.entityName;
    this.entityState = this.questionnaireService.llc.entityState;
  }

  toggleDisclaimer(): void {
    this.showDisclaimer = !this.showDisclaimer;
  }

  save(protectAssets: boolean): void {
    this.questionnaireService.llc.totalCompliance = protectAssets;

    if (protectAssets) {
      this.seadService.addOptin(this.seadService.seadOptins.COMPLIANCE_FULL);
    } else {
      this.seadService.removeOptin(this.seadService.seadOptins.COMPLIANCE_FULL);
    }

    this.eventService.saveAndContinue(PagePath.Compliance);

    if (this.packageService.packageConfigurations === null || this.packageService.packageConfigurations === undefined) {
      this.showBusy(true);
    }
  }

  showBusy(show: boolean): void {
    this.isLoading = show;
  }

  public openInfoPanel() {
    this.trackingService.triggerClickTrack('llc_flow', 'total_compliance_more_info_link');
    this.moreInfo.open();
  }
}
