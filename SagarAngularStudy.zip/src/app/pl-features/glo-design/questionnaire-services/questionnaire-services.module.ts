import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ExtrasComponent } from './extras/extras.component';
import { ProtectPersonalAssetsComponent } from './protect-personal-assets/protect-personal-assets.component';
import { LegalSupportComponent } from './legal-support/legal-support.component';
import { SharedComponentsModule } from '../../../shared/components/shared-components.module';
import { CoreModule } from '../../../core/core.module';
import { GloComponentsModule } from '../shared/components/glo-components.module';

@NgModule({
  imports: [
    CommonModule,
    CoreModule,
    NgbModule,
    ReactiveFormsModule,
    SharedComponentsModule,
    GloComponentsModule
  ],
  providers: [],
  declarations: [
    ExtrasComponent,
    ProtectPersonalAssetsComponent,
    LegalSupportComponent,
  ],
  exports: [
    ExtrasComponent,
    ProtectPersonalAssetsComponent,
    LegalSupportComponent,
  ]
})
export class QuestionnaireServicesModule { }
