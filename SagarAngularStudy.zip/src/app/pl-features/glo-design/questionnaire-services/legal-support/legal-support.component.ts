import { Component, OnInit, ViewChild } from '@angular/core';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { PagePath } from '../../../../shared/models/page-model';
import { SEADService } from '../../../../shared/services/tracking/sead.service';
import { EventService } from '../../../../shared/services/event.service';
import { InfoPanelComponent } from '../../shared/components/info-panel/info-panel.component';

@Component({
  selector: 'app-legal-support',
  templateUrl: './legal-support.component.html',
  styleUrls: ['./legal-support.component.scss']
})
export class LegalSupportComponent implements OnInit {
  public showTermsTop: boolean;
  public entityName: string;
  public showWIPrice: boolean;
  @ViewChild('moreInfo', {static: false}) moreInfo: InfoPanelComponent;

  constructor(
    public questionnaireService: QuestionnaireService,
    private seadService: SEADService,
    private eventService: EventService
  ) { }

  ngOnInit() {

    this.showTermsTop = false;
    this.entityName = this.questionnaireService.llc.entityName;
    if (this.questionnaireService.llc.entityState === 'Wisconsin') {
      this.showWIPrice = true;
    } else {
      this.showWIPrice = false;
    }
  }

  toggleTermsTop(): void {
    this.showTermsTop = !this.showTermsTop;
  }

  save(input: boolean): void {
    this.questionnaireService.llc.legalAdvice = input;
    if (input) {
      this.seadService.addOptin(this.seadService.seadOptins.BUSINESS_LEGAL_PLAN);
    } else {
      this.seadService.removeOptin(this.seadService.seadOptins.BUSINESS_LEGAL_PLAN);
    }
    this.eventService.saveAndContinue(PagePath.Legal);
  }
}
