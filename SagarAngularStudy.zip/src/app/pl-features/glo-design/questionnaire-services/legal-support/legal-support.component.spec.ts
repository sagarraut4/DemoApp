import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LegalSupportComponent } from './legal-support.component';
import { RouterTestingModule } from '@angular/router/testing';
import { ReactiveFormsModule, FormsModule, FormBuilder } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedComponentsModule } from 'src/app/shared/components/shared-components.module';
import { TextMaskModule } from 'angular2-text-mask';
import { WindowRef } from 'src/app/shared/services/windowRef.service';
import { QuestionnaireRoutingService } from 'src/app/shared/services/questionnaire-routing/questionnaire-routing.service';
import { HttpClient } from '@angular/common/http';
import { CookieService } from 'ngx-cookie';
import { QuestionnaireService } from 'src/app/shared/services/questionnaire/questionnaire.service';
import { ExperimentsService } from 'src/app/shared/services/experiments/experiments.service';
import { EventService } from 'src/app/shared/services/event.service';
import { SEADService } from 'src/app/shared/services/tracking/sead.service';
import { PageScrollService } from 'ngx-page-scroll';
import { By } from '@angular/platform-browser';
import { MockComponent } from 'ng-mocks';
import { CtaButtonComponent } from '../../shared/components/cta-button/cta-button.component';
import { InfoPanelComponent } from '../../shared/components/info-panel/info-panel.component';

describe('LegalSupportComponent', () => {
  let component: LegalSupportComponent;
  let fixture: ComponentFixture<LegalSupportComponent>;
  let mockQuestionnaireService, mockSeadService, mockEventService, mockCookieService;
  const llc: any = {
    isBusinessNameAvailable: true,
    isChooseNameLater: true,
    entityName: 'ABC',
    entityState: 'Alaska'
  };
  const seadOptins = {
    OA: 'operating-agreement',
    OA_EIN: 'operating-agreement-and-federal-taxid',
    OA_EIN_LICENCES: 'operating-agreement-federal-taxid-and-licenses',
    BUSINESS_TAX_PLAN: 'affordable-tax',
    BUSINESS_LEGAL_PLAN: 'legal-protect'
  };
  beforeEach(async(() => {
    mockCookieService = jasmine.createSpyObj(['put', 'get']);
    mockQuestionnaireService = jasmine.createSpyObj(['llc']);
    mockEventService = jasmine.createSpyObj(['saveAndContinue']);
    mockSeadService = jasmine.createSpyObj(['addOptin', 'removeOptin', 'seadOptins']);
    mockSeadService.seadOptins = seadOptins;
    mockQuestionnaireService.llc = llc;
    TestBed.configureTestingModule({
      declarations: [LegalSupportComponent, MockComponent(CtaButtonComponent), MockComponent(InfoPanelComponent)],
      imports: [RouterTestingModule,
        ReactiveFormsModule,
        HttpClientTestingModule,
        NgbModule,
        SharedComponentsModule,
        TextMaskModule, FormsModule],
      providers: [
        FormBuilder,
        WindowRef,
        QuestionnaireRoutingService,
        HttpClient,
        ExperimentsService,
        PageScrollService,
        { provide: CookieService, useValue: mockCookieService },
        { provide: SEADService, useValue: mockSeadService },
        { provide: EventService, useValue: mockEventService },
        { provide: QuestionnaireService, useValue: mockQuestionnaireService }
      ]
    }).compileComponents().then(() => {
      fixture = TestBed.createComponent(LegalSupportComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('showWIPrice should be true', () => {
    const questionnarieService = TestBed.get(QuestionnaireService);
    questionnarieService.llc.entityState = 'Wisconsin';
    component.ngOnInit();
    expect(component.showWIPrice).toBeTruthy();
  });
  it('showWIPrice should be false', () => {
    const questionnarieService = TestBed.get(QuestionnaireService);
    questionnarieService.llc.entityState = 'Alaska';
    component.ngOnInit();
    expect(component.showWIPrice).toBeFalsy();
  });
  it('addOptin should have been called', () => {
    component.save(true);
    expect(mockSeadService.addOptin).toHaveBeenCalled();
    expect(mockEventService.saveAndContinue).toHaveBeenCalled();
  });
  it('removeOptin should have been called', () => {
    component.save(false);
    expect(mockSeadService.removeOptin).toHaveBeenCalled();
    expect(mockEventService.saveAndContinue).toHaveBeenCalled();
  });
  it('showTermsTop should be true', () => {
    component.showTermsTop = false;
    component.toggleTermsTop();
    expect(component.showTermsTop).toBeTruthy();
  });

  it('No Thanks button should call save method with false value', () => {
    spyOn(component, 'save');
    const noThanksBtn = fixture.debugElement.query(By.css('#btn-decline-1')).nativeElement;
    // Act
    noThanksBtn.click();
    // Assert
    expect(component.save).toHaveBeenCalledWith(false);
  });

  it('Take my included trial button should call save method with true value', () => {
    spyOn(component, 'save');
    const trialBtn = fixture.debugElement.query(By.css('#btn-accept-1')).nativeElement;
    // Act
    trialBtn.click();
    // Assert
    expect(component.save).toHaveBeenCalledWith(true);
  });

});
