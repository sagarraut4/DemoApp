import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { LLC } from '../../../../shared/models/questionnaire-model';
import { ExtrasComponent } from './extras.component';
import { EventService } from '../../../../shared/services/event.service';
import { Component } from '@angular/core';
import { By } from '@angular/platform-browser';

describe('ExtrasComponent', () => {
  let component: ExtrasComponent;
  let fixture: ComponentFixture<ExtrasComponent>;
  const mockQuestionnaireService = {
    llc: {
      entityName: 'abc'
    }
  };

  @Component({
    selector: 'app-cta-button',
    template: '<div></div>'
  })
  class FakeButtonComponent {
  }
  const mockEventService = jasmine.createSpyObj(['saveAndContinue']);
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ExtrasComponent, FakeButtonComponent],
      providers: [
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: EventService, useValue: mockEventService }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExtrasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create extras component', () => {
    expect(component).toBeTruthy();
  });

  it('should have value for entityName', () => {
    expect(component.entityName).toBe('abc');
  });

  it('save method should get called with saveAndContinue method of eventService', () => {
    component.save();
    expect(mockEventService.saveAndContinue).toHaveBeenCalled();
  });

  it('next button click should call save method', () => {
    const saveButton = fixture.debugElement.query(By.css('#btn-next')).nativeElement;
    saveButton.click();
    expect(mockEventService.saveAndContinue).toHaveBeenCalled()
});
});
