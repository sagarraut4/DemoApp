import { Component, OnInit } from '@angular/core';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { PagePath } from '../../../../shared/models/page-model';
import { EventService } from '../../../../shared/services/event.service';
import {BreakpointObserver} from '@angular/cdk/layout';

@Component({
  selector: 'app-extras',
  templateUrl: './extras.component.html',
  styleUrls: ['./extras.component.scss']
})
export class ExtrasComponent implements OnInit {
  public entityName: string;
  public isMobile = true;

  constructor(
    public questionnaireService: QuestionnaireService,
    private eventService: EventService,
    private breakpointObserver: BreakpointObserver
  ) {
    const size = '(min-width: 768px)';

    breakpointObserver.observe([
      size
    ]).subscribe(result => {
      this.isMobile = !result.matches;
    });
  }

  ngOnInit() {
    this.entityName = this.questionnaireService.llc.entityName;
  }

  save(): void {
    this.eventService.saveAndContinue(PagePath.Extras);
  }
}
