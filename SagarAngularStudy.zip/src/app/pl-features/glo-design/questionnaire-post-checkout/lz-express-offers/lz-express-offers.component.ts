import { BannerService } from './../../shared/services/banner.service';
import { AfterViewInit, Component, OnDestroy, OnInit, Renderer2 } from '@angular/core';
import { PagePath } from '../../../../shared/models/page-model';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { TrackingService } from '../../../../shared/services/tracking/tracking.service';
import { ProductConfigurationIds } from '../../../../shared/models/cart-model';
import { UtilityService } from '../../../../shared/services/utility.service';
import { CrossSellService } from '../../../../shared/services/cross-sell.service';
import { EventService } from '../../../../shared/services/event.service';
import { AppService } from '../../../../../app/shared/state/app/app.service';
import { ReplaySubject, Subscription } from 'rxjs';

@Component({
  selector: 'app-desktop-lz-express-offers',
  templateUrl: './lz-express-offers.component.html',
  styleUrls: ['./lz-express-offers.component.scss']
})
export class LzExpressOffersComponent implements OnInit, AfterViewInit, OnDestroy {
  public paidOrPaying: boolean;
  public packageSelected: string;
  private bannerHeightSubject: ReplaySubject<number>;
  private bannerHeightSubscription: Subscription;
  private agreeAndPayButton: HTMLElement;
  private taxPlanOrder = this.appService.app.crossSellOrderResponse;
  public isMobile = this.questionnaireService.llc.isMobile ? true : false;
  itemList = [];
  public isShowTM = false;

  constructor(
    public questionnaireService: QuestionnaireService,
    private trackingService: TrackingService,
    private utilityService: UtilityService,
    private crossSellService: CrossSellService,
    private eventService: EventService,
    private bannerService: BannerService,
    private renderer: Renderer2,
    private appService: AppService,
  ) { }

  ngOnInit() {
    this.isShowTM = !(this.questionnaireService.llc.packageSelected === ProductConfigurationIds.attrAssistPremiumLLC);
    this.itemList = [{
      id: 'express-both',
      title: 'Will & Trademark Search',
      price: 148,
      usuallyPrice: 288,
      isVisisble: this.isShowTM,
      descriptionList: [
        'Protect your legacy with a will.',
        'Kickstart the trademark process with a federal trademark search.',
        `Save $140 off our usual price. One time only.`,
      ],
    }, {
      id: 'express-tms',
      title: 'Start a Trademark Search',
      price: 99,
      usuallyPrice: 199,
      isVisisble: this.isShowTM,
      descriptionList: [
        'As you launch your LLC, conducting a federal trademark search is the first step in protecting your business name as a brand.',
        'Our comprehensive trademark search report sorts and ranks results to make it easier to review and understand.',
        `Check if ${this.questionnaireService.llc.entityName || 'your business name'} is available as a federal trademark.`,
      ],
    }, {
      id: 'express-lwt',
      title: 'Make a Will',
      price: 49,
      usuallyPrice: 89,
      isVisisble: true,
      descriptionList: [
        'Your business is an asset. Make sure your family or partner inherits it by creating a will.',
        'Your business (and your family) will thank you for not procrastinating.',
        '$40 off our regular price. Only for new LLC customers.',
      ],
    }];
    this.packageSelected = !this.isShowTM ? 'express-lwt': undefined;
    this.trackingService.SetGA_Arrays(PagePath.ExpressOffersPage);
    if (this.taxPlanOrder) { this.sendTaxConversion(); }
    this.utilityService.requestIsUSCustomer().subscribe();
    this.crossSellService.newSkuArray = [];
  }

  ngAfterViewInit() {
    
    this.bannerHeightSubject = this.bannerService.getBannerHeight(this.renderer);
    this.agreeAndPayButton = document.getElementById('btn-accept-1');

    if (this.isMobile) {

      this.bannerHeightSubscription = this.bannerHeightSubject.subscribe(bannerHeight => {

        this.setAgreeAndPayButtonPosition(bannerHeight);

        if (this.bannerHeightSubscription && bannerHeight === 0) {

          this.bannerHeightSubscription.unsubscribe();
        }
      });
    }
  }

  private setAgreeAndPayButtonPosition(bannerHeight: number = 0) {
    this.agreeAndPayButton.style.marginBottom = `${bannerHeight}px`;
    this.setContentScrollWithBanner(bannerHeight);
  }

  private sendTaxConversion() {
    const { productConfigurationId, productName, amount, orderId } = this.taxPlanOrder;
    this.trackingService.sendConversionToGa([{
      sProductID: productConfigurationId,
      sProductName: productName,
      sRelationshipType: 'CrossSell',
      sAmount: amount,
    }], orderId, PagePath.ExpressOffersPage);
  }

  private setContentScrollWithBanner(bannerHeight: number = 0) {
    if (bannerHeight === 0) {
      const contentElement = document.getElementsByClassName('cf-body');
      if (contentElement.length > 0) {
        contentElement[0].setAttribute('style', 'padding-bottom:inherit;');
      }
    }
    else {
      const contentElement = document.getElementsByClassName('cf-body');
      if (contentElement.length > 0) {
        contentElement[0].setAttribute('style', 'padding-bottom:' + bannerHeight + 'px;overflow-x:visible;');
      }
    }
  }

  onClickItem(id: string) {
    this.packageSelected = this.packageSelected === id ? '' : id;
  }

  checkout(): void {
    this.paidOrPaying = true;
    this.crossSellService.newSkuArray = [];
    if (!['express-lwt', 'express-tms', 'express-both'].includes(this.packageSelected)) {
      this.paidOrPaying = false;
    }
    this.crossSellService.savePackage(this.packageSelected);
  }

  continue(): void {
    const win = this.trackingService.winRef.nativeWindow;
    if (win.oCMOrder !== undefined) {
      this.trackingService.ClearOAItems();
      win.oCMOrder.oaItems = win.oCMOrder.oaItems.concat(this.crossSellService.newSkuArray);
    }
    this.eventService.saveAndContinue(PagePath.ExpressOffersPage);
  }

  ngOnDestroy(): void {
    if (this.bannerHeightSubscription) {
      this.bannerHeightSubscription.unsubscribe();
    }
  }

}
