import { ProductConfigurationIds } from '../../../../shared/models/cart-model';
import { CrossSellPackages } from '../../../../shared/constants/cross-sell-packages';
import { UtilityService } from '../../../../shared/services/utility.service';
import { EventService } from '../../../../shared/services/event.service';
import { TrackingService } from '../../../../shared/services/tracking/tracking.service';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { LzExpressOffersComponent } from './lz-express-offers.component';
import { of } from 'rxjs';
import { By } from '@angular/platform-browser';
import { CrossSellService } from '../../../../shared/services/cross-sell.service';
import { COOKIE_OPTIONS, CookieModule, CookieService } from 'ngx-cookie';

// TODO: investigate why this test suite takes so long to execute
describe('LzExpressOffersComponent', () => {
  let component: LzExpressOffersComponent;
  let fixture: ComponentFixture<LzExpressOffersComponent>;
  let mockCrossSellService;
  const mockQuestionnaireService = {
    llc: {
      isChooseEntityNameLater: true,
      entityName: 'Test'
    }
  };
  const utag: any = {
    link() {
    }
  };
  const mockTrackingService = jasmine.createSpyObj(['winRef', 'SetGA_Arrays', 'ClearOAItems']);
  const mockEventService = jasmine.createSpyObj(['saveAndContinue']);
  const mockUtilityService = jasmine.createSpyObj(['requestIsUSCustomer']);
  const mockWindowRef = jasmine.createSpyObj(['nativeWindow', 'utag']);
  mockWindowRef.nativeWindow.utag = utag;
  mockTrackingService.winRef.nativeWindow = mockWindowRef.nativeWindow;

  beforeEach(async(() => {
    mockCrossSellService = jasmine.createSpyObj(['savePackage']);
    TestBed.configureTestingModule({
      declarations: [LzExpressOffersComponent],
      imports: [HttpClientTestingModule, CookieModule],
      providers: [
        { provide: CrossSellService, useValue: mockCrossSellService },
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: TrackingService, useValue: mockTrackingService },
        { provide: EventService, useValue: mockEventService },
        { provide: UtilityService, useValue: mockUtilityService },
        { provide: COOKIE_OPTIONS, useValue: {} },
        { provide: CookieService, useValue: {} }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LzExpressOffersComponent);
    component = fixture.componentInstance;
    mockUtilityService.requestIsUSCustomer.and.returnValue(of(true));
    fixture.detectChanges();
  });

  it('should create lz-express-offers component', () => {
    // Assert
    expect(component).toBeTruthy();
  });
  it('requestIsUSCustomer method should have been called while creating component', () => {
    // Assert
    expect(mockUtilityService.requestIsUSCustomer).toHaveBeenCalled();
  });
  it('SetGA_Arrays method should have been called while creating component', () => {
    // Assert
    expect(mockTrackingService.SetGA_Arrays).toHaveBeenCalled();
  });

  it('should call crossSellService.savePackage after selecting tms', async(() => {
    // Arrange
    spyOn(component, 'checkout');
    const expressTms = fixture.debugElement.query(By.css('#express-tms')).nativeElement;
    expressTms.click();
    const continueBtn = fixture.debugElement.query(By.css('#btn-accept')).nativeElement;
    // Act
    continueBtn.click();
    fixture.whenStable().then(() => {
      // Assert
      expect(component.checkout).toHaveBeenCalled();
    });
  }));
  it('should call crossSellService.savePackage after selecting lwt', async(() => {
    // Arrange
    spyOn(component, 'checkout');
    const expressTms = fixture.debugElement.query(By.css('#express-lwt')).nativeElement;
    expressTms.click();
    const continueBtn = fixture.debugElement.query(By.css('#btn-accept')).nativeElement;
    // Act
    continueBtn.click();
    fixture.whenStable().then(() => {
      // Assert
      expect(component.checkout).toHaveBeenCalled();
    });
  }));
  it('should call crossSellService.savePackage after selecting both', async(() => {
    // Arrange
    spyOn(component, 'checkout');
    const expressTms = fixture.debugElement.query(By.css('#express-both')).nativeElement;
    expressTms.click();
    const continueBtn = fixture.debugElement.query(By.css('#btn-accept')).nativeElement;
    // Act
    continueBtn.click();
    fixture.whenStable().then(() => {
      // Assert
      expect(component.checkout).toHaveBeenCalled();
    });
  }));

  it('should set the value for packageSelected onClickItem', () => {
    // Act
    component.onClickItem('express-tms');
    // Assert
    expect(component.packageSelected).toBe('express-tms');
  });

  it('should call crossSellService.savePackage after selecting tms', async(() => {
    // Arrange
    component.packageSelected = 'express-tms';
    // Act
    component.checkout();
    fixture.whenStable().then(() => {
      // Assert
      expect(mockCrossSellService.savePackage).toHaveBeenCalledWith(CrossSellPackages.tms);
    });
  }));
  it('should call crossSellService.savePackage after selecting lwt', async(() => {
    // Arrange
    component.packageSelected = 'express-lwt';
    // Act
    component.checkout();
    fixture.whenStable().then(() => {
      // Assert
      expect(mockCrossSellService.savePackage).toHaveBeenCalledWith(CrossSellPackages.lwt);
    });
  }));
  it('should call crossSellService.savePackage after selecting both', async(() => {
    // Arrange
    component.packageSelected = 'express-both';
    // Act
    component.checkout();
    fixture.whenStable().then(() => {
      // Assert
      expect(mockCrossSellService.savePackage).toHaveBeenCalledWith(CrossSellPackages.both);
    });
  }));

  it('should call eventService.saveAndContinue on continue method', async(() => {
    // Arrange
    mockTrackingService.ClearOAItems.and.returnValue();
    mockTrackingService.winRef.nativeWindow.oCMOrder = {
      oaItems: []
    };

    // Act
    component.continue();
    fixture.whenStable().then(() => {
      // Assert
      expect(mockTrackingService.ClearOAItems).toHaveBeenCalled();
      expect(mockEventService.saveAndContinue).toHaveBeenCalled();
    });

  }));

  it('should call continue method on click No thanks', async(() => {
    // Arrange
    spyOn(component, 'continue');
    const noThanksButton = fixture.debugElement.query(By.css('#btn-decline')).nativeElement;
    // Act
    noThanksButton.click();
    fixture.whenStable().then(() => {
      // Assert
      expect(component.continue).toHaveBeenCalled();
    });
  }));

  it('should call checkout method on click Agree and pay', async(() => {
    // Arrange
    component.onClickItem('express-tms');
    spyOn(component, 'checkout');
    const btnAccept = fixture.debugElement.query(By.css('#btn-accept')).nativeElement;
    // Act
    btnAccept.click();
    fixture.whenStable().then(() => {
      // Assert
      expect(component.checkout).toHaveBeenCalled();
    });
  }));

  it('should enable aggre and pay button if protectAssistLLC', async(() => {
    // Arrange
    const mockService = TestBed.get(QuestionnaireService);
    mockService.llc.packageSelected = ProductConfigurationIds.attrAssistPremiumLLC;
    // Act    
    component.ngOnInit();
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      // Assert
      expect(component.packageSelected).toBe('express-lwt');
      const btnAccept = fixture.debugElement.query(By.css('#btn-accept')).nativeElement;
      expect(btnAccept).not.toHaveClass('btn-disabled');
    });

  }));

  it('should disable aggre and pay button if package other than protectAssistLLC', async(() => {
    // Arrange
    const mockService = TestBed.get(QuestionnaireService);
    mockService.llc.packageSelected = ProductConfigurationIds.economyLLCPackage;
    // Act    
    component.ngOnInit();
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      // Assert
      expect(component.packageSelected).toBeUndefined();
      const btnAccept = fixture.debugElement.query(By.css('#btn-accept')).nativeElement;
      expect(btnAccept).toHaveClass('btn-disabled');
    });

  }));

});
