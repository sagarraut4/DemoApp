import { ProductName } from '../../../../../app/shared/constants/product-domain';
import { EventService } from '../../../../../app/shared/services/event.service';
import { PrepareCartService } from '../../../../../app/shared/services/prepare-cart.service';
import { AppService } from '../../../../../app/shared/state/app/app.service';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subject, of } from 'rxjs';
import { PagePath } from '../../../../../app/shared/models/page-model';
import { PostCheckoutService } from '../../../../../app/shared/services/post-checkout.service';
import { QuestionnaireService } from '../../../../../app/shared/services/questionnaire/questionnaire.service';
import { IAddAddOnRequest } from '@legalzoom/order-sdk';
import { QueueService, IQueueEntry, TrackJsErrorLogService } from '@legalzoom/business-formation-sdk';
import { HttpErrorResponse } from '@angular/common/http';
import { CookieService } from 'ngx-cookie';
import { AgreementService } from '../../../../../app/shared/services/agreement.service';
import { Agreements } from '../../../../../app/shared/models/agreement-model';
import { BreakpointObserver } from '@angular/cdk/layout';
import {PartnerOptInRequest}from '../../../../../app/shared/models/partner-opt-in-model';
import { PartnerOptInService } from '../../../../../app/shared/services/partner-Opt-In.Service';

@Component({
  selector: 'app-partner-offers',
  templateUrl: './partner-offers.component.html',
  styleUrls: ['./partner-offers.component.scss']
})
export class PartnerOffersComponent implements OnInit, OnDestroy {

  public LLC_MYLO_CONFIG_ID = 5932;
  public LLC_NEXT_CONFIG_ID = 8045;
  private unsubscribe: Subject<void> = new Subject();
  public isMobile = false;
  public isSubmitted = false;
  constructor(
    public questionnaireService: QuestionnaireService,
    private postCheckoutService: PostCheckoutService,
    private appService: AppService,
    private prepareCartService: PrepareCartService,
    private queueService: QueueService,
    private eventService: EventService,
    private trackJS: TrackJsErrorLogService,
    private cookieService: CookieService, 
    private agreementService: AgreementService, 
    private partnerOptInService: PartnerOptInService, 
    private breakpointObserver: BreakpointObserver) {
    const size = '(min-width: 767px)';
    breakpointObserver.observe([size]).subscribe((result) => (this.isMobile = !result.matches));
  }
  ngOnInit() {
    this.questionnaireService.llc.adp = false;
    this.questionnaireService.llc.mylo = false;
  }

  continue(isOfferSelected): void {
    if (this.isSubmitted && isOfferSelected) {
      return;
    }
    this.isSubmitted = true;
    if(isOfferSelected)
    {
    this.queueService.add(this.partnerOptInService.createPartnerOptIn(this.getPartnerOptInRequest()));
    this.queueService.add(this.agreementService.createAgreement(this.LLC_NEXT_CONFIG_ID))
    }
    this.queueService.add(this.preprareSaveAndContinue());
    this.queueService.process().subscribe();
  }


  private getAddOnRequest(configId: number): IAddAddOnRequest {
    return {
      productConfigurationId: configId,
      createdBy: this.appService.app.customerId.toString(),
      price: 0,
      quantity: 1
    };
  }

  private getPartnerOptInRequest(): PartnerOptInRequest {
    const ipAddress = sessionStorage.getItem('ipAddress');
    return {
      orderId:  this.appService.app.orderId.toString(),
      partnerId: 8,
      customerDetails:{
        customerId:this.appService.customerId.toString(),
        email:this.appService.loginEmail,
        firstName:this.appService.firstName,
        lastName:this.appService.lastName,
        clientIp:ipAddress !== null ? ipAddress : '',

      }
    };
  }

  private preprareSaveAndContinue(): IQueueEntry {
    return {
      name: 'prepareSaveAndContinue ' + this.constructor.name,
      pre: () => {
        return of(this.eventService.saveAndContinue(PagePath.PartnerOffers));
      },
      post: (response) => { },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(ProductName.LLC, 'partner-offer.component', error);
        return of(null);
      }
    };
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}
