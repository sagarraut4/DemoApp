
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { PartnerOffersComponent } from './partner-offers.component';
import { RouterTestingModule } from '@angular/router/testing';
import { QuestionnaireService } from '../../../../../app/shared/services/questionnaire/questionnaire.service';
import { PostCheckoutService } from 'src/app/shared/services/post-checkout.service';
import { CookieService } from 'ngx-cookie';
import { QuestionnaireMappingService } from 'src/app/shared/services/questionnaire/questionnaire-mapping.service';
import { QuestionnaireRoutingService } from 'src/app/shared/services/questionnaire-routing/questionnaire-routing.service';
import { QueueService, TrackJsErrorLogService, IQueueEntry } from '@legalzoom/business-formation-sdk';
import { EventService } from '../../../../../app/shared/services/event.service';
import { PrepareCartService } from '../../../../../app/shared/services/prepare-cart.service';
import { AppService } from '../../../../../app/shared/state/app/app.service';
import { of } from 'rxjs';

describe('PartnerOffersComponent', () => {
  let component: PartnerOffersComponent;
  let fixture: ComponentFixture<PartnerOffersComponent>;
  // tslint:disable-next-line: prefer-const
  let mockPostCheckoutService;
  // tslint:disable-next-line: prefer-const
  let mockCookieService;
  // tslint:disable-next-line: prefer-const
  let mockQuestionnaireMappingService;
  // tslint:disable-next-line: prefer-const
  let mockQuestionnaireRoutingService;
  let mockPrepareCartService;
  let mockQuestionnaireService;
  let mockEventService;
  let mockTrackJsErrorLogService;

  const llc: any = {
    isChooseEntityNameLater: true,
    adp: false,
    mylo: true,
    numberOfEmployees: 2
  };
  const mockAppService = {
    app: {
      customerId: 123
    }
  };
  const mockmethod: IQueueEntry = {
    name: 'methodname',
    pre: () => {
      return of(null);
    },
    post: (response) => {
    },
    error: (error) => {
      return of(null);
    }
  };

  beforeEach(async(() => {
    mockQuestionnaireService = jasmine.createSpyObj(['saveQuestionnaire', 'llc']);
    mockQuestionnaireService.llc = llc;
    mockPrepareCartService = jasmine.createSpyObj(['prepareSaveAndGetMappedUserAnswers']);
    mockPostCheckoutService = jasmine.createSpyObj(['prepareAddAddOnToOrder']);
    mockEventService = jasmine.createSpyObj(['saveAndContinue']);
    mockTrackJsErrorLogService = jasmine.createSpyObj(['track']);
    TestBed.configureTestingModule({
      imports: [RouterTestingModule.withRoutes([])],
      declarations: [PartnerOffersComponent],
      providers: [
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: PostCheckoutService, useValue: mockPostCheckoutService },
        { provide: CookieService, useValue: mockCookieService },
        { provide: QuestionnaireMappingService, useValue: mockQuestionnaireMappingService },
        { provide: QuestionnaireRoutingService, useValue: mockQuestionnaireRoutingService },
        { provide: AppService, useValue: mockAppService },
        { provide: PrepareCartService, useValue: mockPrepareCartService },
        QueueService,
        { provide: EventService, useValue: mockEventService },
        { provide: TrackJsErrorLogService, useValue: mockTrackJsErrorLogService }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PartnerOffersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create partner offers component', () => {
    // Assert
    expect(component).toBeTruthy();
  });

  it('should click on #consultations-btn', async(() => {
    // Arrange
    spyOn(component, 'continue');
    const button = fixture.debugElement.nativeElement.querySelector('#consultations-btn');
    // Act
    button.click();
    fixture.whenStable().then(() => {
      // Assert
      expect(component.continue).toHaveBeenCalledWith(true);
    });
  }));

  it('should click on #btn-decline', async(() => {
    // Arrange
    spyOn(component, 'continue');
    const button = fixture.debugElement.nativeElement.querySelector('#btn-decline');
    // Act
    button.click();
    fixture.whenStable().then(() => {
      // Assert
      expect(component.continue).toHaveBeenCalledWith(false);
    });
  }));

  it('should call prepareAddAddOnToOrder on contact me selected', async(() => {
    // Arrange
    mockQuestionnaireService = TestBed.get(QuestionnaireService);
    mockPrepareCartService.prepareSaveAndGetMappedUserAnswers.and.returnValues(mockmethod);
    mockPostCheckoutService.prepareAddAddOnToOrder.and.returnValues(mockmethod, mockmethod);
    mockEventService.saveAndContinue.and.returnValues(of(''));
    // Act
    component.continue(true);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      // Assert
      expect(mockPrepareCartService.prepareSaveAndGetMappedUserAnswers).toHaveBeenCalled();
      expect(mockPostCheckoutService.prepareAddAddOnToOrder).toHaveBeenCalled();
      expect(mockEventService.saveAndContinue).toHaveBeenCalled();
    });
  }));

  it('should not call prepareAddAddOnToOrder if no thanks selected', async(() => {
    // Arrange
    mockQuestionnaireService = TestBed.get(QuestionnaireService);
    mockPrepareCartService.prepareSaveAndGetMappedUserAnswers.and.returnValues(mockmethod);
    mockEventService.saveAndContinue.and.returnValues(of(''));
    // Act
    component.continue(false);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      // Assert
      expect(mockPrepareCartService.prepareSaveAndGetMappedUserAnswers).toHaveBeenCalled();
      expect(mockPostCheckoutService.prepareAddAddOnToOrder).not.toHaveBeenCalled();
      expect(mockEventService.saveAndContinue).toHaveBeenCalled();
    });
  }));
});