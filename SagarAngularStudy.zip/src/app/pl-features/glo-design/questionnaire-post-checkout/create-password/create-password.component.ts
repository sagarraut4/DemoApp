import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from '../../../../../app/shared/state/app/app.service';
import { QuestionnaireRoutingService } from '../../../../../app/shared/services/questionnaire-routing/questionnaire-routing.service';
import { HttpClient } from '@angular/common/http';
import { SetPasswordService } from '../../../../../app/shared/services/set-password.service';
import { PagePath } from '../../../../shared/models/page-model';
import { SetPasswordComponent } from '../../../../../app/shared/components/set-password/set-password.component';
import { SetPasswordErrorComponent } from '../../../../shared/modals/set-password-error/set-password-error.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TrackingService } from '../../../../../app/shared/services/tracking/tracking.service';
import { TrackingAmplitudeEventLabel } from '../../../../../app/shared/constants/tracking-amplitude-event-label.enum';
import { TrackingAmplitudeEventProperties, TrackingAmplitudeEventPropertyProduct } from '../../../../../app/shared/constants/tracking-amplitude-event-properties.enum';
import { TrackingAmplitudeData } from '../../../../../app/shared/models/tracking-model';

@Component({
  selector: 'app-create-password',
  templateUrl: './create-password.component.html',
  styleUrls: ['./create-password.component.scss']
})

export class CreatePasswordComponent implements OnInit {
  public checkoutEmail: string;
  public formTitle: string;
  public formDescription: string;
  public enterPasswordLabel: string;
  public verifyPasswordLabel: string;
  public btnText: string;
  public appTracking: TrackingAmplitudeData;
  private trackingOptions;

  @ViewChild('setPasswordChild', { static: false }) setPasswordChild: SetPasswordComponent;

  constructor(
    private router: Router,
    public appService: AppService,
    public questionnaireRoutingService: QuestionnaireRoutingService,
    public http: HttpClient,
    private setPasswordService: SetPasswordService,
    private modalService: NgbModal,
    public trackingService: TrackingService,
  ) {
    this.checkoutEmail = this.appService.loginEmail;
    this.formTitle = "Set up your online account";
    this.formDescription = `An online account allows you to finalize your LLC filing, track your order, view your documents, and more. <br> <br> To set up an account, create a password for <strong>${this.checkoutEmail}</strong>. Your password must be at least 6 characters.`;
    this.enterPasswordLabel = "Enter password";
    this.verifyPasswordLabel = "Verify password";
    this.btnText = "Create account";
    this.trackingOptions = {
      viewCreatePassword: {
        label: TrackingAmplitudeEventLabel.Create_Password_Open,
        properties: {
          [TrackingAmplitudeEventProperties.BusinessType]: TrackingAmplitudeEventPropertyProduct.LLC,
        },
      },
      createPassword: {
        label: TrackingAmplitudeEventLabel.Create_Password,
        properties: {
          [TrackingAmplitudeEventProperties.BusinessType]: TrackingAmplitudeEventPropertyProduct.LLC,
        },
      },      
      createPasswordError: {
        label: TrackingAmplitudeEventLabel.Create_Password_Error,
        properties: {
          [TrackingAmplitudeEventProperties.BusinessType]: TrackingAmplitudeEventPropertyProduct.LLC,
        },
      }
    }
  }

  ngOnInit() {
    this.appTracking = this.trackingOptions.viewCreatePassword;
    this.trackingService.amplitudeEvent(this.appTracking.label, this.appTracking.properties);
  }
 
  save = (updatedPasswordValue) => {
    const updatedPasswordRequest = {
      "password": updatedPasswordValue
    };
    this.setPasswordService.updatePassword(updatedPasswordRequest).subscribe(result => {
      const nextPage = this.questionnaireRoutingService.getNextPage(PagePath.CreatePassword);
      this.appTracking = this.trackingOptions.createPassword;
      this.trackingService.amplitudeEvent(this.appTracking.label, this.appTracking.properties);
      this.router.navigate(['./' + nextPage]);
    }, error => {
      this.setPasswordChild.form.reset();
      this.modalService.open(SetPasswordErrorComponent, { size: 'lg', centered: true });
      this.appTracking = this.trackingOptions.createPasswordError;
      this.trackingService.amplitudeEvent(this.appTracking.label, this.appTracking.properties);
    });
  }
} 