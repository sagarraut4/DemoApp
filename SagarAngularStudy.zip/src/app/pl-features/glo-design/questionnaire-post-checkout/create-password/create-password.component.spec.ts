import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CreatePasswordComponent } from './create-password.component';
import { SetPasswordComponent } from '../../../../shared/components/set-password/set-password.component';
import { ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { QuestionnaireRoutingService } from '../../../../shared/services/questionnaire-routing/questionnaire-routing.service';
import { AppService } from '../../../../shared/state/app';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { SetPasswordService } from '../../../../shared/services/set-password.service';
import { TrackingService } from '../../../../shared/services/tracking/tracking.service';

describe('CreatePasswordComponent', () => {
  let component: CreatePasswordComponent;
  let fixture: ComponentFixture<CreatePasswordComponent>;
  let mockRouter;
  let mockHttpClient;
  let mockSetPasswordService;  
  let mockTrackingService;

  const formBuilder: FormBuilder = new FormBuilder();
  const mockQuestionnaireRoutingService = jasmine.createSpyObj(['getNextPage']);
  const mockAppService = {
    loginEmail: "test@email.com"
  }

  beforeEach(async(() => {
    mockTrackingService = jasmine.createSpyObj(['amplitudeEvent']);
    mockRouter = {
      navigate: jasmine.createSpy('navigate')
    };
    TestBed.configureTestingModule({
      declarations: [CreatePasswordComponent, SetPasswordComponent],
      imports: [ReactiveFormsModule, RouterTestingModule],
      providers: [
        { provide: Router, useValue: mockRouter },
        { provide: FormBuilder, useValue: formBuilder },
        { provide: QuestionnaireRoutingService, useValue: mockQuestionnaireRoutingService },
        { provide: AppService, useValue: mockAppService },
        { provide: HttpClient, useValue: mockHttpClient },
        { provide: SetPasswordService, useValue: mockSetPasswordService },
        { provide: TrackingService, useValue: mockTrackingService },
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreatePasswordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display correct title', () => {
    const data = fixture.nativeElement;
    expect(data.querySelector("[data-testid='titleText']").innerHTML).toContain(component.formTitle);
  });

  it('should display correct text in the description', () => {
    const data = fixture.nativeElement;
    const textDescription = data.querySelector("[data-testid='descriptionText']");
    expect(textDescription.innerHTML).toBe(component.formDescription);
  });

  it('should display correct text in input labels', () => {
    const data = fixture.nativeElement;
    expect(data.querySelector("[data-testid='enterPasswordLabel']").textContent).toContain(component.enterPasswordLabel);
    expect(data.querySelector("[data-testid='verifyPasswordLabel']").textContent).toContain(component.verifyPasswordLabel);
  });

  it('should display correct text in submit btn', () => {
    const data = fixture.nativeElement;
    expect(data.querySelector("[data-testid='btnText']").textContent).toContain(component.btnText);
  });

  it('title should contain correct test email', () => {
    const data = fixture.nativeElement;
    const textDescription = data.querySelector("[data-testid='descriptionText']");
    expect(textDescription.innerHTML).toContain('test@email.com');
  });

  it('should run save() when button is clicked', async(() => {
    spyOn(component, "save");
    const data = fixture.nativeElement;
    const submitBtn = data.querySelector("[data-testid='submitBtnSPC']");
    const passwordElement: HTMLInputElement = data.querySelector("[data-testid='enterPasswordInput']");
    const verifyElement: HTMLInputElement = data.querySelector("[data-testid='verifyPasswordInput']");
    passwordElement.value = 'test1234';
    passwordElement.dispatchEvent(new Event('input'));
    passwordElement.dispatchEvent(new Event('blur'));
    verifyElement.value = 'test1234';
    verifyElement.dispatchEvent(new Event('input'));
    verifyElement.dispatchEvent(new Event('blur'));
    fixture.detectChanges();
    submitBtn.click();
    expect(component.save).toHaveBeenCalled();
    expect(mockTrackingService.amplitudeEvent).toHaveBeenCalled();
  }));
});