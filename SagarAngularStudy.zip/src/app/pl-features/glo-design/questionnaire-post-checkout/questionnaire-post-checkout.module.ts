import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OrderConfirmationComponent } from './order-confirmation/order-confirmation.component';
import { LzExpressOffersComponent } from './lz-express-offers/lz-express-offers.component';
import { PartnerOffersComponent } from './partner-offers/partner-offers.component';
import { GloComponentsModule } from '../shared/components/glo-components.module';
import { SharedComponentsModule } from '../../../shared/components/shared-components.module';
import { ReactiveFormsModule } from '@angular/forms';
import { CreatePasswordComponent } from './create-password/create-password.component';

@NgModule({
  declarations: [
    OrderConfirmationComponent,
    LzExpressOffersComponent,
    PartnerOffersComponent,
    CreatePasswordComponent
  ],
  imports: [
    CommonModule,
    SharedComponentsModule,
    GloComponentsModule,
    ReactiveFormsModule,
  ],
  exports: [
    OrderConfirmationComponent,
    LzExpressOffersComponent,
    PartnerOffersComponent,
    CreatePasswordComponent
  ],
  entryComponents: [
    OrderConfirmationComponent,
    LzExpressOffersComponent,
    PartnerOffersComponent,
    CreatePasswordComponent
  ]
})
export class QuestionnairePostCheckoutModule { }
