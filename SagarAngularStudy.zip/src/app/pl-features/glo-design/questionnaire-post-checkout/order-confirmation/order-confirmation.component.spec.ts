import { ProductConfigurationIds } from './../../../../shared/models/cart-model';
import { AppService } from 'src/app/shared/state/app';
import { QuestionnaireService } from './../../../../shared/services/questionnaire/questionnaire.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { QuestionnaireRoutingService } from '../../../../../app/shared/services/questionnaire-routing/questionnaire-routing.service';
import { OrderConfirmationComponent } from './order-confirmation.component';
import { TrackingService } from '../../../../../app/shared/services/tracking/tracking.service';
import { ProductDefinitionService } from '../../../../../app/shared/services/product-definition/product-definition.service';
import { Router } from '@angular/router';
import { By } from '@angular/platform-browser';
describe('OrderConfirmationComponent', () => {
  let component: OrderConfirmationComponent;
  let fixture: ComponentFixture<OrderConfirmationComponent>;
  const mockQuestionnaireRoutingService = jasmine.createSpyObj(['getNextPage']);
  const mockQuestionnaireService = {
    llc: {
      orderId: 1,
      checkoutEmail: 'testCheckoutEmail@legalzoom.com',
      LWTExpressOrderResponse: {
        ExpressOrderId: 1,
        PaymentStatus: 1
      },
      TMSExpressOrderResponse: {
        ExpressOrderId: 1,
        PaymentStatus: 1
      },
      GSuiteOrderResponse: {
        ExpressOrderId: 1,
        PaymentStatus: 1
      },
      gsuitePackageType: 'Express',
      gsuiteNumSeats: 1,
      packageSelected: 147,
      businessName: 'packageName',
      entityState: 'California',
      entityName: 'abc'
    }
  };
  const mockTrackingService = jasmine.createSpyObj(['SetGA_Arrays']);
  const mockProductDefService = jasmine.createSpyObj(['getLLCPackageName']);
  const mockAppService = {
    app: {
      getCartBalanceByCartIdResponse: {
        cartInstallments: {
          firstInstallment: {
            installmentAmount: 1
          },
          secondInstallment: {
            installmentAmount: 1
          },
        },
        totalAmount: 123
      }
    },
    lwtCrossSellPaymentResponse: {
      amount: 1
    },
    tmsCrossSellPaymentResponse: {
      amount: 1
    },
    gSuiteCrossSellPaymentResponse: {
      amount: 1
    },
    amount: 1,
    payment: {
      transactionStatus: 3,
      creationDate: '12/11/2020'
    },
    cart: {
      cartItems: [
        { productConfigurationId: 147, amount: 123 },
        { productConfigurationId: ProductConfigurationIds.bapMonthlyLegal },
        { productConfigurationId: ProductConfigurationIds.bapMonthlyLegalProtect },
        { productConfigurationId: ProductConfigurationIds.registeredAgent_249 },
        { productConfigurationId: ProductConfigurationIds.compliancePackage },

      ]
    }
  }
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [OrderConfirmationComponent],
      imports: [RouterTestingModule.withRoutes([]),],
      providers: [{ provide: QuestionnaireRoutingService, useValue: mockQuestionnaireRoutingService },
      { provide: QuestionnaireService, useValue: mockQuestionnaireService },
      { provide: TrackingService, useValue: mockTrackingService },
      { provide: ProductDefinitionService, useValue: mockProductDefService },
      { provide: AppService, useValue: mockAppService },]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderConfirmationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create order confirmation component', () => {
    expect(component).toBeTruthy();
  });

  it('getNextPage should have been called', () => {
    const router: Router = TestBed.get(Router);
    spyOn(router, 'navigate').and.stub();
    mockQuestionnaireRoutingService.getNextPage.and.returnValue('/');
    component.save();
    expect(mockQuestionnaireRoutingService.getNextPage).toHaveBeenCalled();
  });

  it('components variables should have values', () => {
    expect(component.orderId).toBeTruthy();
    expect(component.checkoutEmail).toBeTruthy();
    expect(component.lwtOrder).toBeTruthy();
    expect(component.tmsOrder).toBeTruthy();
    expect(component.gsuiteOrder).toBeTruthy();
    expect(component.gsuitePackageType).toBeTruthy();
    expect(component.gsuiteNumSeats).toBeTruthy();
    expect(component.businessName).toBeTruthy();
    expect(component.location).toBeTruthy();
    expect(component.orderDeclined).toBe(false);
  });

  it('updateDisclaimers should assign correct values', () => {
    mockProductDefService.getLLCPackageName.and.returnValue('Express Gold LLC');
    const packageName = component.getLLCPackage();
    expect(packageName).toBe('Express Gold LLC');
  });

  // TODO: figure out why test is failing
  it('getLLCPackage should return the correct package name', () => {
    expect(component.llcAmount).toBe(1);
    expect(component.hasSmartEmployer).toBe(true);
    expect(component.hasLegalProtect).toBe(true);
    expect(component.hasRegisteredAgent).toBe(true);
    expect(component.hasTotalCompliance).toBe(true);
  });

  it('on click of save button save method should get called', () => {
    spyOn(component, 'save');
    const saveButton = fixture.debugElement.query(By.css('#btn-save')).nativeElement;
    saveButton.click();
    expect(component.save).toHaveBeenCalled();
  });

  it('getTotalAmount should update the value of orderTotal', () => {
    const addtoAmount : number  = 10;
    component.orderTotal  = 20;
    component.getTotalAmount(addtoAmount);
    expect(component.orderTotal).toEqual(30);
  });  
  
  it('getCurrentAmount should update the value of chargedToday', () => {
    const addtoAmount : number  = 10;
    component.chargedToday  = 20;
    component.getCurrentAmount(addtoAmount);
    expect(component.chargedToday).toEqual(30);
  });  
});
