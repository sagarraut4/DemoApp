import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from '../../../../../app/shared/state/app/app.service';
import { ExpressOrderResponse } from '../../../../../app/shared/models/express-order-model';
import { FeatureFlagService } from '../../../../shared/services/feature-flag/feature-flag.service';
import { PagePath } from '../../../../../app/shared/models/page-model';
import { ProductDefinitionService } from '../../../../../app/shared/services/product-definition/product-definition.service';
import { QuestionnaireRoutingService } from '../../../../../app/shared/services/questionnaire-routing/questionnaire-routing.service';
import { QuestionnaireService } from '../../../../../app/shared/services/questionnaire/questionnaire.service';
import { TrackingService } from '../../../../../app/shared/services/tracking/tracking.service';
import { ProductComponentId, ProductConfigurationIds } from '../../../../../app/shared/models/cart-model';
import { IUserCart } from '@legalzoom/cart-sdk';
import * as moment from 'moment';
import { ExperimentsService } from './../../../../shared/services/experiments/experiments.service';
import { CheckoutService } from './../../../../shared/services/checkout.service';
import { gsuite_package_id_mapping } from '../../../../../app/shared/services/gsuite-order.service';
import { isNullOrUndefined } from 'util';

@Component({
  selector: 'app-order-confirmation',
  templateUrl: './order-confirmation.component.html',
  styleUrls: ['./order-confirmation.component.scss']
})
export class OrderConfirmationComponent implements OnInit {

  public orderId: number;
  public lwtOrder: ExpressOrderResponse;
  public tmsOrder: ExpressOrderResponse;
  public gsuiteOrder: ExpressOrderResponse;
  public gsuitePackageType: string;
  public gsuiteNumSeats: number;
  public checkoutEmail: string;
  public isPaymentError: boolean;
  public businessName: string;
  public orderDate: string;
  public location: string;
  public type = 'LLC';
  public orderDeclined = false;
  public firstName: string;

  public hasCompanyName: boolean;
  public isThreePay: boolean;
  public hasRegisteredAgent: boolean;
  public hasLegalProtect: boolean;
  public hasFreemiumBAP = false;
  public hasSmartEmployer: boolean;
  public hasTotalCompliance: boolean;

  public installmentAmount: number;
  public llcAmount: number;
  public lwtAmount: number;
  public tsmAmount: number;
  public gsuiteAmount: number;
  public orderTotal: number = 0;
  public chargedToday: number = 0;
  public showWIPrice: boolean;
  public selectedTaxPlan;
  public taxPlanOrder;
  public showSubscriptionTermsTaxPlan: boolean;

  constructor(
    private router: Router,
    private questionnaireRoutingService: QuestionnaireRoutingService,
    public questionnaireService: QuestionnaireService,
    private checkoutService: CheckoutService,
    private trackingService: TrackingService,
    private productDefinitionService: ProductDefinitionService,
    private appService: AppService,
    private experimentService: ExperimentsService,
    private featureFlagService: FeatureFlagService
  ) {

    this.orderId = this.questionnaireService.llc.orderId;
    this.checkoutEmail = this.appService.loginEmail;
    this.lwtOrder = this.questionnaireService.llc.LWTExpressOrderResponse;
    this.tmsOrder = this.questionnaireService.llc.TMSExpressOrderResponse;
    this.gsuiteOrder = this.questionnaireService.llc.GSuiteOrderResponse;
    this.gsuitePackageType = this.questionnaireService.llc.gsuitePackageType;
    this.gsuiteNumSeats = this.questionnaireService.llc.gsuiteNumSeats;
    this.businessName = this.questionnaireService.llc.entityName;
    this.location = this.questionnaireService.llc.entityState;

    this.hasCompanyName = !!this.questionnaireService.llc.entityName;
    this.selectedTaxPlan = this.checkoutService.getTaxConfig();

    this.showSubscriptionTermsTaxPlan = (
      !isNullOrUndefined(this.selectedTaxPlan) && 
      (this.selectedTaxPlan.productConfigurationId === ProductConfigurationIds.tax_Prep_Essentials_Plan 
        || this.selectedTaxPlan.productConfigurationId === ProductConfigurationIds.tax_Prep_Essentials_Plan_annual))
      ? false : true;

    if(this.appService.app.firstName) {
      this.firstName = this.appService.app.firstName;
    }

    if(this.appService.app.crossSellOrderResponse) {
      this.taxPlanOrder = this.appService.app.crossSellOrderResponse;
      this.getTotalAmount(this.taxPlanOrder.amount);
      this.getCurrentAmount(this.taxPlanOrder.amount);
    }

    if(this.appService.app.lwtCrossSellPaymentResponse) {
      this.lwtAmount = this.appService.app.lwtCrossSellPaymentResponse.amount;
      this.getTotalAmount(this.lwtAmount);
      this.getCurrentAmount(this.lwtAmount);
    }

    if(this.appService.app.tmsCrossSellPaymentResponse) {
      this.tsmAmount = this.appService.app.tmsCrossSellPaymentResponse.amount;
      this.getTotalAmount(this.tsmAmount);
      this.getCurrentAmount(this.tsmAmount);
    }

    // get the gsuite payment data to populate the line item
    if(this.appService.app.gSuiteCrossSellPaymentResponse) {
      this.gsuiteAmount = this.appService.app.gSuiteCrossSellPaymentResponse.amount;
      this.getTotalAmount(this.gsuiteAmount);
      this.getCurrentAmount(this.gsuiteAmount);
    }

    if(this.lwtOrder && this.lwtOrder.ExpressOrderId) {
      this.trackingService.sendConversionToGa([{
        sProductID: String(ProductConfigurationIds.lwtCrosssell),
        sProductName: 'Last Will and Testament',
        sRelationshipType: 'CrossSell',
        sAmount: String(this.lwtAmount),
      }], this.lwtOrder.ExpressOrderId);
    }

    if(this.tmsOrder && this.tmsOrder.ExpressOrderId) {
      this.trackingService.sendConversionToGa([{
        sProductID: String(ProductConfigurationIds.tmsCrosssell),
        sProductName: 'Trademark Search',
        sRelationshipType: 'CrossSell',
        sAmount: String(this.lwtAmount),
      }], this.tmsOrder.ExpressOrderId);
    }

    if(this.gsuiteOrder && this.gsuiteOrder.ExpressOrderId) {
      this.trackingService.sendConversionToGa([{
        sProductID: String(gsuite_package_id_mapping[this.gsuitePackageType]),
        sProductName: `Google Workspace ${this.gsuitePackageType}`,
        sRelationshipType: 'CrossSell',
        sAmount: String(this.gsuiteAmount),
      }], this.gsuiteOrder.ExpressOrderId);
    }

    if(this.appService.payment) {
      const paymentStatus = +this.appService.payment.transactionStatus; // 3 = success, show error for anything except success
      if(paymentStatus !== 3) {
        this.orderDeclined = true;
      }
      // TODO: fix deprecation warning
      // Deprecation warning: value provided is not in a recognized RFC2822 or ISO format.
      // moment construction falls back to js Date(), which is not reliable across all browsers and versions.
      // Non RFC2822/ISO date formats are discouraged. Please refer to http://momentjs.com/guides/#/warnings/js-date/ for more info.
      this.orderDate = moment(this.appService.payment.creationDate).format('M/D/YY');
    }

    if( this.appService.cart) {
      this.updateDisclaimers(this.appService.cart);
    }

    this.isThreePay = this.questionnaireService.llc.is3Pay;
    if(this.isThreePay) {
      this.installmentAmount = this.appService.app.getCartBalanceByCartIdResponse.cartInstallments.secondInstallment.installmentAmount;
    }
    if(this.isThreePay) {
      this.getTotalAmount(this.appService.app.getCartBalanceByCartIdResponse.cartBalance < 0 ? 0 : this.appService.app.getCartBalanceByCartIdResponse.cartBalance);
      this.getCurrentAmount(this.appService.app.getCartBalanceByCartIdResponse.cartInstallments.firstInstallment.installmentAmount);

    } else {
      this.getTotalAmount(this.appService.amount);

    }

    if ((this.lwtOrder && this.lwtOrder.PaymentStatus === 0) ||
      (this.tmsOrder && this.tmsOrder.PaymentStatus === 0) ||
      (this.gsuiteOrder && this.gsuiteOrder.PaymentStatus === 0)) {
      this.orderDeclined = true;
    }

    this.featureFlagService.reinitializeFlagsIfUserChanged(); //user properties may have changed -- refetch flags before q2 as an optimization
  }

  getTotalAmount(addtoAmount: number) {
    this.orderTotal = this.orderTotal + addtoAmount;
  }

  getCurrentAmount(addtoAmount: number) {
    this.chargedToday = this.chargedToday + addtoAmount;
  }

  ngOnInit() {
    if (this.questionnaireService.llc.entityState === 'Wisconsin') {
      this.showWIPrice = true;
    } else {
      this.showWIPrice = false;
    }
  }

  getLLCPackage(): string {
    return this.productDefinitionService.getLLCPackageName(this.questionnaireService.llc.packageSelected);
  }

  save(): void {
    const nextPage = this.questionnaireRoutingService.getNextPage(PagePath.OrderConfirmation);
    this.router.navigate(['./' + nextPage]);
  }

  updateDisclaimers(cart: IUserCart){
    const llcItem = cart.cartItems.find(x => x.productConfigurationId === this.questionnaireService.llc.packageSelected);
    this.llcAmount = this.appService.amount;

    const smartEmployerItem = cart.cartItems.find(i =>
      i.productConfigurationId === ProductConfigurationIds.bapMonthlyLegal ||
      i.productConfigurationId === ProductConfigurationIds.bapMonthlyLegalWisconsin);
    if (smartEmployerItem) {
      this.hasSmartEmployer = true;
    }

    const legalProtectItem = cart.cartItems.find(i =>
      i.productConfigurationId === ProductConfigurationIds.bapMonthlyLegalProtect ||
      i.productConfigurationId === ProductConfigurationIds.bapMonthlyLegalProtectWisconsin);
    if (legalProtectItem) {
      this.hasLegalProtect = true;
    }

    const freemiumBAP = cart.cartItems.find(i => 
      i.productComponentId === ProductComponentId.freemiumPremiumBAP)
      if(freemiumBAP) { this.hasFreemiumBAP = true; }

    const registeredAgentItem = cart.cartItems.find(i =>
      ( i.productConfigurationId === ProductConfigurationIds.registeredAgent ) ||
      ( i.productConfigurationId === ProductConfigurationIds.registeredAgent_199 ) ||
      ( i.productConfigurationId === ProductConfigurationIds.registeredAgent_249 )
    );
    if (registeredAgentItem) {
      this.hasRegisteredAgent = true;
    }

    const totalComplianceItem = cart.cartItems.find(i =>
      ( i.productConfigurationId === ProductConfigurationIds.compliancePackage ));
    if (totalComplianceItem) {
      this.hasTotalCompliance = true;
    }
  }
}
