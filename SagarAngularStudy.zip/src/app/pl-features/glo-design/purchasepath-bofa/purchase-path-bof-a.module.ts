import { SquareModalComponent } from './../modals/square-modal/square-modal.component';
import { BofaModalComponent } from './../modals/bofa-modal/bofa-modal.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BOfAComponent } from './b-of-a/b-of-a.component';
import { GloComponentsModule } from '../shared/components/glo-components.module';
import { BofaSquareComponent } from './bofa-square/bofa-square.component';
import { ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  imports: [CommonModule, 
    ReactiveFormsModule, 
    GloComponentsModule,
    NgbModule],
  declarations: [
    BOfAComponent,
    BofaSquareComponent,
    BofaModalComponent,
    SquareModalComponent
  ],
  exports: [
    BOfAComponent,
    BofaSquareComponent,
    BofaModalComponent,
    SquareModalComponent
  ],
  entryComponents: [
    BofaModalComponent,
    SquareModalComponent
  ]
})
export class PurchasePathBofAModule { }
