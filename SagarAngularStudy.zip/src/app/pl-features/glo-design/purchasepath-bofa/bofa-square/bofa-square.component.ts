import { Component, OnInit, OnDestroy, Renderer2, AfterViewInit } from '@angular/core';
import { ProductName } from '../../../../shared/constants/product-domain';
import { AppService } from '../../../../shared/state/app/app.service';
import { QuestionnaireRoutingService } from '../../../../shared/services/questionnaire-routing/questionnaire-routing.service';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { PagePath } from '../../../../shared/models/page-model';
import { SEADService } from '../../../../shared/services/tracking/sead.service';
import { EventService } from '../../../../shared/services/event.service';
import { takeUntil } from 'rxjs/operators';
import { Subject, of, ReplaySubject, Subscription } from 'rxjs';
import { QueueService, IQueueEntry, TrackJsErrorLogService } from '@legalzoom/business-formation-sdk';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { PrepareCartService } from '../../../../shared/services/prepare-cart.service';
import { BreakpointObserver } from '@angular/cdk/layout';
import { FormBuilder, FormGroup } from '@angular/forms';
import { PartnerOffer } from './../../../../shared/constants/cross-sell-packages';
import { BofaModalComponent } from '../../modals/bofa-modal/bofa-modal.component';
import { SquareModalComponent } from '../../modals/square-modal/square-modal.component';
import { TrackingService } from '../../../../shared/services/tracking/tracking.service';
import { BannerService } from '../../shared/services/banner.service';
@Component({
  selector: 'app-bofa-square',
  templateUrl: './bofa-square.component.html',
  styleUrls: ['./bofa-square.component.scss']
})
export class BofaSquareComponent implements OnInit, AfterViewInit, OnDestroy {
  closeResult: string;
  isLoading: boolean;
  private unsubscribe: Subject<void> = new Subject();
  public isMobile = true;
  public itemList = [];
  public form: FormGroup;
  public bofaOptionSelected = this.questionnaireService.llc.bofa;
  public squareOptionSelected = this.questionnaireService.llc.squarePartnerOffer;
  private bannerHeightSubject: ReplaySubject<number>;
  private bannerHeightSubscription: Subscription;
  private cookieBannerHeight = 0;
  constructor(
    public questionnaireService: QuestionnaireService,
    private modalService: NgbModal,
    public seadService: SEADService,
    private queueService: QueueService,
    private prepareCartService: PrepareCartService,
    private eventService: EventService,
    private router: Router,
    private trackJS: TrackJsErrorLogService,
    private questionnaireRoutingService: QuestionnaireRoutingService,
    private appService: AppService,
    private breakpointObserver: BreakpointObserver,
    private formBuilder: FormBuilder,
    private trackingService: TrackingService,
    private renderer: Renderer2,
    private bannerService: BannerService) {
    const size = '(min-width: 768px)';
    breakpointObserver.observe([size]).subscribe((result) => (this.isMobile = !result.matches));
    this.form = this.formBuilder.group({
      bofa: [this.questionnaireService.llc.bofa],
      square: [this.questionnaireService.llc.squarePartnerOffer],
    });
  }

  ngOnInit() {
    this.updateLoadingStatus();
    this.createData();
  }

  private createData() {
    this.itemList = [{
      controlName: PartnerOffer.bofa,
      optin: this.bofaOptionSelected,
      headerImage: 'assets/img/partner-offer/bofa-logo.svg',
      featureLabel: 'Banking',
      title: 'Earn up to $500',
      titleDescription: 'with qualifying activities',
      description: 'Keep your personal and business finances separate with a small business checking account and credit card.'
    }, {
      controlName: PartnerOffer.square,
      optin: this.squareOptionSelected,
      headerImage: 'assets/img/partner-offer/square-logo.svg',
      featureLabel: 'Point of Sale',
      title: 'Pay zero fees on your first $3,000 in sales',
      titleDescription: '',
      description: 'Run your business with Square to accept every kind of payment, and manage it all in one place.'
    }];   
  }

  viewDetails(value) {
    if (value == PartnerOffer.bofa) {
      this.trackingService.triggerClickTrack('llc_flow', 'partner_boa_more_details');
      // open bofa modal
      this.modalService.open(BofaModalComponent, { size: 'lg', windowClass: 'glo-modal-partner-offer', centered: true, scrollable: true });
    }
    else if (value == PartnerOffer.square) {
      this.trackingService.triggerClickTrack('llc_flow', 'partner_square_more_details');
      // open square modal
      this.modalService.open(SquareModalComponent, { size: 'lg', windowClass: 'glo-modal-partner-offer', centered: true, scrollable: true });
    }
    this.getModalElementAndSetPosition();
  }

  public selectOffer(event, value) {
    if (value == PartnerOffer.bofa) {
      this.bofaOptionSelected = event.target.checked;
      this.trackingService.triggerClickTrack('llc_flow', 'partner_boa_select');
    }
    else if (value == PartnerOffer.square) {
      this.squareOptionSelected = event.target.checked;
      this.trackingService.triggerClickTrack('llc_flow', 'partner_square_select');
    }
    this.updateItemList();
  }

  private updateItemList() {
    this.itemList[0].optin = this.bofaOptionSelected;
    this.itemList[1].optin = this.squareOptionSelected;
  }

  cancel(): void {
    this.bofaOptionSelected = false;
    this.squareOptionSelected = false;
    this.updateItemList();
    this.trackingService.triggerClickTrack('llc_flow', 'partner_no_thanks');
    this.saveData();
  }

  save(): void {
    this.trackingService.triggerClickTrack('llc_flow', 'partner_continue');
    this.saveData();
  }

  private saveData() {
    this.showBusy(true);
    if (
      this.questionnaireService.llc.bofa !== this.bofaOptionSelected ||
      this.questionnaireService.llc.squarePartnerOffer !== this.squareOptionSelected
    ) {
      this.questionnaireService.llc.bofa = this.bofaOptionSelected
      this.questionnaireService.llc.squarePartnerOffer = this.squareOptionSelected
      this.seadService.removeOptin(this.seadService.seadOptins.BOFA);
      if (this.bofaOptionSelected) { this.seadService.addOptin(this.seadService.seadOptins.BOFA); }

      this.queueService.add([this.prepareCartService.prepareSaveAndGetMappedUserAnswers(), this.questionnaireService.prepareUpdateQuestionnaireStorage(this.questionnaireService.llc)]);
      this.queueService.add(this.prepareCartService.prepareUpdateCartByQuestionnaire());
      this.queueService.add(this.prepareCartService.prepareGetCartBalanceByCartId('', false));
      this.queueService.add(this.prepareCartService.prepareGetCartModelFromApiData());
      this.queueService.add(this.prepareCartService.prepareUpdateLoadingStatus());
    }
    this.queueService.add(this.prepareRouteNavigate());
    this.queueService.process().subscribe();
  }

  private prepareRouteNavigate(): IQueueEntry {
    const that = this;
    return {
      name: 'prepareRouteNavigate ' + this.constructor.name,
      pre: () => {
        return of(null);
      },
      post: () => {
        const nextPage = this.questionnaireRoutingService.getNextPage(PagePath.Partners);
        this.questionnaireService.llc.currentView = nextPage;
        this.appService.currentView = nextPage;
        this.router.navigate([`./${nextPage}`]);
      },
      error: (error: HttpErrorResponse) => {
        this.trackJS.track(ProductName.LLC, 'boa.component', error);
        this.eventService.updateLoadingStatus(false);
        return of(null);
      }
    };
  }

  showBusy(show: boolean): void {
    this.isLoading = show;
  }

  updateLoadingStatus() {
    this.eventService.updateLoadingStatusEvent.pipe(takeUntil(this.unsubscribe)).subscribe((isLoading: boolean) => {
      this.isLoading = isLoading;
    });
  }
  
  private setModalPosition(bannerHeight: number = 0) {
    if (bannerHeight === 0) {
      const contentElement = document.getElementsByClassName('glo-modal-partner-offer');
      if (contentElement.length > 0) {
        contentElement[0].setAttribute('style', 'padding-bottom:0;');
      }
    }
    else {
      const contentElement = document.getElementsByClassName('glo-modal-partner-offer');
      if (contentElement.length > 0) {
        contentElement[0].setAttribute('style', 'padding-bottom:' + bannerHeight + 'px;');
      }
    }
  }

  private getModalElementAndSetPosition() {
    setTimeout(() => {
      const contentElement = document.getElementsByClassName('glo-modal-partner-offer');
      if (contentElement.length > 0) {
        this.setModalPosition(this.cookieBannerHeight);
      }
    }, 0);
  }
  
  ngAfterViewInit() {
    this.bannerHeightSubject = this.bannerService.getBannerHeight(this.renderer);

    if (this.isMobile) {

      this.bannerHeightSubscription = this.bannerHeightSubject.subscribe(bannerHeight => {
        this.cookieBannerHeight = bannerHeight;
        this.setModalPosition(bannerHeight);

        if (this.bannerHeightSubscription && bannerHeight === 0) {

          this.bannerHeightSubscription.unsubscribe();
        }
      });
    }
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}
