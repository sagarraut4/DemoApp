import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { of, Subject } from 'rxjs';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { By } from '@angular/platform-browser';
import { AppService } from '../../../../shared/state/app';
import { QuestionnaireRoutingService } from '../../../../shared/services/questionnaire-routing/questionnaire-routing.service';
import { PrepareCartService } from '../../../../shared/services/prepare-cart.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { SEADService } from '../../../../shared/services/tracking/sead.service';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { BofaSquareComponent } from './bofa-square.component';
import { EventService } from '../../../../shared/services/event.service';
import {
  TrackJsErrorLogModule, QueueService, TrackJsErrorLogService, IQueueEntry
} from '@legalzoom/business-formation-sdk';
import { PartnerOffer } from 'src/app/shared/constants/cross-sell-packages';
import { ReactiveFormsModule } from '@angular/forms';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TrackingService } from './../../../../shared/services/tracking/tracking.service';
import { BannerService } from '../../shared/services/banner.service';
import { CtaButtonComponent } from './../../shared/components/cta-button/cta-button.component';

describe('BofaSquareComponent', () => {
  let component: BofaSquareComponent;
  let fixture: ComponentFixture<BofaSquareComponent>;
  let mockSeadService;
  let mockEventService;
  const moockModalService = jasmine.createSpyObj(['open']);
  const mockBannerService = jasmine.createSpyObj(['getBannerHeight', 'bannerIsActive']);
  let mockPrepareCartService;
  const mockTrackJsErrorLogService = jasmine.createSpyObj(['track']);
  let mockQuestionnaireRoutingService;
  let mockQuestionnaireService;
  const mockAppService = { currentView: '' };
  const llc = { llc: { } };
  const mockmethod: IQueueEntry = {
    name: 'methodname',
    pre: () => {
      return of(null);
    },
    post: (response) => {
    },
    error: (error) => {
      return of(null);
    }
  };
  const seadOptins = {
    BOFA: 'Test'
  };
  let mockTrackingService;
  beforeEach(async(() => {
    mockEventService = jasmine.createSpyObj(['updateLoadingStatusEvent']);
    mockEventService.updateLoadingStatusEvent = new Subject();
    mockPrepareCartService = jasmine.createSpyObj(['prepareSaveAndGetMappedUserAnswers',
      'prepareUpdateCartByQuestionnaire', 'prepareGetCartBalanceByCartId',
      'prepareGetCartModelFromApiData', 'prepareUpdateLoadingStatus']);
    mockQuestionnaireRoutingService = jasmine.createSpyObj(['getNextPage']);
    mockSeadService = jasmine.createSpyObj(['addOptin', 'removeOptin', 'seadOptins']);
    mockQuestionnaireService = jasmine.createSpyObj(['prepareUpdateQuestionnaireStorage']);
    mockQuestionnaireService.llc = llc;
    mockTrackingService = jasmine.createSpyObj(['triggerClickTrack']);
    mockBannerService.getBannerHeight.and.returnValue(of(2));

    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        BrowserAnimationsModule,
        TrackJsErrorLogModule.forRoot(),
        ReactiveFormsModule
      ],
      declarations: [BofaSquareComponent, CtaButtonComponent],
      providers: [
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: NgbModal, useValue: moockModalService },
        { provide: SEADService, useValue: mockSeadService },
        QueueService,
        { provide: BannerService, useValue: mockBannerService },
        { provide: PrepareCartService, useValue: mockPrepareCartService },
        { provide: EventService, useValue: mockEventService },
        { provide: Router, useClass: class { navigate = jasmine.createSpy('navigate'); } },
        { provide: TrackJsErrorLogService, useValue: mockTrackJsErrorLogService },
        { provide: QuestionnaireRoutingService, useValue: mockQuestionnaireRoutingService },
        { provide: AppService, useValue: mockAppService },
        { provide: TrackingService, useValue: mockTrackingService }
      ]
    })
      .compileComponents();
    mockSeadService.seadOptins = seadOptins;
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BofaSquareComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call viewDetails method on click of bofa modal view details link', () => {
    spyOn(component, 'viewDetails');
    const viewdetails = fixture.debugElement.query(By.css('#view-details-1')).nativeElement;
    viewdetails.click();
    expect(component.viewDetails).toHaveBeenCalled();
  });

  it('should call viewDetails method on click of square modal view details link', () => {
    spyOn(component, 'viewDetails');
    const viewdetails = fixture.debugElement.query(By.css('#view-details-2')).nativeElement;
    viewdetails.click();
    expect(component.viewDetails).toHaveBeenCalled();
  });

  it('update isLoading value with given value on showBusy method', () => {
    component.showBusy(true);
    expect(component.isLoading).toBe(true);
  });

  it('should call method to update cart questionnaire on square offer selected', async(() => {
    mockPrepareCartService.prepareSaveAndGetMappedUserAnswers.and.returnValue(mockmethod);
    mockQuestionnaireService.prepareUpdateQuestionnaireStorage.and.returnValue(mockmethod);
    mockPrepareCartService.prepareUpdateCartByQuestionnaire.and.returnValue(mockmethod);
    mockPrepareCartService.prepareGetCartBalanceByCartId.and.returnValue(mockmethod);
    mockPrepareCartService.prepareGetCartModelFromApiData.and.returnValue(mockmethod);
    mockPrepareCartService.prepareUpdateLoadingStatus.and.returnValue(mockmethod);
    TestBed.get(QuestionnaireService).llc.squarePartnerOffer = false;
    component.squareOptionSelected = true;
    component.save();
    fixture.whenStable().then(() => {
      expect(mockPrepareCartService.prepareSaveAndGetMappedUserAnswers).toHaveBeenCalled();
      expect(mockQuestionnaireService.prepareUpdateQuestionnaireStorage).toHaveBeenCalled();
      expect(mockPrepareCartService.prepareUpdateCartByQuestionnaire).toHaveBeenCalled();
      expect(mockPrepareCartService.prepareGetCartBalanceByCartId).toHaveBeenCalled();
      expect(mockPrepareCartService.prepareGetCartModelFromApiData).toHaveBeenCalled();
      expect(mockPrepareCartService.prepareUpdateLoadingStatus).toHaveBeenCalled();
    });
  }));

  it('should call method to update cart questionnaire on bofa offer selected', async(() => {
    mockPrepareCartService.prepareSaveAndGetMappedUserAnswers.and.returnValue(mockmethod);
    mockQuestionnaireService.prepareUpdateQuestionnaireStorage.and.returnValue(mockmethod);
    mockPrepareCartService.prepareUpdateCartByQuestionnaire.and.returnValue(mockmethod);
    mockPrepareCartService.prepareGetCartBalanceByCartId.and.returnValue(mockmethod);
    mockPrepareCartService.prepareGetCartModelFromApiData.and.returnValue(mockmethod);
    mockPrepareCartService.prepareUpdateLoadingStatus.and.returnValue(mockmethod);
    TestBed.get(QuestionnaireService).llc.bofa = false;
    component.bofaOptionSelected = true;
    component.save();
    fixture.whenStable().then(() => {
      expect(mockSeadService.removeOptin).toHaveBeenCalled();
      expect(mockSeadService.addOptin).toHaveBeenCalled();
      expect(mockPrepareCartService.prepareSaveAndGetMappedUserAnswers).toHaveBeenCalled();
      expect(mockQuestionnaireService.prepareUpdateQuestionnaireStorage).toHaveBeenCalled();
      expect(mockPrepareCartService.prepareUpdateCartByQuestionnaire).toHaveBeenCalled();
      expect(mockPrepareCartService.prepareGetCartBalanceByCartId).toHaveBeenCalled();
      expect(mockPrepareCartService.prepareGetCartModelFromApiData).toHaveBeenCalled();
      expect(mockPrepareCartService.prepareUpdateLoadingStatus).toHaveBeenCalled();
    });
  }));

  it('selectOffer method should show disclaimer', async(() => {
    const bofaSelectButton = fixture.debugElement.query(By.css('#cb-offer-1')).nativeElement;
    bofaSelectButton.click();
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(fixture.debugElement.query(By.css('.boa-disclaimer'))).toBeTruthy();
    });
  }));

  it('bofa card select button click should call selectOffer method', () => {
    spyOn(component, 'selectOffer');
    const bofaSelectButton = fixture.debugElement.query(By.css('#cb-offer-1')).nativeElement;
    bofaSelectButton.click();
    expect(component.selectOffer).toHaveBeenCalled();
  });

  it('square card select button click should call selectOffer method', () => {
    spyOn(component, 'selectOffer');
    const bofaSelectButton = fixture.debugElement.query(By.css('#cb-offer-2')).nativeElement;
    bofaSelectButton.click();
    expect(component.selectOffer).toHaveBeenCalled();
  });

  it('no thanks button click should call cancel method', () => {
    spyOn(component, 'cancel');
    const acceptButton = fixture.debugElement.query(By.css('#btn-decline')).nativeElement;
    acceptButton.click();
    expect(component.cancel).toHaveBeenCalled();
  });
});
