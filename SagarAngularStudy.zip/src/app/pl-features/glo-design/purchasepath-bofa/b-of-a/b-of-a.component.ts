import { FeatureFlagService } from './../../../../shared/services/feature-flag/feature-flag.service';
import { ProductName } from './../../../../shared/constants/product-domain';
import { AppService } from './../../../../shared/state/app/app.service';
import { QuestionnaireRoutingService } from './../../../../shared/services/questionnaire-routing/questionnaire-routing.service';
import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { QuestionnaireService } from '../../../../../app/shared/services/questionnaire/questionnaire.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Chapter, PagePath } from '../../../../shared/models/page-model';
import { SEADService } from '../../../../shared/services/tracking/sead.service';
import { EventService } from '../../../../shared/services/event.service';
import { takeUntil } from 'rxjs/operators';
import { Subject, of } from 'rxjs';
import { QueueService, IQueueEntry, TrackJsErrorLogService } from '@legalzoom/business-formation-sdk';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { InfoPanelComponent } from '../../../../../app/pl-features/glo-design/shared/components/info-panel/info-panel.component';
import { PrepareCartService } from '../../../../../app/shared/services/prepare-cart.service';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';

@Component({
  selector: 'app-b-of-a',
  templateUrl: './b-of-a.component.html',
  styleUrls: ['./b-of-a.component.scss']
})
export class BOfAComponent implements OnInit, OnDestroy {
  closeResult: string;
  isLoading: boolean;
  private unsubscribe: Subject<void> = new Subject();
  @ViewChild('moreInfo', { static: false }) moreInfo: InfoPanelComponent;
  public isMobile = true;

  constructor(
    public questionnaireService: QuestionnaireService,
    private modalService: NgbModal,
    public seadService: SEADService,
    private queueService: QueueService,
    private prepareCartService: PrepareCartService,
    private eventService: EventService,
    private router: Router,
    private trackJS: TrackJsErrorLogService,
    private questionnaireRoutingService: QuestionnaireRoutingService,
    private appService: AppService,
    private breakpointObserver: BreakpointObserver,
    private featureFlagService: FeatureFlagService
  ) {
    const size = '(min-width: 768px)';
    breakpointObserver.observe([size]).subscribe((result) => (this.isMobile = !result.matches));
    
    if (this.featureFlagService.bofaSquareEnabled) {
      this.router.navigate([`./${Chapter.Package + '/' + PagePath.Partners}`]);
    }
    
  }

  ngOnInit() {
    this.updateLoadingStatus();
  }

  public openInfoPanel() {
    this.moreInfo.open();
  }

  save(input: boolean): void {
    if (input) {
      this.seadService.addOptin(this.seadService.seadOptins.BOFA);
    } else {
      this.seadService.removeOptin(this.seadService.seadOptins.BOFA);
    }

    this.showBusy(true);
    if (this.questionnaireService.llc.bofa !== input) {
      this.questionnaireService.llc.bofa = input;
      this.queueService.add([this.prepareCartService.prepareSaveAndGetMappedUserAnswers(), this.questionnaireService.prepareUpdateQuestionnaireStorage({ bofa: input })]);
      this.queueService.add(this.prepareCartService.prepareUpdateCartByQuestionnaire());
      this.queueService.add(this.prepareCartService.prepareGetCartBalanceByCartId('', false));
      this.queueService.add(this.prepareCartService.prepareGetCartModelFromApiData());
      this.queueService.add(this.prepareCartService.prepareUpdateLoadingStatus());
    }

    this.queueService.add(this.prepareRouteNavigate());
    this.queueService.process().subscribe();
  }

  private prepareRouteNavigate(): IQueueEntry {
    const that = this;
    return {
      name: 'prepareRouteNavigate ' + this.constructor.name,
      pre: () => {
        return of(null);
      },
      post: () => {
        const nextPage = this.questionnaireRoutingService.getNextPage(PagePath.BofA);
        this.questionnaireService.llc.currentView = nextPage;
        this.appService.currentView = nextPage;
        this.router.navigate([`./${nextPage}`]);
      },
      error: (error: HttpErrorResponse) => {
        this.trackJS.track(ProductName.LLC, 'boa.component', error);
        this.eventService.updateLoadingStatus(false);
        return of(null);
      }
    };
  }

  showBusy(show: boolean): void {
    this.isLoading = show;
  }

  updateLoadingStatus() {
    this.eventService.updateLoadingStatusEvent.pipe(takeUntil(this.unsubscribe)).subscribe((isLoading: boolean) => {
      this.isLoading = isLoading;
    });
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}
