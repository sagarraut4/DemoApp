import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-desktop-peace-of-mind',
  templateUrl: './peace-of-mind.component.html',
  styleUrls: ['./peace-of-mind.component.css']
})
export class PeaceOfMindComponent implements OnInit {

  constructor(public activeModal: NgbActiveModal) { }

  ngOnInit() {
  }

  close(): void {
    this.activeModal.close();
  }
}
