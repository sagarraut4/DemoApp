import { Component, HostBinding, Input, ChangeDetectionStrategy, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { ProductDefinitionService } from '../../../../shared/services/product-definition/product-definition.service';
import { SEADService } from '../../../../shared/services/tracking/sead.service';
import { ExperimentsService } from '../../../../shared/../shared/services/experiments/experiments.service';
import { TrackingService } from '../../../../shared/services/tracking/tracking.service';

@Component({
  selector: 'app-registered-agent-modal',
  templateUrl: './registered-agent-modal.component.html',
  styleUrls: ['./registered-agent-modal.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class RegisteredAgentModalComponent implements OnInit {
  @Input() offerAccepted: boolean;
  // add required class to sort modal-content height
  @HostBinding('class.modal-content') true: boolean;

  constructor(
    public activeModal: NgbActiveModal,
    public seadService: SEADService,
    public questionnaireService: QuestionnaireService,
    public productDefinitionService: ProductDefinitionService,
    public experimentService: ExperimentsService,
    public trackingService:TrackingService
  ) {
  }

  ngOnInit() {
  }
  
  acceptOffer(answer: boolean) {
    this.offerAccepted = answer;
    if (answer) {
      this.seadService.addOptin(this.seadService.seadOptins.RA);
      this.trackingService.triggerClickTrack('llc_flow','edit_ra_lzra');
    } else {
      this.seadService.removeOptin(this.seadService.seadOptins.RA);
      this.trackingService.triggerClickTrack('llc_flow','edit_ra_no');
    }
  }

  save() {
    this.trackingService.triggerClickTrack('llc_flow','edit_modal_update_order');
    this.trackingService.triggerClickTrack('llc_flow','edit_ra_update');
    this.activeModal.close(this.offerAccepted);
  }

  cancel() {
    this.trackingService.triggerClickTrack('llc_flow','edit_modal_cancel');
    this.trackingService.triggerClickTrack('llc_flow','edit_ra_cancel');
    this.activeModal.dismiss('cancel');
  }

}
