import { SEADService } from '../../../../shared/services/tracking/sead.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RegisteredAgentModalComponent } from './registered-agent-modal.component';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { By } from '@angular/platform-browser';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { ProductDefinitionService } from '../../../../shared/services/product-definition/product-definition.service';
import { ExperimentsService } from '../../../../shared/services/experiments/experiments.service';

describe('RegisteredAgentModalComponent', () => {
  let component: RegisteredAgentModalComponent;
  let fixture: ComponentFixture<RegisteredAgentModalComponent>;
  const mockNgbActiveModal = jasmine.createSpyObj(['close', 'dismiss']);
  const mockSeadService = jasmine.createSpyObj(['addOptin', 'removeOptin', 'seadOptins']);
  const mockQuestionnaireService = { llc: { isMobile: '' } };
  // tslint:disable-next-line:prefer-const
  let mockExperimentService;
  const seadOptins = {
    RA: 'register-agent'
  };
  beforeEach(async(() => {
    mockSeadService.seadOptins = seadOptins;
    TestBed.configureTestingModule({
      declarations: [RegisteredAgentModalComponent],
      providers: [
        { provide: NgbActiveModal, useValue: mockNgbActiveModal },
        { provide: SEADService, useValue: mockSeadService },
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: ExperimentsService, useValue: mockExperimentService },
        ProductDefinitionService
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisteredAgentModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create registered agent modal component', () => {
    expect(component).toBeTruthy();
  });

  it('close button should close the active modal', () => {
    const closeBtn = fixture.debugElement.query(By.css('.glo-btn-close')).nativeElement;
    closeBtn.click();
    expect(mockNgbActiveModal.dismiss).toHaveBeenCalled();
  });

  it('cancel button should close the active modal', () => {
    const cancelBtn = fixture.debugElement.query(By.css('#btn-cancel')).nativeElement;
    cancelBtn.click();
    expect(mockNgbActiveModal.dismiss).toHaveBeenCalled();
  });

  it('update button should call the save method', () => {
    spyOn(component, 'save');
    const updateBtn = fixture.debugElement.query(By.css('#btn-update')).nativeElement;
    updateBtn.click();
    expect(component.save).toHaveBeenCalled();
  });

  it('update button should call the save method and close the active modal', () => {
    const updateBtn = fixture.debugElement.query(By.css('#btn-update')).nativeElement;
    updateBtn.click();
    expect(mockNgbActiveModal.close).toHaveBeenCalled();
  });

  it('on selecting legalzoom as registered agent it should call acceptOffer method', () => {
    spyOn(component, 'acceptOffer');
    const raBtn = fixture.debugElement.query(By.css('#rd-agent-lz')).nativeElement;
    raBtn.click();
    expect(component.acceptOffer).toHaveBeenCalled();
  });

  it('on selecting own registered agent it should call acceptOffer method', () => {
    spyOn(component, 'acceptOffer');
    const raBtn = fixture.debugElement.query(By.css('#rd-agent-not-lz')).nativeElement;
    raBtn.click();
    expect(component.acceptOffer).toHaveBeenCalled();
  });

  it('on selecting legalzoom as registered agent sead service should add selected value should save in offerAccepted', () => {
    const raBtn = fixture.debugElement.query(By.css('#rd-agent-lz')).nativeElement;
    raBtn.click();
    expect(component.offerAccepted).toBe(true);
    expect(mockSeadService.addOptin).toHaveBeenCalled();
  });

  it('on selecting own registered agent sead service should remove selected value should save in offerAccepted', () => {
    const raBtn = fixture.debugElement.query(By.css('#rd-agent-not-lz')).nativeElement;
    raBtn.click();
    expect(component.offerAccepted).toBe(false);
    expect(mockSeadService.removeOptin).toHaveBeenCalled();
  });

});
