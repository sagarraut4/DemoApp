import { BreakpointObserver } from '@angular/cdk/layout';
import { Component, HostBinding, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-bofa-modal',
  templateUrl: './bofa-modal.component.html',
  styleUrls: ['./bofa-modal.component.scss']
})
export class BofaModalComponent implements OnInit {
  @HostBinding('class.modal-content') true: boolean;
  public isMobile = false;
  constructor(public activeModal: NgbActiveModal,
    private breakpointObserver: BreakpointObserver) {
    const size = '(min-width: 768px)';
    breakpointObserver.observe([size]).subscribe((result) => (this.isMobile = !result.matches));
  }

  ngOnInit() {
  }

}
