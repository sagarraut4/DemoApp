/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BofaModalComponent } from './bofa-modal.component';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { By } from '@angular/platform-browser';
describe('BofaModalComponent', () => {
  let component: BofaModalComponent;
  let fixture: ComponentFixture<BofaModalComponent>;
  const mockNgbActiveModal = jasmine.createSpyObj(['close', 'dismiss']);
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BofaModalComponent],
      providers: [{ provide: NgbActiveModal, useValue: mockNgbActiveModal }]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BofaModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  
  it('cross button should close the active modal', () => {
    const crossBtn = fixture.debugElement.query(By.css('.close')).nativeElement;
    crossBtn.click();
    expect(mockNgbActiveModal.dismiss).toHaveBeenCalled();
  });
});
