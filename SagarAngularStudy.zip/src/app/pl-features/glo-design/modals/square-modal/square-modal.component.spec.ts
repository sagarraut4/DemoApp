/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { SquareModalComponent } from './square-modal.component';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

describe('SquareModalComponent', () => {
  let component: SquareModalComponent;
  let fixture: ComponentFixture<SquareModalComponent>;
  const mockNgbActiveModal = jasmine.createSpyObj(['close', 'dismiss']);
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SquareModalComponent],
      providers: [{ provide: NgbActiveModal, useValue: mockNgbActiveModal }]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SquareModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  
  it('cross button should close the active modal', () => {
    const crossBtn = fixture.debugElement.query(By.css('.close')).nativeElement;
    crossBtn.click();
    expect(mockNgbActiveModal.dismiss).toHaveBeenCalled();
  });
});
