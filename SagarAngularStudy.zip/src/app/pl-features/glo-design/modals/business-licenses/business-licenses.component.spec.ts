import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BusinessLicensesComponent } from './business-licenses.component';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { By } from '@angular/platform-browser';

describe('BusinessLicensesComponent', () => {
  let component: BusinessLicensesComponent;
  let fixture: ComponentFixture<BusinessLicensesComponent>;
  const mockNgbActiveModal = jasmine.createSpyObj(['close', 'dismiss']);
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BusinessLicensesComponent],
      providers: [{ provide: NgbActiveModal, useValue: mockNgbActiveModal }]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BusinessLicensesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create business-license component', () => {
    expect(component).toBeTruthy();
  });

  it('cross button should close the active modal', () => {
    const crossBtn = fixture.debugElement.query(By.css('.close')).nativeElement;
    crossBtn.click();
    expect(mockNgbActiveModal.dismiss).toHaveBeenCalled();
  });

  it('close button should click and call close method', () => {
    spyOn(component, 'close');
    const close = fixture.debugElement.query(By.css('.lz-button-primary')).nativeElement;
    close.click();
    expect(component.close).toHaveBeenCalled();
  });

  it('close button should close the active modal', () => {
    const close = fixture.debugElement.query(By.css('.lz-button-primary')).nativeElement;
    close.click();
    expect(mockNgbActiveModal.close).toHaveBeenCalled();
  });
});
