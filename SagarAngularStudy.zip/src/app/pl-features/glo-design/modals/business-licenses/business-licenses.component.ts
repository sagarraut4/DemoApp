import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-business-licenses',
  templateUrl: './business-licenses.component.html',
  styleUrls: ['./business-licenses.component.css']
})
export class BusinessLicensesComponent implements OnInit {

  constructor(public activeModal: NgbActiveModal) { }

  ngOnInit() {
  }

  close(): void {
    this.activeModal.close();
  }
}
