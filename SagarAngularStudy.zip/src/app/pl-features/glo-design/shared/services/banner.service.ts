import {Injectable, Renderer2} from '@angular/core';
import {CookieService} from 'ngx-cookie';
import {fromEvent, Observable, ReplaySubject, Subscription} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BannerService {
  private bannerSdkAvailable: boolean;
  private renderer;
  private bannerElement: HTMLElement;
  private monitoringPromise: Promise<any>;
  private screenSizeChange: Observable<Event>;
  private screenSizeSubscription: Subscription;
  private readonly bannerHeightSubject: ReplaySubject<number>;

  constructor(private cookieService: CookieService) {
    this.bannerHeightSubject = new ReplaySubject<number>(1);
    this.screenSizeChange = fromEvent(window, 'resize');
  }

  getBannerHeight(renderer: Renderer2): ReplaySubject<number> {
    this.renderer = renderer || this.errorHandler('renderer');

    this.monitoringPromise =
      this.monitoringPromise ||
      new Promise<any>((resolve, reject) => {
        resolve(setTimeout(_ => this.startMonitoring(), 2000));
      });

    return this.bannerHeightSubject;
  }

  private errorHandler(field) {
    throw new Error(`${field} is required.`);
  }

  private startMonitoring() {
    const bannerElements: HTMLElement[] = [
      document.getElementById('onetrust-accept-btn-handler'),
      document.getElementById('accept-recommended-btn-handler'),
      document.querySelector('.onetrust-close-btn-handler')
    ];

    bannerElements.forEach(bannerElement => this.registerHandler(bannerElement));

    if (this.checkBannerAvailability()) {
      this.bannerElement = document.getElementById('onetrust-banner-sdk');
      this.screenSizeSubscription =
        this.screenSizeSubscription ||
        this.screenSizeChange.subscribe(_ => this.bannerHeightSubject.next(this.calculateBannerHeight()));
    }

    this.bannerHeightSubject.next(this.checkBannerAvailability() ? this.calculateBannerHeight() : 0);
  }

  private registerHandler(targetElement: HTMLElement) {
    if (targetElement) {

      this.bannerSdkAvailable = true;

      if (this.bannerIsActive()) {

        this.renderer.listen(targetElement, 'click', event => {

          this.bannerHeightSubject.next(0);
          this.bannerHeightSubject.complete();
          this.screenSizeSubscription.unsubscribe();
        });
      }
    } else {

      this.bannerSdkAvailable = false;
    }
  }

  private checkBannerAvailability(): boolean {
    return this.bannerSdkAvailable && this.bannerIsActive();
  }

  public bannerIsActive(): boolean {
    return !Boolean(this.cookieService.get('OptanonAlertBoxClosed'))
  }

  private calculateBannerHeight(): number {
    return this.bannerElement ? this.bannerElement.offsetHeight : 0;
  }
}
