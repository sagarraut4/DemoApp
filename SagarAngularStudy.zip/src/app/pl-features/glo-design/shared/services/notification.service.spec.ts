import { TestBed } from '@angular/core/testing';
import { NotificationService } from './notification.service';

describe('NotificationService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created notification service', () => {
    const service: NotificationService = TestBed.get(NotificationService);
    expect(service).toBeTruthy();
  });

  it('should call showNotification method', () => {
    const service: NotificationService = TestBed.get(NotificationService);
    service.showNotification('test notification');
    expect(service).toBeTruthy();
  });
});
