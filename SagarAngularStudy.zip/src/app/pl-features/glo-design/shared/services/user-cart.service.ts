import { ConstantsService } from './../../../../shared/services/constants.service';
import { PagePath } from '../../../../shared/models/page-model';
import { SEADService } from '../../../../shared/services/tracking/sead.service';
import {
  ProductConfigurationIds, CartItemsPkgIdDisplayOrder,
  ComponentsToShowZeroAmount, CustomFilingFeeIncludes, CustomItemSubTotalIncludes, IUserCartItemContent
} from '../../../../shared/models/cart-model';
import { LLCMapped } from '../../../../shared/models/llcmapped-model';
import { QuestionnaireMappingService } from '../../../../shared/services/questionnaire/questionnaire-mapping.service';
import { CartStateService } from '../../../../shared/state/cart/cart-state.service';
import { Injectable } from '@angular/core';
import { Observable, of, forkJoin, Subject } from 'rxjs';
import { IQueueEntry, TrackJsErrorLogService, UtilitiesService } from '@legalzoom/business-formation-sdk';
import {
  CartItemSource,
  UpdateCartByQuestionnaireRequest,
  CartResponse,
  CartService,
  IUserCart,
  UpdateCartByCustomerIdRequest,
  UpdateCartByCustomerIdResponse,
  CartItem,
  CartRequest,
  OrderSource,
  GetCartBalanceByCartIdResponse,
  CartItemType,
  IUserCartItem,
  CartDiscounts
} from '@legalzoom/cart-sdk';
import { AppService } from '../../../../shared/state/app';
import { HttpErrorResponse } from '@angular/common/http';
import { ProductName } from '../../../../shared/constants/product-domain';
import { flatMap, map } from 'rxjs/operators';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { CartCreationStatus, EventService } from '../../../../shared/services/event.service';
import { ProductComponentId } from '../../../../shared/models/cart-model';
import { Chapter } from '../../../../shared/models/page-model';
import { ProcessingOrderService, IUpdateProcessingOrderResponse, IUpdateProcessingOrderRequest } from '@legalzoom/processing-order-sdk';
import { LoginCustomerAndSessionResponse } from '@legalzoom/web-session-sdk';
import { IUserAnswerRequest, QuestionnaireAnswerService, IUserAnswerResponse } from '@legalzoom/questionnaire-answer-sdk';
import { CustomerService } from '@legalzoom/customer-sdk';
import { ExperimentsService } from '../../../../shared/services/experiments/experiments.service';
import { TaxPackages } from '../../../../shared/models/tax-packages-model';

@Injectable({
  providedIn: 'root'
})
export class UserCartService {
  public get cartResponse(): CartResponse {
    return this.cartState.cartResponse;
  }
  public set cartResponse(value: CartResponse) {
    this.cartState.cartResponse = value;
  }
  public get userCart(): IUserCart {
    return this.cartState.cart;
  }
  public set userCart(value: IUserCart) {
    this.cartState.cartId = value.cartId;
    this.cartState.cart = value;
    const app = this.appService.app;
    app.cartId = value.cartId;
    app.cart = value;
    this.appService.app = app;
  }

  userCartChange: Subject<IUserCart> = new Subject<IUserCart>();
  public updateCartResponse: CartResponse;
  public answerResponse: any;

  constructor(
    private cartService: CartService,
    private appService: AppService,
    private utilitiesService: UtilitiesService,
    private processingOrderService: ProcessingOrderService,
    private trackJS: TrackJsErrorLogService,
    private questionnaireService: QuestionnaireService,
    private seadService: SEADService,
    private questionnaireMappingService: QuestionnaireMappingService,
    private questionnaireAnswerService: QuestionnaireAnswerService,
    private eventService: EventService,
    private cartState: CartStateService,
    private customerService: CustomerService
  ) {
    this.cartResponse = new CartResponse();
  }

  updateCartAndProcessingOrderByCustomerId(existingCustomerId: number, updatedCustomerId: number, updatedCustomerInfo: LoginCustomerAndSessionResponse): Observable<LoginCustomerAndSessionResponse> {
    return forkJoin([this.updateCartByCustomerId(existingCustomerId, updatedCustomerId), this.updateProcessingOrderByCustomerId(existingCustomerId, updatedCustomerId)]).pipe(
      flatMap((result) => {
        return this.updateCustomerInfoInAppService(updatedCustomerInfo);
      })
    );
  }

  private updateCartByCustomerId(existingCustomerId: number, updatedCustomerId: number): Observable<UpdateCartByCustomerIdResponse> {
    const updateCartByCustomerIdRequest: UpdateCartByCustomerIdRequest = {
      customerId: updatedCustomerId,
      updatedBy: updatedCustomerId.toString()
    };
    return this.cartService.updateCartByCustomerId(this.appService.app.cartId, updateCartByCustomerIdRequest);
  }

  public prepareCreateNewCart(): IQueueEntry {
    const that = this;
    return {
      name: 'prepareCreateNewCart ' + this.constructor.name,
      pre: () => {
        this.eventService.updateCartCreationStatus(CartCreationStatus.Pending);
        return that.createNewCart();
      },
      post: (response: CartResponse) => {
        if (response) {
          const app = that.appService.app;
          app.cartId = response.cart.cartId;
          const cartItem: CartItem = response.cart.cartItems.find((ci) => ci.processingOrderId !== null);
          app.processingOrderId = cartItem.processingOrderId;
          that.appService.app = app;
          that.cartResponse = response;
          this.eventService.updateCartCreationStatus(CartCreationStatus.Created);
          window.sessionStorage.setItem('sessionStore', JSON.stringify({ "cartId": app.cartId, "processingOrderId": app.processingOrderId }));
        }
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.eventService.updateCartCreationStatus(CartCreationStatus.Error);
        this.trackJS.track(ProductName.LLC, 'user-cart.service', error);
        console.log('--failed to create cart, proceeding with error--');
        return of(null);
      }
    };
  }

  public createNewCart(): Observable<CartResponse> {
    if (!this.questionnaireService.llc.entityState) {
      this.questionnaireService.llc.entityState = 'Alaska';
    }
    const cartRequest: CartRequest = {
      processId: this.appService.app.processId,
      customerId: this.appService.app.customerId,
      orderSourceId: OrderSource.legalZoom,
      checkOpenedCart: true,
      stateId: this.questionnaireService.llc.entityState.replace(/ /g, '').replace('.', ''),
      defaultPackageConfigurationId: '0'
    };
    return this.cartService.createCart(cartRequest);
  }

  private updateProcessingOrderByCustomerId(existingCustomerId: number, updatedCustomerId: number): Observable<IUpdateProcessingOrderResponse> {
    const updateProcessingOrderRequest: IUpdateProcessingOrderRequest = {
      customerId: updatedCustomerId,
      stateId: null,
      isQuestionnaireCompleted: null,
      postOption: null,
      shippingMethodId: null,
      lastPageVisited: null,
      comment: null
    };

    return this.processingOrderService.updateProcessingOrder(this.appService.app.processingOrderId, updateProcessingOrderRequest);
  }

  public updateCustomerInfoInAppService(updatedCustomerInfo: LoginCustomerAndSessionResponse): Observable<LoginCustomerAndSessionResponse> {
    const app = this.appService.app;
    app.customerId = updatedCustomerInfo.customer.customerId;
    app.loginEmail = updatedCustomerInfo.customer.emailId;
    app.sessionId = updatedCustomerInfo.session.sessionId;
    app.accessToken = updatedCustomerInfo.session.accessToken;
    this.appService.app = app;
    const isGuest = this.customerService.isGuestCustomer(this.appService.loginEmail);

    this.utilitiesService.saveCookies(this.appService.app.sessionId, this.appService.app.accessToken, this.appService.app.customerId, isGuest);
    return of(updatedCustomerInfo);
  }
  public trackPackage(pkgConfigId) {
    let selectedPackageName = '';
    switch (pkgConfigId) {
      case ProductConfigurationIds.economyLLCPackage:
        selectedPackageName = 'Economy LLC';
        break;
      case ProductConfigurationIds.standarLLCPackage:
        selectedPackageName = 'Standard LLC';
        break;
      case ProductConfigurationIds.expressGoldLLCPackage:
        selectedPackageName = 'Express Gold LLC';
        break;
      case ProductConfigurationIds.tier1LLCPackage:
        selectedPackageName = 'LLC - Get Me Started';
        this.questionnaireService.llc.legalAdvice = false;
        break;
      case ProductConfigurationIds.tier2LLCPackage:
        selectedPackageName = 'LLC - Support Me';
        this.questionnaireService.llc.legalAdvice = true;
        break;
      case ProductConfigurationIds.tier3LLCPackage:
        selectedPackageName = 'LLC - Help Me Grow';
        // defaulting value since page is skipped
        this.questionnaireService.llc.legalAdvice = true;
        break;
    }

    this.questionnaireService.llc.packageSelected = pkgConfigId;
    this.seadService.TrackingObject.pkgSelected = selectedPackageName;
    this.seadService.PushToTealium();
  }

  getUpdatedCart(cartId: number, token: string, customerId: number): Observable<IUserCart> {
    return this.getMappedCartWithBalance(cartId, token, customerId).pipe(
      map((res) => {
        return this.getCartModelFromApiData(res.updateCartResponse, res.cartBalanceResponse);
      })
    );
  }

  public getMappedCartWithBalance(
    cartId: number,
    token: string,
    customerId: number
  ): Observable<{
    updateCartResponse: CartResponse;
    cartBalanceResponse: GetCartBalanceByCartIdResponse;
  }> {
    const mapping: LLCMapped = this.questionnaireMappingService.doMapping(this.questionnaireService.llc, this.appService.app.processingOrderId);

    const answerRequest: IUserAnswerRequest = {
      questionnaireFieldGroupAnswers: {
        userOrderId: mapping.userOrderId,
        questionnaireId: this.appService.questionnaireId,
        fieldAnswers: mapping.fieldAnswers,
        groupAnswers: [] // mapping.groupAnswers
      }
    };

    const updateCartRequest: UpdateCartByQuestionnaireRequest = {
      cartItemSource: CartItemSource.userAction,
      changedBy: customerId.toString(),
      fieldAnswers: null,
      groupAnswers: null
    };

    // use this code for debugging RYO page
    // return this.cartService.getCart(cartId, customerId, token).pipe(flatMap(updateCartResponse => {
    //   return this.cartService.getCartBalanceByCartId(cartId, customerId, token)
    //     .pipe(map((cartBalanceResponse) => {
    //       return {
    //         updateCartResponse, cartBalanceResponse
    //       };
    //     }));
    // }));

    return this.questionnaireAnswerService.saveAndGetMappedUserAnswers(answerRequest, this.appService.app.questionnaireId).pipe(
      flatMap((answerResponse: IUserAnswerResponse) => {
        updateCartRequest.fieldAnswers = answerResponse.questionnaireFieldGroupAnswers.fieldAnswers;
        updateCartRequest.groupAnswers = answerResponse.questionnaireFieldGroupAnswers.groupAnswers;
        return this.cartService.updateCartByQuestionnaire(cartId, updateCartRequest).pipe(
          flatMap((updateCartResponse: CartResponse) => {
            return this.cartService.getCartBalanceByCartId(cartId).pipe(
              map((cartBalanceResponse) => {
                return {
                  updateCartResponse,
                  cartBalanceResponse
                };
              })
            );
          })
        );
      })
    );
  }

  public getCartModelFromApiData(updateCartResponse: CartResponse, cartBalanceResponse: GetCartBalanceByCartIdResponse): IUserCart {
    //  const isMobileMode = this.isMobileMode();

    // removes cancelled cart items which we do not need
    updateCartResponse.cart.cartItems = updateCartResponse.cart.cartItems.filter((item) => !item.isCancelled);

    const installementPrice: number = this.getCartInstallmentFee(cartBalanceResponse);

    const promoCode: string = this.getCartPromoCode(cartBalanceResponse);

    this.insertCompanyDetailsCartItem(updateCartResponse);

    this.insertOAEinBL(updateCartResponse);

    this.insertSalesTaxAndDigitalDownloadDetails(updateCartResponse);

    this.addBPPToCart(updateCartResponse, ProductConfigurationIds.economyLLCPackage, ProductConfigurationIds.economyLLCShipping);

    this.insertUnselectedPackages(updateCartResponse);

    this.insertTaxPackages(updateCartResponse);

    let cartItems: IUserCartItem[] = this.getCartItemsViewModel(updateCartResponse);
    cartItems = cartItems.sort((a, b) => a.rank - b.rank);
    return this.userCart = {
      cartId: updateCartResponse.cart.cartId,
      packageTitle: '',
      dueNow: cartBalanceResponse.cartBalance < 0 ? 0 : cartBalanceResponse.cartBalance,
      discount: cartBalanceResponse.totalDiscount,
      cartItems,
      installmentAmount: installementPrice,
      storeCredit: cartBalanceResponse.storeCreditAvailable,
      promoCode,
      isThreePay: updateCartResponse.cart.cartFlags.threePay
    };
  }

  private insertUnselectedPackages(cartRes: CartResponse): void {
    if (
      cartRes.cart.cartItems.findIndex(
        (x) => x.productConfigurationId === ProductConfigurationIds.registeredAgent || x.productConfigurationId === ProductConfigurationIds.registeredAgent_199 || x.productConfigurationId === ProductConfigurationIds.registeredAgent_249
      ) === -1
    ) {
      cartRes.cart.cartItems.push(
        this.getApiCartItem(ProductComponentId.custom_RegisteredAgent_NoThanks, this.questionnaireService.llc.isMobile ? 'Registered Agent Services' : 'LegalZoom Registered Agent', ProductConfigurationIds.custom_RegisteredAgent_details)
      );
    }

    if (cartRes.cart.cartItems.findIndex((x) => x.productConfigurationId === ProductConfigurationIds.essentialComplianceTaxPreparationPackage) === -1) {
      cartRes.cart.cartItems.push(
        this.getApiCartItem(
          ProductComponentId.custom_TotalCompliance,
          'Total Compliance',
          ProductConfigurationIds.custom_Total_Compliance));
    }

    // TODO check if we need to add this
    // if (cartRes.cart.cartItems.findIndex( x => x.productConfigurationId === ProductConfigurationIds.bapAnnualTax )
    // === -1) {
    //   // Add tax
    //   cartRes.cart.cartItems.push(
    //     this.getApiCartItem(ProductComponentId.Custom_Affordable_Tax, 'Affordable Tax - No thanks', ProductConfigurationIds.Custom_Affordable_Tax)      );
    // }

    const taxAndLegalPkgs: number[] = [ProductConfigurationIds.bapMonthlyLegal, ProductConfigurationIds.bapMonthlyLegalWisconsin, ProductConfigurationIds.bapMonthlyLegalProtect, ProductConfigurationIds.bapMonthlyLegalProtectWisconsin];
    if (cartRes.cart.cartItems.findIndex((x) => taxAndLegalPkgs.includes(x.productConfigurationId)) === -1) {
      // Add legal
      cartRes.cart.cartItems.push(
        this.getApiCartItem(
          this.questionnaireService.llc.entityState
            && this.questionnaireService.llc.entityState.toLowerCase() === 'wisconsin'
            ? ProductComponentId.custom_LegalProtext_SmartEmployer_WI
            : ProductComponentId.custom_LegalProtext_SmartEmployer,
          'Legal Protect Plan',
          this.questionnaireService.llc.entityState
            && this.questionnaireService.llc.entityState.toLowerCase() === 'wisconsin'
            ? ProductComponentId.custom_LegalProtext_SmartEmployer_WI
            : ProductComponentId.custom_LegalProtext_SmartEmployer,
          // this.getAnnualLegalProductConfigurationId(this.questionnaireService.llc.entityState),
          0,
          false,
          '',
          CartItemType.CrossSellAndAddOn_Offer
        )
      );
    }
  }


  private insertTaxPackages(cartRes: CartResponse): void {
    if ((this.questionnaireService.llc.taxPackageSelected == undefined ||
      this.questionnaireService.llc.taxPackageSelected == null ||
      this.questionnaireService.llc.taxPackageSelected == ProductConfigurationIds.custom_Tax_Package ||
      this.questionnaireService.llc.taxPackageSelected.toString() == '')) {
      cartRes.cart.cartItems.push(
        this.getApiCartItem(
          ProductComponentId.custom_Tax_Package,
          'Tax and Accounting Plans',
          ProductConfigurationIds.custom_Tax_Package));
    }
    else {
      const taxPackage = TaxPackages.find(tp => tp.productConfigurationId == this.questionnaireService.llc.taxPackageSelected);
      cartRes.cart.cartItems.push(
        this.getApiCartItem(
          taxPackage.productComponentId,
          taxPackage.title,
          taxPackage.productConfigurationId));
    }
  }


  public getAnnualLegalProductConfigurationId(entityState: string) {
    return entityState && entityState.toLowerCase() === 'wisconsin' ? ProductConfigurationIds.bapMonthlyLegalProtectWisconsin : ProductConfigurationIds.bapMonthlyLegalProtect;
  }

  public getCartItemsViewModel(cartData: CartResponse): IUserCartItem[] {
    return cartData.cart.cartItems.map((item) => {
      const updatedContent = this.renameCartItem(item);
      return {
        productConfigurationId: item.productConfigurationId,
        productComponentId: item.productComponentId,
        type: item.productTypeId,
        title: updatedContent.title != null ? updatedContent.title : item.productName,
        description: null,
        details:
          updatedContent.intro && updatedContent.body
            ? {
              intro: updatedContent.intro,
              body: updatedContent.body,
              showBody: false
            }
            : null,
        amount: item.extendedPrice,
        hideOnRYO: null,
        hideEditLink: null,
        showZeroAmount: ComponentsToShowZeroAmount.findIndex((c) => c === item.productConfigurationId) > -1,
        rank: (CartItemsPkgIdDisplayOrder.indexOf(item.productConfigurationId) === -1 ? 0 : CartItemsPkgIdDisplayOrder.indexOf(item.productConfigurationId)),
        isShowAmountText: null,
        amountText: updatedContent.amountText,
        isSelected: null,
        subItems: null,
        isAdded: updatedContent.isAdded,
        subscriptionMessage: updatedContent.subscriptionMessage
      };
    });
  }

  private renameCartItem(cartItem: CartItem): IUserCartItemContent {
    const updatedContent = {
      title: null,
      intro: null,
      body: null,
      amountText: null,
      isAdded: null,
      subscriptionMessage: null
    } as IUserCartItemContent

    switch (cartItem.productConfigurationId) {
      case ProductConfigurationIds.tier1LLCPackage:
        updatedContent.title = 'Get Me Started';
        break;
      case ProductConfigurationIds.tier2LLCPackage:
        updatedContent.title = 'Support Me';
        break;
      case ProductConfigurationIds.tier3LLCPackage:
        updatedContent.title = 'Help Me Grow';
        break;
      case ProductConfigurationIds.economyLLCStateFilingFee:
      case ProductConfigurationIds.standardLLCStateFilingFee:
      case ProductConfigurationIds.goldExpressLLCStateFilingFee:
      case ProductConfigurationIds.standardFilingFee:
        updatedContent.title = this.questionnaireService.llc.entityState ? `${this.questionnaireService.llc.entityState} filing fee <br> This is the admin fee charged by the state.` : cartItem.productName;
        break;
      case ProductConfigurationIds.registeredAgent:
      case ProductConfigurationIds.registeredAgent_199:
      case ProductConfigurationIds.registeredAgent_249:
        updatedContent.title = 'LegalZoom Registered Agent <br><span class="content-3 font-weight-normal"> No fees until documents sent to state </span>';
        updatedContent.intro = '(No fees until documents sent to state)';
        updatedContent.body =
          "LegalZoom's Registered Agent Service only starts when your LLC is submitted to state." +
          ' When we receive official notification that your LLC has been registered, your card will automatically be charged $159.' +
          ' The service renews automatically each year, billed to your card, for the service price (currently $159).' +
          ' You may cancel online or by calling us at (844) 962-7490. You will first need to appoint a new RA for your business.';
        updatedContent.amountText = 'Added';
        updatedContent.isAdded = true;
        updatedContent.subscriptionMessage = 'Billed when your filing documents are sent to the state. Cancel anytime online or by phone after you have appointed a new registered agent.'
        break;
      case ProductConfigurationIds.expediteFilingFee:
      case ProductConfigurationIds.standardExpediteFilingFee:
        updatedContent.title = `${this.questionnaireService.llc.entityState} expedited fee + filing fee`;
        break;
      case ProductConfigurationIds.processingExpedited:
        updatedContent.title = 'Expedited Processing';
        break;
      case ProductConfigurationIds.essentialComplianceTaxPreparationPackage:
        updatedContent.title = 'Total Compliance';
        updatedContent.intro = '(10 days included)';
        updatedContent.body =
          'This package is offered for 10 days. After the 10-day period, benefits continue automatically for the same term and rate unless otherwise notified.' +
          ' Cancel online or by calling (888) 310-0151. For full details, please see our' +
          ' <a href="http://www.legalzoom.com/legal/product-service-terms/supplemental-terms-of-service-for-advantage-subscriptions" target="_blank">Subscription Terms</a>' +
          ' and <a href="https://www.legalzoom.com/legal/product-service-terms/legal-plan-contract" target="_blank">Legal Plan Contract</a>.';
        updatedContent.amountText = 'Added';
        updatedContent.isAdded = true;
        updatedContent.subscriptionMessage = 'Billed after 10-day trial. Cancel anytime online or by phone.';
        break;
      case ProductConfigurationIds.bapAnnualTax:
        updatedContent.intro = '(10 days included)';
        updatedContent.body =
          'This package is offered as a trial for 10 days.' +
          ' After the 10-day trial period, benefits continue automatically for the same term and rate unless otherwise notified.' +
          ' Cancel online or by calling (888) 310-0151. For full details, please see our' +
          ' <a href="http://www.legalzoom.com/legal/product-service-terms/supplemental-terms-of-service-for-advantage-subscriptions" target="_blank">Subscription Terms</a>' +
          ' and <a href="https://www.legalzoom.com/legal/product-service-terms/legal-plan-contract" target="_blank">Legal Plan Contract</a>.';
        updatedContent.isAdded = true;
        break;
      case ProductConfigurationIds.bapMonthlyLegal:
        updatedContent.title = 'Legal Protect Plan';
        updatedContent.intro = '(10 days included) ';
        updatedContent.body =
          'This package is offered as a trial for 10 days.' +
          ' After the 10-day trial period, benefits continue automatically for the same term and rate unless otherwise notified.' +
          ' Cancel online or by calling (888) 310-0151. For full details, please see our' +
          ' <a href="http://www.legalzoom.com/legal/product-service-terms/supplemental-terms-of-service-for-advantage-subscriptions" target="_blank">Subscription Terms</a>' +
          ' and <a href="https://www.legalzoom.com/legal/product-service-terms/legal-plan-contract" target="_blank">Legal Plan Contract</a>.';
        updatedContent.amountText = cartItem.productName.includes('- No thanks') ? 'No thanks' : 'Added';
        updatedContent.isAdded = cartItem.productName.includes('- No thanks') ? false : true;
        updatedContent.subscriptionMessage = 'Billed after 10-day trial. Cancel anytime online or by phone.';
        break;
      case ProductConfigurationIds.bapMonthlyLegalWisconsin:
        updatedContent.title = 'Legal Protect Plan';
        updatedContent.intro = '(10 days included) ';
        updatedContent.body =
          'This package is offered as a trial for 10 days.' +
          ' After the 10-day trial period, benefits continue automatically for the same term and rate unless otherwise notified.' +
          ' Cancel online or by calling (888) 310-0151. For full details, please see our' +
          ' <a href="http://www.legalzoom.com/legal/product-service-terms/supplemental-terms-of-service-for-advantage-subscriptions" target="_blank">Subscription Terms</a>' +
          ' and <a href="https://www.legalzoom.com/legal/product-service-terms/legal-plan-contract" target="_blank">Legal Plan Contract</a>.';
        updatedContent.amountText = cartItem.productName.includes('- No thanks') ? 'No thanks' : 'Added';
        updatedContent.isAdded = cartItem.productName.includes('- No thanks') ? false : true;
        updatedContent.subscriptionMessage = 'Billed after 10-day trial. Cancel anytime online or by phone.';
        break;
      case ProductConfigurationIds.bapMonthlyLegalProtect:
        updatedContent.title = 'Legal Protect Plan';
        updatedContent.amountText = cartItem.productName.includes('- No thanks') ? 'No thanks' : 'Added';
        updatedContent.isAdded = cartItem.productName.includes('- No thanks') ? false : true;
        updatedContent.subscriptionMessage = 'Billed after 10-day trial. Cancel anytime online or by phone.';
        break;
      case ProductConfigurationIds.bapMonthlyLegalProtectWisconsin:
        updatedContent.title = 'Legal Protect Plan';
        updatedContent.amountText = cartItem.productName.includes('- No thanks') ? 'No thanks' : 'Added';
        updatedContent.isAdded = cartItem.productName.includes('- No thanks') ? false : true;
        updatedContent.subscriptionMessage = 'Billed after 10-day trial. Cancel anytime online or by phone.';
        break;
      case 2400:
        updatedContent.intro = 'Filing Fee';
        updatedContent.body = '';
        break;
      case 4529:
        updatedContent.intro = '';
        updatedContent.body = '';
        break;
      case ProductConfigurationIds.salesTax:
        updatedContent.title = 'Sales Tax';
        updatedContent.intro = '';
        updatedContent.body = '';
        break;
      case ProductConfigurationIds.salesTax_details:
        updatedContent.title = 'We’ve got you covered!';
        updatedContent.intro = '';
        updatedContent.body = '';
        break;
      case ProductConfigurationIds.custom_OAEinBL_NoThanks:
        updatedContent.amountText = 'No thanks';
        updatedContent.intro = '';
        updatedContent.isAdded = false;
        updatedContent.subscriptionMessage = 'Secure the documents needed to run your company, open a bank account, and meet requirements.';
        break;
      case ProductConfigurationIds.custom_OAEinBL:
        updatedContent.amountText = '$' + cartItem.extendedPrice.toString();
        updatedContent.intro = '';
        updatedContent.isAdded = true;
        updatedContent.subscriptionMessage = 'Secure the documents needed to run your company, open a bank account, and meet requirements.';
        break;
      case ProductConfigurationIds.compliancePackage_noThanks:
        updatedContent.amountText = 'No thanks';
        updatedContent.isAdded = false;
        updatedContent.subscriptionMessage = 'Make sure your business stays compliant to keep your limited liability protection.';
        break;
      case ProductConfigurationIds.custom_RegisteredAgent_details:
        updatedContent.title = 'LegalZoom Registered Agent';
        updatedContent.amountText = 'No thanks';
        updatedContent.isAdded = false;
        updatedContent.subscriptionMessage = 'Having a Registered Agent is legally required in most states.';
        break;
      case ProductConfigurationIds.custom_LegalProtext_SmartEmployer:
        updatedContent.amountText = 'No thanks';
        updatedContent.isAdded = false;
        updatedContent.subscriptionMessage = 'Get legal advice on critical business topics from experienced independent attorneys.';
        break;
      case ProductConfigurationIds.custom_LegalProtext_SmartEmployer_WI:
        updatedContent.amountText = 'No thanks';
        updatedContent.isAdded = false;
        updatedContent.subscriptionMessage = 'Get legal advice on critical business topics from experienced independent attorneys.';
        break;
      case ProductConfigurationIds.statementOfInformationFilingFee:
        updatedContent.title = 'Statement of Information filing fee';
        break;
      case ProductConfigurationIds.custom_Tax_Package:
        updatedContent.amountText = 'No thanks';
        updatedContent.isAdded = false;
        break;
      case ProductConfigurationIds.tax_Prep_Essentials_Plan:
      case ProductConfigurationIds.accounting_Full_Service_Tax_Plan:
        const taxPackage = TaxPackages.find(tp => tp.productConfigurationId == this.questionnaireService.llc.taxPackageSelected);
        updatedContent.title = `${taxPackage.title}<br><span class="content-3 font-weight-normal">Annual plan, paid monthly</span>`;
        updatedContent.amountText = 'Added';
        updatedContent.isAdded = true;
        updatedContent.subscriptionMessage = 'Annual plan, paid monthly';
        break;
      // TODO add details for digital download
      //  case ProductConfigurationIds.digitalDownload2_details:
      //  break;
      default:
        break;
    }
    return updatedContent;
  }

  private getCartInstallmentFee(cartBalance: GetCartBalanceByCartIdResponse): number {
    const installmentFee = 2;

    if (cartBalance.totalAmount >= 200 && cartBalance.cartInstallments) {
      const prices = [cartBalance.cartInstallments.firstInstallment.installmentAmount, cartBalance.cartInstallments.secondInstallment.installmentAmount, cartBalance.cartInstallments.thirdInstallment.installmentAmount];
      return Math.max(...prices) + installmentFee;
    }

    return 0;
  }

  private getCartPromoCode(cartBalance: GetCartBalanceByCartIdResponse): string {
    if (cartBalance.cartDiscounts) {
      const discount: CartDiscounts = cartBalance.cartDiscounts.find((d) => d.discountCode && d.discountCode.length > 0);
      if (discount) {
        return discount.discountCode;
      }
    }
    return null;
  }

  private insertCompanyDetailsCartItem(cartRes: CartResponse): void {
    const companyRowItem: CartItem = this.getApiCartItem(ProductComponentId.custom_Company, 'Company info', ProductConfigurationIds.custom_Company);
    const entityNameRowItem: CartItem = this.getApiCartItem(ProductComponentId.custom_EntityName, this.questionnaireService.llc.entityName, ProductConfigurationIds.custom_EntityName);

    cartRes.cart.cartItems.unshift(companyRowItem, entityNameRowItem);
  }

  private getApiCartItem(productComponentId: number, productName: string, productConfigurationId: number = 0, extendedPrice: number = 0, isShowAmountText: boolean = false, amountText: string = '', productTypeId: number = 0): CartItem {
    return {
      cartItemId: 0,
      parentCartItemId: 0,
      productComponentId,
      productConfigurationId: productConfigurationId != null ? productConfigurationId : 0,
      relationshipTypeId: 0,
      productName,
      productTypeId: 0,
      basePrice: 0,
      extendedPrice,
      adjustedPrice: 0,
      quantity: 0,
      processingOrderId: 0,
      isPrePaid: false,
      shouldDisplayOnBill: false,
      isCancelled: false,
      productBasePriceId: 0,
      productPriceAdjustment: 0,
      stateId: 0,
      countyId: 0,
      cartItemSource: '',
      sourceOrderItemId: '',
      lineNumber: 0,
      dateCreated: '',
      createdBy: '',
      dateUpdated: '',
      updatedBy: ''
    };
  }

  private insertSalesTaxAndDigitalDownloadDetails(cartRes: CartResponse): void {
    cartRes.cart.cartItems.push(this.getApiCartItem(ProductComponentId.custom_SalesTax, 'Sales Tax', ProductConfigurationIds.salesTax, 0));
    cartRes.cart.cartItems.push(this.getApiCartItem(ProductComponentId.custom_SalesTaxDetails, 'We’ve got you covered!', ProductConfigurationIds.salesTax_details, 0));
    cartRes.cart.cartItems.push(this.getApiCartItem(ProductComponentId.custom_DigitalDownload2_details, 'All your documents in one convenient location + 1 TB of free cloud storage.',
      ProductConfigurationIds.digitalDownload2_details, 0));
  }
  // this method combines (OA/EIN/Business Licenses) into one line item
  private insertOAEinBL(cartRes: CartResponse): void {
    const oAIndex: number = cartRes.cart.cartItems.findIndex((i) => i.productComponentId === ProductComponentId.operatingAgreement);
    const einIndex: number = cartRes.cart.cartItems.findIndex((i) => i.productComponentId === ProductComponentId.ein);
    const blIndex: number = cartRes.cart.cartItems.findIndex((i) => i.productComponentId === ProductComponentId.businessLicense);
    this.inSertOAEinBLforControl(oAIndex, cartRes, einIndex, blIndex);
  }

  private inSertOAEinBLforControl(oAIndex: number, cartRes: CartResponse, einIndex: number, blIndex: number) {
    let cartItemTotal = 0;
    let cartItemName = '';
    if (oAIndex === -1) {
      cartItemName += 'Essential documents';
    } else {
      if (oAIndex > -1) {
        cartItemName += 'Operating agreement';
        cartItemTotal += cartRes.cart.cartItems[oAIndex].extendedPrice;
      }
      if (einIndex > -1) {
        cartItemName += blIndex > -1 ? ', EIN' : ' and EIN';
        cartItemTotal += cartRes.cart.cartItems[einIndex].extendedPrice;
      }
      if (blIndex > -1) {
        cartItemName += ' and licenses';
        cartItemTotal += cartRes.cart.cartItems[blIndex].extendedPrice;
      }
    }

    cartRes.cart.cartItems.push(
      this.getApiCartItem(
        oAIndex === -1 ? ProductComponentId.custom_OAEinBL_NoThanks : ProductComponentId.custom_OAEinBL,
        cartItemName,
        oAIndex === -1 ? ProductConfigurationIds.custom_OAEinBL_NoThanks : ProductConfigurationIds.custom_OAEinBL,
        cartItemTotal
      )
    );
  }

  private addBPPToCart(cartRes: CartResponse, configId: number, shipId: number) {
    const isEconomyPackage = cartRes.cart.cartItems.some((x) => x.productConfigurationId === configId);
    const hasProfPrintShipping = cartRes.cart.cartItems.some((x) => x.productConfigurationId === shipId);
    if (isEconomyPackage && !hasProfPrintShipping) {
      const itemToAdd = this.getApiCartItem(ProductComponentId.custom_ProfessionPrint, 'Professional Printing - Standard', shipId, 0, false, '', CartItemType.ShippingItems);

      cartRes.cart.cartItems.splice(4, 0, itemToAdd);
    } else if (hasProfPrintShipping) {
      // Remove Prof print item and add it to proper position to display it on UI
      const shippingItemIndex = cartRes.cart.cartItems.findIndex((x) => x.relationshipTypeId === CartItemType.ShippingItems && x.productConfigurationId === shipId);
      const removedItem = cartRes.cart.cartItems.splice(shippingItemIndex, 1);
      cartRes.cart.cartItems.splice(4, 0, removedItem[0]);
      this.questionnaireService.llc.professionalPrintSelected = true;
    }
  }

  prepareGetCartById(context: any, appService: any, cartId: number, customerId: number, productName: ProductName): IQueueEntry {
    const that = this;
    return {
      name: 'prepareGetCartById cart.service ' + context.constructor.name,
      pre: () => {
        return that.cartService.getCart(cartId);
      },
      post: (response) => {
        const appState = appService.app;
        if (!!response) {
          appState.cartId = response.cart.cartId;
          context.cart = response.cart;
          if (response.cart.cartStatus === "Expired") {
            that.eventService.updateCartCreationStatus(CartCreationStatus.Pending);
            that.createNewCart().subscribe((res: CartResponse) => {
              if (res) {
                const app = that.appService.app;
                app.cartId = res.cart.cartId;
                const cartItem: CartItem = res.cart.cartItems.find((ci) => ci.processingOrderId !== null);
                app.processingOrderId = cartItem.processingOrderId;
                that.appService.app = app;
                that.cartResponse = res;
                this.eventService.updateCartCreationStatus(CartCreationStatus.Created);
                window.sessionStorage.setItem('sessionStore', JSON.stringify({ "cartId": app.cartId, "processingOrderId": app.processingOrderId }));
              }
            });
          }
        } else {
          appState.cartId = 0;
          appState.processingOrderId = 0;
        }
        appService.app = appState;
      },
      error: (error: HttpErrorResponse) => {
        console.log(error.message);
        this.trackJS.track(productName, 'user-cart.service' + context.constructor.name, error);
        return of(null);
      }
    };
  }

  public savePackageSelected(pkgConfigId: number): void {
    let selectedPackageName = '';
    switch (pkgConfigId) {
      case ProductConfigurationIds.economyLLCPackage:
        selectedPackageName = 'Economy LLC';
        break;
      case ProductConfigurationIds.standarLLCPackage:
        selectedPackageName = 'Standard LLC';
        break;
      case ProductConfigurationIds.expressGoldLLCPackage:
        selectedPackageName = 'Express Gold LLC';
        break;
      case ProductConfigurationIds.tier1LLCPackage:
        selectedPackageName = 'LLC - Get Me Started';
        this.questionnaireService.llc.legalAdvice = false;
        break;
      case ProductConfigurationIds.tier2LLCPackage:
        selectedPackageName = 'LLC - Support Me';
        this.questionnaireService.llc.legalAdvice = true;
        break;
      case ProductConfigurationIds.tier3LLCPackage:
        selectedPackageName = 'LLC - Help Me Grow';
        // defaulting value since page is skipped
        this.questionnaireService.llc.legalAdvice = true;
        break;
    }
  }
}
