import { Renderer2 } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { CookieService } from 'ngx-cookie';
import { BannerService } from './banner.service';

describe('BannerService', () => {
  let service: BannerService
  const mockCookieService = jasmine.createSpyObj(['get', 'post', 'put', 'delete']);
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        Renderer2,
        { provide: CookieService, useValue: mockCookieService },
      ]
    });
    service = TestBed.get(BannerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should get getBannerHeight', () => {
    const renderer = TestBed.get(Renderer2)
    const result = service.getBannerHeight(renderer);
    expect(result).not.toBeNull();
  });
});
