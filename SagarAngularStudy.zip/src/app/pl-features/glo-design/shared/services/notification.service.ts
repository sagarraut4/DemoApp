import { BreakpointObserver, BreakpointState, MediaMatcher } from '@angular/cdk/layout';
import { ComponentFactoryResolver, Injectable,  } from '@angular/core';
import { NotificationContainerComponent } from '../components/notification-container/notification-container.component';
import { NotificationMobilePopupComponent } from '../components/notification-mobile-popup/notification-mobile-popup.component';
import { NotificationPopupComponent } from '../components/notification-popup/notification-popup.component';

@Injectable({
  providedIn: 'root'
})
export class NotificationService {

  private notificationContainer: NotificationContainerComponent;

  private queue: string[] = [];

  private isMobile = false;

  constructor(private componentFactoryResolver: ComponentFactoryResolver, private breakpointObserver: BreakpointObserver) {

    this.breakpointObserver
      .observe(['(max-width: 767px)'])
      .subscribe((state: BreakpointState) => {
        this.isMobile = state.matches;
      });
  }

  public setNotificationContainer(ref: NotificationContainerComponent) {
    this.notificationContainer = ref;

    if (this.queue.length > 0) {
      this.queue.forEach( notification => {
        this.showNotification(notification);
      });
    }
  }

  public showNotification(text: string, icon: string = '') {

    if (!this.notificationContainer) {
      this.queue.push(text);
      return;
    }

    if (this.isMobile) {
      const componentFactoryMobile = this.componentFactoryResolver.resolveComponentFactory(NotificationMobilePopupComponent);
      const componentRefMobile = this.notificationContainer.viewContainer.createComponent<NotificationMobilePopupComponent>(componentFactoryMobile);
      componentRefMobile.instance.notificationText = text;
      componentRefMobile.instance.componentRef = componentRefMobile;
    } else {
      const componentFactory = this.componentFactoryResolver.resolveComponentFactory(NotificationPopupComponent);
      const componentRef = this.notificationContainer.viewContainer.createComponent<NotificationPopupComponent>(componentFactory);
      componentRef.instance.notificationText = text;
      componentRef.instance.componentRef = componentRef;
    }
  }
}
