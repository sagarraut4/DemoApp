import { TestBed, inject } from '@angular/core/testing';
import { of } from 'rxjs';
import { LoginCustomerAndSessionResponse, Customer, Session } from '@legalzoom/web-session-sdk';
import { EventService } from 'src/app/shared/services/event.service';
import { QuestionnaireMappingService } from 'src/app/shared/services/questionnaire/questionnaire-mapping.service';
import { SEADService } from 'src/app/shared/services/tracking/sead.service';
import { QuestionnaireService } from 'src/app/shared/services/questionnaire/questionnaire.service';
import { ProcessingOrderModule, ProcessingOrderService } from '@legalzoom/processing-order-sdk';
import { UtilitiesService, QueueService } from '@legalzoom/business-formation-sdk';
import { AppService } from 'src/app/shared/state/app';
import { CookieService } from 'ngx-cookie';
import { CartModule, CartService, Cart } from '@legalzoom/cart-sdk';
import { UserCartService } from './user-cart.service';
import { QuestionnaireAnswerService } from '@legalzoom/questionnaire-answer-sdk';
import { ProductConfigurationIds } from '../../../../shared/models/cart-model';
import { ProductName } from '../../../../shared/constants/product-domain';
import { COMMON_LIB_CONFIG, CommonLibConfig } from '@legalzoom/common-sdk';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('UserCartService', () => {
  const mockCartService = jasmine.createSpyObj(['updateCartByCustomerId', 'createCart', 'updateCartByQuestionnaire', 'updateCartByQuestionnaire', 'getCartBalanceByCartId', 'getCart']);
  const mockCookieService = jasmine.createSpyObj(['get', 'post', 'put', 'delete']);
  const mockAppService = { app: { processingOrderId: 1, questionnaireId: 1 }, questionnaireId: 1 };
  const mockUtilitiesService = jasmine.createSpyObj(['saveCookies']);
  const mockProcessingOrderService = jasmine.createSpyObj(['updateProcessingOrder']);
  const mockQuestionnaireService = { llc: { currentView: '', packageSelected: '', entityState: 'California', legalAdvice: false } };
  const mockSeadService = jasmine.createSpyObj(['PushToTealium']);
  mockSeadService.TrackingObject = { pkgSelected: '' };
  const mockQuestMappingService = jasmine.createSpyObj(['doMapping']);
  const mockQuestAnswerService = jasmine.createSpyObj(['saveAndGetMappedUserAnswers']);
  const mockEventService = jasmine.createSpyObj(['updateCartCreationStatus']);
  const mockCart = {
    cart: {
      cartId: 123,
      cartItems: [{ processingOrderId: 123 }]
    }
  };
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, CartModule, ProcessingOrderModule],
      providers: [
        UserCartService,
        { provide: CartService, useValue: mockCartService },
        { provide: CookieService, useValue: mockCookieService },
        { provide: AppService, useValue: mockAppService },
        { provide: UtilitiesService, useValue: mockUtilitiesService },
        { provide: ProcessingOrderService, useValue: mockProcessingOrderService },
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: SEADService, useValue: mockSeadService },
        { provide: QuestionnaireMappingService, useValue: mockQuestMappingService },
        { provide: QuestionnaireAnswerService, useValue: mockQuestAnswerService },
        { provide: EventService, useValue: mockEventService },
        { provide: COMMON_LIB_CONFIG, useValue: new CommonLibConfig('', '', '', '', '') }
      ]
    });
  });

  it('UserCartService should ...', inject([UserCartService], (service: UserCartService) => {
    expect(service).toBeTruthy();
  }));

  it('updateCartAndProcessingOrderByCustomerId method update cart and processingOrder', () => {
    const service: UserCartService = TestBed.get(UserCartService);
    const updatedCustomerInfoResponse = new LoginCustomerAndSessionResponse();

    updatedCustomerInfoResponse.customer = new Customer();
    updatedCustomerInfoResponse.customer.customerId = 123;
    updatedCustomerInfoResponse.customer.emailId = 'test@legalzoom.com';
    updatedCustomerInfoResponse.customer.password = 'testPass';

    updatedCustomerInfoResponse.session = new Session();
    updatedCustomerInfoResponse.session.sessionId = 'sessionId';
    updatedCustomerInfoResponse.session.accessToken = 'accessToken';
    mockCartService.updateCartByCustomerId.and.returnValue(of(true));
    mockProcessingOrderService.updateProcessingOrder.and.returnValue(of(true));

    service.updateCartAndProcessingOrderByCustomerId(1234, 4321, updatedCustomerInfoResponse);

    expect(mockCartService.updateCartByCustomerId).toHaveBeenCalled();
    expect(mockProcessingOrderService.updateProcessingOrder).toHaveBeenCalled();
  });


  it('prepareCreateNewCart method should prepare the cart', () => {
    const service: UserCartService = TestBed.get(UserCartService);
    const mockQueueService = TestBed.get(QueueService);
    mockCartService.createCart.and.returnValue(of(mockCart));
    mockQueueService.add(service.prepareCreateNewCart());
    mockQueueService.process().subscribe();
    expect(mockCartService.createCart).toHaveBeenCalled();
    expect(mockEventService.updateCartCreationStatus).toHaveBeenCalled();
    expect(service.cartResponse.cart.cartId).toBe(123);
  });

  it('trackPackage method should track the package', () => {
    const service: UserCartService = TestBed.get(UserCartService);
    service.trackPackage(ProductConfigurationIds.economyLLCPackage);
    expect(mockQuestionnaireService.llc.packageSelected).not.toBeNull();
    expect(mockSeadService.TrackingObject.pkgSelected).not.toBeNull();
    expect(mockSeadService.PushToTealium).toHaveBeenCalled();
  });

  it('getUpdatedCart method should get the updated cart', () => {
    const service: UserCartService = TestBed.get(UserCartService);

    mockQuestMappingService.doMapping.and.returnValue({ userOrderId: 1, fieldAnswers: [], groupAnswerCollections: [] });
    mockQuestAnswerService.saveAndGetMappedUserAnswers.and.returnValue(of({ questionnaireFieldGroupAnswers: { fieldAnswers: [], groupAnswers: [] } }));
    mockCartService.updateCartByQuestionnaire.and.returnValue(of({ cart: new Cart() }));

    service.getUpdatedCart(123, 'token13', 132456);
    expect(mockQuestMappingService.doMapping).toHaveBeenCalled();
    expect(mockQuestAnswerService.saveAndGetMappedUserAnswers).toHaveBeenCalled();
  });

  it('getAnnualLegalProductConfigurationId method should return annual legal product config id', () => {
    const service: UserCartService = TestBed.get(UserCartService);
    const data = service.getAnnualLegalProductConfigurationId('California');
    expect(data).toBe(ProductConfigurationIds.bapMonthlyLegal);
  });

  it('prepareGetCartById method should return cart', () => {
    const service: UserCartService = TestBed.get(UserCartService);
    const mockQueueService = TestBed.get(QueueService);
    mockCartService.getCart.and.returnValue(of(mockCart));
    mockQueueService.add(service.prepareGetCartById({ constructor: { name: 'test' } }, mockAppService, 123456, 123, ProductName.LLC));
    mockQueueService.process().subscribe();
    expect(mockCartService.getCart).toHaveBeenCalled();
  });

  it('savePackageSelected method should save the correct data', () => {
    const service: UserCartService = TestBed.get(UserCartService);
    service.savePackageSelected(ProductConfigurationIds.tier1LLCPackage);
    expect(mockQuestionnaireService.llc.legalAdvice).toBe(false);
  });
});
