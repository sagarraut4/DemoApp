import { AppService } from '../../../../../shared/state/app/app.service';
import { UserCartService } from '../user-cart.service';
import { IUserCart } from '@legalzoom/cart-sdk';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from '@angular/router';
import { Observable, of } from 'rxjs';
@Injectable({
    providedIn: 'root'
})
export class ReviewYourOrderResolver implements Resolve<IUserCart> {
    constructor(
        private userCartService: UserCartService,
        private appService: AppService
    ) { }

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<IUserCart> {
        if (this.userCartService.userCart) {
            return of(this.userCartService.userCart);
        } else {
            return this.userCartService.getUpdatedCart(this.appService.app.cartId, this.appService.app.accessToken, this.appService.app.customerId);
        }
    }
}
