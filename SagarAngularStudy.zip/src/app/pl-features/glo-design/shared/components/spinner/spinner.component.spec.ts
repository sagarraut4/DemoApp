import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { GloSpinnerComponent } from './spinner.component';

describe('SpinnerComponent', () => {
  let component: GloSpinnerComponent;
  let fixture: ComponentFixture<GloSpinnerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GloSpinnerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GloSpinnerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create spinner component', () => {
    expect(component).toBeTruthy();
  });

  it('should define maxWaitTimeBeforeShowing and waitedLongEnoughToShow', () => {
    expect(component.maxWaitTimeBeforeShowing).toBeDefined();
    expect(component.waitedLongEnoughToShow).toMatch(/true|false/);
  });
});
