import { Component, Input, OnDestroy, OnChanges } from '@angular/core';

@Component({
  selector: 'app-glo-spinner',
  templateUrl: './spinner.component.html',
  styleUrls: ['./spinner.component.scss']
})
export class GloSpinnerComponent implements OnChanges, OnDestroy {
  private currentTimeout: any;
  public waitedLongEnoughToShow = false;

  @Input()
  public maxWaitTimeBeforeShowing = 301;

  @Input()
  isBusy: boolean;

  ngOnChanges() {
    if (this.isBusy) {
      if (this.currentTimeout) {
        return;
      }
      this.currentTimeout = setTimeout(() => {
        this.waitedLongEnoughToShow = this.isBusy;
        this.cancelTimeout();
      }, this.maxWaitTimeBeforeShowing);
    } else {
      this.cancelTimeout();
      this.waitedLongEnoughToShow = false;
      return;
    }
  }

  private cancelTimeout(): void {
      clearTimeout(this.currentTimeout);
      this.currentTimeout = undefined;
  }

  ngOnDestroy(): any {
      this.cancelTimeout();
  }
}
