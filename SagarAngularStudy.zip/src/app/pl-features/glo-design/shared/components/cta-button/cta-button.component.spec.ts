import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CookieService } from 'ngx-cookie';
import { QuestionnaireService } from '../../../../../shared/services/questionnaire/questionnaire.service';
import { BannerService } from '../../services/banner.service';
import { CtaButtonComponent } from './cta-button.component';

describe('CtaButtonComponent', () => {
  let component: CtaButtonComponent;
  let fixture: ComponentFixture<CtaButtonComponent>;
  const mockQuestionnaireService = {
    llc: {}
  }
  const mockCookieService = jasmine.createSpyObj(['get', 'post', 'put', 'delete']);
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CtaButtonComponent],
      providers: [
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: CookieService, useValue: mockCookieService }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CtaButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create cta-button component', () => {
    expect(component).toBeTruthy();
  });

  it('should call bannerService.getBannerHeight', () => {
    const bannerService = TestBed.get(BannerService);
    spyOn(bannerService, 'getBannerHeight');
    component.ngAfterViewInit();
    expect(bannerService.getBannerHeight).toHaveBeenCalled();
  });

});
