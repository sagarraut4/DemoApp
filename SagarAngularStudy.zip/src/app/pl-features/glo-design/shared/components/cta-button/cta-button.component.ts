import { Component, ElementRef, Input, AfterViewInit, ViewChild, Renderer2, OnDestroy } from '@angular/core';
import { QuestionnaireService } from '../../../../../shared/services/questionnaire/questionnaire.service';
import { BannerService } from '../../services/banner.service';
import { ReplaySubject, Subscription } from 'rxjs';

@Component({
  selector: 'app-cta-button',
  templateUrl: './cta-button.component.html',
  styleUrls: ['./cta-button.component.scss']
})
export class CtaButtonComponent implements AfterViewInit, OnDestroy {
  @ViewChild('btn', { static: false }) btn: ElementRef;
  private bannerHeightSubject: ReplaySubject<number>;
  private bannerHeightSubscription: Subscription;
  private ctaButton: HTMLElement;
  public isMobile = this.questionnaireService.llc.isMobile ? true : false;
  public squishy = false;
  @Input() type = 'button';
  @Input() disabled = false;
  @Input() noIcon = false;
  @Input() isLoading = false;

  constructor(
    public questionnaireService: QuestionnaireService,
    private bannerService: BannerService,
    private renderer: Renderer2

  ) { }

  ngAfterViewInit() {
    if (this.btn.nativeElement.textContent.length > 15) {
      this.squishy = true;
    }

    this.bannerHeightSubject = this.bannerService.getBannerHeight(this.renderer);
    this.ctaButton = document.getElementById('btn-save');

    if (this.isMobile) {

      this.bannerHeightSubscription = this.bannerHeightSubject.subscribe(bannerHeight => {

        this.setCTAButtonPosition(bannerHeight);

        if (this.bannerHeightSubscription && bannerHeight === 0) {

          this.bannerHeightSubscription.unsubscribe();
        }
      });
    }
  }

  private setCTAButtonPosition(bannerHeight: number = 0) {
    this.ctaButton.style.marginBottom = `${bannerHeight}px`;
    this.setContentScrollWithBanner(bannerHeight);
  }

  private setContentScrollWithBanner(bannerHeight: number = 0) {
    if (bannerHeight === 0) {
      const contentElement = document.getElementsByClassName('cf-body');
      if (contentElement.length > 0) {
        contentElement[0].setAttribute('style', 'padding-bottom:inherit;');
      }
    }
    else {
      const contentElement = document.getElementsByClassName('cf-body');
      if (contentElement.length > 0) {
        contentElement[0].setAttribute('style', 'padding-bottom:'+ bannerHeight +'px;overflow-x:visible;');
      }
    }
  }

  ngOnDestroy(): void {
    if (this.bannerHeightSubscription) {
      this.bannerHeightSubscription.unsubscribe();
    }
  }
}
