import {Component, OnDestroy, OnInit, Renderer2} from '@angular/core';
import {BannerService} from '../../services/banner.service';
import {Observable, ReplaySubject, Subscription} from 'rxjs';
import { TrackingService } from '../../../../../shared/services/tracking/tracking.service';

@Component({
  selector: 'app-back-button',
  templateUrl: './back-button.component.html',
  styleUrls: ['./back-button.component.scss']
})
export class BackButtonComponent implements OnInit, OnDestroy {
  bannerHeightSubject: ReplaySubject<number>;
  bannerHeightObservable: Observable<number>;
  backButton: HTMLElement;
  bannerHeightSubscription: Subscription;

  constructor(
    private renderer: Renderer2,
    private bannerService: BannerService,
    public trackingService: TrackingService,
  ) { }

  ngOnInit() {
    this.bannerHeightSubject = this.bannerService.getBannerHeight(this.renderer);
    this.bannerHeightObservable = this.bannerHeightSubject.asObservable();
    this.backButton = document.getElementById('glo-navigation-back-button');

    this.bannerHeightSubscription = this.bannerHeightSubject.subscribe(bannerHeight => {

      this.setBackButtonPosition(bannerHeight);

      if (this.bannerHeightSubscription && bannerHeight === 0) {
        this.bannerHeightSubscription.unsubscribe();
      }
    });
  }

  track() {
    this.trackingService.triggerClickTrack('back_button_test','back_button_click');
  }

  private setBackButtonPosition(bannerHeight: number = 0) {
    this.backButton.style.marginBottom = `${bannerHeight}px`;
  }

  ngOnDestroy(): void {
    if (this.bannerHeightSubscription) {
      this.bannerHeightSubscription.unsubscribe();
    }
  }
}
