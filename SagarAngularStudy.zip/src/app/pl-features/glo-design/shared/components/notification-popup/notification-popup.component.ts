import { animate, AnimationMetadata, query, style, transition, trigger } from '@angular/animations';
import { BreakpointObserver } from '@angular/cdk/layout';
import {Component, ComponentRef, ElementRef, HostBinding, OnDestroy, OnInit, Renderer2} from '@angular/core';
import {Observable, ReplaySubject, Subscription, timer} from 'rxjs';
import {BannerService} from '../../services/banner.service';

@Component({
  selector: 'app-notification-popup',
  templateUrl: './notification-popup.component.html',
  styleUrls: ['./notification-popup.component.scss'],
  animations: [
    trigger('slideInOut', [
      transition(':enter', [
        style({transform: 'translateY(150%)'}),
        animate('500ms ease-in-out', style({transform: 'translateY(0%)'}), )
      ]),
      transition(':leave', [
        style({transform: 'translateY(0%)'}),
        animate('500ms ease-in-out', style({transform: 'translateY(150%)'}))
      ])
    ])
  ]
})
export class NotificationPopupComponent implements OnInit, OnDestroy {

  @HostBinding('@slideInOut')

  public notificationText = '';
  public componentRef: ComponentRef<NotificationPopupComponent>;
  bannerHeightSubject: ReplaySubject<number>;
  bannerHeightObservable: Observable<number>;
  bannerHeightSubscription: Subscription;

  constructor(
    public breakpointObserver: BreakpointObserver,
    private elementRef: ElementRef,
    private renderer: Renderer2,
    private bannerService: BannerService
  ) {
    timer(3000).subscribe(val => {
      this.componentRef.destroy();
    });

   }

  ngOnInit() {
    this.bannerHeightSubject = this.bannerService.getBannerHeight(this.renderer);
    this.bannerHeightObservable = this.bannerHeightSubject.asObservable();

    this.bannerHeightSubscription = this.bannerHeightSubject.subscribe(bannerHeight => {

      this.setNotificationPosition(bannerHeight);

      if (this.bannerHeightSubscription && bannerHeight === 0) {
        this.bannerHeightSubscription.unsubscribe();
      }
    });

  }

  private setNotificationPosition(bannerHeight: number = 0) {
    this.elementRef.nativeElement.style.marginBottom = `${bannerHeight}px`;
  }

  ngOnDestroy(): void {
    if (this.bannerHeightSubscription) {
      this.bannerHeightSubscription.unsubscribe();
    }
  }
}
