import { CookieService } from 'ngx-cookie';
import { BehaviorSubject, of, ReplaySubject } from 'rxjs';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BannerService } from '../../services/banner.service';
import { NotificationPopupComponent } from './notification-popup.component';
import { Renderer2 } from '@angular/core';

describe('NotificationPopupComponent', () => {
  let component: NotificationPopupComponent;
  let fixture: ComponentFixture<NotificationPopupComponent>;
  const mockCookieService = jasmine.createSpyObj(['get', 'post', 'put', 'delete']);
  beforeEach(async(() => {   
    TestBed.configureTestingModule({
      declarations: [NotificationPopupComponent],
      imports: [BrowserAnimationsModule],
      providers: [
        Renderer2,
        { provide: CookieService, useValue: mockCookieService }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NotificationPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create notification popup component', () => {
    expect(component).toBeTruthy();
  });
});
