import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { InfoPanelComponent } from './info-panel/info-panel.component';
import { BackButtonComponent } from './back-button/back-button.component';
import { CtaButtonComponent } from './cta-button/cta-button.component';
import { NotificationPopupComponent } from './notification-popup/notification-popup.component';
import { NotificationContainerComponent } from './notification-container/notification-container.component';
import { NotificationMobilePopupComponent } from './notification-mobile-popup/notification-mobile-popup.component';
import { StepperComponent } from './stepper/stepper.component';
import { GloSpinnerComponent } from './spinner/spinner.component';

@NgModule({
  declarations: [
    InfoPanelComponent,
    BackButtonComponent,
    CtaButtonComponent,
    NotificationPopupComponent,
    NotificationContainerComponent,
    NotificationMobilePopupComponent,
    StepperComponent,
    GloSpinnerComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    InfoPanelComponent,
    CtaButtonComponent,
    BackButtonComponent,
    NotificationPopupComponent,
    NotificationMobilePopupComponent,
    NotificationContainerComponent,
    StepperComponent,
    GloSpinnerComponent
  ],
  entryComponents: [
    NotificationPopupComponent,
    NotificationMobilePopupComponent,
  ]
})
export class GloComponentsModule { }
