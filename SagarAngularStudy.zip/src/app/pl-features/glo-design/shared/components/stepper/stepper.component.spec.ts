import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { StepperComponent } from './stepper.component';

describe('StepperComponent', () => {
  let component: StepperComponent;
  let fixture: ComponentFixture<StepperComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StepperComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StepperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create stepper component', () => {
    expect(component).toBeTruthy();
  });

  it('should click on #button-minus', async(() => {
    spyOn(component, 'decreaseCount');

    const button = fixture.debugElement.nativeElement.querySelector('#button-minus');
    button.click();

    fixture.whenStable().then(() => {
      expect(component.decreaseCount).toHaveBeenCalled();
      expect(component.count).toBeGreaterThanOrEqual(1);
    });
  }));

  it('should click on #button-plus', async(() => {
    spyOn(component, 'increaseCount');

    const button = fixture.debugElement.nativeElement.querySelector('#button-plus');
    button.click();

    fixture.whenStable().then(() => {
      expect(component.increaseCount).toHaveBeenCalled();
      expect(component.count).toBeGreaterThanOrEqual(1);
    });
  }));
  
  it('increaseCount method should increase the count value', () => {
    component.increaseCount();
    expect(component.count).toBe(2);
  });

  it('decreaseCount method should decrease the count value', () => {
    component.decreaseCount();
    expect(component.count).toBe(1);
  });
});
