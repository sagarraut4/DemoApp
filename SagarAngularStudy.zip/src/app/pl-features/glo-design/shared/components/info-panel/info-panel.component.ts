import { animate, state, style, transition, trigger } from '@angular/animations';
import { Component, OnInit, Renderer2 } from '@angular/core';
import { BreakpointObserver, BreakpointState } from '@angular/cdk/layout';
import { ReplaySubject, Subscription } from 'rxjs';
import { BannerService } from '../../services/banner.service';

@Component({
  selector: 'app-info-panel',
  templateUrl: './info-panel.component.html',
  styleUrls: ['./info-panel.component.scss'],
  animations: [
    trigger('desktopOpen', [
      state('open', style({transform: 'translateX(0)'})),
      state('close', style({transform: 'translateX(100%)'})),
      transition( '* => *', [
        animate('300ms ease-in-out')
      ])
    ]),
    trigger('mobileOpen', [
      state('open', style({transform: 'translateY(0)'})),
      state('close', style({transform: 'translateY(100%)'})),
      transition( '* => *', [
        animate('400ms ease-in-out')
      ])
    ]),
    trigger('fade', [
      state('in', style({opacity: 1, color: 'purple', display: 'block'})),
      state('out', style({opacity: 0, color: 'red', display: 'none'})),
      transition('in <=> out', [
        style({display: 'block'}),
        animate('300ms ease-in-out')
      ])
    ])
  ]
})
export class InfoPanelComponent implements OnInit {

  public isDesktopOpen = false;
  public isMobileOpen = false;
  public isMobile = false;
  private bannerHeightSubject: ReplaySubject<number>;
  private bannerHeightSubscription: Subscription;
  private cookieBannerHeight = 0;

  constructor(public breakpointObserver: BreakpointObserver,
    private bannerService: BannerService,
    private renderer: Renderer2) {
  }

  ngOnInit(): void {

    const size = '(min-width: 768px)';

    this.breakpointObserver
      .observe([size])
      .subscribe((bpState: BreakpointState) => {
        if (bpState.matches) {
          this.isMobile = false;
        } else {
          this.isMobile = true;
        }
      });
  }

  ngAfterViewInit(): void {
    this.bannerHeightSubject = this.bannerService.getBannerHeight(this.renderer);
    this.bannerHeightSubscription = this.bannerHeightSubject.subscribe(bannerHeight => {
      this.cookieBannerHeight = bannerHeight;
      this.setBottomPadding(bannerHeight);
      if (this.bannerHeightSubscription && !this.bannerService.bannerIsActive()) {
        this.bannerHeightSubscription.unsubscribe();
      }
    });
  }

  private setBottomPadding(bannerHeight: number = 0) {
    setTimeout(() => {
      const panelElement = document.getElementsByClassName('panel');
      const contentElement = panelElement.length ? panelElement[0].getElementsByClassName('content') : null;
      if (contentElement && contentElement.length > 0) {
        if (bannerHeight === 0) {
            contentElement[0].setAttribute('style', '');
        } else {
          // tslint:disable-next-line: max-line-length
          contentElement[0].setAttribute('style', 'padding-bottom:' + bannerHeight + 'px;');
        }
      }
    }, 0);
  }

  onClose() {
    this.close();
  }

  backgroundClick() {
    this.isDesktopOpen = false;
  }

  public open() {
    if (this.isMobile) {
      this.isMobileOpen = true;
    } else {
      this.isDesktopOpen = true;
    }
    this.setBottomPadding(this.cookieBannerHeight);
  }

  public close() {
    if (this.isMobile) {
      this.isMobileOpen = false;
    } else {
      this.isDesktopOpen = false;
    }
  }

  public toggle() {
    if (this.isMobileOpen || this.isDesktopOpen) {
      this.close();
    } else {
      this.open();
    }
  }

}
