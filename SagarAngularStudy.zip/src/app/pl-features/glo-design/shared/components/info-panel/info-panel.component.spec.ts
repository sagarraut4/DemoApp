import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { InfoPanelComponent } from './info-panel.component';

describe('InfoPanelComponent', () => {
  let component: InfoPanelComponent;
  let fixture: ComponentFixture<InfoPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [InfoPanelComponent],
      imports: [BrowserAnimationsModule]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InfoPanelComponent);
    component = fixture.componentInstance;
    component.isDesktopOpen = true;
    fixture.detectChanges();
  });

  it('should create info panel component', () => {
    expect(component).toBeTruthy();
  });

  it('on click of background should call backgroundClick method', () => {
    spyOn(component, 'backgroundClick');
    const background = fixture.debugElement.query(By.css('.background')).nativeElement;
    background.click();
    expect(component.backgroundClick).toHaveBeenCalled();
  });

  it('on click of background should save value of isDesktopOpen as false', () => {
    const background = fixture.debugElement.query(By.css('.background')).nativeElement;
    background.click();
    expect(component.isDesktopOpen).toBe(false);
  });

  it('on click of close should call onClose method', () => {
    spyOn(component, 'onClose');
    const close = fixture.debugElement.query(By.css('.close-button')).nativeElement;
    close.click();
    expect(component.onClose).toHaveBeenCalled();
  });

  it('on click of close should call onClose method and then close method of component', () => {
    spyOn(component, 'close');
    const close = fixture.debugElement.query(By.css('.close-button')).nativeElement;
    close.click();
    expect(component.close).toHaveBeenCalled();
  });

  it('on click of close should  save value of isDesktopOpen as false', () => {
    const close = fixture.debugElement.query(By.css('.close-button')).nativeElement;
    close.click();
    expect(component.isDesktopOpen).toBe(false);
  });
});
