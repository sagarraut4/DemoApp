import { animate, style, transition, trigger } from '@angular/animations';
import {Component, ComponentRef, ElementRef, HostBinding, OnDestroy, OnInit, Renderer2} from '@angular/core';
import {Observable, ReplaySubject, Subscription, timer} from 'rxjs';
import {BannerService} from '../../services/banner.service';

@Component({
  selector: 'app-notification-mobile-popup',
  templateUrl: './notification-mobile-popup.component.html',
  styleUrls: ['./notification-mobile-popup.component.scss'],
  animations: [
    trigger('slideInOut', [
      transition(':enter', [
        style({transform: 'translateY(150%)'}),
        animate('300ms ease-in-out', style({transform: 'translateY(0%)'}), )
      ]),
      transition(':leave', [
        style({transform: 'translateY(0%)'}),
        animate('300ms ease-in-out', style({transform: 'translateY(150%)'}))
      ])
    ])
  ]
})
export class NotificationMobilePopupComponent implements OnInit, OnDestroy {

  @HostBinding('@slideInOut')

  public notificationText = '';
  public componentRef: ComponentRef<NotificationMobilePopupComponent>;
  bannerHeightSubject: ReplaySubject<number>;
  bannerHeightObservable: Observable<number>;
  bannerHeightSubscription: Subscription;

  constructor(
    private elementRef: ElementRef,
    private renderer: Renderer2,
    private bannerService: BannerService
  ) {
    timer(3000).subscribe(val => {
      this.componentRef.destroy();
    });
   }

  ngOnInit() {
    this.bannerHeightSubject = this.bannerService.getBannerHeight(this.renderer);
    this.bannerHeightObservable = this.bannerHeightSubject.asObservable();

    this.bannerHeightSubscription = this.bannerHeightSubject.subscribe(bannerHeight => {

      this.setNotificationPosition(bannerHeight);

      if (this.bannerHeightSubscription && bannerHeight === 0) {
        this.bannerHeightSubscription.unsubscribe();
      }
    });

  }

  private setNotificationPosition(bannerHeight: number = 0) {
    this.elementRef.nativeElement.style.marginBottom = `${bannerHeight}px`;
  }

  ngOnDestroy(): void {
    if (this.bannerHeightSubscription) {
      this.bannerHeightSubscription.unsubscribe();
    }
  }
}
