import { Component, OnInit, ViewChild, ViewContainerRef } from '@angular/core';

@Component({
  selector: 'app-notification-container',
  templateUrl: './notification-container.component.html',
  styleUrls: ['./notification-container.component.scss']
})
export class NotificationContainerComponent implements OnInit {

  @ViewChild('viewContainer', {static: true, read: ViewContainerRef}) public viewContainer: ViewContainerRef;

  constructor() { }

  ngOnInit() {
  }

  public getViewContainerRef() {
    return this.viewContainer;
  }
}
