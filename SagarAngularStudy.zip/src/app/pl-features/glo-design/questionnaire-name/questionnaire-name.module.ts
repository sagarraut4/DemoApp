import { AppInitializationService } from '../../../shared/services/app-initialization.service';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TextMaskModule } from 'angular2-text-mask';
import { NameAvailableComponent } from './name-available/name-available.component';
import { ChangeNameComponent } from './change-name/change-name.component';
import { ChangeNameLzredComponent } from './change-name-lzred/change-name-lzred.component';
import { BusinessStateComponent } from './business-state/business-state.component';
import { SharedComponentsModule } from '../../../shared/components/shared-components.module';
import { BusinessActivityService } from '../../../shared/services/business-activity.service';
import { GloComponentsModule } from '../shared/components/glo-components.module';
@NgModule({
  imports: [
    CommonModule,
    NgbModule,
    ReactiveFormsModule,
    SharedComponentsModule,
    TextMaskModule,
    GloComponentsModule
  ],
  providers: [
    BusinessActivityService,
    AppInitializationService
  ],
  declarations: [
    BusinessStateComponent,
    NameAvailableComponent,
    ChangeNameComponent,
    ChangeNameLzredComponent,
  ],
  exports: [
    BusinessStateComponent,
    NameAvailableComponent,
    ChangeNameComponent,
    ChangeNameLzredComponent,
  ],
  entryComponents: [],
})
export class QuestionnaireNameModule {

}
