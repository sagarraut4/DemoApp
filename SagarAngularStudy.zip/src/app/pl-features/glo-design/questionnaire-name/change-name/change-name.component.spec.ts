import { environmentCommon } from '../../../../../environments/environment';
import { BusinessNameCheckModule } from '@legalzoom/business-name-check-sdk';
import { PrepareCartService } from '../../../../shared/services/prepare-cart.service';
import { BehaviorSubject, of } from 'rxjs';
import { By } from '@angular/platform-browser';
import { TextMaskModule } from 'angular2-text-mask';
import { UtilityService } from '../../../../shared/services/utility.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { WindowRef } from '../../../../shared/services/windowRef.service';
import { EventService, CartCreationStatus } from '../../../../shared/services/event.service';
import { SEADService } from '../../../../shared/services/tracking/sead.service';
import { TrackSEMDataService } from '../../../../shared/services/tracking/track-sem-data.service';
import { QuestionnaireRoutingService } from '../../../../shared/services/questionnaire-routing/questionnaire-routing.service';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { async, ComponentFixture, TestBed, fakeAsync } from '@angular/core/testing';
import { ChangeNameComponent } from './change-name.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { RouterTestingModule } from '@angular/router/testing';
import { QueueService } from '@legalzoom/business-formation-sdk';
import { CookieModule } from 'ngx-cookie';
import { CookieService as ngxCookieService } from 'ngx-cookie-service';
import { BusinessNameCheckService } from '@legalzoom/business-name-check-sdk';
import { MockComponent } from 'ng-mocks';
import { UsefulInfoComponent } from '../../../../shared/components/useful-info/useful-info.component';
import { BackToTopComponent } from '../../../../shared/components/back-to-top/back-to-top.component';

describe('ChangeNameComponent', () => {
  let component: ChangeNameComponent;
  let fixture: ComponentFixture<ChangeNameComponent>;
  let mockBusinessNameCheckService;
  const mockQuestionnaireRoutingService = jasmine.createSpyObj(['getNextPage']);
  // tslint:disable-next-line:prefer-const
  let mockTrackSemData: TrackSEMDataService;
  const mockSeadService = jasmine.createSpyObj(['PushToTealium']);
  const mockEventService = jasmine.createSpyObj(['updateCartCreationStatus', 'cartCreation$']);
  let mockUtilityService;
  const mockWindowRef = jasmine.createSpyObj(['nativeWindow']);
  const mockErrorLoggingService = jasmine.createSpyObj(['trackError', 'setMetadata']);
  const mockQuestionnaireService = {
    llc: {
      isChooseEntityNameLater: false,
      entityName: 'testtest'
    }
  };
  const mockPrepareCartService = jasmine.createSpyObj(['prepareQueueEntries']);
  mockPrepareCartService.clearQueueOnError = {};
  // tslint:disable-next-line:prefer-const
  let mockTrackingService;
  const mockQueueService = jasmine.createSpyObj(['add', 'process', 'subscribe']);

  beforeEach(async(() => {
    mockUtilityService = jasmine.createSpyObj(['setApprovedCookie']);
    mockBusinessNameCheckService = jasmine.createSpyObj(['checkNameAvailability']);
    mockEventService.cartCreation$ = new BehaviorSubject(CartCreationStatus.Created);
    mockQueueService.process.and.returnValue(of(true));
    TestBed.configureTestingModule({
      declarations: [ChangeNameComponent, MockComponent(UsefulInfoComponent), MockComponent(BackToTopComponent)],
      imports: [
        RouterTestingModule.withRoutes([]),
        BusinessNameCheckModule.forRoot(environmentCommon),
        CookieModule.forRoot(),
        FormsModule,
        ReactiveFormsModule,
        HttpClientTestingModule,
        NgbModule,
        TextMaskModule],
      providers: [
        { provide: WindowRef, useValue: mockWindowRef },
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: BusinessNameCheckService, useValue: mockBusinessNameCheckService },
        { provide: QuestionnaireRoutingService, useValue: mockQuestionnaireRoutingService },
        { provide: SEADService, useValue: mockSeadService },
        { provide: EventService, useValue: mockEventService },
        { provide: UtilityService, useValue: mockUtilityService },
        { provide: PrepareCartService, useValue: mockPrepareCartService },
        { provide: QueueService, useValue: mockQueueService },
        ngxCookieService
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangeNameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create business-state component', () => {
    expect(component).toBeTruthy();
  });

  it('isLoading is false if form is invalid', () => {
    component.save();
    expect(component.isLoading).toBe(false);
  });

  it('checkname should call businessNameCheckService.checkNameAvailability if the inputs are correct', async(() => {
    setInputValue('#tb-entity-state', 'California');
    component.changeNameForm.controls.entityName.setValue('Testing');
    mockBusinessNameCheckService.checkNameAvailability.and.returnValue(of({}));
    const input = { item: { abbr: 'CA' } };
    component.checkName(input);
    fixture.whenStable().then(() => {
      expect(mockBusinessNameCheckService.checkNameAvailability).toHaveBeenCalled();
    });
  }));

  it('should call save method on click of submit button', async(() => {
    spyOn(component, 'save');
    setInputValue('#tb-entity-state', 'California');
    component.changeNameForm.controls.entityName.setValue('Testing');
    const saveButton = fixture.debugElement.query(By.css('#btn-submit')).nativeElement;
    saveButton.click();
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(component.save).toHaveBeenCalled();
    });
  }));

  // TODO: fix test
  xit('isLoading is true if form is valid', async () => {
    setInputValue('#tb-entity-state', 'California');
    fixture.detectChanges();
    const selectStateButton = fixture.debugElement.query(By.css('#ngb-typeahead-0-0'));
    await fixture.detectChanges();
    await fixture.whenStable();
    selectStateButton.nativeElement.click();
    selectStateButton.nativeElement.dispatchEvent(new Event('input'));
    component.changeNameForm.controls.entityName.setValue('test');
    component.save();
    expect(component.isLoading).toBe(true);
  });

  it('save should get called continue method', async () => {
    TestBed.get(QuestionnaireService).llc.isChooseEntityNameLater = true;
    mockQuestionnaireRoutingService.getNextPage.and.returnValue('/');
    setInputValue('#tb-entity-state', 'Califo');
    await fixture.detectChanges();
    fixture.whenStable().then(() => {
      const selectStateButton = fixture.debugElement.query(By.css('#ngb-typeahead-0-0')).nativeElement;
      selectStateButton.click();
      selectStateButton.dispatchEvent(new Event('input'));
      const saveButton = fixture.debugElement.query(By.css('#btn-save')).nativeElement;
      saveButton.click();
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        mockEventService.cartCreation$.next({ res: CartCreationStatus.Created });
      });
      expect(mockUtilityService.setApprovedCookie).toHaveBeenCalled();
    });
  });

  function setInputValue(selector: string, value: string) {
    fixture.detectChanges();
    const input = fixture.debugElement.query(By.css(selector)).nativeElement;
    input.value = value;
    input.dispatchEvent(new Event('input'));
    fixture.whenStable().then(() => {
      fixture.detectChanges();
    });
  }
});
