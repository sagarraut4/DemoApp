import { QueueService } from '@legalzoom/business-formation-sdk';
import { PrepareCartService } from '../../../../shared/services/prepare-cart.service';
import {
  AfterViewInit,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
} from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import {
  debounceTime,
  distinctUntilChanged,
  map,
  takeUntil,
} from 'rxjs/operators';
import {
  ConstantsService,
  CookieName,
} from '../../../../../app/shared/services/constants.service';
import { QuestionnaireService } from '../../../../../app/shared/services/questionnaire/questionnaire.service';
import { ServerErrorComponent } from '../../../../shared/modals/server-error/server-error.component';
import { CartResponse } from '../../../../shared/models/cart-model';
import { Chapter, PagePath } from '../../../../shared/models/page-model';
import {
  CartCreationStatus,
  EventService,
} from '../../../../shared/services/event.service';
import { QuestionnaireRoutingService } from '../../../../shared/services/questionnaire-routing/questionnaire-routing.service';
import { SEADService } from '../../../../shared/services/tracking/sead.service';
import { TrackSEMDataService } from '../../../../shared/services/tracking/track-sem-data.service';
import { ValidateState } from '../../../../shared/validators/form-control.validator';
import { UtilityService } from '../../../../shared/services/utility.service';
import { ErrorLoggingService } from '../../../../shared/services/error-logging.service';
import {
  BusinessNameCheckService,
  IsBusinessNameAvailable,
} from '@legalzoom/business-name-check-sdk';
import { ExperimentsService } from '../../../../../app/shared/services/experiments/experiments.service';
import { InfoPanelComponent } from '../../shared/components/info-panel/info-panel.component';
import { isNullOrUndefined } from 'util';
import { TrackingService } from '../../../../shared/services/tracking/tracking.service';

type State = ReturnType<typeof ConstantsService.GetAllStates>[0];

@Component({
  // tslint:disable-next-line: component-selector
  selector: 'business-state',
  templateUrl: './business-state.component.html',
  styleUrls: ['./business-state.component.scss'],
})
export class BusinessStateComponent
  implements OnInit, OnDestroy, AfterViewInit {
  @ViewChild('moreInfo', { static: false }) moreInfo: InfoPanelComponent;
  public entityStateForm: FormGroup;
  public cartResponse: CartResponse;
  public states: any;
  public submitted: boolean;
  public isLoading: boolean;
  private unsubscribe: Subject<void> = new Subject();
  public isFunnelTest = false;
  public buttonText: string;
  public stateList: State[] = ConstantsService.GetAllStates();
  private retryCount = 0;
  public isFocused: boolean;

  // tslint:disable-next-line: variable-name
  private _stateSelection = new BehaviorSubject<IsBusinessNameAvailable>({
    isAvailable: true,
  });
  stateSelection = this._stateSelection.asObservable();

  constructor(
    public questionnaireService: QuestionnaireService,
    private fb: FormBuilder,
    private businessNameCheckService: BusinessNameCheckService,
    private router: Router,
    private route: ActivatedRoute,
    private questionnaireRoutingService: QuestionnaireRoutingService,
    private trackSEMData: TrackSEMDataService,
    private seadService: SEADService,
    private eventService: EventService,
    private modalService: NgbModal,
    private utilityService: UtilityService,
    private loggingService: ErrorLoggingService,
    private prepareCartService: PrepareCartService,
    private queueService: QueueService,
    private trackingService: TrackingService
  ) {}

  onClickMoreInfoLink($event) {
    $event.preventDefault();
    this.trackingService.triggerClickTrack('llc_flow', 'state_selection_more_info_link');
    this.moreInfo.open();
  }

  ngOnInit(): void {
    this.isLoading = false;
    this.buttonText = 'Search';

    this.route.params
      .pipe(takeUntil(this.unsubscribe))
      .subscribe((params: Params) => {
        const entity = this.route.snapshot.queryParams.entity;
        const kenshooID = this.route.snapshot.queryParams.kid;

        if (kenshooID) {
          this.trackSEMData.setSEMCookies();
        }

        if (entity) {
          this.questionnaireService.llc.entityName = entity;
          this.seadService.TrackingObject.business_name = entity;
          this.seadService.PushToTealium();
        }

        const chooseEntityNameLater = this.route.snapshot.queryParams
          .choose_later;
        if (
          chooseEntityNameLater &&
          chooseEntityNameLater.toLowerCase() === 'true'
        ) {
          this.questionnaireService.llc.isChooseEntityNameLater = true;
          this.buttonText = 'Continue';
        }

        if (
          !this.questionnaireService.llc.entityName &&
          !this.questionnaireService.llc.isChooseEntityNameLater
        ) {
          this.router.navigate([Chapter.Name + '/' + PagePath.ChangeName]);
        }

        // START - added for 11 page short flow llc test
        const stateCode = this.route.snapshot.queryParams.state;
        let state;

        if (stateCode) {
          state = this.stateList.find(
            (s) => s.abbr === stateCode.toUpperCase()
          );
        }

        if (state) {
          this.isFunnelTest = true;
          this.questionnaireService.llc.entityState = state.name;
          this.questionnaireService.llc.isEntityStateSelected = true;
          this.entityStateForm = this.fb.group({
            entityState: new FormControl(
              ConstantsService.getStateByName(
                this.questionnaireService.llc.entityState
              ),
              Validators.compose([Validators.required, ValidateState])
            ),
          });
          this.save();
        }
        // END
      });

    // prepare the form with validators
    this.entityStateForm = this.fb.group({
      entityState: new FormControl(
        this.initState(),
        Validators.compose([Validators.required, ValidateState])
      ),
    });

    // create user a cart for order
    this.queueService.add(this.prepareCartService.prepareQueueEntries());
    this.queueService.process().subscribe();
  }

  stateSelectComparison(state1: State, state2: State) {
    if (isNullOrUndefined(state2)) {
      return false;
    }
    return state1.abbr === state2.abbr;
  }

  ngAfterViewInit() {
    this.checkName({});
  }

  search = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(200),
      distinctUntilChanged(),
      map((term) =>
        term.length < 1
          ? []
          : this.stateList
              .filter(
                (v) =>
                  v.abbr.toLowerCase().startsWith(term.toLowerCase()) ||
                  v.name.toLowerCase().startsWith(term.toLowerCase())
              )
              .slice(0, 10)
      )
    );

  formatter = (x: { name: string }) => x.name;

  save(): void {
    this.submitted = true;

    // if the form is not valid, do not proceed
    if (this.entityStateForm.invalid) {
      return;
    }

    this.isLoading = true;

    this.questionnaireService.llc.entityState = this.entityStateForm.get(
      'entityState'
    ).value.name;
    this.questionnaireService.llc.isEntityStateSelected = true;
    // set state cookie for optimizely targeting
    this.utilityService.setApprovedCookie(
      'C0002',
      CookieName.LLC_Formation_State,
      this.questionnaireService.llc.entityState,
      true
    );

    if (this.questionnaireService.llc.isChooseEntityNameLater) {
      this.continue();
      return;
    }

    // check if the name is available
    this.businessNameCheckService
      .checkNameAvailability(
        this.questionnaireService.llc.entityName,
        this.entityStateForm.get('entityState').value.abbr
      )
      .subscribe(
        (res) => {
          this.questionnaireService.llc.isBusinessNameAvailable =
            res.isAvailable;
          this.continue();
        },
        (err) => {
          this.questionnaireService.llc.isBusinessNameAvailable = true;
          this.continue();
        }
      );
  }

  private continue(): void {
    if (this.unsubscribe.isStopped) {
      this.unsubscribe = new Subject();
    }

    this.eventService.cartCreation$
      .pipe(takeUntil(this.unsubscribe))
      .subscribe((res) => {
        if (res === CartCreationStatus.Created) {
          const nextPage = this.questionnaireRoutingService.getNextPage(
            PagePath.BusinessState
          );
          this.router.navigate([`./${nextPage}`]);
        } else if (res === CartCreationStatus.Error) {
          this.isLoading = false;
          const errorPopup = this.modalService.open(ServerErrorComponent, {
            size: 'lg',
          });
          errorPopup.result
            .then((result: string) => {
              this.unsubscribeAndRetry();
              this.continue();
            })
            .catch((err) => {
              this.unsubscribeAndRetry();
            });
        } else {
          // cart is still being created
          this.isLoading = true;
        }
      });
  }

  private unsubscribeAndRetry(): void {
    this.unsubscribe.next();
    this.unsubscribe.complete();
    this.eventService.updateCartCreationStatus(CartCreationStatus.Pending);
    this.queueService.add(this.prepareCartService.prepareQueueEntries());
    this.queueService.process().subscribe();
    this.loggingService.setMetadata('Retry', (++this.retryCount).toString());
    this.loggingService.trackError('LLC - Cart Creation Error');
  }

  checkName(e): void {
    const name = this.questionnaireService.llc.entityName;
    const state = this.entityStateForm.get('entityState').value;
    let stateAbbr = '';

    if (typeof state === 'string' && typeof e.item !== 'undefined') {
      stateAbbr = e.item.abbr;
    } else if (typeof state === 'object' && state !== null) {
      stateAbbr = state.abbr;
    }

    if (name !== undefined && name.length > 0 && stateAbbr.length > 0) {
      this.businessNameCheckService
        .checkNameAvailability(name, stateAbbr)
        .subscribe((res) => {
          this._stateSelection.next(res);
        });
    }
  }

  private initState() {
    if (this.questionnaireService.llc.isEntityStateSelected) {
      return ConstantsService.getStateByName(
        this.questionnaireService.llc.entityState
      );
    }
    return undefined;
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}
