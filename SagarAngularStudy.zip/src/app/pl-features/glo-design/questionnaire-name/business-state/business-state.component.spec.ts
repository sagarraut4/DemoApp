import { CtaButtonComponent } from './../../shared/components/cta-button/cta-button.component';
import { RouterTestingModule } from '@angular/router/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TextMaskModule } from 'angular2-text-mask';
import { Router } from '@angular/router';
import { By } from '@angular/platform-browser';
import { WindowRef } from 'src/app/shared/services/windowRef.service';
import { TrackingService } from '../../../../shared/services/tracking/tracking.service';
import { QueueService } from '@legalzoom/business-formation-sdk';
import { PrepareCartService } from '../../../../shared/services/prepare-cart.service';
import { BehaviorSubject, of, ReplaySubject } from 'rxjs';
import { QuestionnaireService } from '../../../../../app/shared/services/questionnaire/questionnaire.service';
import { CartCreationStatus, EventService } from '../../../../shared/services/event.service';
import { QuestionnaireRoutingService } from '../../../../shared/services/questionnaire-routing/questionnaire-routing.service';
import { SEADService } from '../../../../shared/services/tracking/sead.service';
import { TrackSEMDataService } from '../../../../shared/services/tracking/track-sem-data.service';
import { UtilityService } from '../../../../shared/services/utility.service';
import { ErrorLoggingService } from '../../../../shared/services/error-logging.service';
import { BusinessNameCheckService } from '@legalzoom/business-name-check-sdk';
import { BusinessStateComponent } from './business-state.component';
import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { ExperimentsService } from './../../../../shared/services/experiments/experiments.service';
import { InfoPanelComponent } from '../../shared/components/info-panel/info-panel.component';
import { CookieService } from 'ngx-cookie';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

describe('BusinessStateComponent', () => {
  let component: BusinessStateComponent;
  let fixture: ComponentFixture<BusinessStateComponent>;
  const mockBusinessNameCheckService = jasmine.createSpyObj(['checkNameAvailability']);
  const mockQuestionnaireRoutingService = jasmine.createSpyObj(['getNextPage']);
  const mockTrackSemData = jasmine.createSpyObj(['setSEMCookies']);
  const mockSeadService = jasmine.createSpyObj(['PushToTealium']);
  const mockEventService = jasmine.createSpyObj(['updateCartCreationStatus', 'cartCreation$', 'updateResetConfigEvent']);
  const mockUtilityService = jasmine.createSpyObj(['setApprovedCookie']);
  const mockWindowRef = jasmine.createSpyObj(['nativeWindow']);
  const mockErrorLoggingService = jasmine.createSpyObj(['trackError', 'setMetadata']);
  const mockQuestionnaireService = {
    llc: {
      isChooseEntityNameLater: false,
      entityName: 'testtest'
    }
  };
  const mockPrepareCartService = jasmine.createSpyObj(['prepareQueueEntries']);
  mockPrepareCartService.clearQueueOnError = {};
  const mockTrackingService = jasmine.createSpyObj(['triggerClickTrack']);
  const mockQueueService = jasmine.createSpyObj(['add', 'process', 'subscribe']);
  const mockCookieService = jasmine.createSpyObj(['get', 'post', 'put', 'delete']);
  beforeEach(async(() => {
    mockEventService.cartCreation$ = new BehaviorSubject(CartCreationStatus.Created);
    mockQueueService.process.and.returnValue(of(true));
    TestBed.configureTestingModule({
      declarations: [BusinessStateComponent, CtaButtonComponent, InfoPanelComponent],
      imports: [RouterTestingModule.withRoutes([]), FormsModule, ReactiveFormsModule, BrowserAnimationsModule,
        HttpClientTestingModule, NgbModule, TextMaskModule],
      providers: [
        { provide: WindowRef, useValue: mockWindowRef },
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: QuestionnaireRoutingService, useValue: mockQuestionnaireRoutingService },
        { provide: TrackSEMDataService, useValue: mockTrackSemData },
        { provide: SEADService, useValue: mockSeadService },
        { provide: EventService, useValue: mockEventService },
        { provide: ErrorLoggingService, useValue: mockErrorLoggingService },
        { provide: UtilityService, useValue: mockUtilityService },
        { provide: BusinessNameCheckService, useValue: mockBusinessNameCheckService },
        { provide: PrepareCartService, useValue: mockPrepareCartService },
        { provide: TrackingService, useValue: mockTrackingService },
        { provide: QueueService, useValue: mockQueueService },
        { provide: CookieService, useValue: mockCookieService }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BusinessStateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create business-state component', () => {
    expect(component).toBeTruthy();
  });

  it('save should not execute if form is invalid', () => {
    component.save();
    expect(component.entityStateForm.invalid).toBeTruthy();
  });

  it('save should get called', () => {
    setInputValue('#tb-entity-state', 'California');
    component.entityStateForm.controls.entityState.markAsDirty();
    component.entityStateForm.controls.entityState.markAsTouched();
    const saveButton = fixture.debugElement.query(By.css('#btn-save')).nativeElement;
    spyOn(component, 'save');
    saveButton.click();
    expect(component.save).toHaveBeenCalled();
  });

  // TODO: fix test, seems like an async issue with setInputValue() method
  xit('save should get called continue method', async () => {
    TestBed.get(QuestionnaireService).llc.isChooseEntityNameLater = true;
    mockQuestionnaireRoutingService.getNextPage.and.returnValue('/');
    mockBusinessNameCheckService.checkNameAvailability.and.returnValue(of({}));
    setInputValue('#tb-entity-state', 'Califo');
    await fixture.detectChanges();
    await fixture.whenStable();
    const selectStateButton = fixture.debugElement.query(By.css('#ngb-typeahead-0-0')).nativeElement;
    selectStateButton.click();
    selectStateButton.dispatchEvent(new Event('input'));
    component.entityStateForm.controls.entityState.markAsDirty();
    component.entityStateForm.controls.entityState.markAsTouched();
    const saveButton = fixture.debugElement.query(By.css('#btn-save')).nativeElement;
    saveButton.click();
    fixture.detectChanges();
    await fixture.whenStable();
    mockEventService.cartCreation$.next({ res: CartCreationStatus.Created });
    expect(mockUtilityService.setApprovedCookie).toHaveBeenCalled();
  });

  it('on Search button click save method should get call', () => {
    const router: Router = TestBed.get(Router);
    spyOn(router, 'navigate').and.stub();
    spyOn(component, 'save');
    const btn = fixture.debugElement.query(By.css('#btn-save')).nativeElement;
    btn.click();
    fixture.detectChanges();
    expect(component.save).toHaveBeenCalled();
  });

  it('on changeName click should redirect to change name page', async(() => {
    const btn = fixture.debugElement.query(By.css('#btn-retry'));
    expect(btn.nativeElement.getAttribute('routerLink')).toBe('/name/change-name');
  }));

  it('checkname should call businessNameCheckService.checkNameAvailability if the inputs are correct', async(() => {
    setInputValue('#tb-entity-state', 'California');
    mockBusinessNameCheckService.checkNameAvailability.and.returnValue(of({}));
    const input = { item: { abbr: 'CA' } };
    component.checkName(input);
    fixture.whenStable().then(() => {
      expect(mockBusinessNameCheckService.checkNameAvailability).toHaveBeenCalled();
    });
  }));

  it('should call InfoPanelComponent open method', () => {
    spyOn(component.moreInfo, 'open');
    const el = fixture.debugElement.query(By.css('#lnk-more-info')).nativeElement;
    const mockEvent: Event = {
      srcElement: {
        classList: el.classList
      },
      stopPropagation: ((e: any) => { /**/
      }) as any,
      preventDefault: ((e: any) => { /**/
      }) as any,
      target: el
    } as any as Event;
    component.onClickMoreInfoLink(mockEvent);
    expect(component.moreInfo.open).toHaveBeenCalled();
  });

  function setInputValue(selector: string, value: string) {
    fixture.detectChanges();
    const input = fixture.debugElement.query(By.css(selector)).nativeElement;
    input.value = value;
    input.dispatchEvent(new Event('input'));
    fixture.whenStable().then(() => {
      fixture.detectChanges();
    });
  }

});



