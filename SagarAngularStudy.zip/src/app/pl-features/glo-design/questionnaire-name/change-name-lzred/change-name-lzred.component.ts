import { PrepareCartService } from '../../../../shared/services/prepare-cart.service';
import {AfterViewInit, ChangeDetectorRef, Component, OnDestroy, OnInit, ViewChild} from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, map, takeUntil } from 'rxjs/operators';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { ServerErrorComponent } from '../../../../shared/modals/server-error/server-error.component';
import { PagePath } from '../../../../shared/models/page-model';
import { ConstantsService, CookieName } from '../../../../shared/services/constants.service';
import { CartCreationStatus, EventService } from '../../../../shared/services/event.service';
import { QuestionnaireRoutingService } from '../../../../shared/services/questionnaire-routing/questionnaire-routing.service';
import { SEADService } from '../../../../shared/services/tracking/sead.service';
import { ValidateState } from '../../../../shared/validators/form-control.validator';
import { UtilityService } from '../../../../shared/services/utility.service';
import { QueueService } from '@legalzoom/business-formation-sdk';
import { BusinessNameCheckService } from '@legalzoom/business-name-check-sdk';
import { InfoPanelComponent } from '../../shared/components/info-panel/info-panel.component';
import { BreakpointObserver } from '@angular/cdk/layout';
import { TrackingService } from '../../../../shared/services/tracking/tracking.service';

type State = ReturnType<typeof ConstantsService.GetAllStates>[0];

declare var trackJs: any;
@Component({
  selector: 'app-desktop-change-name-lzred',
  templateUrl: './change-name-lzred.component.html',
  styleUrls: ['./change-name-lzred.component.scss']
})
export class ChangeNameLzredComponent implements OnInit, OnDestroy, AfterViewInit {
  public model: any;
  public changeNameForm: FormGroup;
  public changeType: string;
  public states: any;
  public submitted: boolean;
  public isLoading: boolean;
  private unsubscribe: Subject<void> = new Subject();
  private retryCount = 0;
  public allStates: any[];
  public isMobile = true;
  public stateList: State[]  = ConstantsService.GetAllStates();
  // tslint:disable-next-line: variable-name
  private _stateSelection = new BehaviorSubject<any>({});
  stateSelection = this._stateSelection.asObservable();
  public isFocused: boolean;
  @ViewChild('moreInfo', {static: false}) moreInfo: InfoPanelComponent;


  constructor(
    public questionnaireService: QuestionnaireService,
    private fb: FormBuilder,
    private router: Router,
    private businessNameCheckService: BusinessNameCheckService,
    private questionnaireRoutingService: QuestionnaireRoutingService,
    private seadService: SEADService,
    private eventService: EventService,
    private modalService: NgbModal,
    private utilityService: UtilityService,
    private prepareCartService: PrepareCartService,
    private queueService: QueueService,
    private breakpointObserver: BreakpointObserver,
    private changeDetectorRef: ChangeDetectorRef,
    private trackingService: TrackingService
  ) {
    this.isLoading = false;
    this.submitted = false;

    const size = '(min-width: 768px)';

    breakpointObserver.observe([
      size
    ]).subscribe(result => {
      this.isMobile = !result.matches;
    });

  }

  ngOnInit(): void {
    this.questionnaireService.llc.isChooseEntityNameLater = false;

    // get route data and set changeType
    this.changeType = !this.questionnaireService.llc.isBusinessNameAvailable ? 'retry' : 'change';

    this.changeNameForm = this.fb.group({
      entityName: [
        '',
        Validators.compose([
          Validators.required
        ])
      ],
      entityState: new FormControl(
        ConstantsService.getStateByName(this.questionnaireService.llc.entityState),
        Validators.compose([
          Validators.required,
          ValidateState
        ])
      )
    });

    this.allStates = ConstantsService.GetAllStates();
  }

  ngAfterViewInit(): void {
    if (this.changeNameForm.valid) {
      this.checkName({});

    }
  }

  search = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(200),
      distinctUntilChanged(),
      map(term =>
        term.length < 2 ? []
          : ConstantsService.GetAllStates().filter(v => v.abbr.toLowerCase().startsWith(term.toLowerCase()) || v.name.toLowerCase().startsWith(term.toLowerCase())
          ).slice(0, 10)))

  formatter = (x: { name: string }) => x.name;

  save(): void {
    this.submitted = true;

    // if the form is not valid, do not proceed
    if (this.changeNameForm.invalid) {
      return;
    }

    this.isLoading = true;
    const entityName = this.changeNameForm.get('entityName').value;

    this.seadService.TrackingObject.business_name = entityName;
    this.seadService.PushToTealium();
    const state = this.changeNameForm.get('entityState').value;

    this.questionnaireService.llc.entityName = entityName;
    this.questionnaireService.llc.entityState = state.name;

    // set state cookie for optimizely targeting
    this.utilityService.setApprovedCookie('C0002', CookieName.LLC_Formation_State, this.questionnaireService.llc.entityState, true);

    // check if the name is available
    this.businessNameCheckService.checkNameAvailability(entityName, state.abbr).subscribe(res => {

      if (typeof res.isAvailable !== 'undefined') {
        if (res.isAvailable === false) {
          this.changeType = 'retry';
        }

        this.questionnaireService.llc.isBusinessNameAvailable = res.isAvailable;
        this.submitted = false;
        this.isLoading = false;

        // go to next page
        this.continue();
      }
    }, err => {
      this.questionnaireService.llc.isBusinessNameAvailable = true;
      this.submitted = false;
      this.isLoading = false;
      // go to next page
      this.continue();
    });
  }

  private continue(): void {
    if (this.unsubscribe.isStopped) {
      this.unsubscribe = new Subject();
    }

    this.eventService.cartCreation$.pipe(takeUntil(this.unsubscribe)).subscribe(res => {
      if (res === CartCreationStatus.Created) {
        const nextPage = this.questionnaireRoutingService.getNextPage(PagePath.BusinessState);
        this.router.navigate([`./${nextPage}`]);
      } else if (res === CartCreationStatus.Error) {
        this.isLoading = false;
        const errorPopup = this.modalService.open(ServerErrorComponent, { size: 'lg', centered: true, windowClass: 'glo-modal' });
        errorPopup.result.then((result: string) => {
          this.unsubscribeAndRetry();
          this.trackTheRetryCount();
          this.continue();
        }).catch((err) => {
          this.unsubscribeAndRetry();
          this.trackTheRetryCount();
        });
      } else if (res === CartCreationStatus.None) {
        this.unsubscribeAndRetry();
        this.continue();
      } else {
        // cart is still being created
        this.isLoading = true;
      }
    });
  }

  private unsubscribeAndRetry(): void {
    this.unsubscribe.next();
    this.unsubscribe.complete();
    this.eventService.updateCartCreationStatus(CartCreationStatus.Pending);
    this.queueService.add(this.prepareCartService.prepareQueueEntries());
    this.queueService.process().subscribe();
  }

  private trackTheRetryCount() {
    trackJs.addMetadata('Retry', ++this.retryCount);
    trackJs.track('LLC - Cart Creation Error');
  }

  checkName(e): void {
    const name = this.changeNameForm.controls.entityName.value;
    const state = this.changeNameForm.controls.entityState.value;
    let stateAbbr = '';

    if (typeof state === 'string' && typeof e.item !== 'undefined') {
      stateAbbr = e.item.abbr;
    } else if (typeof state === 'object') {
      stateAbbr = state.abbr;
    }

    if (name.length > 0 && stateAbbr.length > 0) {
      this.businessNameCheckService.checkNameAvailability(name, stateAbbr).subscribe(res => {
        this._stateSelection.next(res);
      });
    }
  }

  public stateSelectComparison(state1: State, state2: State) {
    if(!state1 || !state2) {
      return false;
    }
    return state1.abbr === state2.abbr;
  }

  public getAllStates() {
    return ConstantsService.GetAllStates();
  }

  public openInfoPanel() {
    this.trackingService.triggerClickTrack('llc_flow', 'search_again_more_info_link');
    this.moreInfo.open();
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}
