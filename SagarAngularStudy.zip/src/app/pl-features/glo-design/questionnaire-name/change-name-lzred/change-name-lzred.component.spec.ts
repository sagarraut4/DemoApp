import { BehaviorSubject, of } from 'rxjs';
import { By } from '@angular/platform-browser';
import { TextMaskModule } from 'angular2-text-mask';
import { BusinessNameCheckModule } from '@legalzoom/business-name-check-sdk';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { QueueService } from '@legalzoom/business-formation-sdk';
import { CookieModule } from 'ngx-cookie';
import { MockComponent } from 'ng-mocks';
import { CookieService as ngxCookieService } from 'ngx-cookie-service';
import { environmentCommon } from '../../../../../environments/environment';
import { PrepareCartService } from '../../../../shared/services/prepare-cart.service';
import { UtilityService } from '../../../../shared/services/utility.service';
import { WindowRef } from '../../../../shared/services/windowRef.service';
import { EventService, CartCreationStatus } from '../../../../shared/services/event.service';
import { SEADService } from '../../../../shared/services/tracking/sead.service';
import { QuestionnaireRoutingService } from '../../../../shared/services/questionnaire-routing/questionnaire-routing.service';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { ChangeNameLzredComponent } from './change-name-lzred.component';
import { TrackingService } from '../../../../shared/services/tracking/tracking.service';
import { CtaButtonComponent } from '../../shared/components/cta-button/cta-button.component';
import { BusinessNameCheckService } from '@legalzoom/business-name-check-sdk';
import { InfoPanelComponent } from '../../shared/components/info-panel/info-panel.component';

describe('ChangeNameComponentLZRED', () => {
  let component: ChangeNameLzredComponent;
  let fixture: ComponentFixture<ChangeNameLzredComponent>;
  const mockBusinessNameCheckService = jasmine.createSpyObj(['checkNameAvailability']);
  const mockQuestionnaireRoutingService = jasmine.createSpyObj(['getNextPage']);
  const mockSeadService = jasmine.createSpyObj(['PushToTealium', 'TrackingObject']);
  const mockEventService = jasmine.createSpyObj(['updateCartCreationStatus', 'cartCreation$']);
  const mockUtilityService = jasmine.createSpyObj('UtilityService', ['setApprovedCookie']);
  const mockWindowRef = jasmine.createSpyObj(['nativeWindow']);
  const mockTrackingService = jasmine.createSpyObj(['triggerClickTrack']);
  const mockQuestionnaireService = {
    llc: {
      isChooseEntityNameLater: false,
      entityName: 'testtest'
    }
  };
  const mockPrepareCartService = jasmine.createSpyObj(['prepareQueueEntries']);
  mockPrepareCartService.clearQueueOnError = {};
  const mockQueueService = jasmine.createSpyObj(['add', 'process', 'subscribe']);
  beforeEach(async(() => {
    mockSeadService.TrackingObject = {
      business_name: ''
    };
    mockEventService.cartCreation$ = new BehaviorSubject(CartCreationStatus.Created);
    mockQueueService.process.and.returnValue(of(true));
    TestBed.configureTestingModule({
      declarations: [ChangeNameLzredComponent, CtaButtonComponent, MockComponent(InfoPanelComponent)],
      imports: [
        RouterTestingModule.withRoutes([]),
        BusinessNameCheckModule.forRoot(environmentCommon),
        CookieModule.forRoot(),
        FormsModule,
        ReactiveFormsModule,
        HttpClientTestingModule,
        NgbModule,
        TextMaskModule],
      providers: [
        { provide: WindowRef, useValue: mockWindowRef },
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: BusinessNameCheckService, useValue: mockBusinessNameCheckService },
        { provide: QuestionnaireRoutingService, useValue: mockQuestionnaireRoutingService },
        { provide: SEADService, useValue: mockSeadService },
        { provide: EventService, useValue: mockEventService },
        { provide: UtilityService, useValue: mockUtilityService },
        { provide: PrepareCartService, useValue: mockPrepareCartService },
        { provide: QueueService, useValue: mockQueueService },
        { provide: TrackingService, useValue: mockTrackingService },
        ngxCookieService
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangeNameLzredComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create business-state component', () => {
    expect(component).toBeTruthy();
  });

  it('isLoading is false if form is invalid', () => {
    component.save();
    expect(component.isLoading).toBe(false);
  });

  xit('isLoading is true if form is valid', async () => {
    await setInputValue('#tb-entity-state', 'California');
    mockBusinessNameCheckService.checkNameAvailability.and.returnValue(of({}));
    await fixture.detectChanges();
    await fixture.whenStable();
    const selectStateButton = fixture.debugElement.query(By.css('.dropdown-item'));
    selectStateButton.nativeElement.click();
    selectStateButton.nativeElement.dispatchEvent(new Event('input'));
    component.changeNameForm.controls.entityName.setValue('test');
    component.save();
    expect(component.isLoading).toBe(true);
  });

  it('checkname should call businessNameCheckService.checkNameAvailability if the inputs are correct', async(async () => {
    await setInputValue('#tb-entity-state', 'California');
    component.changeNameForm.controls.entityName.setValue('Testing');
    mockBusinessNameCheckService.checkNameAvailability.and.returnValue(of({}));
    const input = { item: { abbr: 'CA' } };
    component.checkName(input);
    fixture.whenStable();
    expect(mockBusinessNameCheckService.checkNameAvailability).toHaveBeenCalled();
  }));

  it('should call save method on click of submit button', async(async () => {
    spyOn(component, 'save');
    await setInputValue('#tb-entity-state', 'California');
    component.changeNameForm.controls.entityName.setValue('Testing');
    const saveButton = fixture.debugElement.query(By.css('#btn-save')).nativeElement;
    saveButton.click();
    fixture.detectChanges();
    fixture.whenStable();
    expect(component.save).toHaveBeenCalled();
  }));

  // TODO: fix test
  xit('save should get called continue method', async () => {
    TestBed.get(QuestionnaireService).llc.isChooseEntityNameLater = true;
    mockQuestionnaireRoutingService.getNextPage.and.returnValue('/');
    await setInputValue('#tb-entity-state', 'Califo');

    await fixture.detectChanges();
    await fixture.whenStable();

    const selectStateButton = fixture.debugElement.query(By.css('.dropdown-item')).nativeElement;
    selectStateButton.click();
    selectStateButton.dispatchEvent(new Event('input'));

    const saveButton = fixture.debugElement.query(By.css('#btn-save')).nativeElement;
    saveButton.click();

    await fixture.detectChanges();
    await fixture.whenStable();

    mockEventService.cartCreation$.next({ res: CartCreationStatus.Created });
    expect(mockUtilityService.setApprovedCookie).toHaveBeenCalled();
  });

  async function setInputValue(selector: string, value: string) {
    fixture.detectChanges();
    const input = fixture.debugElement.query(By.css(selector)).nativeElement;
    input.value = value;
    input.dispatchEvent(new Event('input'));
    await fixture.whenStable();
    fixture.detectChanges();
  }
});
