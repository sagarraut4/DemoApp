import { CtaButtonComponent } from './../../shared/components/cta-button/cta-button.component';
import { By } from '@angular/platform-browser';
import { CookieService } from 'ngx-cookie';
import { CustomerService } from '@legalzoom/customer-sdk';
import { FormBuilder, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { RouterTestingModule } from '@angular/router/testing';
import { TextMaskModule } from 'angular2-text-mask';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { AppService } from '../../../../../app/shared/state/app/app.service';
import { EventService } from 'src/app/shared/services/event.service';
import { ExperimentsService } from 'src/app/shared/services/experiments/experiments.service';
import { NameAvailableComponent } from './name-available.component';
import { PrepareCartService } from '../../../../../app/shared/services/prepare-cart.service';
import { QuestionnaireService } from 'src/app/shared/services/questionnaire/questionnaire.service';
import { SEADService } from 'src/app/shared/services/tracking/sead.service';
import { SharedComponentsModule } from 'src/app/shared/components/shared-components.module';
import { TrackingService } from 'src/app/shared/services/tracking/tracking.service';
import { WindowRef } from 'src/app/shared/services/windowRef.service';
import { Router } from '@angular/router';
import { LLC } from '../../../../shared/models/questionnaire-model';

describe('NameAvailableComponent', () => {
  let component: NameAvailableComponent;
  let fixture: ComponentFixture<NameAvailableComponent>;
  let formBuilder: FormBuilder;
  // tslint:disable-next-line:prefer-const
  let mockCookieService: CookieService;
  const mockEventService = jasmine.createSpyObj(['saveAndContinue']);
  const mockSeadService = jasmine.createSpyObj(['PushToTealium', 'TrackingObject']);
  const mockCustomerService = jasmine.createSpyObj(['isGuestCustomer']);
  const mockAppService = {
    currentView: '',
    loginEmail: '',
    app: {
      processingOrderId: 123
    }
  };
  const mockExperimentService = jasmine.createSpyObj(['GetBFunnelTestValue', 'GetBShowPriceTestValue', 'GetBShowPriceTest1Value']);
  let mockTrackingService;
  const mockQuestionnaireService = jasmine.createSpyObj(['setQuestionnaire', 'llc']);
  const mockPrepareCartService = jasmine.createSpyObj(['mockPrepareCartService', 'prepareQueueForQuestStorageFillingFee']);
  const llc = {
    isBusinessNameAvailable: true,
    isChooseNameLater: true,
    entityName: 'ABC'
  } as unknown as LLC;

  const trackingObject: any = {
    user_fname: 'ABC'
  };

  beforeEach(async(() => {
    mockTrackingService = jasmine.createSpyObj(['triggerClickTrack']);
    formBuilder = new FormBuilder();
    mockSeadService.TrackingObject = trackingObject;
    mockAppService.loginEmail = '';
    mockPrepareCartService.parentComponentName = '';
    mockQuestionnaireService.llc = llc;
    (mockQuestionnaireService.setQuestionnaire as jasmine.Spy)
      .and.returnValue(of(null));

    TestBed.configureTestingModule({
      declarations: [NameAvailableComponent, CtaButtonComponent],
      imports: [
        RouterTestingModule,
        ReactiveFormsModule,
        HttpClientTestingModule,
        NgbModule,
        SharedComponentsModule,
        TextMaskModule,
        FormsModule
      ],
      providers: [
        FormBuilder,
        WindowRef,
        { provide: EventService, useValue: mockEventService },
        { provide: ExperimentsService, useValue: mockExperimentService },
        { provide: SEADService, useValue: mockSeadService },
        { provide: TrackingService, useValue: mockTrackingService },
        { provide: CookieService, useValue: mockCookieService },
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: PrepareCartService, useValue: mockPrepareCartService },
        { provide: CustomerService, useValue: mockCustomerService },
        { provide: AppService, useValue: mockAppService }
      ]
    }).compileComponents().then(() => {
      fixture = TestBed.createComponent(NameAvailableComponent);
      component = fixture.componentInstance;

      component.entityAvailableForm = formBuilder.group({
        phoneNumber: [],
        emailAddress: []
      });

      fixture.detectChanges();
    });
  }));

  it('allows user to proceed for empty form', () => {
    const nextButton = fixture.debugElement.query(By.css('#btn-save')).nativeElement;
    expect(nextButton.disabled).toBeFalsy();
  });

  it('allows user to proceed for valid form', () => {
    spyOn(component, 'save');
    setInputValue('#llc-contact-email', 'user@example.com');
    setInputValue('#llc-contact-phone', '(555) 867-5309');

    const getNextButton = fixture.debugElement.query(By.css('#btn-save'));
    getNextButton.nativeElement.click();

    fixture.detectChanges();

    expect(component.save).toHaveBeenCalled();
  });

  it('supports phone with country code and formatting', async () => {
    setInputValue('#llc-contact-phone', '+01 (234) 567-8901');

    fixture.detectChanges();
    await fixture.whenStable();

    const input = fixture.debugElement.query(By.css('#llc-contact-email')).nativeElement;
    expect(input.classList).not.toContain('ng-invalid');
  })

  it('supports phone with country code and no formatting', async () => {
    setInputValue('#llc-contact-phone', '012345678901');

    fixture.detectChanges();
    await fixture.whenStable();

    const input = fixture.debugElement.query(By.css('#llc-contact-email')).nativeElement;
    expect(input.classList).not.toContain('ng-invalid');
  })

  it('supports phone without country code and with formatting', async () => {
    setInputValue('#llc-contact-phone', '(234) 567-8901');

    fixture.detectChanges();
    await fixture.whenStable();

    const input = fixture.debugElement.query(By.css('#llc-contact-email')).nativeElement;
    expect(input.classList).not.toContain('ng-invalid');
  })

  it('supports phone without country code and without formatting', async () => {
    setInputValue('#llc-contact-phone', '2345678901');

    fixture.detectChanges();
    await fixture.whenStable();

    const input = fixture.debugElement.query(By.css('#llc-contact-email')).nativeElement;
    expect(input.classList).not.toContain('ng-invalid');
  })

  it('displays an error for an invalid email', async(async () => {
    setInputValue('#llc-contact-email', 'thisisnotanemail');

    fixture.detectChanges();
    await fixture.whenStable();

    const input = fixture.debugElement.query(By.css('#llc-contact-email')).nativeElement;
    expect(input.classList).toContain('ng-invalid');
  }));

  it('displays an error for an invalid phone number', async(async () => {
    setInputValue('#llc-contact-phone', 'jfdlkafjdksalfjdlsa');

    fixture.detectChanges();
    await fixture.whenStable();

    const input = fixture.debugElement.query(By.css('#llc-contact-phone')).nativeElement;
    expect(input.classList.toString()).toContain('ng-invalid');
  }))

  it('reports user information to Tealium', () => {
    setInputValue('#llc-contact-email', 'user@example.com');
    setInputValue('#llc-contact-phone', '(555) 867-5309');

    const getNextButton = fixture.debugElement.query(By.css('#btn-save'));
    getNextButton.nativeElement.click();

    fixture.detectChanges();

    expect(mockTrackingService.triggerClickTrack).toHaveBeenCalledTimes(2);
    expect(mockSeadService.PushToTealium).toHaveBeenCalled();
    expect(mockPrepareCartService.prepareQueueForQuestStorageFillingFee).toHaveBeenCalled();
  });

  it('should call router.navigate on changeName method', () => {
    const router: Router = TestBed.get(Router);
    spyOn(router, 'navigate').and.stub();

    component.changeName();

    expect(router.navigate).toHaveBeenCalled();
  });

  it('does not display `try another name` link when the user skipped picking a name', async () => {
    component.isChooseNameLater = true;

    fixture.detectChanges();
    await fixture.whenStable();

    const tryAnotherNameLink = fixture.debugElement.query(By.css('#try-another-name-action'));
    expect(tryAnotherNameLink).toBeFalsy();
  });

  it('displays `try another name` link when the user selected a name', async () => {
    component.isChooseNameLater = false;

    fixture.detectChanges();
    await fixture.whenStable();

    const tryAnotherNameLink = fixture.debugElement.query(By.css('#try-another-name-action'));
    expect(tryAnotherNameLink.nativeElement).toBeDefined();
  });

  it('displays the cta button when a name is not selected', async () => {
    component.isChooseNameLater = true;

    fixture.detectChanges();
    await fixture.whenStable();

    const ctaButton = fixture.debugElement.query(By.css('app-cta-button'));
    expect(ctaButton.nativeElement).toBeDefined();
  })

  function setInputValue(selector: string, value: string) {
    fixture.detectChanges();
    const input = fixture.debugElement.query(By.css(selector)).nativeElement;
    input.value = value;
    input.dispatchEvent(new Event('input'));
    input.dispatchEvent(new Event('change'));
  }
});
