import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { CustomerService } from '@legalzoom/customer-sdk';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { QueueService } from '@legalzoom/business-formation-sdk';
import { AppService } from '../../../../../app/shared/state/app/app.service';
import { Chapter, PagePath } from '../../../../../app/shared/models/page-model';
import { EventService } from '../../../../../app/shared/services/event.service';
import { ExperimentsService } from '../../../../../app/shared/services/experiments/experiments.service';
import { PrepareCartService } from '../../../../../app/shared/services/prepare-cart.service';
import { QuestionnaireService } from '../../../../../app/shared/services/questionnaire/questionnaire.service';
import { SEADService } from '../../../../../app/shared/services/tracking/sead.service';
import { TrackingService } from '../../../../../app/shared/services/tracking/tracking.service';
import { ValidateEmail } from '../../../../../app/shared/validators/form-control.validator';

const VALID_PHONE_PATTERN = /^\([2-9]\d{2}\) \d{3}-\d{4}$/;

@Component({
  selector: 'app-name-available',
  templateUrl: './name-available.component.html',
  styleUrls: ['./name-available.component.scss'],
})
export class NameAvailableComponent implements OnInit, OnDestroy {
  public entityAvailableForm: FormGroup;
  public isLoading: boolean;
  public processId: number;
  public sPage: string;
  public isFunnelTest = false;
  public isChooseNameLater = false;
  public isSubmitted = false;
  public emailInputEmpty = true;
  public phoneInputEmpty = true;

  public phoneMask = [
    '(',
    /[1-9]/,
    /\d/,
    /\d/,
    ')',
    ' ',
    /\d/,
    /\d/,
    /\d/,
    '-',
    /\d/,
    /\d/,
    /\d/,
    /\d/
  ];

  private unsubscribe: Subject<void> = new Subject();

  @ViewChild('emailErrorUnderline', { static: false })
  emailErrorUnderline: ElementRef;

  @ViewChild('emailErrorMessage', { static: false })
  emailErrorMessage: ElementRef;

  @ViewChild('phoneErrorUnderline', { static: false })
  phoneErrorUnderline: ElementRef;

  @ViewChild('phoneErrorMessage', { static: false })
  phoneErrorMessage: ElementRef;

  constructor(
    private router: Router,
    public questionnaireService: QuestionnaireService,
    private fb: FormBuilder,
    private seadService: SEADService,
    private experimentService: ExperimentsService,
    private eventService: EventService,
    private trackingService: TrackingService,
    private prepareCartService: PrepareCartService,
    private customerService: CustomerService,
    private appService: AppService,
    private queueService: QueueService
  ) {}

  ngOnInit() {
    this.isLoading = false;
    this.isChooseNameLater =
      this.questionnaireService.llc.isChooseEntityNameLater ||
      !this.questionnaireService.llc.isBusinessNameAvailable;

    if (!this.questionnaireService.llc.entityName && !this.isChooseNameLater) {
      this.router.navigate([`./${Chapter.Name}/${PagePath.ChangeName}`]);
    }

    this.entityAvailableForm = this.fb.group({
      phoneNumber: ['', [Validators.pattern(VALID_PHONE_PATTERN)]],
      emailAddress: ['', [ValidateEmail]],
    });

    this.questionnaireService.llc.bFunnelTest = this.experimentService.GetBFunnelTestValue();
    this.questionnaireService.llc.bShowPriceTest1 = this.experimentService.GetBShowPriceTest1Value();

    // update questionnaire values since we default user entity state during early cart creation
    this.prepareCartService.parentComponentName = this.constructor.name;
  }

  public onEmailBlur(event: Event) {
    const emailInput = event.target as HTMLInputElement;
    this.emailInputEmpty = emailInput.value.length < 1;
  }

  public onPhoneBlur(event: Event) {
    const phoneInput = event.target as HTMLInputElement;
    this.phoneInputEmpty = phoneInput.value.length < 1;
  }

  save(): void {
    this.isSubmitted = true;
    if (this.entityAvailableForm.invalid) {
      return;
    }

    this.isLoading = true;
    this.questionnaireService.llc.customerPhoneNumber = this.entityAvailableForm.get(
      'phoneNumber'
    ).value;
    this.questionnaireService.llc.customerEmail = this.entityAvailableForm.get(
      'emailAddress'
    ).value;

    // GA Tracking
    if (this.questionnaireService.llc.customerPhoneNumber) {
      this.trackingService.triggerClickTrack(
        'llc_name_available',
        'phone_number',
        'type'
      );
    }
    if (this.questionnaireService.llc.customerEmail) {
      this.trackingService.triggerClickTrack(
        'llc_name_available',
        'email_address',
        'type'
      );
    }

    if (
      this.entityAvailableForm.get('phoneNumber').value ||
      this.entityAvailableForm.get('emailAddress').value
    ) {
      // create a drip lead
      if (this.customerService.isGuestCustomer(this.appService.loginEmail)) {
        // user entered phone number, save as a lead
        this.seadService.TrackingObject.user_fname = 'LegalZoom';
        this.seadService.TrackingObject.user_lname = 'Customer';
        this.seadService.PushToTealium();
      } else {
        // send user first/last name
        this.seadService.TrackingObject.user_fname = 'bst_firstname';
        this.seadService.TrackingObject.user_lname = 'bst_lastname';
        this.seadService.PushToTealium();
      }
    }
    // Fetch the available packages earlier to reduce package selection load time
    this.prepareCartService.prepareQueueForQuestStorageFillingFee();

    this.eventService.saveAndContinue(PagePath.NameAvailable);
  }

  changeName(): void {
    this.router.navigate([Chapter.Name + '/' + PagePath.ChangeName]);
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}
