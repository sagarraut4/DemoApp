import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { QuestionnaireService } from '../../../shared/services/questionnaire/questionnaire.service';
import { LoadingComponent } from './loading.component';
import { Router } from '@angular/router';
import { LLC } from '../../../shared/models/questionnaire-model';
import { AppService } from '../../../shared/state/app';
import { QuestionnaireRoutingService } from '../../../shared/services/questionnaire-routing/questionnaire-routing.service';
import { MockComponent } from 'ng-mocks';
import { SpinnerComponent } from './spinner/spinner.component';

describe('LoadingComponent', () => {
  let component: LoadingComponent;
  let fixture: ComponentFixture<LoadingComponent>;
  let mockRouter;
  const mockQuestionnaireRoutingService = jasmine.createSpyObj(['getNextPage']);
  const mockQuestionnaireService = {
    llc: new LLC()
  };
  const mockAppService = {
    currentView: '',
    loginEmail: '',
    app: {
      processingOrderId: 123
    }
  };
  beforeEach(async(() => {
    mockRouter = {
      navigate: jasmine.createSpy('navigate')
    };
    TestBed.configureTestingModule({
      declarations: [LoadingComponent, MockComponent(SpinnerComponent)],
      providers: [
        { provide: Router, useValue: mockRouter },
        { provide: QuestionnaireRoutingService, useValue: mockQuestionnaireRoutingService },
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: AppService, useValue: mockAppService }
      ]
    })
      .compileComponents();
  }));
  let originalTimeout;
  beforeEach(() => {
    originalTimeout = jasmine.DEFAULT_TIMEOUT_INTERVAL;
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 100000;
    fixture = TestBed.createComponent(LoadingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = originalTimeout;
  });

  it('should create', async () => {
    expect(component).toBeTruthy();
  });

  it('should call QuestionnaireRoutingService.getNextPage and  Router.navigate', async () => {
    expect(component).toBeTruthy();
    await sleep(6500);
    expect(mockQuestionnaireRoutingService.getNextPage).toHaveBeenCalled();
    expect(mockRouter.navigate).toHaveBeenCalled();
  });

  function sleep(ms) {
    return new Promise(resolve => {
      setTimeout(resolve, ms);
    });
  }
});
