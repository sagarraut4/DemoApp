
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { QuestionnaireRoutingService } from '../../../shared/services/questionnaire-routing/questionnaire-routing.service';
import { AppService } from '../../../shared/state/app';
import { QuestionnaireService } from '../../../shared/services/questionnaire/questionnaire.service';
import { PagePath } from '../../../shared/models/page-model';

@Component({
  selector: 'app-loading',
  templateUrl: './loading.component.html',
  styleUrls: ['./loading.component.scss']
})
export class LoadingComponent implements OnInit {
  @ViewChild('analyzing', null) analyzing: ElementRef;
  public showAnalyzing = false;
  public showFinalizing = false;
  public reviewingComplete = false;
  public analyzingComplete = false;
  public finalizingComplete = false;
  public completed = false;

  constructor(
    private router: Router,
    private appService: AppService,
    private questionnaireRoutingService: QuestionnaireRoutingService,
    private questionnaireService: QuestionnaireService
  ) {   
  }

  ngOnInit() {
    // how long the spinner "loads"
    const LOADING_DELAY = 1000;
    // how long before the next item gets added
    const PAUSE_DELAY = 500;

    // "loading" sequence
    setTimeout(() => this.reviewingComplete = true, LOADING_DELAY);
    setTimeout(() => this.showAnalyzing = true, LOADING_DELAY + PAUSE_DELAY);
    setTimeout(() => this.analyzingComplete = true, LOADING_DELAY + PAUSE_DELAY + LOADING_DELAY);
    setTimeout(() => this.showFinalizing = true, LOADING_DELAY + PAUSE_DELAY + LOADING_DELAY + PAUSE_DELAY);
    setTimeout(() => this.finalizingComplete = true, LOADING_DELAY + PAUSE_DELAY + LOADING_DELAY + PAUSE_DELAY + LOADING_DELAY);

    // "completion" sequence
    setTimeout(() => this.completed = true, LOADING_DELAY + PAUSE_DELAY + LOADING_DELAY + PAUSE_DELAY + LOADING_DELAY + LOADING_DELAY);

    // redirect to results page
    setTimeout(() => {
      const nextPage = this.questionnaireRoutingService.getNextPage(PagePath.OrderLoading);
      this.questionnaireService.llc.currentView = nextPage;
      this.appService.currentView = nextPage;
      this.router.navigate([`./${nextPage}`]); 
    }, 6000);
  }

}
