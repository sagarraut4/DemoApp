import { ProductConfigurationIds } from '../../../../shared/models/cart-model';
import { FormsModule } from '@angular/forms';
import { PrepareCartService } from '../../../../shared/services/prepare-cart.service';
import { EventService } from '../../../../shared/services/event.service';
import { UserCartService } from '../../shared/services/user-cart.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TrackingService } from '../../../../shared/services/tracking/tracking.service';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { QuestionnaireRoutingService } from '../../../../shared/services/questionnaire-routing/questionnaire-routing.service';
import { MatTooltipModule } from '@angular/material';
import { SpinnerComponent } from '../../../../shared/components/spinner/spinner.component';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReviewYourOrderComponent } from './review-your-order.component';
import { Component, Input } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import { Subject } from 'rxjs';
import { NgbModule, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TippyService } from 'ng-tippy';
import { MockComponent } from 'ng-mocks';
import { CartItemsComponent } from './cart-items/cart-items.component';
import { GloSpinnerComponent } from '../../shared/components/spinner/spinner.component';
import { CookieService } from 'ngx-cookie';

// TODO: these tests take a long time to execute, we should look into why
describe('ReviewYourOrderComponent', () => {
  let component: ReviewYourOrderComponent;
  let fixture: ComponentFixture<ReviewYourOrderComponent>;
  const mockQuestionnaireRoutingService = jasmine.createSpyObj(['getNextPage']);
  let mockQuestionnaireService = {
    llc: {
      entityName: 'Test',
      hireEmployees: 'no',
      businessPurpose: '',
      lzRA: 'Yes',
      legalAdvice: false,
      taxAdvice: false,
      documentsPackage: 'OA',
      totalCompliance: false,
      professionalPrintSelected: true
    }
  };
  const utag: any = {
    link() { }
  };
  const mockTrackingService = jasmine.createSpyObj(['winRef', 'ClearOAItems', 'MapToOAItems', 'sendAdConversion']);
  const mockWindowRef = jasmine.createSpyObj(['nativeWindow', 'utag']);
  const mockTippyService = jasmine.createSpyObj(['getAllTippies']);
  mockWindowRef.nativeWindow.utag = utag;
  mockTrackingService.winRef.nativeWindow = mockWindowRef.nativeWindow;
  let mockPrepareCartService;
  const mockUserCartService = jasmine.createSpyObj(['userCartChange', 'getAnnualLegalProductConfigurationId']);
  let mockEventService;

  mockUserCartService.userCart = {
    cartId: 22233965, packageTitle: '', dueNow: 518,
    discount: 0, cartItems: [
      // tslint:disable-next-line:max-line-length
      { productConfigurationId: 0, productComponentId: 0, type: 0, title: 'Company details', description: null, details: null, amount: 0, hideOnRYO: null, hideEditLink: null, showZeroAmount: true, rank: 0, isShowAmountText: null, amountText: null, isSelected: null, subItems: null },
      // tslint:disable-next-line:max-line-length
      { productConfigurationId: -1, productComponentId: -1, type: 0, title: 'asdfasdf', description: null, details: null, amount: 0, hideOnRYO: null, hideEditLink: null, showZeroAmount: true, rank: 0, isShowAmountText: null, amountText: null, isSelected: null, subItems: null },
      // tslint:disable-next-line:max-line-length
      { productConfigurationId: 5793, productComponentId: 2311, type: 9, title: 'Storage Subscription', description: null, details: null, amount: 0, hideOnRYO: null, hideEditLink: null, showZeroAmount: false, rank: 0, isShowAmountText: null, amountText: null, isSelected: null, subItems: null },
      // tslint:disable-next-line:max-line-length
      { productConfigurationId: 146, productComponentId: 112, type: 2, title: 'Standard LLC', description: null, details: null, amount: 329, hideOnRYO: null, hideEditLink: null, showZeroAmount: false, rank: 2, isShowAmountText: null, amountText: null, isSelected: null, subItems: null },
      // tslint:disable-next-line:max-line-length
      { productConfigurationId: 804, productComponentId: 322, type: 8, title: 'California filing fee(This is the admin fee charged by the state)', description: null, details: null, amount: 70, hideOnRYO: null, hideEditLink: null, showZeroAmount: false, rank: 6, isShowAmountText: null, amountText: null, isSelected: null, subItems: null },
      // tslint:disable-next-line:max-line-length
      { productConfigurationId: 5893, productComponentId: 132, type: 3, title: 'Operating Agreement', description: null, details: null, amount: 99, hideOnRYO: null, hideEditLink: null, showZeroAmount: false, rank: 14, isShowAmountText: null, amountText: null, isSelected: null, subItems: null },
      // tslint:disable-next-line:max-line-length
      { productConfigurationId: -2, productComponentId: -6, type: 0, title: 'Operating Agreement', description: null, details: null, amount: 99, hideOnRYO: null, hideEditLink: null, showZeroAmount: false, rank: 15, isShowAmountText: null, amountText: null, isSelected: null, subItems: null },
      {
        productConfigurationId: 6286, productComponentId: 2429, type: 9, title: 'LegalZoom Registered Agent(No fees until documents sent to state)', description: null, details: {
          // tslint:disable-next-line:max-line-length
          intro: '(No fees until documents sent to state)', body: 'LegalZoom\'s Registered Agent Service only starts when your LLC is submitted to state. When we receive official notification that your LLC has been registered, your card will automatically be charged $159. The service renews automatically each year, billed to your card, for the service price (currently $159). You may cancel online or by calling us at (844) 962-7490. You will first need to appoint a new RA for your business.',
          showBody: false
        }, amount: 0, hideOnRYO: null, hideEditLink: null, showZeroAmount: false, rank: 19, isShowAmountText: null, amountText: null, isSelected: null, subItems: null
      },
      {
        productConfigurationId: 7327, productComponentId: 2817, type: 9, title: 'Legal Protect Plan', description: null, details: {
          // tslint:disable-next-line:max-line-length
          intro: '(10 days included)', body: 'This package is offered as a trial for 10 days.After the 10 - day trial period, benefits continue automatically for the same term and rate unless otherwise notified.Cancel online or by calling(888) 310 - 0151.For full details, please see our < a href =\http://www.legalzoom.com/legal/product-service-terms/supplemental-terms-of-service-for-advantage-subscriptions\ target=\_blank\>Subscription Terms</a> and <a href=\https://www.legalzoom.com/legal/product-service-terms/legal-plan-contract\ target=\_blank\>Legal Plan Contract</a>.',
          showBody: false
        }, amount: 0, hideOnRYO: null, hideEditLink: null, showZeroAmount: false, rank: 22, isShowAmountText: null, amountText: null, isSelected: null, subItems: null
      },
      {
        productConfigurationId: 6282, productComponentId: 2438, type: 9, title: 'Total Compliance', description: null,
        details: {
          // tslint:disable-next-line:max-line-length
          intro: '(10 days included)', body: 'This package is offered for 10 days. After the 10-day period, benefits continue automatically for the same term and rate unless otherwise notified.Cancel online or by calling(888) 310 - 0151.For full details, please see our < a href =\http://www.legalzoom.com/legal/product-service-terms/supplemental-terms-of-service-for-advantage-subscriptions\ target=\_blank\>Subscription Terms</> and <a href=\https://www.legalzoom.com/legal/product-service-terms/legal-plan-contract\ target=\_blank\>Legal Plan Contract</a>.',
          showBody: false
        }, amount: 0, hideOnRYO: null, hideEditLink: null, showZeroAmount: false, rank: 27, isShowAmountText: null,
        amountText: null, isSelected: null, subItems: null
      },
      {
        productConfigurationId: 3917, productComponentId: 646, type: 8, title: 'Statement of Information Filing Fee',
        description: null, details: null, amount: 20, hideOnRYO: null, hideEditLink: null, showZeroAmount: false, rank: 29, isShowAmountText: null, amountText: null, isSelected: null,
        subItems: null
      },
      {
        productConfigurationId: -5, productComponentId: -5, type: 0, title: 'Sales Tax', description: null, details: null, amount: 0, hideOnRYO: null, hideEditLink: null,
        showZeroAmount: false, rank: 34, isShowAmountText: null, amountText: null, isSelected: null, subItems: null
      },
      {
        productConfigurationId: -6, productComponentId: -6, type: 0, title: 'We’ve got you covered!', description: null, details: null, amount: 0, hideOnRYO: null, hideEditLink: null, showZeroAmount: false,
        rank: 35, isShowAmountText: null, amountText: null, isSelected: null, subItems: null
      },
      {
        productConfigurationId: 6553, productComponentId: 2493, type: 3, title: 'Digital Download',
        description: null, details: null, amount: 0, hideOnRYO: null, hideEditLink: null, showZeroAmount: false,
        rank: 36, isShowAmountText: null, amountText: null, isSelected: null, subItems: null
      },
      {
        productConfigurationId: 6579, productComponentId: 2499, type: 3, title: 'Digital Download',
        description: null, details: null, amount: 0, hideOnRYO: null, hideEditLink: null, showZeroAmount: false,
        rank: 37, isShowAmountText: null, amountText: null, isSelected: null, subItems: null
      },
      {
        productConfigurationId: -10, productComponentId: -10, type: 0,
        title: 'All your documents in one convenient location + <br />1 TB of free cloud storage.',
        description: null, details: null, amount: 0, hideOnRYO: null,
        hideEditLink: null, showZeroAmount: false, rank: 38,
        isShowAmountText: null, amountText: null, isSelected: null, subItems: null
      },
      {
        productConfigurationId: 162, productComponentId: 138, type: 7, title: 'Professional Printing - Standard',
        description: null, details: null, amount: 0, hideOnRYO: null, hideEditLink: null, showZeroAmount: false,
        rank: 39, isShowAmountText: null, amountText: null, isSelected: null, subItems: null
      },
      {
        productConfigurationId: 4384, productComponentId: 1988, type: 9, title: 'Statement of Information',
        description: null, details: null, amount: 0, hideOnRYO: null, hideEditLink: null, showZeroAmount: false,
        rank: 41, isShowAmountText: null, amountText: null, isSelected: null, subItems: null
      },
      {
        productConfigurationId: 2809, productComponentId: 1546, type: 3, title: 'Small Business Banking Consultation',
        description: null, details: null, amount: 0, hideOnRYO: null, hideEditLink: null, showZeroAmount: false, rank: 42,
        isShowAmountText: null, amountText: null, isSelected: null, subItems: null
      },
      {
        productConfigurationId: 6292,
        productComponentId: 2443, type: 3, title: 'Tax Savings Analysis by 1-800Accountant',
        description: null, details: null,
        amount: 0, hideOnRYO: null, hideEditLink: null, showZeroAmount: false, rank: 43, isShowAmountText: null,
        amountText: null, isSelected: null, subItems: null
      },
      {
        productConfigurationId: 6296, productComponentId: 2447,
        type: 3, title: 'ClientBooks Free Trial', description: null, details: null,
        amount: 0, hideOnRYO: null,
        hideEditLink: null, showZeroAmount: false, rank: 44, isShowAmountText: null, amountText: null, isSelected: null,
        subItems: null
      }], installmentAmount: 174.67, storeCredit: 0, promoCode: null, isThreePay: false
  };
  let mockModalService: any = {
    open() {
      return null;
    }
  };

  let mockCookieService = {};

  const mockModalRef = {
    componentInstance: {},
    result: Promise.resolve({})
  };

  @Component({
    selector: 'app-cart-items',
    template: '<div></div>'
  })
  class LZFakeCartItemsComponent {
    @Input() cart = mockUserCartService.userCart;
  }

  beforeEach(async(() => {
    mockPrepareCartService = jasmine.createSpyObj(['prepareSaveAndGetMappedUserAnswers', 'prepareUpdateQuestionnaireStorage',
      'prepareUpdateCartByQuestionnaire', 'prepareGetCartBalanceByCartId', 'saveAndRefreshCart', 'savePackageAndGetCart',
      'applyPromoCode', 'AddProfessionalPrint', 'RemoveProfessionalPrint', 'prepareGetCartModelFromApiData', 'prepareUpdateLoadingStatus', 'getCartWithUpdatedPackage', 'removePromoCode']);

    mockEventService = jasmine.createSpyObj(['updateLoadingStatusEvent']);
    mockEventService.updateLoadingStatusEvent = new Subject();
    mockUserCartService.userCartChange = new Subject();
    TestBed.configureTestingModule({
      imports: [MatTooltipModule, RouterTestingModule.withRoutes([]), HttpClientTestingModule,
        NgbModule, FormsModule,
      ],
      declarations: [
        ReviewYourOrderComponent,
        // LZFakeCartItemsComponent,
        SpinnerComponent,
        MockComponent(CartItemsComponent),
        MockComponent(GloSpinnerComponent)
      ],
      providers: [
        { provide: QuestionnaireRoutingService, useValue: mockQuestionnaireRoutingService },
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: PrepareCartService, useValue: mockPrepareCartService },
        { provide: TrackingService, useValue: mockTrackingService },
        { provide: UserCartService, useValue: mockUserCartService },
        { provide: NgbModal, useValue: mockModalService },
        { provide: EventService, useValue: mockEventService },
        { provide: TippyService, useValue: mockTippyService },
        { provide: CookieService, useValue: mockCookieService }
      ]
    })
      .compileComponents();

    mockModalService = TestBed.get(NgbModal);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReviewYourOrderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.isLoading = false;
  });

  it('should create', () => {
    // Assert
    expect(component).toBeTruthy();
  });

  it('should set isLoading to be true', () => {
    // Act
    component.showBusy(true);
    // Assert
    expect(component.isLoading).toBeTruthy();
    // Clean up
    component.isLoading = false;
  });
  it('should set isLoading to be false', () => {
    // Act
    component.showBusy(false);
    // Assert
    expect(component.isLoading).toBeFalsy();
  });

  it('should open handleCompanyDetailsModalResponse model for Custom_Company', async(() => {
    // Arrange
    const mockRef = {
      componentInstance: {
        modalDataset: {
          entityName: 'test',
          hireEmployees: true,
          businessPurpose: ''
        }
      },
      result: Promise.resolve({ selectedPackageConfigId: ProductConfigurationIds.custom_Company })
    };
    mockPrepareCartService.saveAndRefreshCart.and.returnValue();
    spyOn(mockModalService, 'open').and.returnValue(mockRef);
    // Act
    component.receiveConfigurationId(ProductConfigurationIds.custom_Company);
    // Assert
    mockRef.result.then(() => {
      expect(mockPrepareCartService.saveAndRefreshCart).toHaveBeenCalled();
    });
  }));

  it('should open handlePackageSelectionModalResponse model for EconomyPackage', async(() => {
    // Arrange
    mockPrepareCartService.savePackageAndGetCart.and.returnValue();
    mockModalRef.result = Promise.resolve(ProductConfigurationIds.economyLLCPackage);
    spyOn(mockModalService, 'open').and.returnValue(mockModalRef);
    // Act
    component.receiveConfigurationId(ProductConfigurationIds.economyLLCPackage);
    // Assert
    mockModalRef.result.then((result) => {
      expect(mockPrepareCartService.savePackageAndGetCart).toHaveBeenCalled();
      expect(result).toBe(ProductConfigurationIds.economyLLCPackage);
    });
  }));
  it('should open handlePackageSelectionModalResponse model for StandardPackage', async(() => {
    // Arrange
    mockPrepareCartService.savePackageAndGetCart.and.returnValue();
    mockModalRef.result = Promise.resolve(ProductConfigurationIds.standarLLCPackage);
    spyOn(mockModalService, 'open').and.returnValue(mockModalRef);
    // Act
    component.receiveConfigurationId(ProductConfigurationIds.standarLLCPackage);
    // Assert
    mockModalRef.result.then((result) => {
      expect(mockPrepareCartService.savePackageAndGetCart).toHaveBeenCalled();
      expect(result).toBe(ProductConfigurationIds.standarLLCPackage);
    });
  }));
  it('should open handlePackageSelectionModalResponse model for GoldPackage', async(() => {
    // Arrange
    mockPrepareCartService.savePackageAndGetCart.and.returnValue();
    mockModalRef.result = Promise.resolve(ProductConfigurationIds.expressGoldLLCPackage);
    spyOn(mockModalService, 'open').and.returnValue(mockModalRef);
    // Act
    component.receiveConfigurationId(ProductConfigurationIds.expressGoldLLCPackage);
    // Assert
    mockModalRef.result.then((result) => {
      expect(mockPrepareCartService.savePackageAndGetCart).toHaveBeenCalled();
      expect(result).toBe(ProductConfigurationIds.expressGoldLLCPackage);
    });
  }));

  it('should open handleRAModalResponse model for ProductConfigurationIds registeredAgent', async(() => {
    // Arrange
    mockPrepareCartService.saveAndRefreshCart.and.returnValue();
    mockModalRef.result = Promise.resolve(false);
    spyOn(mockModalService, 'open').and.returnValue(mockModalRef);
    // Act
    component.receiveConfigurationId(ProductConfigurationIds.registeredAgent);
    // Assert
    mockModalRef.result.then((result) => {
      expect(mockPrepareCartService.saveAndRefreshCart).toHaveBeenCalled();
      mockQuestionnaireService = TestBed.get(QuestionnaireService);
      expect(mockQuestionnaireService.llc.lzRA).toBe('No');
      expect(result).toBe(false);
    });
  }));
  it('should open handleRAModalResponse model for ProductConfigurationIds registeredAgent_199', async(() => {
    // Arrange
    mockQuestionnaireService = TestBed.get(QuestionnaireService);
    mockQuestionnaireService.llc.lzRA = 'No';
    mockPrepareCartService.saveAndRefreshCart.and.returnValue();
    mockModalRef.result = Promise.resolve(true);
    spyOn(mockModalService, 'open').and.returnValue(mockModalRef);
    // Act
    component.receiveConfigurationId(ProductConfigurationIds.registeredAgent_199);
    // Assert
    mockModalRef.result.then((result) => {
      expect(mockPrepareCartService.saveAndRefreshCart).toHaveBeenCalled();
      mockQuestionnaireService = TestBed.get(QuestionnaireService);
      expect(mockQuestionnaireService.llc.lzRA).toBe('Yes');
    });
  }));
  it('should open handleRAModalResponse model for ProductConfigurationIds registeredAgent_249', async(() => {
    // Arrange
    mockPrepareCartService.saveAndRefreshCart.and.returnValue();
    mockQuestionnaireService = TestBed.get(QuestionnaireService);
    mockQuestionnaireService.llc.lzRA = 'No';
    mockModalRef.result = Promise.resolve(true);
    spyOn(mockModalService, 'open').and.returnValue(mockModalRef);
    // Act
    component.receiveConfigurationId(ProductConfigurationIds.registeredAgent_249);
    // Assert
    mockModalRef.result.then((result) => {
      expect(mockPrepareCartService.saveAndRefreshCart).toHaveBeenCalled();
      mockQuestionnaireService = TestBed.get(QuestionnaireService);
      expect(mockQuestionnaireService.llc.lzRA).toBe('Yes');
    });
  }));
  it('should open handleRAModalResponse model for ProductConfigurationIds custom_RegisteredAgent_details', async(() => {
    // Arrange
    mockPrepareCartService.saveAndRefreshCart.and.returnValue();
    mockQuestionnaireService = TestBed.get(QuestionnaireService);
    mockQuestionnaireService.llc.lzRA = 'No';
    mockModalRef.result = Promise.resolve(true);
    spyOn(mockModalService, 'open').and.returnValue(mockModalRef);
    // Act
    component.receiveConfigurationId(ProductConfigurationIds.custom_RegisteredAgent_details);
    // Assert
    mockModalRef.result.then((result) => {
      expect(mockPrepareCartService.saveAndRefreshCart).toHaveBeenCalled();
      mockQuestionnaireService = TestBed.get(QuestionnaireService);
      expect(mockQuestionnaireService.llc.lzRA).toBe('Yes');
    });
  }));

  it('should open handleTaxAndLegalModalResponse model for ProductConfigurationIds bapMonthlyLegal', async(() => {
    // Arrange
    mockUserCartService.getAnnualLegalProductConfigurationId.and.returnValue(false);
    mockPrepareCartService.saveAndRefreshCart.and.returnValue();
    mockModalRef.result = Promise.resolve(ProductConfigurationIds.bapMonthlyLegalProtect);
    spyOn(mockModalService, 'open').and.returnValue(mockModalRef);
    // Act
    component.receiveConfigurationId(ProductConfigurationIds.bapMonthlyLegal);
    // Assert
    mockModalRef.result.then((result) => {
      expect(mockPrepareCartService.saveAndRefreshCart).toHaveBeenCalled();
      mockQuestionnaireService = TestBed.get(QuestionnaireService);
      expect(mockQuestionnaireService.llc.legalAdvice).toBe(true);
    });
  }));
  it('should open handleTaxAndLegalModalResponse model for ProductConfigurationIds bapMonthlyLegalProtect', async(() => {
    // Arrange
    mockUserCartService.getAnnualLegalProductConfigurationId.and.returnValue(false);
    mockPrepareCartService.saveAndRefreshCart.and.returnValue();
    mockModalRef.result = Promise.resolve(ProductConfigurationIds.bapMonthlyLegal);
    spyOn(mockModalService, 'open').and.returnValue(mockModalRef);
    // Act
    component.receiveConfigurationId(ProductConfigurationIds.bapMonthlyLegalProtect);
    // Assert
    mockModalRef.result.then((result) => {
      expect(mockPrepareCartService.saveAndRefreshCart).toHaveBeenCalled();
      mockQuestionnaireService = TestBed.get(QuestionnaireService);
      expect(mockQuestionnaireService.llc.legalAdvice).toBe(true);
    });
  }));
  it('should open handleTaxAndLegalModalResponse model for ProductConfigurationIds bapMonthlyLegalWisconsin', async(() => {
    // Arrange
    mockUserCartService.getAnnualLegalProductConfigurationId.and.returnValue(false);
    mockPrepareCartService.saveAndRefreshCart.and.returnValue();
    mockModalRef.result = Promise.resolve(ProductConfigurationIds.bapMonthlyLegalProtectWisconsin);
    spyOn(mockModalService, 'open').and.returnValue(mockModalRef);
    // Act
    component.receiveConfigurationId(ProductConfigurationIds.bapMonthlyLegalWisconsin);
    // Assert
    mockModalRef.result.then((result) => {
      expect(mockPrepareCartService.saveAndRefreshCart).toHaveBeenCalled();
      mockQuestionnaireService = TestBed.get(QuestionnaireService);
      expect(mockQuestionnaireService.llc.legalAdvice).toBe(true);
    });
  }));
  it('should open handleTaxAndLegalModalResponse model for ProductConfigurationIds bapMonthlyLegalProtectWisconsin', async(() => {
    // Arrange
    mockUserCartService.getAnnualLegalProductConfigurationId.and.returnValue(false);
    mockPrepareCartService.saveAndRefreshCart.and.returnValue();
    mockModalRef.result = Promise.resolve(ProductConfigurationIds.bapMonthlyLegalProtectWisconsin);
    spyOn(mockModalService, 'open').and.returnValue(mockModalRef);
    // Act
    component.receiveConfigurationId(ProductConfigurationIds.bapMonthlyLegalWisconsin);
    // Assert
    mockModalRef.result.then((result) => {
      expect(mockPrepareCartService.saveAndRefreshCart).toHaveBeenCalled();
      mockQuestionnaireService = TestBed.get(QuestionnaireService);
      expect(mockQuestionnaireService.llc.legalAdvice).toBe(true);
    });
  }));
  it('should open handleTaxAndLegalModalResponse model for ProductConfigurationIds bapAnnualTax', async(() => {
    // Arrange
    mockUserCartService.getAnnualLegalProductConfigurationId.and.returnValue(false);
    mockPrepareCartService.saveAndRefreshCart.and.returnValue();
    mockModalRef.result = Promise.resolve(ProductConfigurationIds.custom_LegalProtext_SmartEmployer);
    spyOn(mockModalService, 'open').and.returnValue(mockModalRef);
    // Act
    component.receiveConfigurationId(ProductConfigurationIds.bapAnnualTax);
    // Assert
    mockModalRef.result.then((result) => {
      expect(mockPrepareCartService.saveAndRefreshCart).toHaveBeenCalled();
      mockQuestionnaireService = TestBed.get(QuestionnaireService);
      expect(mockQuestionnaireService.llc.taxAdvice).toBe(false);
    });
  }));
  it('should open handleTaxAndLegalModalResponse model for ProductConfigurationIds custom_LegalProtext_SmartEmployer', async(() => {
    // Arrange
    mockUserCartService.getAnnualLegalProductConfigurationId.and.returnValue(false);
    mockPrepareCartService.saveAndRefreshCart.and.returnValue();
    mockModalRef.result = Promise.resolve(ProductConfigurationIds.bapAnnualTax);
    spyOn(mockModalService, 'open').and.returnValue(mockModalRef);
    // Act
    component.receiveConfigurationId(ProductConfigurationIds.custom_LegalProtext_SmartEmployer);
    // Assert
    mockModalRef.result.then((result) => {
      expect(mockPrepareCartService.saveAndRefreshCart).toHaveBeenCalled();
      mockQuestionnaireService = TestBed.get(QuestionnaireService);
      expect(mockQuestionnaireService.llc.taxAdvice).toBe(true);
    });
  }));

  it('should open handleLegalDocumentsModalResponse model for ProductConfigurationIds oAPackage', async(() => {
    // Arrange
    mockPrepareCartService.saveAndRefreshCart.and.returnValue();
    mockQuestionnaireService = TestBed.get(QuestionnaireService);
    mockQuestionnaireService.llc.documentsPackage = '';
    mockModalRef.result = Promise.resolve(ProductConfigurationIds.oAPackage);
    spyOn(mockModalService, 'open').and.returnValue(mockModalRef);
    // Act
    component.receiveConfigurationId(ProductConfigurationIds.oAPackage);
    // Assert
    mockModalRef.result.then((result) => {
      expect(mockPrepareCartService.saveAndRefreshCart).toHaveBeenCalled();
      mockQuestionnaireService = TestBed.get(QuestionnaireService);
      expect(mockQuestionnaireService.llc.documentsPackage).toBe('OA');
    });
  }));
  it('should open handleLegalDocumentsModalResponse model for ProductConfigurationIds oAEinPackage', async(() => {
    // Arrange
    mockPrepareCartService.saveAndRefreshCart.and.returnValue();
    mockQuestionnaireService = TestBed.get(QuestionnaireService);
    mockQuestionnaireService.llc.documentsPackage = '';
    mockModalRef.result = Promise.resolve(ProductConfigurationIds.oAEinPackage);
    spyOn(mockModalService, 'open').and.returnValue(mockModalRef);
    // Act
    component.receiveConfigurationId(ProductConfigurationIds.oAEinPackage);
    // Assert
    mockModalRef.result.then((result) => {
      expect(mockPrepareCartService.saveAndRefreshCart).toHaveBeenCalled();
      mockQuestionnaireService = TestBed.get(QuestionnaireService);
      expect(mockQuestionnaireService.llc.documentsPackage).toBe('OA_EIN');
    });
  }));
  it('should open handleLegalDocumentsModalResponse model for ProductConfigurationIds oAEinLicensesPackage', async(() => {
    // Arrange
    mockPrepareCartService.saveAndRefreshCart.and.returnValue();
    mockQuestionnaireService = TestBed.get(QuestionnaireService);
    mockQuestionnaireService.llc.documentsPackage = '';
    mockModalRef.result = Promise.resolve(ProductConfigurationIds.oAEinLicensesPackage);
    spyOn(mockModalService, 'open').and.returnValue(mockModalRef);
    // Act
    component.receiveConfigurationId(ProductConfigurationIds.oAEinLicensesPackage);
    // Assert
    mockModalRef.result.then((result) => {
      expect(mockPrepareCartService.saveAndRefreshCart).toHaveBeenCalled();
      mockQuestionnaireService = TestBed.get(QuestionnaireService);
      expect(mockQuestionnaireService.llc.documentsPackage).toBe('OA_EIN_LICENCES');
    });
  }));
  it('should open handleLegalDocumentsModalResponse model for ProductConfigurationIds custom_OAEinBL', async(() => {
    // Arrange
    mockPrepareCartService.saveAndRefreshCart.and.returnValue();
    mockQuestionnaireService = TestBed.get(QuestionnaireService);
    mockQuestionnaireService.llc.documentsPackage = 'OA_EIN_LICENCES';
    mockModalRef.result = Promise.resolve(ProductConfigurationIds.custom_OAEinBL);
    spyOn(mockModalService, 'open').and.returnValue(mockModalRef);
    // Act
    component.receiveConfigurationId(ProductConfigurationIds.custom_OAEinBL);
    // Assert
    mockModalRef.result.then((result) => {
      expect(mockPrepareCartService.saveAndRefreshCart).toHaveBeenCalled();
      mockQuestionnaireService = TestBed.get(QuestionnaireService);
      expect(mockQuestionnaireService.llc.documentsPackage).toBe('');
    });
  }));
  it('should open handleLegalDocumentsModalResponse model for ProductConfigurationIds custom_OAEinBL_NoThanks', async(() => {
    // Arrange
    mockPrepareCartService.saveAndRefreshCart.and.returnValue();
    mockQuestionnaireService = TestBed.get(QuestionnaireService);
    mockQuestionnaireService.llc.documentsPackage = 'OA';
    mockModalRef.result = Promise.resolve(ProductConfigurationIds.custom_OAEinBL_NoThanks);
    spyOn(mockModalService, 'open').and.returnValue(mockModalRef);
    // Act
    component.receiveConfigurationId(ProductConfigurationIds.custom_OAEinBL_NoThanks);
    // Assert
    mockModalRef.result.then((result) => {
      expect(mockPrepareCartService.saveAndRefreshCart).toHaveBeenCalled();
      mockQuestionnaireService = TestBed.get(QuestionnaireService);
      expect(mockQuestionnaireService.llc.documentsPackage).toBe('');
    });
  }));

  it('should open handleComplianceModalResponse model for ProductConfigurationIds compliancePackage', async(() => {
    // Arrange
    mockPrepareCartService.saveAndRefreshCart.and.returnValue();
    mockQuestionnaireService = TestBed.get(QuestionnaireService);
    mockQuestionnaireService.llc.totalCompliance = false;
    mockModalRef.result = Promise.resolve(true);
    spyOn(mockModalService, 'open').and.returnValue(mockModalRef);
    // Act
    component.receiveConfigurationId(ProductConfigurationIds.compliancePackage);
    // Assert
    mockModalRef.result.then((result) => {
      expect(mockPrepareCartService.saveAndRefreshCart).toHaveBeenCalled();
      mockQuestionnaireService = TestBed.get(QuestionnaireService);
      expect(mockQuestionnaireService.llc.totalCompliance).toBe(true);
    });
  }));
  it('should open handleComplianceModalResponse model for ProductConfigurationIds custom_Total_Compliance', async(() => {
    // Arrange
    mockPrepareCartService.saveAndRefreshCart.and.returnValue();
    mockQuestionnaireService = TestBed.get(QuestionnaireService);
    mockQuestionnaireService.llc.totalCompliance = true;
    mockModalRef.result = Promise.resolve(false);
    spyOn(mockModalService, 'open').and.returnValue(mockModalRef);
    // Act
    component.receiveConfigurationId(ProductConfigurationIds.custom_Total_Compliance);
    // Assert
    mockModalRef.result.then((result) => {
      expect(mockPrepareCartService.saveAndRefreshCart).toHaveBeenCalled();
      mockQuestionnaireService = TestBed.get(QuestionnaireService);
      expect(mockQuestionnaireService.llc.totalCompliance).toBe(false);
    });
  }));

  it('should open handleBppSelection model for ProductConfigurationIds economyLLCShipping ', async(() => {
    // Arrange
    mockPrepareCartService.AddProfessionalPrint.and.returnValue();
    mockQuestionnaireService = TestBed.get(QuestionnaireService);
    mockQuestionnaireService.llc.professionalPrintSelected = true;
    spyOn(mockModalService, 'open').and.returnValue(mockModalRef);
    // Act
    component.receiveConfigurationId(ProductConfigurationIds.economyLLCShipping);
    // Assert
    mockModalRef.result.then((result) => {
      expect(mockPrepareCartService.AddProfessionalPrint).toHaveBeenCalled();
      mockQuestionnaireService = TestBed.get(QuestionnaireService);
      expect(mockQuestionnaireService.llc.professionalPrintSelected).toBe(true);
    });
  }));
  it('should open handleBppSelection model for ProductConfigurationIds LLCTier1StandardShipping', async(() => {
    // Arrange
    mockPrepareCartService.RemoveProfessionalPrint.and.returnValue();
    mockQuestionnaireService = TestBed.get(QuestionnaireService);
    mockQuestionnaireService.llc.professionalPrintSelected = false;
    mockModalRef.result = Promise.resolve(false);
    spyOn(mockModalService, 'open').and.returnValue(mockModalRef);
    // Act
    component.receiveConfigurationId(ProductConfigurationIds.LLCTier1StandardShipping);
    // Assert
    mockModalRef.result.then((result) => {
      expect(mockPrepareCartService.RemoveProfessionalPrint).toHaveBeenCalled();
      mockQuestionnaireService = TestBed.get(QuestionnaireService);
      expect(mockQuestionnaireService.llc.professionalPrintSelected).toBe(false);
    });
  }));

  it('should call applyPromoCode on applyPromoCode', () => {
    // Act
    component.applyPromoCode('test');
    // Assert
    expect(mockPrepareCartService.applyPromoCode).toHaveBeenCalled();
  });

  it('should call removePromoCode on removePromoCode', () => {
    // Act
    component.removePromoCode();
    // Assert
    expect(mockPrepareCartService.removePromoCode).toHaveBeenCalled();
  });
});
