import { SEAD } from '../../../../../shared/services/constants.service';
import { Subject } from 'rxjs';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { MatTooltipModule } from '@angular/material';
import { QuestionnaireService } from '../../../../../shared/services/questionnaire/questionnaire.service';
import { TrackingService } from '../../../../../shared/services/tracking/tracking.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CartItemsComponent } from './cart-items.component';
import { TippyService } from 'ng-tippy';
import { IUserCart } from '@legalzoom/business-formation-sdk';
import { PrepareCartService } from '../../../../../shared/services/prepare-cart.service';

describe('CartItemsComponent', () => {
  let component: CartItemsComponent;
  let fixture: ComponentFixture<CartItemsComponent>;
  const mockTrackingService: TrackingService = undefined;
  const mockQuestionnaireService = {
    llc: {
      entityState: 'California',
      entityName: 'test',
      professionalPrintSelected: true
    }
  };
  const mockCart: IUserCart = {
    cartId: 22233965, packageTitle: '', dueNow: 518,
    discount: 0, cartItems: [
      // tslint:disable-next-line:max-line-length
      { productConfigurationId: 0, productComponentId: 0, type: 0, title: 'Company details', description: null, details: null, amount: 0, hideOnRYO: null, hideEditLink: null, showZeroAmount: true, rank: 0, subItems: null },
      // tslint:disable-next-line:max-line-length
      { productConfigurationId: -1, productComponentId: -1, type: 0, title: 'asdfasdf', description: null, details: null, amount: 0, hideOnRYO: null, hideEditLink: null, showZeroAmount: true, rank: 0, subItems: null },
      // tslint:disable-next-line:max-line-length
      { productConfigurationId: 5793, productComponentId: 2311, type: 9, title: 'Storage Subscription', description: null, details: null, amount: 0, hideOnRYO: null, hideEditLink: null, showZeroAmount: false, rank: 0, subItems: null },
      // tslint:disable-next-line:max-line-length
      { productConfigurationId: 146, productComponentId: 112, type: 2, title: 'Standard LLC', description: null, details: null, amount: 329, hideOnRYO: null, hideEditLink: null, showZeroAmount: false, rank: 2, subItems: null },
      // tslint:disable-next-line:max-line-length
      { productConfigurationId: 804, productComponentId: 322, type: 8, title: 'California filing fee(This is the admin fee charged by the state)', description: null, details: null, amount: 70, hideOnRYO: null, hideEditLink: null, showZeroAmount: false, rank: 6, subItems: null },
      // tslint:disable-next-line:max-line-length
      { productConfigurationId: 5893, productComponentId: 132, type: 3, title: 'Operating Agreement', description: null, details: null, amount: 99, hideOnRYO: null, hideEditLink: null, showZeroAmount: false, rank: 14, subItems: null },
      // tslint:disable-next-line:max-line-length
      { productConfigurationId: -2, productComponentId: -6, type: 0, title: 'Operating Agreement', description: null, details: null, amount: 99, hideOnRYO: null, hideEditLink: null, showZeroAmount: false, rank: 15, subItems: null },
      {
        productConfigurationId: 6286, productComponentId: 2429, type: 9, title: 'LegalZoom Registered Agent(No fees until documents sent to state)', description: null, details: {
          // tslint:disable-next-line:max-line-length
          intro: '(No fees until documents sent to state)', body: 'LegalZoom\'s Registered Agent Service only starts when your LLC is submitted to state. When we receive official notification that your LLC has been registered, your card will automatically be charged $159. The service renews automatically each year, billed to your card, for the service price (currently $159). You may cancel online or by calling us at (844) 962-7490. You will first need to appoint a new RA for your business.',
          showBody: false
        }, amount: 0, hideOnRYO: null, hideEditLink: null, showZeroAmount: false, rank: 19, subItems: null
      },
      {
        productConfigurationId: 7327, productComponentId: 2817, type: 9, title: 'Legal Protect Plan', description: null, details: {
          // tslint:disable-next-line:max-line-length
          intro: '(10 days included)', body: 'This package is offered as a trial for 10 days.After the 10 - day trial period, benefits continue automatically for the same term and rate unless otherwise notified.Cancel online or by calling(888) 310 - 0151.For full details, please see our < a href =\#\ target=\_blank\>Subscription Terms</a> and <a href=\#\ target=\_blank\>Legal Plan Contract</a>.',
          showBody: false
        }, amount: 0, hideOnRYO: null, hideEditLink: null, showZeroAmount: false, rank: 22, subItems: null
      },
      {
        productConfigurationId: 6282, productComponentId: 2438, type: 9, title: 'Total Compliance', description: null,
        details: {
          // tslint:disable-next-line:max-line-length
          intro: '(10 days included)', body: 'This package is offered for 10 days. After the 10-day period, benefits continue automatically for the same term and rate unless otherwise notified.Cancel online or by calling(888) 310 - 0151.For full details, please see our < a href =\#\ target=\_blank\>Subscription Terms</> and <a href=\#\ target=\_blank\>Legal Plan Contract</a>.',
          showBody: false
        }, amount: 0, hideOnRYO: null, hideEditLink: null, showZeroAmount: false, rank: 27,
        subItems: null
      },
      {
        productConfigurationId: 3917, productComponentId: 646, type: 8, title: 'Statement of Information Filing Fee',
        description: null, details: null, amount: 20, hideOnRYO: null, hideEditLink: null, showZeroAmount: false, rank: 29,
        subItems: null
      },
      {
        productConfigurationId: -5, productComponentId: -5, type: 0, title: 'Sales Tax', description: null, details: null, amount: 0, hideOnRYO: null, hideEditLink: null,
        showZeroAmount: false, rank: 34, subItems: null
      },
      {
        productConfigurationId: -6, productComponentId: -6, type: 0, title: 'We’ve got you covered!', description: null, details: null, amount: 0, hideOnRYO: null, hideEditLink: null, showZeroAmount: false,
        rank: 35, subItems: null
      },
      {
        productConfigurationId: 6553, productComponentId: 2493, type: 3, title: 'Digital Download',
        description: null, details: null, amount: 0, hideOnRYO: null, hideEditLink: null, showZeroAmount: false,
        rank: 36, subItems: null
      },
      {
        productConfigurationId: 6579, productComponentId: 2499, type: 3, title: 'Digital Download',
        description: null, details: null, amount: 0, hideOnRYO: null, hideEditLink: null, showZeroAmount: false,
        rank: 37, subItems: null
      },
      {
        productConfigurationId: -10, productComponentId: -10, type: 0,
        title: 'All your documents in one convenient location + <br />1 TB of free cloud storage.',
        description: null, details: null, amount: 0, hideOnRYO: null,
        hideEditLink: null, showZeroAmount: false, rank: 38,
        subItems: null
      },
      {
        productConfigurationId: 162, productComponentId: 138, type: 7, title: 'Professional Printing - Standard',
        description: null, details: null, amount: 0, hideOnRYO: null, hideEditLink: null, showZeroAmount: false,
        rank: 39, subItems: null
      },
      {
        productConfigurationId: 4384, productComponentId: 1988, type: 9, title: 'Statement of Information',
        description: null, details: null, amount: 0, hideOnRYO: null, hideEditLink: null, showZeroAmount: false,
        rank: 41, subItems: null
      },
      {
        productConfigurationId: 2809, productComponentId: 1546, type: 3, title: 'Small Business Banking Consultation',
        description: null, details: null, amount: 0, hideOnRYO: null, hideEditLink: null, showZeroAmount: false, rank: 42,
        subItems: null
      }
    ], installmentAmount: 174.67, storeCredit: 0, promoCode: null, isThreePay: false
  };
  let mockPrepareCartService;
  beforeEach(async(() => {
    mockPrepareCartService = jasmine.createSpyObj(['promoCodeApplyErrorEvent']);
    mockPrepareCartService.promoCodeApplyErrorEvent = new Subject();

    TestBed.configureTestingModule({
      imports: [MatTooltipModule, ReactiveFormsModule],
      declarations: [CartItemsComponent],
      providers: [
        FormBuilder,
        { provide: TrackingService, useValue: mockTrackingService },
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        TippyService,
        { provide: PrepareCartService, useValue: mockPrepareCartService }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CartItemsComponent);
    component = fixture.componentInstance;
    component.cart = mockCart;
    component.entityName = 'Test';
    component.entityState = 'California';
    component.productConfigIDsToHide = [];
    component.productConfigIDsWithModalInfo = [];
    component.stateFilingSubItemPkgIds = [];
    component.hideSubscriptionAmountIds = [];
    component.showPromoCode = true;
    fixture.detectChanges();
  });

  it('should create cart-item component', () => {
    expect(component).toBeTruthy();
  });

  it('should push configuration id in cartItemDetailsShow on pushCartItemDetailsShow', () => {
    const previousSize = component.cartItemDetailsShow.length;
    component.pushCartItemDetailsShow(123);
    expect(component.cartItemDetailsShow.length).toBeGreaterThan(previousSize);
  });
  it('should pop configuration id in cartItemDetailsShow on popCartItemDetailsShow', () => {
    const previousSize = component.cartItemDetailsShow.length;
    component.pushCartItemDetailsShow(123);
    component.popCartItemDetailsShow(123);
    expect(component.cartItemDetailsShow.length).toBe(previousSize);
  });
  it('should show promocode on showPromoCodeBox', () => {
    component.showPromoCode = false;
    component.showPromoCodeBox();
    expect(component.showPromoCode).toBe(true);
  });
  it('should applyDiscount', () => {
    component.form.get('discountCode').setValue('test');
    spyOn(component.applyPromoCode, 'emit');
    component.applyDiscount();
    expect(component.applyPromoCode.emit).toHaveBeenCalled();
  });
  it('should removeDiscount', () => {
    spyOn(component.removePromoCode, 'emit');
    component.removeDiscount();
    expect(component.removePromoCode.emit).toHaveBeenCalled();
  });
  it('should selectCartItem', () => {
    spyOn(component.selectedConfigurationId, 'emit');
    component.selectCartItem(123);
    expect(component.selectedConfigurationId.emit).toHaveBeenCalledWith(123);
  });
  it('should getSeadValue for productConfigurationId 2400', () => {
    const result = component.getSeadValue(2400);
    expect(result).toBe(SEAD.PACKAGE_NAME);
  });
  it('should return null from getSeadValue for productConfigurationId 123', () => {
    const result = component.getSeadValue(123);
    expect(result).toBeNull();
  });
  it('should return false if config id not isFollowedBySubItem', () => {
    const result = component.isFollowedBySubItem(123);
    expect(result).toBe(false);
  });
  it('should return true if config id isFollowedBySubItem', () => {
    component.stateFilingSubItemPkgIds.push(-1);
    const result = component.isFollowedBySubItem(0);
    expect(result).toBe(true);
  });
});
