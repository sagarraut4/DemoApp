import { PrepareCartService } from '../../../../../shared/services/prepare-cart.service';
import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnDestroy, Output, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Subject } from 'rxjs';
import { ProductConfigurationIds } from '../../../../../shared/models/cart-model';
import { SEAD } from '../../../../../shared/services/constants.service';
import { QuestionnaireService } from '../../../../../shared/services/questionnaire/questionnaire.service';
import { TrackingService } from '../../../../../shared/services/tracking/tracking.service';
import { TippyService } from 'ng-tippy';
import { DOCUMENT } from '@angular/common';
import { IUserCart } from '@legalzoom/cart-sdk';

@Component({
  selector: 'app-cart-items',
  templateUrl: './cart-items.component.html',
  styleUrls: ['./cart-items.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class CartItemsComponent implements OnDestroy, OnInit {
  // tracking data attribute
  SEAD: any = SEAD;
  form: FormGroup;
  submitted: boolean;
  discountMessage = '';
  public showTerms = false;

  ppToolTipLabel = 'Convenient and durable folder that contains your printed formation paperwork, such as articles of organization, step-by-step checklist, and more.';

  private unsubscribe: Subject<void> = new Subject();

  public showPromoCode = false;
  public errorClass = false;

  public cartItemDetailsShow: number[] = [];
  public economyLLCShipping: number;

  public custom_Company = ProductConfigurationIds.custom_Company;
  // tslint:disable-next-line: variable-name
  public total_compliance = ProductConfigurationIds.essentialComplianceTaxPreparationPackage;

  public editPositionForPackageMobile: number[] = [
    ProductConfigurationIds.standarLLCPackage,
    ProductConfigurationIds.expressGoldLLCPackage,
  ];

  public subProductConfigurationIdList: number[] = [
    ProductConfigurationIds.custom_EntityName,
    ProductConfigurationIds.standardLLCStateFilingFee,
    ProductConfigurationIds.economyLLCShipping,
    ProductConfigurationIds.goldExpressLLCStateFilingFee,
    ProductConfigurationIds.statementOfInformationFilingFee
  ];

  public parentIdBySubProductConfigurationId  = {
    [ProductConfigurationIds.custom_EntityName]: ProductConfigurationIds.custom_Company,
    [ProductConfigurationIds.standardLLCStateFilingFee]: ProductConfigurationIds.standarLLCPackage,
    [ProductConfigurationIds.economyLLCShipping]: ProductConfigurationIds.economyLLCPackage,
    [ProductConfigurationIds.goldExpressLLCStateFilingFee]: ProductConfigurationIds.expressGoldLLCPackage,
    [ProductConfigurationIds.statementOfInformationFilingFee]: ProductConfigurationIds.compliancePackage
  };

  public economyLLCPackage = ProductConfigurationIds.economyLLCPackage;


  @Input()
  cart: IUserCart;

  @Input()
  entityName: string;

  @Input()
  entityState: string;

  @Input()
  productConfigIDsToHide: number[];

  @Input()
  productConfigIDsWithModalInfo: number[];

  @Input() stateFilingSubItemPkgIds: number[];

  @Input() hideSubscriptionAmountIds: number[];

  @Output() selectedConfigurationId: EventEmitter<number> = new EventEmitter<number>();

  @Output()
  applyPromoCode: EventEmitter<string> = new EventEmitter<string>();

  @Output()
  removePromoCode: EventEmitter<string> = new EventEmitter<string>();

  constructor(
    private formBuilder: FormBuilder,
    private tracking: TrackingService,
    public questionnaireService: QuestionnaireService,
    private tippyService: TippyService,
    private prepareCartService: PrepareCartService,
    @Inject(DOCUMENT) private document: any
  ) {
    this.submitted = false;
    this.economyLLCShipping = ProductConfigurationIds.economyLLCShipping;
  }

  ngOnInit() {
    this.form = this.formBuilder.group({
      discountCode: new FormControl()
    });

    this.prepareCartService.promoCodeApplyErrorEvent.subscribe(data => {
      if (data) {
        this.form.controls.discountCode.setErrors({ error: true });
      } else {
        this.tracking.SetDiscountCode(this.form.get('discountCode').value);
      }
    });
  }

  onClickOrderItem(productConfigurationId: number) {
    const finalId = this.parentIdBySubProductConfigurationId[productConfigurationId] !== undefined
      ? this.parentIdBySubProductConfigurationId[productConfigurationId]
      : productConfigurationId;

    if (this.productConfigIDsWithModalInfo.includes(finalId)) {
      this.selectCartItem(finalId);
    }
  }

  pushCartItemDetailsShow(configId) {
    this.cartItemDetailsShow.push(configId);
  }

  popCartItemDetailsShow(configId) {
    const index = this.cartItemDetailsShow.indexOf(configId);
    this.cartItemDetailsShow.splice(index, 1);
  }

  showPromoCodeBox() {
    this.showPromoCode = !this.showPromoCode;
  }

  applyDiscount() {
    (document.getElementById('promoForm') as HTMLFormElement).classList.add('was-validated');
    const promocode = this.form.get('discountCode').value;
    if (promocode && promocode.length > 0) {
      this.applyPromoCode.emit(this.form.get('discountCode').value);
    }
  }

  removeDiscount() {
    this.removePromoCode.emit();
  }

  selectCartItem(productConfigurationId: number) {
    this.selectedConfigurationId.emit(productConfigurationId);
  }

  selectShippingMethod(event: { target: { checked: any; }; }) {
    if (event.target.checked) {
      this.questionnaireService.llc.professionalPrintSelected = true;
    } else {
      this.questionnaireService.llc.professionalPrintSelected = false;
    }
    this.selectedConfigurationId.emit(this.economyLLCShipping);
  }

  getSeadValue(productConfigurationId: number): string {
    if (productConfigurationId === 2400) {
      return SEAD.PACKAGE_NAME;
    }
    return null;
  }


  isFollowedBySubItem(configId: number): boolean {
    const index = this.cart.cartItems.findIndex(c => c.productConfigurationId === configId);

    if (index + 1 < this.cart.cartItems.length) {
      return this.stateFilingSubItemPkgIds.includes(this.cart.cartItems[index + 1].productConfigurationId);
    }

    return false;
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();

    // Destroy All Tippies
    this.tippyService.getAllTippies().forEach(
      tippy => tippy.destroyAll()
    );

    // Not Proud of this but we have to FORCE remove tippy from the DOM
    const poppers = this.document.getElementsByClassName('tippy-popper');
    for (let i = 0; i < poppers.length; i += 1) {
      const item = poppers.item(i);
      item.parentElement.removeChild(item);
    }
  }

}
