import { Component, OnDestroy, OnInit, Renderer2 } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ReplaySubject, Subject, Subscription } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { RegisteredAgentModalComponent } from '../../modals/registered-agent-modal/registered-agent-modal.component';
import { CartItemType, ProductConfigurationIds, TaxAndLegalInfo } from '../../../../shared/models/cart-model';
import { PagePath } from '../../../../shared/models/page-model';
import { LLC } from '../../../../shared/models/questionnaire-model';
import { QuestionnaireRoutingService } from '../../../../shared/services/questionnaire-routing/questionnaire-routing.service';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { TrackingService } from '../../../../shared/services/tracking/tracking.service';
import { CompanyDetailsModalComponent } from '../company-details-modal/company-details-modal.component';
import { ComplianceModalComponent } from '../compliance-modal/compliance-modal.component';
import { LegalDocumentsModalComponent } from '../legal-documents-modal/legal-documents-modal.component';
import { LlcPackageModalComponent } from '../llc-package-modal/llc-package-modal.component';
import { TaxAndLegalPackageModalComponent } from '../tax-and-legal-package-modal/tax-and-legal-package-modal.component';
import { IUserCart } from '@legalzoom/cart-sdk';
import { QueueService } from '@legalzoom/business-formation-sdk';
import { BannerService } from '../../shared/services/banner.service';
import { BreakpointObserver } from '@angular/cdk/layout';
import { ExperimentsService } from '../../../../shared/services/experiments/experiments.service';
import { PrepareCartService } from '../../../../shared/services/prepare-cart.service';
import { EventService } from '../../../../shared/services/event.service';
import { UserCartService } from '../../shared/services/user-cart.service';
import { TaxPackages } from '../../../../shared/models/tax-packages-model';
import { TaxPackageModalComponent } from '../tax-package-modal/tax-package-modal.component';

@Component({
  selector: 'app-review-your-order',
  templateUrl: './review-your-order.component.html',
  styleUrls: ['./review-your-order.component.scss']
})

export class ReviewYourOrderComponent implements OnInit, OnDestroy {
  private unsubscribe: Subject<void> = new Subject();
  installmentAmount = 0;
  productConfigurationId = 0;
  entityName: string;
  userCart: IUserCart;
  isLoading: boolean;
  serverSideError = '';
  economyPackageShippingFee = 19.00;
  isEconomyPackage = false;
  hasProfPrintShipping = false;
  taxPackageLineItem = '';
  taxPackageLineItemAmount = '';
  showTaxPackageDisclaimer = false;
  taxPackageDisclaimerText = '';

  productConfigIDsToHide: number[] = [
    ProductConfigurationIds.standardLLCShipping,
    ProductConfigurationIds.expressGoldLLCShipping,
    ProductConfigurationIds.statementOfInformation,
    ProductConfigurationIds.smallBusinessBankingConsultation,
    ProductConfigurationIds.squarePartnerOffer,
    ProductConfigurationIds.brexPartnerOffer,
    ProductConfigurationIds.toastPartnerOffer,
    ProductConfigurationIds.taxSavingAnalysisOffer,
    ProductConfigurationIds.taxSavingAnalysisOffer2,
    ProductConfigurationIds.clientBooksOffer,
    ProductConfigurationIds.priorityRushService,
    ProductConfigurationIds.customLogoDesign,
    ProductConfigurationIds.smartBusinessPlanCreator,
    ProductConfigurationIds.LLCTier2DeliveryStandard,
    ProductConfigurationIds.LLCTier2ExpediteShipping,
    ProductConfigurationIds.LLCTier3DeliveryStandard,
    ProductConfigurationIds.LLCTier3ExpediteShipping,
    ProductConfigurationIds.bapAnnualTax,
    ProductConfigurationIds.oAPackage,
    ProductConfigurationIds.oAEinPackage,
    ProductConfigurationIds.oAEinLicensesPackage,
    ProductConfigurationIds.oAEinPackage1,
    ProductConfigurationIds.oAEinPackage2,
    ProductConfigurationIds.oAEinLicensesPackage1,
    ProductConfigurationIds.storageSubscription
    // ProductConfigurationIds.sellersPermit
  ];

  productConfigIDsWithModalInfo: number[] = [
    ProductConfigurationIds.custom_Company,
    ProductConfigurationIds.economyLLCPackage,
    ProductConfigurationIds.standarLLCPackage,
    ProductConfigurationIds.expressGoldLLCPackage,
    ProductConfigurationIds.tier1LLCPackage,
    ProductConfigurationIds.tier2LLCPackage,
    ProductConfigurationIds.tier3LLCPackage,
    ProductConfigurationIds.essentialComplianceTaxPreparationPackage,
    ProductConfigurationIds.registeredAgent,
    ProductConfigurationIds.registeredAgent_199,
    ProductConfigurationIds.registeredAgent_249,
    ProductConfigurationIds.custom_OAEinBL,
    ProductConfigurationIds.custom_OAEinBL_NoThanks,
    ProductConfigurationIds.bapMonthlyLegal,
    ProductConfigurationIds.bapMonthlyLegalProtect,
    ProductConfigurationIds.bapMonthlyLegalWisconsin,
    ProductConfigurationIds.bapMonthlyLegalProtectWisconsin,
    ProductConfigurationIds.bapAnnualTax,
    ProductConfigurationIds.processingStandard,
    ProductConfigurationIds.processingExpedited,
    ProductConfigurationIds.custom_RegisteredAgent_details,
    ProductConfigurationIds.custom_Total_Compliance,
    ProductConfigurationIds.custom_LegalProtext_SmartEmployer,
    ProductConfigurationIds.custom_LegalProtext_SmartEmployer_WI,
    ProductConfigurationIds.custom_Tax_Package,
    ProductConfigurationIds.tax_Prep_Essentials_Plan,
    ProductConfigurationIds.accounting_Full_Service_Tax_Plan,  
  ];

  stateFilingSubItemPkgIds: number[] = [
    ProductConfigurationIds.economyLLCStateFilingFee,
    ProductConfigurationIds.standardLLCStateFilingFee,
    ProductConfigurationIds.goldExpressLLCStateFilingFee,
    ProductConfigurationIds.statementOfInformationFilingFee,
    ProductConfigurationIds.economyLLCShipping,
    ProductConfigurationIds.LLCTier1StandardShipping,
    ProductConfigurationIds.standardExpediteFilingFee,
    ProductConfigurationIds.standardFilingFee,
    ProductConfigurationIds.expediteFilingFee,
    ProductConfigurationIds.processingStandard_details,
    ProductConfigurationIds.processingExpedited_details,
    ProductConfigurationIds.salesTax_details,
    ProductConfigurationIds.digitalDownload2_details,
    ProductConfigurationIds.custom_EntityName,
    ProductConfigurationIds.salesTax_details
  ];

  hideSubscriptionAmountIds: number[] = [
    ProductConfigurationIds.salesTax_details,
    ProductConfigurationIds.digitalDownload2_details,
    ProductConfigurationIds.processingStandard_details,
    ProductConfigurationIds.processingExpedited_details,
    ProductConfigurationIds.bapMonthlyLegal,
    ProductConfigurationIds.bapMonthlyLegalProtect,
    ProductConfigurationIds.bapMonthlyLegalProtectWisconsin,
    ProductConfigurationIds.bapMonthlyLegalWisconsin,
    ProductConfigurationIds.bapAnnualTax,
    ProductConfigurationIds.compliancePackage,
    ProductConfigurationIds.registeredAgent,
    ProductConfigurationIds.registeredAgent_199,
    ProductConfigurationIds.registeredAgent_249
  ];

  // For google analytics
  private trackingWindow = this.trackingService.winRef.nativeWindow;
  public isMobile: boolean;
  private bannerHeightSubject: ReplaySubject<number>;
  private bannerHeightSubscription: Subscription;
  private cookieBannerHeight = 0;
  constructor(
    private router: Router,
    private questionnaireRoutingService: QuestionnaireRoutingService,
    public questionnaireService: QuestionnaireService,
    private queueService: QueueService,
    private modalService: NgbModal,
    private trackingService: TrackingService,
    private userCartService: UserCartService,
    private prepareCartService: PrepareCartService,
    private eventService: EventService,
    private bannerService: BannerService,
    private renderer: Renderer2,
    private breakpointObserver: BreakpointObserver,
    public experimentService: ExperimentsService,
  ) {
    this.userCart = this.userCartService.userCart;
    this.userCartService.userCartChange.subscribe(value => {
      this.userCart = value;
      this.installmentAmount = this.userCart.installmentAmount;
      this.trackingService.ClearOAItems();
      this.trackingService.MapToOAItems(this.userCart);
      this.updateTaxLineUp();
      this.showBusy(false);
    });
    const size = '(min-width: 769px)';
    breakpointObserver.observe([size]).subscribe((result) => (this.isMobile = !result.matches));
  }

  showBusy(show: boolean) {
    this.isLoading = show;
  }

  ngOnInit() {
    this.entityName = this.questionnaireService.llc.entityName;
    this.updateLoadingStatus();
    if (this.userCart) {
      this.installmentAmount = this.userCart.installmentAmount;
      this.updateTrackingService();
      this.updateTaxLineUp();
    } else {
      this.experimentService.GetTsaTestValue();
      this.showBusy(true);
      const that = this;
      this.prepareCartService.getCartWithUpdatedPackage().subscribe({
        next() {
          that.installmentAmount = that.userCart.installmentAmount;
          that.updateTrackingService();
          that.updateTaxLineUp();
        }
      });
    }
    this.showBusy(false); 
  }

  updateLoadingStatus() {
    this.eventService.updateLoadingStatusEvent
      .pipe(takeUntil(this.unsubscribe))
      .subscribe((isLoading: boolean) => {
        this.isLoading = isLoading;
      });
  }

  continueToCheckout() {
    const nextPage = this.questionnaireRoutingService.getNextPage(PagePath.ReviewYourOrder);
    this.queueService.add(this.questionnaireService.prepareUpdateQuestionnaireStorage({ currentView: nextPage }));
    this.queueService.process().subscribe(() => this.router.navigate([`./${nextPage}`]));
  }

  // openModalHelper(component) {
  //   this.modalService.open(component, { size: 'lg', windowClass: 'modal--review' });
  // }

  private updateTrackingService() {
    this.trackingService.ClearOAItems();
    this.trackingService.MapToOAItems(this.userCart);
    this.trackingService.sendAdConversion(PagePath.ReviewYourOrder);
  }

  private updateTaxLineUp() {
    const taxPackage = TaxPackages.find(tp => tp.productConfigurationId === this.questionnaireService.llc.taxPackageSelected);
    if (taxPackage) {
      this.taxPackageLineItem = 'Plus,1st month of ' + taxPackage.title + '**';
      if (taxPackage.subscriptionTerm === 'monthly') {
        this.taxPackageDisclaimerText = '**Billed separately.';
      } else if (taxPackage.subscriptionTerm) {
        this.taxPackageDisclaimerText = '**Annual plan, paid monthly. Billed separately.';
      }

      this.taxPackageLineItemAmount = '$' + taxPackage.amount;
    }
    else {
      this.taxPackageLineItem = '';
      this.taxPackageLineItemAmount = '';
    }
    this.showTaxPackageDisclaimer = this.questionnaireService.llc.taxPackageSelected && this.questionnaireService.llc.taxPackageSelected > 0;
  }

  private handleCompanyDetailsModalResponse() {
    this.trackingService.triggerClickTrack('llc_flow', 'edit_company_details');
    const modalRef = this.modalService.open(CompanyDetailsModalComponent, { size: 'lg', windowClass: 'modal-ryo-review', centered: true, scrollable: true });
    modalRef.componentInstance.modalDataset.entityName = this.questionnaireService.llc.entityName;
    modalRef.componentInstance.modalDataset.hireEmployees = this.questionnaireService.llc.hireEmployees;
    modalRef.componentInstance.modalDataset.businessPurpose = this.questionnaireService.llc.businessPurpose;
    this.getModalElementAndSetPosition();

    modalRef.result.then(
      (result: LLC) => {
        if (result) {
          this.showBusy(true);
          this.questionnaireService.llc.entityName = this.entityName = result.entityName;
          this.questionnaireService.llc.hireEmployees = result.hireEmployees;
          this.questionnaireService.llc.businessPurpose = result.businessPurpose;
          this.prepareCartService.saveAndRefreshCart();
        }
      }, () => {
        this.showBusy(false);
      }
    );
  }

  private handlePackageSelectionModalResponse() {
    this.trackingService.triggerClickTrack('llc_flow', 'edit_formation_package');
    const modalRef = this.modalService.open(LlcPackageModalComponent, { size: 'lg', windowClass: 'modal-ryo-review', centered: true, scrollable: true });
    modalRef.componentInstance.selectedPackageId = this.getRootPackageConfigurationId();
    this.getModalElementAndSetPosition();

    modalRef.result.then(
      (selectedPkg: number) => {
        if (selectedPkg && selectedPkg > 0) {
          this.showBusy(true);
          this.questionnaireService.llc.packageSelected = selectedPkg;
          this.questionnaireService.llc.professionalPrintSelected = false;
          // added to fix package switching for Q2R2 test
          // TODO Check if these packages is in use
          switch (selectedPkg) {
            case ProductConfigurationIds.tier1LLCPackage:
              this.questionnaireService.llc.legalAdvice = false;
              break;
            case ProductConfigurationIds.tier2LLCPackage:
              this.questionnaireService.llc.legalAdvice = true;
              break;
            case ProductConfigurationIds.tier3LLCPackage:
              this.questionnaireService.llc.legalAdvice = true;
              break;
            default:
              break;
          }
          this.prepareCartService.savePackageAndGetCart(selectedPkg);
        }
      }, () => { }
    );
  }

  private handleBppSelection(): any {
    this.showBusy(true);
    if (this.questionnaireService.llc.professionalPrintSelected) {
      this.prepareCartService.AddProfessionalPrint();
    } else {
      this.prepareCartService.RemoveProfessionalPrint();
    }
  }

  private setTaxAndLegalInfo(pkgId: number) {
    const taxAndLegalInfo: TaxAndLegalInfo = { productConfigurationId: 0, subTitle: '', description: '', title: '' };
    switch (pkgId) {
      case ProductConfigurationIds.bapMonthlyLegal:
        taxAndLegalInfo.productConfigurationId = ProductConfigurationIds.bapMonthlyLegal;
        taxAndLegalInfo.title = 'Legal Protect Plan';
        taxAndLegalInfo.subTitle = '$39.99';
        taxAndLegalInfo.description = '/month';
        taxAndLegalInfo.modalText = 'Access to our library of customizable HR policies and employment agreements';
        break;
        case ProductConfigurationIds.bapMonthlyLegalProtect:
        taxAndLegalInfo.productConfigurationId = ProductConfigurationIds.bapMonthlyLegalProtect;
        taxAndLegalInfo.title = 'Legal Protect Plan';
        taxAndLegalInfo.subTitle = '$49';
        taxAndLegalInfo.description = '/month';
        taxAndLegalInfo.modalText = 'Access to our library of customizable legal forms';
        break;
      case ProductConfigurationIds.custom_LegalProtext_SmartEmployer:
        taxAndLegalInfo.productConfigurationId = ProductConfigurationIds.custom_LegalProtext_SmartEmployer;
        taxAndLegalInfo.title = 'Legal Protect Plan';
        taxAndLegalInfo.subTitle = '$49';
        taxAndLegalInfo.description = '/month';
        taxAndLegalInfo.modalText = 'Access to our library of customizable legal forms';
        break;
      case ProductConfigurationIds.bapMonthlyLegalWisconsin:
        taxAndLegalInfo.productConfigurationId = ProductConfigurationIds.bapMonthlyLegalWisconsin;
        taxAndLegalInfo.title = 'Legal Protect Plan';
        taxAndLegalInfo.subTitle = '$15.99';
        taxAndLegalInfo.description = '/month';
        taxAndLegalInfo.modalText = 'Access to our library of customizable HR policies and employment agreements';
        break;
      case ProductConfigurationIds.bapMonthlyLegalProtectWisconsin:
        taxAndLegalInfo.productConfigurationId = ProductConfigurationIds.bapMonthlyLegalProtectWisconsin;
        taxAndLegalInfo.title = 'Legal Protect Plan';
        taxAndLegalInfo.subTitle = '$15.99';
        taxAndLegalInfo.description = '/month';
        taxAndLegalInfo.modalText = 'Access to our library of customizable legal forms';
        break;
      case ProductConfigurationIds.custom_LegalProtext_SmartEmployer_WI:
        taxAndLegalInfo.productConfigurationId = ProductConfigurationIds.custom_LegalProtext_SmartEmployer_WI;
        taxAndLegalInfo.title = 'Legal Protect Plan';
        taxAndLegalInfo.subTitle = '$15.99';
        taxAndLegalInfo.description = '/month';
        taxAndLegalInfo.modalText = 'Access to our library of customizable legal forms';
        break;
      case ProductConfigurationIds.bapAnnualTax:
        taxAndLegalInfo.productConfigurationId = ProductConfigurationIds.bapAnnualTax;
        taxAndLegalInfo.title = 'Affordable Tax';
        taxAndLegalInfo.subTitle = '$320';
        taxAndLegalInfo.description = '/year';
        break;
    }
    return taxAndLegalInfo;
  }

  private getAnnualTaxAndLegalPackages(entityState: string) {
    return entityState && entityState.toLowerCase() === 'wisconsin'
      ? [ProductConfigurationIds.bapAnnualTax, ProductConfigurationIds.bapMonthlyLegalWisconsin, ProductConfigurationIds.bapMonthlyLegalProtectWisconsin, ProductConfigurationIds.custom_LegalProtext_SmartEmployer_WI]
      : [ProductConfigurationIds.bapAnnualTax, ProductConfigurationIds.bapMonthlyLegal, ProductConfigurationIds.bapMonthlyLegalProtect, ProductConfigurationIds.custom_LegalProtext_SmartEmployer];
  }

  private handleTaxAndLegalModalResponse(pkgId: number) {
    this.trackingService.triggerClickTrack('llc_flow', 'edit_legal_protect');
    const willHireEmployees: boolean = !(this.questionnaireService.llc.hireEmployees === 'no');
    const taxAndLegalPkgs: number[] = this.getAnnualTaxAndLegalPackages(this.questionnaireService.llc.entityState);

    const modalRef = this.modalService.open(TaxAndLegalPackageModalComponent, { size: 'lg', windowClass: 'modal-ryo-review', centered: true, scrollable: true });
    modalRef.componentInstance.annualTaxOfferinfo = this.setTaxAndLegalInfo(ProductConfigurationIds.bapAnnualTax);
    modalRef.componentInstance.annualLegalOfferinfo = this.setTaxAndLegalInfo(this.userCart.cartItems.filter(x => taxAndLegalPkgs.includes(x.productConfigurationId))[0].productConfigurationId);
    modalRef.componentInstance.willHireEmployees = willHireEmployees;

    const pkgs = this.userCart.cartItems.filter(x => taxAndLegalPkgs.includes(x.productConfigurationId) && x.type > 0);
    const selectedPkgId = pkgs.length > 0 && pkgs.findIndex(x => x.productConfigurationId === pkgId) !== -1 ? pkgs.find(x => x.productConfigurationId === pkgId).productConfigurationId : 0;
    modalRef.componentInstance.currentPkgId = selectedPkgId === pkgId ? selectedPkgId : 0;

    modalRef.componentInstance.pkgIdToOffer = pkgId;
    this.getModalElementAndSetPosition();

    modalRef.result.then(
      (resultPkgId: number) => {

        if (resultPkgId === selectedPkgId) {
          return;
        }

        this.showBusy(true);
        switch (resultPkgId) {
          case ProductConfigurationIds.bapAnnualTax:
            this.questionnaireService.llc.taxAdvice = true;
            break;
          case ProductConfigurationIds.bapMonthlyLegal:
          case ProductConfigurationIds.bapMonthlyLegalProtect:
          case ProductConfigurationIds.bapMonthlyLegalWisconsin:
          case ProductConfigurationIds.bapMonthlyLegalProtectWisconsin:
          case ProductConfigurationIds.custom_LegalProtext_SmartEmployer:
          case ProductConfigurationIds.custom_LegalProtext_SmartEmployer_WI:
            this.questionnaireService.llc.legalAdvice = true;
            break;
          default:
            switch (pkgId) {
              case ProductConfigurationIds.bapAnnualTax:
                this.questionnaireService.llc.taxAdvice = false;
                break;
              case ProductConfigurationIds.bapMonthlyLegal:
              case ProductConfigurationIds.bapMonthlyLegalProtect:
              case ProductConfigurationIds.bapMonthlyLegalWisconsin:
              case ProductConfigurationIds.bapMonthlyLegalProtectWisconsin:
              case ProductConfigurationIds.custom_LegalProtext_SmartEmployer:
              case ProductConfigurationIds.custom_LegalProtext_SmartEmployer_WI:
                this.questionnaireService.llc.legalAdvice = false;
                break;
              default:
                this.questionnaireService.llc.legalAdvice = false;
                this.questionnaireService.llc.taxAdvice = false;
            }
            break;
        }
        this.prepareCartService.saveAndRefreshCart();
      }, () => { }
    );
  }

  private handleRAModalResponse() {
    this.trackingService.triggerClickTrack('llc_flow', 'edit_ra');
    const modalRef = this.modalService.open(RegisteredAgentModalComponent, { size: 'lg', windowClass: 'modal-ryo-review', centered: true, scrollable: true });
    modalRef.componentInstance.offerAccepted = (this.questionnaireService.llc.lzRA.toLowerCase() === 'yes');
    this.getModalElementAndSetPosition();

    modalRef.result.then(
      (result: boolean) => {
        const raResult = result ? 'Yes' : 'No';
        if (this.questionnaireService.llc.lzRA !== raResult) {
          this.questionnaireService.llc.lzRA = result ? 'Yes' : 'No';
          this.showBusy(true);
          this.prepareCartService.saveAndRefreshCart();
        }
      }, () => { }
    );
  }

  getRootPackageConfigurationId() {
    const rootPackage = this.userCart.cartItems.filter(x => x.type === CartItemType.RootPackage);
    if (rootPackage !== undefined && rootPackage.length > 0) {
      return rootPackage[0].productConfigurationId;
    } else {
      return undefined;
    }
  }

  private handleComplianceModalResponse() {
    this.trackingService.triggerClickTrack('llc_flow', 'edit_compliance');
    const modalRef = this.modalService.open(ComplianceModalComponent, { size: 'lg', windowClass: 'modal-ryo-review', centered: true, scrollable: true });
    modalRef.componentInstance.offerAccepted = this.questionnaireService.llc.totalCompliance;
    this.getModalElementAndSetPosition();
    modalRef.result.then(
      (result: boolean) => {
        if (this.questionnaireService.llc.totalCompliance !== result) { // Save only if the answer changed.
          this.questionnaireService.llc.totalCompliance = result;
          this.showBusy(true);
          this.prepareCartService.saveAndRefreshCart();
        }
      }, () => { }
    );
  }

  private handleTaxPackageModalResponse() {
    const modalRef = this.modalService.open(TaxPackageModalComponent, { size: 'lg', windowClass: 'modal-ryo-review', centered: true, scrollable: true });
    modalRef.componentInstance.selectedPackageId = this.questionnaireService.llc.taxPackageSelected;
    this.getModalElementAndSetPosition();
    modalRef.result.then(
      (result: number) => {
        if (this.questionnaireService.llc.taxPackageSelected !== result) { // Save only if the answer changed.
          this.questionnaireService.llc.taxPackageSelected = result;
          this.experimentService.GetTsaTestValue();
          this.showBusy(true);
          this.prepareCartService.saveAndRefreshCart();
        }
      }, () => { }
    );
  }

  applyPromoCode(promoCode) {
    this.showBusy(true);
    this.prepareCartService.applyPromoCode(promoCode);
  }

  removePromoCode() {
    this.showBusy(true);
    this.prepareCartService.removePromoCode();
  }

  private mapDocumentsPackageToProductConfigurationId(documentsPackage: string) {
    let packageId = 0;
    switch (documentsPackage) {
      case 'OA':
        packageId = ProductConfigurationIds.oAPackage;
        break;
      case 'OA_EIN':
        packageId = ProductConfigurationIds.oAEinPackage;
        break;
      case 'OA_EIN_LICENCES':
        packageId = ProductConfigurationIds.oAEinLicensesPackage;
        break;
      default:
        packageId = -1;
        break;
    }
    return packageId;
  }

  private mapProductConfigurationIdToDocumentsPackage(id: number) {
    let documentPackage: string;
    switch (id) {
      case ProductConfigurationIds.oAPackage:
        documentPackage = 'OA';
        break;
      case ProductConfigurationIds.oAEinPackage:
        documentPackage = 'OA_EIN';
        break;
      case ProductConfigurationIds.oAEinLicensesPackage:
        documentPackage = 'OA_EIN_LICENCES';
        break;
      default:
        documentPackage = '';
        break;
    }
    return documentPackage;
  }

  private handleLegalDocumentsModalResponse() {
    this.trackingService.triggerClickTrack('llc_flow', 'edit_essential_doc');
    const modalRef = this.modalService.open(LegalDocumentsModalComponent, { size: 'lg', windowClass: 'modal-ryo-review', centered: true, scrollable: true });
    modalRef.componentInstance.Selected_Package = this.mapDocumentsPackageToProductConfigurationId(this.questionnaireService.llc.documentsPackage);
    modalRef.componentInstance.OA_Package = ProductConfigurationIds.oAPackage;
    modalRef.componentInstance.OA_EIN_Package = ProductConfigurationIds.oAEinPackage;
    modalRef.componentInstance.OA_EIN_Licenses_Package = ProductConfigurationIds.oAEinLicensesPackage;
    this.getModalElementAndSetPosition();

    modalRef.result.then(
      (result: number) => {
        const selPkg = this.mapProductConfigurationIdToDocumentsPackage(result);
        if (selPkg !== this.questionnaireService.llc.documentsPackage) {
          this.questionnaireService.llc.documentsPackage = selPkg;
          this.showBusy(true);
          this.prepareCartService.saveAndRefreshCart();
        }
      }, () => { }
    );
  }

  // Seems that this method and package not in used
  // handleDeliveryModalResponse(): void {
  //   const modalRef = this.modalService.open(DeliveryModalComponent, { size: 'lg', windowClass: 'modal--review' });
  //   modalRef.componentInstance.offerAccepted = this.questionnaireService.llc.isExpedite;
  //   modalRef.componentInstance.deliveryName = this.productDefinitionService.PROCESSING().name;
  //   modalRef.componentInstance.deliveryPrice = this.productDefinitionService.PROCESSING().price;
  //   modalRef.componentInstance.timeframeInDays = this.productDefinitionService.PROCESSING().NonExpdTimeFrame;
  //   modalRef.componentInstance.entityState = ConstantsService.getStateAbbr(this.questionnaireService.llc.entityState);
  //   modalRef.componentInstance.expediteFee = this.packageSelectionService.expediteFee;
  //   modalRef.result.then(
  //     (result: boolean) => {
  //       if (result !== this.questionnaireService.llc.isExpedite) {
  //         this.questionnaireService.llc.isExpedite = result;
  //         this.showBusy(true);
  //         this.questionnaireService.setQuestionnaire().subscribe(
  //           (setQxResult) => {
  //             const mappedLLC = this.questionnaireMappingService.doMapping(this.questionnaireService.llc, this.userOrderService.userOrder.userOrderId);
  //             this.questionnaireService.saveQuestionnaire(mappedLLC).subscribe(
  //               (mappingResult) => {
  //                 this.packageSelectionService.updateCart().subscribe(
  //                   (pkgRefresh) => {
  //                     this.cartService.refreshCart().subscribe(
  //                       () => { }
  //                     );
  //                   }
  //                 );
  //               }
  //             );
  //           }
  //         );
  //       }
  //     }, () => { }
  //   );
  // }

  receiveConfigurationId(id: number) {
    this.productConfigurationId = id;
    switch (this.productConfigurationId) {
      case 0:
        this.handleCompanyDetailsModalResponse();
        break;

      case ProductConfigurationIds.registeredAgent:
      case ProductConfigurationIds.registeredAgent_199:
      case ProductConfigurationIds.registeredAgent_249:
      case ProductConfigurationIds.custom_RegisteredAgent_details:
        this.handleRAModalResponse();
        break;

      case ProductConfigurationIds.economyLLCPackage:
      case ProductConfigurationIds.standarLLCPackage:
      case ProductConfigurationIds.expressGoldLLCPackage:
      case ProductConfigurationIds.tier1LLCPackage:
      case ProductConfigurationIds.tier2LLCPackage:
      case ProductConfigurationIds.tier3LLCPackage:
        this.handlePackageSelectionModalResponse();
        break;
      case ProductConfigurationIds.bapMonthlyLegal:
      case ProductConfigurationIds.bapMonthlyLegalProtect:
      case ProductConfigurationIds.bapMonthlyLegalWisconsin:
      case ProductConfigurationIds.bapMonthlyLegalProtectWisconsin:
      case ProductConfigurationIds.bapAnnualTax:
      case ProductConfigurationIds.custom_LegalProtext_SmartEmployer:
      case ProductConfigurationIds.custom_LegalProtext_SmartEmployer_WI:
        this.handleTaxAndLegalModalResponse(this.productConfigurationId);
        break;

      case ProductConfigurationIds.oAPackage:
      case ProductConfigurationIds.oAEinPackage:
      case ProductConfigurationIds.oAEinLicensesPackage:
      case ProductConfigurationIds.custom_OAEinBL:
      case ProductConfigurationIds.custom_OAEinBL_NoThanks:
        this.handleLegalDocumentsModalResponse();
        break;

      case ProductConfigurationIds.compliancePackage:
      case ProductConfigurationIds.custom_Total_Compliance:
        this.handleComplianceModalResponse();
        break;

      case ProductConfigurationIds.economyLLCShipping:
      case ProductConfigurationIds.LLCTier1StandardShipping:
        this.handleBppSelection();
        break;

      case ProductConfigurationIds.accounting_Full_Service_Tax_Plan:
      case ProductConfigurationIds.tax_Prep_Essentials_Plan:
      case ProductConfigurationIds.custom_Tax_Package:
        this.handleTaxPackageModalResponse();
        break;
      // Seems that it's not in used
      //  case ProductConfigurationIds.processingStandard:
      //  case ProductConfigurationIds.processingExpedited:
      //   this.handleDeliveryModalResponse();
      //   break;

      default:
        alert('Item: ' + id + ' has no assigned modal yet');
        break;
    }
  }

  ngAfterViewInit() {
    this.bannerHeightSubject = this.bannerService.getBannerHeight(this.renderer);

    if (this.isMobile) {

      this.bannerHeightSubscription = this.bannerHeightSubject.subscribe(bannerHeight => {
        this.cookieBannerHeight = bannerHeight;
        this.setModalPosition(bannerHeight);

        if (this.bannerHeightSubscription && bannerHeight === 0) {

          this.bannerHeightSubscription.unsubscribe();
        }
      });
    }
  }

  private setModalPosition(bannerHeight: number = 0) {
    if (bannerHeight === 0) {
      const contentElement = document.getElementsByClassName('modal-ryo-review');
      if (contentElement.length > 0) {
        contentElement[0].setAttribute('style', 'padding-bottom:0;');
      }
    }
    else {
      const contentElement = document.getElementsByClassName('modal-ryo-review');
      if (contentElement.length > 0) {
        contentElement[0].setAttribute('style', 'padding-bottom:' + bannerHeight + 'px;');
      }
    }
  }

  private getModalElementAndSetPosition() {
    setTimeout(() => {
      const contentElement = document.getElementsByClassName('modal-ryo-review');
      if (contentElement.length > 0) {
        this.setModalPosition(this.cookieBannerHeight);
      }
    }, 0);
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
    if (this.bannerHeightSubscription) {
      this.bannerHeightSubscription.unsubscribe();
    }
  }

}
