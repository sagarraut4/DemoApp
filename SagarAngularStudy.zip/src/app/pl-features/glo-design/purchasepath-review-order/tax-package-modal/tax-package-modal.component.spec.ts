import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { TaxPackageModalComponent } from './tax-package-modal.component';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ProductConfigurationIds } from 'src/app/shared/models/cart-model';

describe('TaxPackageModalComponent', () => {
  let component: TaxPackageModalComponent;
  let fixture: ComponentFixture<TaxPackageModalComponent>;
  let mockNgbActiveModal;
  beforeEach(async(() => {
    mockNgbActiveModal = jasmine.createSpyObj(['close', 'dismiss']);
    TestBed.configureTestingModule({
      declarations: [TaxPackageModalComponent],
      providers: [
        { provide: NgbActiveModal, useValue: mockNgbActiveModal },
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaxPackageModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


  it('should call setPackage on click of tax prep essential', async(() => {
    spyOn(component, 'setPackage');
    const accountingPlan = fixture.debugElement.query(By.css('#review_llc_taxPackage_tax_prep_ess')).nativeElement;
    accountingPlan.click();
    fixture.whenStable().then(() => {
      expect(component.setPackage).toHaveBeenCalled();
    });
  }));

  it('should call setPackage on click of accounting full service plan', async(() => {
    spyOn(component, 'setPackage');
    const accountingFullServicePlan = fixture.debugElement.query(By.css('#review_llc_taxPackage_accounting_full_service')).nativeElement;
    accountingFullServicePlan.click();
    fixture.whenStable().then(() => {
      expect(component.setPackage).toHaveBeenCalled();
    });
  }));

it('should call setPackage on click of no thanks', async(() => {
    spyOn(component, 'setPackage');
    const noThanks = fixture.debugElement.query(By.css('#review_llc_taxPackage_no_thanks')).nativeElement;
    noThanks.click();
    fixture.whenStable().then(() => {
      expect(component.setPackage).toHaveBeenCalled();
    });
  }));

  it('should call activeModal.close', () => {
    component.selectedPackageId = ProductConfigurationIds.accounting_Full_Service_Tax_Plan;
    component.updateOrder();
    expect(mockNgbActiveModal.close).toHaveBeenCalledWith(ProductConfigurationIds.accounting_Full_Service_Tax_Plan);
  });


  it('close button should close the active modal', () => {
    const closeBtn = fixture.debugElement.query(By.css('.glo-btn-close')).nativeElement;
    closeBtn.click();
    expect(mockNgbActiveModal.dismiss).toHaveBeenCalled();
  });
});
