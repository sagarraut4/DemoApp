import { Component, OnInit, HostBinding, Input } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ProductConfigurationIds } from '../../../../shared/models/cart-model';
import { TaxPackages } from '../../../../shared/models/tax-packages-model';
import { ExperimentsService } from './../../../../shared/services/experiments/experiments.service';

@Component({
  selector: 'app-tax-package-modal',
  templateUrl: './tax-package-modal.component.html',
  styleUrls: ['./tax-package-modal.component.scss']
})
export class TaxPackageModalComponent implements OnInit {
  @Input() public selectedPackageId: number;
  private newId$ = new BehaviorSubject<number>(this.selectedPackageId);
  public accountingFullServicePkg;
  public taxPrepEssPkg;
  public taxPrepEssPackage: boolean;
  public accountingFullServicePackage: boolean;
  public isLoaded = false;

  // add required class to sort modal-content height
  @HostBinding('class.modal-content') true: boolean;

  constructor(
    public activeModal: NgbActiveModal,
    public experimentsService: ExperimentsService
  ) { }

  ngOnInit() {
    this.load();
    this.setSelection(this.selectedPackageId);
    this.newId$.subscribe(
      (result: number) => {
        if (result !== undefined) {
          this.setSelection(result);
        }
      }
    );
  }

  private setSelection(selectedPackageId: number) {
    this.accountingFullServicePackage = selectedPackageId === ProductConfigurationIds.accounting_Full_Service_Tax_Plan;

    this.taxPrepEssPackage = selectedPackageId === ProductConfigurationIds.tax_Prep_Essentials_Plan;

    this.selectedPackageId = selectedPackageId;
  }

  load(): void {
    this.CreatePackageConfigurations(TaxPackages);
    this.isLoaded = true;
    this.setSelection(this.selectedPackageId);
  }

  private CreatePackageConfigurations(packages) {
    this.taxPrepEssPkg = {};
    this.accountingFullServicePkg = {};
    for (const pkg of packages) {
      if (pkg.productConfigurationId === ProductConfigurationIds.accounting_Full_Service_Tax_Plan) {
        this.setPackageDetails(this.accountingFullServicePkg, pkg);
      }
      if (pkg.productConfigurationId === ProductConfigurationIds.tax_Prep_Essentials_Plan) {
        this.setPackageDetails(this.taxPrepEssPkg, pkg);
      }
    }
  }

  setPackage(pkgConfigId: number): void {
    this.newId$.next(pkgConfigId);
  }

  setPackageDetails(pkg: any, pkgDetails: any) {
    pkg.productConfigurationId = pkgDetails.productConfigurationId;
    pkg.displayNameOnWeb = pkgDetails.title;
    pkg.amount = pkgDetails.amount;
    pkg.description = pkgDetails.description;
  }

  updateOrder() {
    this.activeModal.close(this.selectedPackageId);
  }

  cancel() {
    this.activeModal.dismiss('cancel');
  }
}
