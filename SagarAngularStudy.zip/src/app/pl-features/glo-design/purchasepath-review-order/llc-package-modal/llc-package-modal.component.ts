import { PackageService } from '../../../../shared/services/package.service';
import { Component, OnInit, HostBinding, Input, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ProductConfigurationIds } from '../../../../shared/models/cart-model';
import { PACKAGEINCLUDES } from '../../../../shared/models/package-selection-model';
import { QuestionnaireService } from '../../../../../app/shared/services/questionnaire/questionnaire.service';
import { SEADService } from '../../../../shared/services/tracking/sead.service';
import { IPackageConfiguration, FilingFees, IPackageConfigurations } from '@legalzoom/questionnaire-answer-sdk';
import { ExperimentsService } from '../../../../shared/services/experiments/experiments.service';
import { TrackingService } from '../../../../shared/services/tracking/tracking.service';
@Component({
  selector: 'app-desktop-llc-package-modal',
  templateUrl: './llc-package-modal.component.html',
  styleUrls: ['./llc-package-modal.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LlcPackageModalComponent implements OnInit {
  @Input() public selectedPackageId: number;
  packageIncludes: any = PACKAGEINCLUDES;
  private newId$ = new BehaviorSubject<number>(this.selectedPackageId);
  public entityStateCode: string;
  public economyPkg: IPackageConfiguration;
  public standardPkg: IPackageConfiguration;
  public goldPkg: IPackageConfiguration;
  public economyPackage: boolean;
  public standardPackage: boolean;
  public goldPackage: boolean;
  public isLoaded = false;
  public showTSA = false;

  // add required class to sort modal-content height
  @HostBinding('class.modal-content') true: boolean;

  constructor(
    public questionnaireService: QuestionnaireService,
    public activeModal: NgbActiveModal,
    public seadService: SEADService,
    private packageService: PackageService,
    private changeDetectRef: ChangeDetectorRef,
    private experimentsService: ExperimentsService,
    private trackingService: TrackingService
  ) { }

  ngOnInit() {
  
    const selectedTaxPackage = this.questionnaireService.llc.taxPackageSelected && this.questionnaireService.llc.taxPackageSelected > 0;
    const inTaxExperiment = this.experimentsService.isLLCTaxPilotTest_EXPA();

    // Check if TSA is selected
    this.showTSA = !selectedTaxPackage && inTaxExperiment;

    this.load();
    this.setSelection(this.selectedPackageId);
    this.newId$.subscribe(
      (result: number) => {
        if (result !== undefined) {
          this.setSelection(result);
        }
      }
    );
  }

  private setSelection(selectedPackageId: number) {
    this.economyPackage = selectedPackageId === ProductConfigurationIds.economyLLCPackage;
    this.standardPackage = selectedPackageId === ProductConfigurationIds.standarLLCPackage;
    this.goldPackage = selectedPackageId === ProductConfigurationIds.expressGoldLLCPackage;
    this.selectedPackageId = selectedPackageId;
  }

  toggleClass(event) {
    const chevron = event.target.closest('div').children[0];
    const descText = event.target.closest('div').children[2];
    // show/hide the description text
    if (descText.classList.contains('hidden')) {
      descText.classList.remove('hidden');
    } else {
      descText.classList.add('hidden');
    }

    // rotate the chevron
    if (chevron.classList.contains('rotated')) {
      chevron.classList.remove('rotated');
    } else {
      chevron.classList.add('rotated');
    }
  }

  load(): void {
    this.packageService.getPackages().subscribe(packages => {
      this.CreatePackageConfigurations(packages);
      this.isLoaded = true;
      this.setSelection(this.selectedPackageId);
      this.changeDetectRef.detectChanges();
    },
      err => {
        // we still want to show the DOM if we don't get a response from filling fees
        // the text will default with the 'State' string as a placeholder
        // TODO: may need to think about another way to either retry getting filing fees
        // or better placeholder text in case we can't get that information
        this.isLoaded = true;
        this.changeDetectRef.detectChanges();
      });
  }

  private CreatePackageConfigurations(packages: IPackageConfigurations) {
    this.economyPkg = this.packageService.createNewPackageConfiguration();
    this.standardPkg = this.packageService.createNewPackageConfiguration();
    this.goldPkg = this.packageService.createNewPackageConfiguration();
    for (const pkg of packages.packageConfiguration) {
      if (pkg.productConfigurationId === ProductConfigurationIds.economyLLCPackage) {
        this.economyPkg.productConfigurationId = pkg.productConfigurationId;
        this.economyPkg.displayNameOnWeb = this.packageService.getPackageDisplayName(pkg);
        this.economyPkg.extendedPrice = pkg.extendedPrice;
        this.economyPkg.filingfees = new FilingFees();
        this.economyPkg.filingfees.basePrice = pkg.filingfees.basePrice;
        this.economyPkg.filingfees.adjustedPrice = pkg.filingfees.adjustedPrice;
      }
      if (pkg.productConfigurationId === ProductConfigurationIds.standarLLCPackage) {
        this.standardPkg.productConfigurationId = pkg.productConfigurationId;
        this.standardPkg.displayNameOnWeb = this.packageService.getPackageDisplayName(pkg);
        this.standardPkg.extendedPrice = pkg.extendedPrice;
        this.standardPkg.filingfees = new FilingFees();
        this.standardPkg.filingfees.basePrice = pkg.filingfees.basePrice;
        this.standardPkg.filingfees.adjustedPrice = pkg.filingfees.adjustedPrice;
      }
      if (pkg.productConfigurationId === ProductConfigurationIds.expressGoldLLCPackage) {
        this.goldPkg.productConfigurationId = pkg.productConfigurationId;
        this.goldPkg.displayNameOnWeb = this.packageService.getPackageDisplayName(pkg);
        this.goldPkg.extendedPrice = pkg.extendedPrice;
        this.goldPkg.filingfees = new FilingFees();
        this.goldPkg.filingfees.basePrice = pkg.filingfees.basePrice;
        this.goldPkg.filingfees.adjustedPrice = pkg.filingfees.adjustedPrice;
      }
    }
  }

  getEntityState() {
    return this.questionnaireService.llc.entityState;
  }

  getEntityName() {
    return this.questionnaireService.llc.entityName;
  }

  setPackage(pkgConfigId: number): void {
    let selectedPackage = '';
    switch (pkgConfigId) {
      case ProductConfigurationIds.economyLLCPackage:
        selectedPackage = 'Economy LLC';
        this.trackingService.triggerClickTrack('llc_flow', 'edit_formation_economy');
        break;
      case ProductConfigurationIds.standarLLCPackage:
        selectedPackage = 'Standard LLC';
        this.trackingService.triggerClickTrack('llc_flow', 'edit_formation_standard');
        break;
      case ProductConfigurationIds.expressGoldLLCPackage:
        selectedPackage = 'Express Gold LLC';
        this.trackingService.triggerClickTrack('llc_flow', 'edit_formation_express_gold');
        break;
    }

    this.newId$.next(pkgConfigId);
    this.seadService.TrackingObject.pkgSelected = selectedPackage;
    this.seadService.PushToTealium();
  }

  updateOrder() {
    this.trackingService.triggerClickTrack('llc_flow', 'edit_modal_update_order');
    this.trackingService.triggerClickTrack('llc_flow', 'edit_formation_update');
    this.activeModal.close(this.selectedPackageId);
  }

  cancel() {
    this.trackingService.triggerClickTrack('llc_flow', 'edit_modal_cancel');
    this.trackingService.triggerClickTrack('llc_flow', 'edit_formation_cancel');
    this.activeModal.dismiss('cancel');
  }
}
