import { By } from '@angular/platform-browser';
import { ProductConfigurationIds } from '../../../../shared/models/cart-model';
import { PackageService } from '../../../../shared/services/package.service';
import { SEADService } from 'src/app/shared/services/tracking/sead.service';
import { QuestionnaireService } from 'src/app/shared/services/questionnaire/questionnaire.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LlcPackageModalComponent } from './llc-package-modal.component';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { of } from 'rxjs';
import { IPackageConfigurations, IPackageConfiguration } from '@legalzoom/business-formation-sdk';

describe('LlcPackageModalComponent', () => {
  let component: LlcPackageModalComponent;
  let fixture: ComponentFixture<LlcPackageModalComponent>;
  const mockQuestionnaireService = {
    llc: {
      entityName: 'Test',
      entityState: 'California'
    }
  };
  let mockNgbActiveModal;
  let mockSEADService;
  let mockPackageService;
  const mockPackages: IPackageConfigurations = {
    packageConfiguration: [
      // tslint:disable-next-line:max-line-length
      { name: 'LLC Economy', productConfigurationId: 145, displayNameOnBill: 'Economy LLC', displayNameOnWeb: 'Economy LLC', productTypeId: '', shouldDisplayOnBill: false, isDefaultPackage: false, extendedPrice: 79, filingfees: { productBasePriceId: 7325, productPricePointId: 106, basePrice: 70, lawyerAmount: 0, adjustedPrice: 70, stateId: 5, productName: 'LLC Filing Fee', billingDisplayName: 'State Filing Fee - {state}', purchaseLockDisplayName: 'State Filing Fee - {state}' } } as IPackageConfiguration,
      // tslint:disable-next-line:max-line-length
      { name: 'LLC Standard', productConfigurationId: 146, displayNameOnBill: 'Standard LLC', displayNameOnWeb: 'Standard LLC', productTypeId: '', shouldDisplayOnBill: false, isDefaultPackage: false, extendedPrice: 329, filingfees: { productBasePriceId: 7325, productPricePointId: 106, basePrice: 70, lawyerAmount: 0, adjustedPrice: 70, stateId: 5, productName: 'LLC Filing Fee', billingDisplayName: 'State Filing Fee - {state}', purchaseLockDisplayName: 'State Filing Fee - {state}' } } as IPackageConfiguration,
      // tslint:disable-next-line:max-line-length
      { name: 'LLC Express Gold', productConfigurationId: 147, displayNameOnBill: 'Express Gold LLC', displayNameOnWeb: 'Express Gold LLC', productTypeId: '', isDefaultPackage: false, extendedPrice: 349, filingfees: { productBasePriceId: 7326, productPricePointId: 635, basePrice: 70, lawyerAmount: 0, adjustedPrice: 70, stateId: 5, productName: 'LLC Filing Fee - Expedited', billingDisplayName: 'State Filing Fee - {state}', purchaseLockDisplayName: 'State Filing Fee - {state}' } } as IPackageConfiguration
    ]
  };
  const mockPackageConfiguration = {
    name: '',
    parentProductId: 0,
    productComponentId: 0,
    productConfigurationId: 0,
    displayNameOnBill: '',
    displayNameOnWeb: '',
    packageProductConfigurationId: '',
    extendedPrice: 0,
    filingfees: null,
    productTypeId: '',
    shouldDisplayOnBill: false,
    productComponent: null,
    isDefaultPackage: false,
    childProducts: null
  };
  beforeEach(async(() => {
    mockPackageService = jasmine.createSpyObj(['getPackages', 'getPackageDisplayName', 'createNewPackageConfiguration']);
    mockNgbActiveModal = jasmine.createSpyObj(['close', 'dismiss']);
    mockSEADService = jasmine.createSpyObj(['PushToTealium', 'addOptin']);
    mockSEADService.TrackingObject = {};

    mockPackageService.getPackages.and.returnValues(of(mockPackages));
    mockPackageService.createNewPackageConfiguration.and.returnValues(mockPackageConfiguration, mockPackageConfiguration, mockPackageConfiguration);
    TestBed.configureTestingModule({
      declarations: [LlcPackageModalComponent],
      providers: [
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: NgbActiveModal, useValue: mockNgbActiveModal },
        { provide: SEADService, useValue: mockSEADService },
        { provide: PackageService, useValue: mockPackageService }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LlcPackageModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should return entity name', () => {
    const entityname = component.getEntityName();
    expect(entityname).toBe('Test');
  });
  it('should return entity state', () => {
    const entityname = component.getEntityState();
    expect(entityname).toBe('California');
  });

  it('should call activeModal.close', () => {
    // Arrange
    component.selectedPackageId = ProductConfigurationIds.economyLLCPackage;
    // Act
    component.updateOrder();
    // Assert
    expect(mockNgbActiveModal.close).toHaveBeenCalledWith(ProductConfigurationIds.economyLLCPackage);
  });

  it('should call seadService.PushToTealium', () => {
    // Act
    component.setPackage(ProductConfigurationIds.economyLLCPackage);
    // Assert
    expect(mockSEADService.PushToTealium).toHaveBeenCalled();
  });

  it('should call setPackage onc click of economy package', async(() => {
    // Act
    spyOn(component, 'setPackage');
    const economyPackage = fixture.debugElement.query(By.css('#review_llc_package_economy')).nativeElement;
    // Act
    economyPackage.click();
    // Assert
    fixture.whenStable().then(() => {
      expect(component.setPackage).toHaveBeenCalled();
    });
  }));
  it('should call setPackage onc click of standard package', async(() => {
    // Act
    spyOn(component, 'setPackage');
    const standardPackage = fixture.debugElement.query(By.css('#review_llc_package_standard')).nativeElement;
    // Act
    standardPackage.click();
    // Assert
    fixture.whenStable().then(() => {
      expect(component.setPackage).toHaveBeenCalled();
    });
  }));
  it('should call setPackage onc click of express gold package', async(() => {
    // Act
    spyOn(component, 'setPackage');
    const standardPackage = fixture.debugElement.query(By.css('#review_llc_package_express_gold')).nativeElement;
    // Act
    standardPackage.click();
    // Assert
    fixture.whenStable().then(() => {
      expect(component.setPackage).toHaveBeenCalled();
    });
  }));
  it('close button should close the active modal', () => {
    const closeBtn = fixture.debugElement.query(By.css('.glo-btn-close')).nativeElement;
    closeBtn.click();
    expect(mockNgbActiveModal.dismiss).toHaveBeenCalled();
  });
});
