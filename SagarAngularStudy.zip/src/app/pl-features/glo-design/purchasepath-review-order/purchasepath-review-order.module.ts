import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ReactiveFormsModule } from '@angular/forms';
import { MatTooltipModule } from '@angular/material';
import { CompanyDetailsModalComponent } from './company-details-modal/company-details-modal.component';
import { ReviewYourOrderComponent } from './review-your-order/review-your-order.component';
import { LlcPackageModalComponent } from './llc-package-modal/llc-package-modal.component';
import { LegalDocumentsModalComponent } from './legal-documents-modal/legal-documents-modal.component';
import { ComplianceModalComponent } from './compliance-modal/compliance-modal.component';
import { CartItemsComponent } from './review-your-order/cart-items/cart-items.component';
import { PeaceOfMindComponent } from '../modals/peace-of-mind/peace-of-mind.component';
import { TaxAndLegalPackageModalComponent } from './tax-and-legal-package-modal/tax-and-legal-package-modal.component';
import { PurchasepathPlCheckoutModule } from '../../../pl-features/glo-design/purchasepath-checkout/purchasepath-checkout.module';
import { RegisteredAgentModalComponent } from '../modals/registered-agent-modal/registered-agent-modal.component';
import { SharedComponentsModule } from '../../../shared/components/shared-components.module';
import { CoreModule } from '../../../core/core.module';
import { DeliveryModalComponent } from './delivery-modal/delivery-modal.component';
import { TippyModule } from 'ng-tippy';
import { StateTaxRegModalComponent } from './state-tax-reg-modal/state-tax-reg-modal.component';
import { GloComponentsModule } from '../shared/components/glo-components.module';
import { TaxPackageModalComponent } from './tax-package-modal/tax-package-modal.component';


@NgModule({

  imports: [
    CommonModule,
    CoreModule,
    NgbModule,
    ReactiveFormsModule,
    PurchasepathPlCheckoutModule,
    SharedComponentsModule,
    MatTooltipModule,
    TippyModule,
    GloComponentsModule,
  ],
  providers: [],
  declarations: [
    CompanyDetailsModalComponent,
    ReviewYourOrderComponent,
    LlcPackageModalComponent,
    LegalDocumentsModalComponent,
    ComplianceModalComponent,
    CartItemsComponent,
    PeaceOfMindComponent,
    TaxAndLegalPackageModalComponent,
    RegisteredAgentModalComponent,
    DeliveryModalComponent,
    StateTaxRegModalComponent,
    TaxPackageModalComponent
  ],
  entryComponents: [
    CompanyDetailsModalComponent,
    LlcPackageModalComponent,
    LegalDocumentsModalComponent,
    ComplianceModalComponent,
    PeaceOfMindComponent,
    TaxAndLegalPackageModalComponent,
    RegisteredAgentModalComponent,
    DeliveryModalComponent,
    StateTaxRegModalComponent,
    TaxPackageModalComponent
  ],
  exports: [
    CompanyDetailsModalComponent,
    ReviewYourOrderComponent,
    LlcPackageModalComponent,
    LegalDocumentsModalComponent,
    ComplianceModalComponent,
    CartItemsComponent,
    PeaceOfMindComponent,
    TaxAndLegalPackageModalComponent,
    RegisteredAgentModalComponent,
    DeliveryModalComponent,
    TaxPackageModalComponent
  ]
})
export class PurchasepathReviewOrderModule { }
