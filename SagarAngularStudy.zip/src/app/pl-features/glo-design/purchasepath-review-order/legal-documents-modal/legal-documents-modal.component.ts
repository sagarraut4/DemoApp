import { TrackingService } from './../../../../shared/services/tracking/tracking.service';
import { Component, HostBinding, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { SEADService } from '../../../../shared/services/tracking/sead.service';
import { ProductDefinitionService } from '../../../../shared/services/product-definition/product-definition.service';
import { ExperimentsService } from '../../../../shared/services/experiments/experiments.service';

@Component({
  selector: 'app-desktop-legal-documents-modal',
  templateUrl: './legal-documents-modal.component.html',
  styleUrls: ['./legal-documents-modal.component.scss']
})
export class LegalDocumentsModalComponent implements OnInit {
  // tslint:disable-next-line: variable-name
  Selected_Package: number;
  // tslint:disable-next-line: variable-name
  OA_Package: number;
  // tslint:disable-next-line: variable-name
  OA_EIN_Package: number;
  // tslint:disable-next-line: variable-name
  OA_EIN_Licenses_Package: number;

  NoPackage = -1;
  // add required class to sort modal-content height
  @HostBinding('class.modal-content') true: boolean;

  constructor(
    public activeModal: NgbActiveModal,
    public questionnaireService: QuestionnaireService,
    public productDefinitionService: ProductDefinitionService,
    public seadService: SEADService,
    public experimentService: ExperimentsService,
    public trackingService: TrackingService
  ) { }

  public notDirty: boolean;

  public titles = this.productDefinitionService.ESSENTIAL_DOCS_PKGS();

  ngOnInit() {
    this.notDirty = true;
    this.titles.recommended.price = '$199';
  }

  selectPackage(val: number) {
    this.Selected_Package = val;
    this.notDirty = false;

    // empty whatever optins we had for legal documents
    this.seadService.removeOptin(this.seadService.seadOptins.OA);
    this.seadService.removeOptin(this.seadService.seadOptins.OA_EIN);
    this.seadService.removeOptin(this.seadService.seadOptins.OA_EIN_LICENCES);

    switch (val) {
      case 3975:
        this.seadService.addOptin(this.seadService.seadOptins.OA_EIN_LICENCES);
        this.trackingService.triggerClickTrack('llc_flow','edit_doc_oa_ein_bl');
        break;
      case 4526:
        this.seadService.addOptin(this.seadService.seadOptins.OA_EIN);
        this.trackingService.triggerClickTrack('llc_flow','edit_doc_oa_ein');
        break;
      case 5893:
        this.seadService.addOptin(this.seadService.seadOptins.OA);
        this.trackingService.triggerClickTrack('llc_flow','edit_doc_oa');
        break;
      case  -1:
        this.trackingService.triggerClickTrack('llc_flow','edit_doc_no');
        break; 
    }

  }

  updateOrder() {
    this.trackingService.triggerClickTrack('llc_flow','edit_modal_update_order');
    this.trackingService.triggerClickTrack('llc_flow','edit_doc_update_order');
    this.activeModal.close(this.Selected_Package);
  }

  cancel() {
    this.trackingService.triggerClickTrack('llc_flow','edit_modal_cancel');
    this.trackingService.triggerClickTrack('llc_flow','edit_doc_cancel');
    this.activeModal.dismiss('cancel');
  }
}
