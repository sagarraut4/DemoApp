import { LLC } from '../../../../shared/models/questionnaire-model';
import { ProductDefinitionService } from '../../../../shared/services/product-definition/product-definition.service';
import { ExperimentsService } from '../../../../shared/services/experiments/experiments.service';
import { SEADService } from '../../../../shared/services/tracking/sead.service';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LegalDocumentsModalComponent } from './legal-documents-modal.component';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { By } from '@angular/platform-browser';

describe('LegalDocumentsModalComponent', () => {
  let component: LegalDocumentsModalComponent;
  let fixture: ComponentFixture<LegalDocumentsModalComponent>;
  const mockQuestionnaireService = {
    llc: new LLC()
  };
  let mockNgbActiveModal;
  let mockSeadService;
  let mockExperimentsService;
  beforeEach(async(() => {
    mockNgbActiveModal = jasmine.createSpyObj(['close', 'dismiss']);
    mockSeadService = jasmine.createSpyObj(['addOptin', 'removeOptin']);
    mockSeadService.seadOptins = {
      OA: 'test',
      OA_EIN: 'test',
      OA_EIN_LICENCES: 'OA_EIN_LICENCES'
    };
    TestBed.configureTestingModule({
      declarations: [LegalDocumentsModalComponent],
      providers: [
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: NgbActiveModal, useValue: mockNgbActiveModal },
        { provide: SEADService, useValue: mockSeadService },
        { provide: ExperimentsService, useValue: mockExperimentsService },
        ProductDefinitionService
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LegalDocumentsModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create legal document modal component', () => {
    expect(component).toBeTruthy();
  });
  it('should call seadService.addOptin if OA_EIN_LICENCES offer is accepted ', () => {
    // Act
    component.selectPackage(3975);
    // Assert
    expect(mockSeadService.addOptin).toHaveBeenCalled();
    expect(mockSeadService.removeOptin).toHaveBeenCalledTimes(3);
  });
  it('should call seadService.addOptin if OA_EIN offer is accepted ', () => {
    // Act
    component.selectPackage(4526);
    // Assert
    expect(mockSeadService.addOptin).toHaveBeenCalled();
    expect(mockSeadService.removeOptin).toHaveBeenCalledTimes(3);
  });
  it('should call seadService.addOptin if OA offer is accepted ', () => {
    // Act
    component.selectPackage(5893);
    // Assert
    expect(mockSeadService.addOptin).toHaveBeenCalled();
    expect(mockSeadService.removeOptin).toHaveBeenCalledTimes(3);
  });
  it('should call close modal on updateOrder', () => {
    // Act
    component.updateOrder();
    // Assert
    expect(mockNgbActiveModal.close).toHaveBeenCalled();
  });
  it('should call selectPackage method  on click of review_operating_agreement link ', () => {
    // Arrange
    spyOn(component, 'selectPackage');
    const complianceYes = fixture.debugElement.query(By.css('#review_operating_agreement')).nativeElement;
    // Act
    complianceYes.click();
    // Assert
    expect(component.selectPackage).toHaveBeenCalled();
  });
});
