import { ExperimentsService } from '../../../../shared/services/experiments/experiments.service';
import { SEADService } from '../../../../shared/services/tracking/sead.service';
import { ProductDefinitionService } from '../../../../shared/services/product-definition/product-definition.service';
import { LLC } from '../../../../shared/models/questionnaire-model';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ComplianceModalComponent } from './compliance-modal.component';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { By } from '@angular/platform-browser';

describe('ComplianceModalComponent', () => {
  let component: ComplianceModalComponent;
  let fixture: ComponentFixture<ComplianceModalComponent>;
  const mockQuestionnaireService = {
    llc: new LLC()
  };
  let mockNgbActiveModal;
  let mockSeadService;
  // tslint:disable-next-line:prefer-const
  let mockExperimentsService;
  beforeEach(async(() => {
    mockNgbActiveModal = jasmine.createSpyObj(['close', 'dismiss']);
    mockSeadService = jasmine.createSpyObj(['addOptin', 'removeOptin']);
    mockSeadService.seadOptins = {
      COMPLIANCE_FULL: 'test'
    };
    TestBed.configureTestingModule({
      declarations: [ComplianceModalComponent],
      providers: [
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: NgbActiveModal, useValue: mockNgbActiveModal },
        { provide: SEADService, useValue: mockSeadService },
        { provide: ExperimentsService, useValue: mockExperimentsService },
        ProductDefinitionService
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComplianceModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    // Assert
    expect(component).toBeTruthy();
  });

  it('should call seadService.addOptin if offer is accepted ', () => {
    // Act
    component.acceptOffer(true);
    // Assert
    expect(mockSeadService.addOptin).toHaveBeenCalled();
  });
  it('should call seadService.removeOptin if offer is not accepted ', () => {
    // Act
    component.acceptOffer(false);
    // Assert
    expect(mockSeadService.removeOptin).toHaveBeenCalled();
  });
  it('should close activeModal on click of updateOrder', () => {
    // Act
    component.updateOrder();
    // Assert
    expect(mockNgbActiveModal.close).toHaveBeenCalled();
  });

  it('should call acceptOffer method  on click of review_compliance_package_yes link ', () => {
    // Arrange
    spyOn(component, 'acceptOffer');
    const complianceYes = fixture.debugElement.query(By.css('#review_compliance_package_yes')).nativeElement;
    // Act
    complianceYes.click();
    // Assert
    expect(component.acceptOffer).toHaveBeenCalled();
  });
  it('should call acceptOffer method  on click of review_compliance_package_none link ', () => {
    // Arrange
    spyOn(component, 'acceptOffer');
    const complianceNone = fixture.debugElement.query(By.css('#review_compliance_package_none')).nativeElement;
    // Act
    complianceNone.click();
    // Assert
    expect(component.acceptOffer).toHaveBeenCalled();
  });
  it('close button should close the active modal', () => {
    // Arrange
    const closeBtn = fixture.debugElement.query(By.css('.glo-btn-close')).nativeElement;
    // Act
    closeBtn.click();
    // Assert
    expect(mockNgbActiveModal.dismiss).toHaveBeenCalled();
  });
});
