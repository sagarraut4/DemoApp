import { TrackingService } from './../../../../shared/services/tracking/tracking.service';
import { Component, HostBinding, OnInit, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { TaxAndLegalInfo, ProductConfigurationIds } from '../../../../shared/models/cart-model';
import { QuestionnaireService } from '../../../../../app/shared/services/questionnaire/questionnaire.service';
import { SEADService } from '../../../../shared/services/tracking/sead.service';
import { ExperimentsService } from '../../../../shared/../shared/services/experiments/experiments.service';

@Component({
  selector: 'app-desktop-tax-and-legal-package-modal',
  templateUrl: './tax-and-legal-package-modal.component.html',
  styleUrls: ['./tax-and-legal-package-modal.component.scss']
})
export class TaxAndLegalPackageModalComponent implements OnInit {
  @Input() annualTaxOfferinfo: TaxAndLegalInfo;
  @Input() annualLegalOfferinfo: TaxAndLegalInfo;
  // @Input() annualTaxAndLegalOfferinfo: TaxAndLegalInfo;
  @Input() pkgIdToOffer: number;
  @Input() currentPkgId: number;
  @Input() willHireEmployees: boolean;

  newSelectedPackage: number;
  // add required class to sort modal-content height
  @HostBinding('class.modal-content') true: boolean;
  public showWIPrice: boolean;

  acceptOffer(pkg: number) {
    this.newSelectedPackage = pkg;

    switch (this.newSelectedPackage) {
      case ProductConfigurationIds.bapAnnualTax:
        this.seadService.addOptin(this.seadService.seadOptins.BUSINESS_TAX_PLAN);
        // this.seadService.removeOptin(this.seadService.seadOptins.BUSINESS_LEGAL_PLAN);
        break;
      case ProductConfigurationIds.bapMonthlyLegal:
      case ProductConfigurationIds.bapMonthlyLegalWisconsin:
      case ProductConfigurationIds.bapMonthlyLegalProtect:
      case ProductConfigurationIds.bapMonthlyLegalProtectWisconsin:
      case ProductConfigurationIds.custom_LegalProtext_SmartEmployer:
      case ProductConfigurationIds.custom_LegalProtext_SmartEmployer_WI:
        this.seadService.addOptin(this.seadService.seadOptins.BUSINESS_LEGAL_PLAN);
        this.trackingService.triggerClickTrack('llc_flow','edit_legalprotect_lzlegalprotect');
        // this.seadService.removeOptin(this.seadService.seadOptins.BUSINESS_TAX_PLAN);
        break;
      default:
        this.seadService.removeOptin(this.seadService.seadOptins.BUSINESS_LEGAL_PLAN);
        this.seadService.removeOptin(this.seadService.seadOptins.BUSINESS_TAX_PLAN);
        this.trackingService.triggerClickTrack('llc_flow','edit_legalprotect_no');
    }
  }

  constructor(
    public activeModal: NgbActiveModal,
    public seadService: SEADService,
    public questionnaireService: QuestionnaireService,
    public experimentService: ExperimentsService,
    public trackingService: TrackingService
  ) { }

  ngOnInit() {
    this.newSelectedPackage = this.currentPkgId < 0 ? -1 : this.currentPkgId;
    if (this.questionnaireService.llc.entityState === 'Wisconsin') {
      this.showWIPrice = true;
    } else {
      this.showWIPrice = false;
    }
  }

  updateOrder() {
    if (this.newSelectedPackage === -1) {
      this.newSelectedPackage = 0;
    }
    if (this.newSelectedPackage < 0) {
      if (this.questionnaireService.llc.entityState === 'Wisconsin') {
        this.newSelectedPackage = ProductConfigurationIds.bapMonthlyLegalProtectWisconsin;
      } else {
        this.newSelectedPackage = ProductConfigurationIds.bapMonthlyLegalProtect;
      }
    }
    this.trackingService.triggerClickTrack('llc_flow','edit_modal_update_order');
    this.trackingService.triggerClickTrack('llc_flow','edit_legalprotect_update');
    this.activeModal.close(this.newSelectedPackage);
  }

  cancel() {
    this.trackingService.triggerClickTrack('llc_flow','edit_modal_cancel');
    this.trackingService.triggerClickTrack('llc_flow','edit_legalprotect_no');
    this.activeModal.dismiss('cancel');
  }
}
