import { By } from '@angular/platform-browser';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ProductConfigurationIds } from '../../../../shared/models/cart-model';
import { SEADService } from 'src/app/shared/services/tracking/sead.service';
import { QuestionnaireService } from 'src/app/shared/services/questionnaire/questionnaire.service';
import { TaxAndLegalPackageModalComponent } from './tax-and-legal-package-modal.component';

describe('TaxAndLegalPackageModalComponent', () => {
  let component: TaxAndLegalPackageModalComponent;
  let fixture: ComponentFixture<TaxAndLegalPackageModalComponent>;
  const mockQuestionnaireService = {
    llc: {
      entityName: 'Test'
    }
  };
  let mockNgbActiveModal;
  let mockSEADService;
  const mockAnnualLegalOfferinfo = {
    description: '',
    productConfigurationId: 7327,
    subTitle: '$39.99 per month',
    title: 'Legal Protect Plan',
  };
  const mockAnnualTaxOfferinfo = {
    description: '',
    productConfigurationId: 6573,
    subTitle: '$320 a year',
    title: 'Affordable Tax'
  };
  const seadOptins = {
    BUSINESS_TAX_PLAN: 'affordable-tax',
    BUSINESS_LEGAL_PLAN: 'legal-protect'
  };

  beforeEach(async(() => {
    mockNgbActiveModal = jasmine.createSpyObj(['close', 'dismiss']);
    mockSEADService = jasmine.createSpyObj(['removeOptin', 'addOptin']);
    mockSEADService.seadOptins = seadOptins;
    TestBed.configureTestingModule({
      declarations: [TaxAndLegalPackageModalComponent],
      providers: [
        { provide: QuestionnaireService, useValue: mockQuestionnaireService },
        { provide: NgbActiveModal, useValue: mockNgbActiveModal },
        { provide: SEADService, useValue: mockSEADService }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaxAndLegalPackageModalComponent);
    component = fixture.componentInstance;
    component.annualLegalOfferinfo = mockAnnualLegalOfferinfo;
    component.annualTaxOfferinfo = mockAnnualTaxOfferinfo;
    component.pkgIdToOffer = ProductConfigurationIds.bapMonthlyLegal;
    component.currentPkgId = ProductConfigurationIds.bapMonthlyLegal;
    component.willHireEmployees = true;
    fixture.detectChanges();
  });

  it('should create', () => {
    // Assert
    expect(component).toBeTruthy();
  });

  it('should acceptOffer addOptin for ProductConfigurationId  bapAnnualTax', () => {
    // Act
    component.acceptOffer(ProductConfigurationIds.bapAnnualTax);
    // Assert
    expect(mockSEADService.addOptin).toHaveBeenCalled();
  });
  it('should acceptOffer addOptin forProductConfigurationIds bapMonthlyLegal', () => {
    // Act
    component.acceptOffer(ProductConfigurationIds.bapMonthlyLegal);
    // Assert
    expect(mockSEADService.addOptin).toHaveBeenCalled();
  });
  it('should acceptOffer addOptin forProductConfigurationIds bapMonthlyLegalWisconsin', () => {
    // Act
    component.acceptOffer(ProductConfigurationIds.bapMonthlyLegalWisconsin);
    // Assert
    expect(mockSEADService.addOptin).toHaveBeenCalled();
  });
  it('should acceptOffer addOptin forProductConfigurationIds bapMonthlyLegalProtect', () => {
    // Act
    component.acceptOffer(ProductConfigurationIds.bapMonthlyLegalProtect);
    // Assert
    expect(mockSEADService.addOptin).toHaveBeenCalled();
  });
  it('should acceptOffer addOptin forProductConfigurationIds bapMonthlyLegalProtectWisconsin', () => {
    // Act
    component.acceptOffer(ProductConfigurationIds.bapMonthlyLegalProtectWisconsin);
    // Assert
    expect(mockSEADService.addOptin).toHaveBeenCalled();
  });
  it('should acceptOffer removeOptin for default', () => {
    // Act
    component.acceptOffer(0);
    // Assert
    expect(mockSEADService.removeOptin).toHaveBeenCalled();
  });

  it('should call activeModal.close', () => {
    // Act
    component.updateOrder();
    // Assert
    expect(mockNgbActiveModal.close).toHaveBeenCalledWith(ProductConfigurationIds.bapMonthlyLegal);
  });

  it('should call acceptOffer for review_tax_package_yes', async(() => {
    // Act
    component.pkgIdToOffer = ProductConfigurationIds.bapAnnualTax;
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      spyOn(component, 'acceptOffer');
      const taxPackageYes = fixture.debugElement.query(By.css('#review_tax_package_yes')).nativeElement;
      // Act
      taxPackageYes.click();
      // Assert
      expect(component.acceptOffer).toHaveBeenCalledWith(ProductConfigurationIds.bapAnnualTax);
    });
  }));
  it('should call acceptOffer for review_tax_package_yes', async(() => {
    // Act
    component.pkgIdToOffer = ProductConfigurationIds.bapMonthlyLegal;
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      spyOn(component, 'acceptOffer');
      const taxPackageYes = fixture.debugElement.query(By.css('#review_legal_package_yes')).nativeElement;
      // Act
      taxPackageYes.click();
      // Assert
      expect(component.acceptOffer).toHaveBeenCalledWith(ProductConfigurationIds.bapMonthlyLegal);
    });
  }));
  it('should call acceptOffer for review_legal_package_none', async(() => {
    // Act
    component.pkgIdToOffer = ProductConfigurationIds.bapMonthlyLegal;
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      spyOn(component, 'acceptOffer');
      const taxPackageYes = fixture.debugElement.query(By.css('#review_legal_package_none')).nativeElement;
      // Act
      taxPackageYes.click();
      // Assert
      expect(component.acceptOffer).toHaveBeenCalledWith(0);
    });
  }));
});
