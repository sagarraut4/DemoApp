import { QuestionnaireService } from 'src/app/shared/services/questionnaire/questionnaire.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { StateTaxRegModalComponent } from './state-tax-reg-modal.component';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { By } from '@angular/platform-browser';

describe('StateTaxRegModalComponent', () => {
  let component: StateTaxRegModalComponent;
  let fixture: ComponentFixture<StateTaxRegModalComponent>;
  let mockNgbActiveModal = jasmine.createSpyObj(['dismiss', 'close']);
  let mockQuesService = { llc: { isMobile: false } };
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [StateTaxRegModalComponent],
      providers: [{ provide: NgbActiveModal, useValue: mockNgbActiveModal },
      { provide: QuestionnaireService, useValue: mockQuesService }]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StateTaxRegModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('StateTaxRegModalComponent should create', () => {
    expect(component).toBeTruthy();
  });

  it('decline Btn should call acceptOffer', () => {
    spyOn(component, 'acceptOffer');
    const declineButton = fixture.debugElement.query(By.css('#review_compliance_package_none')).nativeElement;
    declineButton.click();
    expect(component.acceptOffer).toHaveBeenCalled();
  });

  it('accept Btn should call acceptOffer', () => {
    spyOn(component, 'acceptOffer');
    const acceptButton = fixture.debugElement.query(By.css('#review_compliance_package_yes')).nativeElement;
    acceptButton.click();
    expect(component.acceptOffer).toHaveBeenCalled();
  });

  it('cancel Btn should call close the modal', () => {
    const cancelBtn = fixture.debugElement.query(By.css('#btn-cancel')).nativeElement;
    cancelBtn.click();
    expect(mockNgbActiveModal.dismiss).toHaveBeenCalled();
  });

  it('update Btn should call acceptOffer', () => {
    spyOn(component, 'updateOrder');
    const updateBtn = fixture.debugElement.query(By.css('.btn-update')).nativeElement;
    updateBtn.click();
    expect(component.updateOrder).toHaveBeenCalled();
  });

  it('acceptOffer should save answer', () => {
    component.acceptOffer(true);
    expect(component.offerAccepted).toBe(true);
  });

  it('updateOrder should save answer', () => {
    component.updateOrder();
    expect(mockNgbActiveModal.close).toHaveBeenCalled();
  });

});
