import { OnInit, HostBinding, Input, Component } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';

@Component({
  selector: 'app-state-tax-reg-modal',
  templateUrl: './state-tax-reg-modal.component.html',
  styleUrls: ['./state-tax-reg-modal.component.scss']
})
export class StateTaxRegModalComponent implements OnInit {
  @HostBinding('class.modal-content') true: boolean;
  @Input() offerAccepted: boolean;
  @Input() entityState: string;
  @Input() price: number;
  // @Input() filingFee: number;

  constructor(
    public activeModal: NgbActiveModal,
    public questionnaireService: QuestionnaireService
  ) { }

  ngOnInit() {
  }

  acceptOffer(answer: boolean): void {
    this.offerAccepted = answer;
  }

  updateOrder(): void {
    this.activeModal.close(this.offerAccepted);
  }

  get stateTaxIdOnly(): boolean {
    return this.questionnaireService.llc.entityState === 'New Jersey';
  }

}
