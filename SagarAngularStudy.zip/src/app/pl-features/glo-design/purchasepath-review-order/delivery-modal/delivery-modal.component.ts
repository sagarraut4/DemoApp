import { ProductDefinitionService } from '../../../../shared/services/product-definition/product-definition.service';
import { Component, Input, HostBinding, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';

@Component({
  selector: 'app-desktop-delivery-modal',
  templateUrl: './delivery-modal.component.html',
  styleUrls: ['./delivery-modal.component.scss']
})
export class DeliveryModalComponent implements OnInit {
  @Input() offerAccepted: boolean;
  @Input() deliveryName: string;
  @Input() deliveryPrice: number;
  @Input() timeframeInDays: string;
  @Input() entityState: string;
  @Input() expediteFee: number;
  public priceBreakDown: string;
  // add required class to sort modal-content height
  @HostBinding('class.modal-content') true: boolean;

  constructor(
    public activeModal: NgbActiveModal,
    public questionnaireService: QuestionnaireService,
    private productDefinitionService: ProductDefinitionService
  ) { }

  ngOnInit() {
    if (this.expediteFee) {
      this.deliveryPrice = this.productDefinitionService.getProcessingFee(this.questionnaireService.llc.packageSelected) + this.expediteFee;
      this.priceBreakDown = `$${this.productDefinitionService.getProcessingFee(this.questionnaireService.llc.packageSelected)} processing fee + $${this.expediteFee} ${this.entityState} expedited fee`;
    }
  }

  acceptOffer(answer: boolean): void {
    this.offerAccepted = answer;
  }

  updateOrder(): void {
    this.activeModal.close(this.offerAccepted);
  }
}
