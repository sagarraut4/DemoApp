import { ProductDefinitionService } from './../../../../shared/services/product-definition/product-definition.service';
import { QuestionnaireService } from './../../../../shared/services/questionnaire/questionnaire.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DeliveryModalComponent } from './delivery-modal.component';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder } from '@angular/forms';

describe('DeliveryModalComponent', () => {
  let component: DeliveryModalComponent;
  let fixture: ComponentFixture<DeliveryModalComponent>;
  let mockNgbActiveModal;
  const mockQuestionniareService = {
    llc: {
      isChooseEntityNameLater: true
    }
  };
  const mockProductDefinitionService: ProductDefinitionService = undefined;
  const formBuilder: FormBuilder = new FormBuilder();
  beforeEach(async(() => {
    mockNgbActiveModal = jasmine.createSpyObj(['close']);
    TestBed.configureTestingModule({
      declarations: [DeliveryModalComponent],
      providers: [
        { provide: NgbActiveModal, useValue: mockNgbActiveModal },
        { provide: QuestionnaireService, useValue: mockQuestionniareService },
        { provide: ProductDefinitionService, useValue: mockProductDefinitionService },
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeliveryModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create delivery-modal component', () => {
    expect(component).toBeTruthy();
  });

  it('on click review component yes it should save', () => {
    const reviewCompYes = fixture.debugElement.nativeElement.querySelector('#review_compliance_package_yes');
    reviewCompYes.click();
    expect(component.offerAccepted).toBe(true);
  });

  it('on click review component none it should save', () => {
    const reviewCompNone = fixture.debugElement.nativeElement.querySelector('#review_compliance_package_none');
    reviewCompNone.click();
    expect(component.offerAccepted).toBe(false);
  });

  it('should update order on update order button click', () => {
    const updateOrderBtn = fixture.debugElement.nativeElement.querySelector('.btn-update');
    updateOrderBtn.click();
    expect(mockNgbActiveModal.close).toHaveBeenCalled();
  });
});
