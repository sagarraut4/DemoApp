import { SEADService } from '../../../../shared/services/tracking/sead.service';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { FormsModule, ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CompanyDetailsModalComponent } from './company-details-modal.component';
import { NgbModule, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

describe('CompanyDetailsModalComponent', () => {
  let component: CompanyDetailsModalComponent;
  let fixture: ComponentFixture<CompanyDetailsModalComponent>;
  let mockNgbActiveModal;
  const mockQuestionniareService = {
    llc: {
      isChooseEntityNameLater: true
    }
  };
  let mockSeadService;
  const formBuilder: FormBuilder = new FormBuilder();
  beforeEach(async(() => {
    mockNgbActiveModal = jasmine.createSpyObj(['close', 'dismiss']);
    mockSeadService = jasmine.createSpyObj(['PushToTealium']);
    mockSeadService.TrackingObject = {
      business_name: '',
      business_activity: ''
    };
    TestBed.configureTestingModule({
      declarations: [CompanyDetailsModalComponent],
      imports: [FormsModule, ReactiveFormsModule, NgbModule],
      providers: [
        { provide: NgbActiveModal, useValue: mockNgbActiveModal },
        { provide: QuestionnaireService, useValue: mockQuestionniareService },
        { provide: SEADService, useValue: mockSeadService },
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompanyDetailsModalComponent);
    component = fixture.componentInstance;
    component.form = formBuilder.group({
      entityName: ['name'],
      hireEmployees: [true],
      businessPurpose: ['test'],
    });
    fixture.detectChanges();
  });

  it('should create company-details-modal component', () => {
    expect(component).toBeTruthy();
  });

  it('should mockSeadService.PushToTealium on update order', () => {
    component.form.controls.entityName.setValue('name');
    component.form.controls.entityName.markAsTouched();
    component.form.controls.entityName.markAsDirty();

    component.form.controls.hireEmployees.setValue(true);
    component.form.controls.hireEmployees.markAsTouched();
    component.form.controls.hireEmployees.markAsDirty();

    component.form.controls.businessPurpose.setValue('test');
    component.form.controls.businessPurpose.markAsTouched();
    component.form.controls.businessPurpose.markAsDirty();

    component.updateOrder();
    expect(mockSeadService.PushToTealium).toHaveBeenCalled();
    expect(mockNgbActiveModal.close).toHaveBeenCalled();
  });

  it('should show validation on update order if field is invalid', () => {
    component.form.controls.entityName.setValue('name');
    component.form.controls.entityName.markAsTouched();
    component.form.controls.entityName.markAsDirty();

    component.form.controls.hireEmployees.setValue(true);
    component.form.controls.hireEmployees.markAsTouched();
    component.form.controls.hireEmployees.markAsDirty();

    component.form.controls.businessPurpose.setValue('');
    component.form.controls.businessPurpose.markAsTouched();
    component.form.controls.businessPurpose.markAsDirty();

    component.updateOrder();
    expect(mockSeadService.PushToTealium).not.toHaveBeenCalled();
    expect(mockNgbActiveModal.close).not.toHaveBeenCalled();
    expect(component.form.invalid).toBe(true);
    expect(fixture.debugElement.nativeElement.querySelector('.invalid-feedback')).toBeDefined();
  });

  it('should call update order method of component on Update Order button click', () => {
    spyOn(component, 'updateOrder');
    const updateOrderBtn = fixture.debugElement.nativeElement.querySelector('#btn-update');
    updateOrderBtn.click();
    expect(component.updateOrder).toHaveBeenCalled();
  });

  it('should call activeModal.dismiss on Cancel button click', () => {
    const updateOrderBtn = fixture.debugElement.nativeElement.querySelector('#btn-cancel');
    updateOrderBtn.click();
    expect(mockNgbActiveModal.dismiss).toHaveBeenCalled();
  });
});
