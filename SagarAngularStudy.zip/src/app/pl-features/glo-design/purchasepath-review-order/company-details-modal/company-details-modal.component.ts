import { Component, OnInit, ChangeDetectionStrategy, HostBinding, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { QuestionnaireService } from '../../../../shared/services/questionnaire/questionnaire.service';
import { LLC } from '../../../../shared/models/questionnaire-model';
import { SEADService } from '../../../../shared/services/tracking/sead.service';
import { TrackingService } from '../../../../shared/services/tracking/tracking.service';

@Component({
  selector: 'app-company-details-modal',
  templateUrl: './company-details-modal.component.html',
  styleUrls: ['./company-details-modal.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})

export class CompanyDetailsModalComponent implements OnInit {
  @Input() modalDataset: LLC = new LLC();
  form: FormGroup;
  submitted: boolean;

  // add required class to sort modal-content height
  @HostBinding('class.modal-content') true: boolean;
  constructor(
    public activeModal: NgbActiveModal,
    private questionnaireService: QuestionnaireService,
    private formBuilder: FormBuilder,
    private seadService: SEADService,
    private trackingService: TrackingService
  ) {
    this.submitted = false;
  }

  ngOnInit() {
    this.form = this.formBuilder.group({
      entityName: new FormControl(this.modalDataset.entityName, Validators.required),
      hireEmployees: new FormControl(this.modalDataset.hireEmployees, Validators.required),
      businessPurpose: new FormControl(this.modalDataset.businessPurpose, Validators.required),
    });

    if (this.questionnaireService.llc.isChooseEntityNameLater && !this.modalDataset.entityName) {
      this.form.controls.entityName.clearValidators();
      this.form.controls.entityName.updateValueAndValidity();
    }
  }

  updateOrder() {
    this.submitted = true;

    if (this.form.invalid) {
      return;
    }
    this.trackingService.triggerClickTrack('llc_flow','edit_modal_update_order');
    this.trackingService.triggerClickTrack('llc_flow','edit_company_detail_update');
    this.modalDataset = new LLC();
    this.modalDataset.entityName = this.form.get('entityName').value;
    this.modalDataset.hireEmployees = this.form.get('hireEmployees').value;
    this.modalDataset.businessPurpose = this.form.get('businessPurpose').value;
    // Update SEAD with the new values
    this.seadService.TrackingObject.business_name = this.modalDataset.entityName;
    this.seadService.TrackingObject.business_activity = this.modalDataset.businessPurpose;
    this.seadService.PushToTealium();
    this.activeModal.close(this.modalDataset);

  }

  cancel() {
    this.trackingService.triggerClickTrack('llc_flow','edit_modal_cancel');
    this.trackingService.triggerClickTrack('llc_flow','edit_company_detail_cancel');
    this.activeModal.dismiss('cancel');
  }

  updateTracking(value:string){
    if(value == 'yes'){
      this.trackingService.triggerClickTrack('llc_flow','edit_company_detail_yes');
    }
    else{
      this.trackingService.triggerClickTrack('llc_flow','edit_company_detail_no');
    }
  }

}
